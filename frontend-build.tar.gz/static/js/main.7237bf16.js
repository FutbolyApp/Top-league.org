/*! For license information please see main.7237bf16.js.LICENSE.txt */
(()=>{var e={43:(e,r,t)=>{"use strict";e.exports=t(202)},153:(e,r,t)=>{"use strict";var i=t(43),n=Symbol.for("react.element"),o=Symbol.for("react.fragment"),a=Object.prototype.hasOwnProperty,s=i.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,l={key:!0,ref:!0,__self:!0,__source:!0};function d(e,r,t){var i,o={},d=null,c=null;for(i in void 0!==t&&(d=""+t),void 0!==r.key&&(d=""+r.key),void 0!==r.ref&&(c=r.ref),r)a.call(r,i)&&!l.hasOwnProperty(i)&&(o[i]=r[i]);if(e&&e.defaultProps)for(i in r=e.defaultProps)void 0===o[i]&&(o[i]=r[i]);return{$$typeof:n,type:e,key:d,ref:c,props:o,_owner:s.current}}r.Fragment=o,r.jsx=d,r.jsxs=d},202:(e,r)=>{"use strict";var t=Symbol.for("react.element"),i=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),o=Symbol.for("react.strict_mode"),a=Symbol.for("react.profiler"),s=Symbol.for("react.provider"),l=Symbol.for("react.context"),d=Symbol.for("react.forward_ref"),c=Symbol.for("react.suspense"),u=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),p=Symbol.iterator;var h={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},m=Object.assign,f={};function x(e,r,t){this.props=e,this.context=r,this.refs=f,this.updater=t||h}function v(){}function b(e,r,t){this.props=e,this.context=r,this.refs=f,this.updater=t||h}x.prototype.isReactComponent={},x.prototype.setState=function(e,r){if("object"!==typeof e&&"function"!==typeof e&&null!=e)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,r,"setState")},x.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")},v.prototype=x.prototype;var j=b.prototype=new v;j.constructor=b,m(j,x.prototype),j.isPureReactComponent=!0;var y=Array.isArray,w=Object.prototype.hasOwnProperty,k={current:null},_={key:!0,ref:!0,__self:!0,__source:!0};function S(e,r,i){var n,o={},a=null,s=null;if(null!=r)for(n in void 0!==r.ref&&(s=r.ref),void 0!==r.key&&(a=""+r.key),r)w.call(r,n)&&!_.hasOwnProperty(n)&&(o[n]=r[n]);var l=arguments.length-2;if(1===l)o.children=i;else if(1<l){for(var d=Array(l),c=0;c<l;c++)d[c]=arguments[c+2];o.children=d}if(e&&e.defaultProps)for(n in l=e.defaultProps)void 0===o[n]&&(o[n]=l[n]);return{$$typeof:t,type:e,key:a,ref:s,props:o,_owner:k.current}}function C(e){return"object"===typeof e&&null!==e&&e.$$typeof===t}var z=/\/+/g;function E(e,r){return"object"===typeof e&&null!==e&&null!=e.key?function(e){var r={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(e){return r[e]})}(""+e.key):r.toString(36)}function A(e,r,n,o,a){var s=typeof e;"undefined"!==s&&"boolean"!==s||(e=null);var l=!1;if(null===e)l=!0;else switch(s){case"string":case"number":l=!0;break;case"object":switch(e.$$typeof){case t:case i:l=!0}}if(l)return a=a(l=e),e=""===o?"."+E(l,0):o,y(a)?(n="",null!=e&&(n=e.replace(z,"$&/")+"/"),A(a,r,n,"",function(e){return e})):null!=a&&(C(a)&&(a=function(e,r){return{$$typeof:t,type:e.type,key:r,ref:e.ref,props:e.props,_owner:e._owner}}(a,n+(!a.key||l&&l.key===a.key?"":(""+a.key).replace(z,"$&/")+"/")+e)),r.push(a)),1;if(l=0,o=""===o?".":o+":",y(e))for(var d=0;d<e.length;d++){var c=o+E(s=e[d],d);l+=A(s,r,n,c,a)}else if(c=function(e){return null===e||"object"!==typeof e?null:"function"===typeof(e=p&&e[p]||e["@@iterator"])?e:null}(e),"function"===typeof c)for(e=c.call(e),d=0;!(s=e.next()).done;)l+=A(s=s.value,r,n,c=o+E(s,d++),a);else if("object"===s)throw r=String(e),Error("Objects are not valid as a React child (found: "+("[object Object]"===r?"object with keys {"+Object.keys(e).join(", ")+"}":r)+"). If you meant to render a collection of children, use an array instead.");return l}function R(e,r,t){if(null==e)return e;var i=[],n=0;return A(e,i,"","",function(e){return r.call(t,e,n++)}),i}function N(e){if(-1===e._status){var r=e._result;(r=r()).then(function(r){0!==e._status&&-1!==e._status||(e._status=1,e._result=r)},function(r){0!==e._status&&-1!==e._status||(e._status=2,e._result=r)}),-1===e._status&&(e._status=0,e._result=r)}if(1===e._status)return e._result.default;throw e._result}var T={current:null},q={transition:null},P={ReactCurrentDispatcher:T,ReactCurrentBatchConfig:q,ReactCurrentOwner:k};function $(){throw Error("act(...) is not supported in production builds of React.")}r.Children={map:R,forEach:function(e,r,t){R(e,function(){r.apply(this,arguments)},t)},count:function(e){var r=0;return R(e,function(){r++}),r},toArray:function(e){return R(e,function(e){return e})||[]},only:function(e){if(!C(e))throw Error("React.Children.only expected to receive a single React element child.");return e}},r.Component=x,r.Fragment=n,r.Profiler=a,r.PureComponent=b,r.StrictMode=o,r.Suspense=c,r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=P,r.act=$,r.cloneElement=function(e,r,i){if(null===e||void 0===e)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var n=m({},e.props),o=e.key,a=e.ref,s=e._owner;if(null!=r){if(void 0!==r.ref&&(a=r.ref,s=k.current),void 0!==r.key&&(o=""+r.key),e.type&&e.type.defaultProps)var l=e.type.defaultProps;for(d in r)w.call(r,d)&&!_.hasOwnProperty(d)&&(n[d]=void 0===r[d]&&void 0!==l?l[d]:r[d])}var d=arguments.length-2;if(1===d)n.children=i;else if(1<d){l=Array(d);for(var c=0;c<d;c++)l[c]=arguments[c+2];n.children=l}return{$$typeof:t,type:e.type,key:o,ref:a,props:n,_owner:s}},r.createContext=function(e){return(e={$$typeof:l,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null}).Provider={$$typeof:s,_context:e},e.Consumer=e},r.createElement=S,r.createFactory=function(e){var r=S.bind(null,e);return r.type=e,r},r.createRef=function(){return{current:null}},r.forwardRef=function(e){return{$$typeof:d,render:e}},r.isValidElement=C,r.lazy=function(e){return{$$typeof:g,_payload:{_status:-1,_result:e},_init:N}},r.memo=function(e,r){return{$$typeof:u,type:e,compare:void 0===r?null:r}},r.startTransition=function(e){var r=q.transition;q.transition={};try{e()}finally{q.transition=r}},r.unstable_act=$,r.useCallback=function(e,r){return T.current.useCallback(e,r)},r.useContext=function(e){return T.current.useContext(e)},r.useDebugValue=function(){},r.useDeferredValue=function(e){return T.current.useDeferredValue(e)},r.useEffect=function(e,r){return T.current.useEffect(e,r)},r.useId=function(){return T.current.useId()},r.useImperativeHandle=function(e,r,t){return T.current.useImperativeHandle(e,r,t)},r.useInsertionEffect=function(e,r){return T.current.useInsertionEffect(e,r)},r.useLayoutEffect=function(e,r){return T.current.useLayoutEffect(e,r)},r.useMemo=function(e,r){return T.current.useMemo(e,r)},r.useReducer=function(e,r,t){return T.current.useReducer(e,r,t)},r.useRef=function(e){return T.current.useRef(e)},r.useState=function(e){return T.current.useState(e)},r.useSyncExternalStore=function(e,r,t){return T.current.useSyncExternalStore(e,r,t)},r.useTransition=function(){return T.current.useTransition()},r.version="18.3.1"},219:(e,r,t)=>{"use strict";var i=t(763),n={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},o={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},a={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},s={};function l(e){return i.isMemo(e)?a:s[e.$$typeof]||n}s[i.ForwardRef]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},s[i.Memo]=a;var d=Object.defineProperty,c=Object.getOwnPropertyNames,u=Object.getOwnPropertySymbols,g=Object.getOwnPropertyDescriptor,p=Object.getPrototypeOf,h=Object.prototype;e.exports=function e(r,t,i){if("string"!==typeof t){if(h){var n=p(t);n&&n!==h&&e(r,n,i)}var a=c(t);u&&(a=a.concat(u(t)));for(var s=l(r),m=l(t),f=0;f<a.length;++f){var x=a[f];if(!o[x]&&(!i||!i[x])&&(!m||!m[x])&&(!s||!s[x])){var v=g(t,x);try{d(r,x,v)}catch(b){}}}}return r}},234:(e,r)=>{"use strict";function t(e,r){var t=e.length;e.push(r);e:for(;0<t;){var i=t-1>>>1,n=e[i];if(!(0<o(n,r)))break e;e[i]=r,e[t]=n,t=i}}function i(e){return 0===e.length?null:e[0]}function n(e){if(0===e.length)return null;var r=e[0],t=e.pop();if(t!==r){e[0]=t;e:for(var i=0,n=e.length,a=n>>>1;i<a;){var s=2*(i+1)-1,l=e[s],d=s+1,c=e[d];if(0>o(l,t))d<n&&0>o(c,l)?(e[i]=c,e[d]=t,i=d):(e[i]=l,e[s]=t,i=s);else{if(!(d<n&&0>o(c,t)))break e;e[i]=c,e[d]=t,i=d}}}return r}function o(e,r){var t=e.sortIndex-r.sortIndex;return 0!==t?t:e.id-r.id}if("object"===typeof performance&&"function"===typeof performance.now){var a=performance;r.unstable_now=function(){return a.now()}}else{var s=Date,l=s.now();r.unstable_now=function(){return s.now()-l}}var d=[],c=[],u=1,g=null,p=3,h=!1,m=!1,f=!1,x="function"===typeof setTimeout?setTimeout:null,v="function"===typeof clearTimeout?clearTimeout:null,b="undefined"!==typeof setImmediate?setImmediate:null;function j(e){for(var r=i(c);null!==r;){if(null===r.callback)n(c);else{if(!(r.startTime<=e))break;n(c),r.sortIndex=r.expirationTime,t(d,r)}r=i(c)}}function y(e){if(f=!1,j(e),!m)if(null!==i(d))m=!0,q(w);else{var r=i(c);null!==r&&P(y,r.startTime-e)}}function w(e,t){m=!1,f&&(f=!1,v(C),C=-1),h=!0;var o=p;try{for(j(t),g=i(d);null!==g&&(!(g.expirationTime>t)||e&&!A());){var a=g.callback;if("function"===typeof a){g.callback=null,p=g.priorityLevel;var s=a(g.expirationTime<=t);t=r.unstable_now(),"function"===typeof s?g.callback=s:g===i(d)&&n(d),j(t)}else n(d);g=i(d)}if(null!==g)var l=!0;else{var u=i(c);null!==u&&P(y,u.startTime-t),l=!1}return l}finally{g=null,p=o,h=!1}}"undefined"!==typeof navigator&&void 0!==navigator.scheduling&&void 0!==navigator.scheduling.isInputPending&&navigator.scheduling.isInputPending.bind(navigator.scheduling);var k,_=!1,S=null,C=-1,z=5,E=-1;function A(){return!(r.unstable_now()-E<z)}function R(){if(null!==S){var e=r.unstable_now();E=e;var t=!0;try{t=S(!0,e)}finally{t?k():(_=!1,S=null)}}else _=!1}if("function"===typeof b)k=function(){b(R)};else if("undefined"!==typeof MessageChannel){var N=new MessageChannel,T=N.port2;N.port1.onmessage=R,k=function(){T.postMessage(null)}}else k=function(){x(R,0)};function q(e){S=e,_||(_=!0,k())}function P(e,t){C=x(function(){e(r.unstable_now())},t)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(e){e.callback=null},r.unstable_continueExecution=function(){m||h||(m=!0,q(w))},r.unstable_forceFrameRate=function(e){0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):z=0<e?Math.floor(1e3/e):5},r.unstable_getCurrentPriorityLevel=function(){return p},r.unstable_getFirstCallbackNode=function(){return i(d)},r.unstable_next=function(e){switch(p){case 1:case 2:case 3:var r=3;break;default:r=p}var t=p;p=r;try{return e()}finally{p=t}},r.unstable_pauseExecution=function(){},r.unstable_requestPaint=function(){},r.unstable_runWithPriority=function(e,r){switch(e){case 1:case 2:case 3:case 4:case 5:break;default:e=3}var t=p;p=e;try{return r()}finally{p=t}},r.unstable_scheduleCallback=function(e,n,o){var a=r.unstable_now();switch("object"===typeof o&&null!==o?o="number"===typeof(o=o.delay)&&0<o?a+o:a:o=a,e){case 1:var s=-1;break;case 2:s=250;break;case 5:s=1073741823;break;case 4:s=1e4;break;default:s=5e3}return e={id:u++,callback:n,priorityLevel:e,startTime:o,expirationTime:s=o+s,sortIndex:-1},o>a?(e.sortIndex=o,t(c,e),null===i(d)&&e===i(c)&&(f?(v(C),C=-1):f=!0,P(y,o-a))):(e.sortIndex=s,t(d,e),m||h||(m=!0,q(w))),e},r.unstable_shouldYield=A,r.unstable_wrapCallback=function(e){var r=p;return function(){var t=p;p=r;try{return e.apply(this,arguments)}finally{p=t}}}},324:e=>{e.exports=function(e,r,t,i){var n=t?t.call(i,e,r):void 0;if(void 0!==n)return!!n;if(e===r)return!0;if("object"!==typeof e||!e||"object"!==typeof r||!r)return!1;var o=Object.keys(e),a=Object.keys(r);if(o.length!==a.length)return!1;for(var s=Object.prototype.hasOwnProperty.bind(r),l=0;l<o.length;l++){var d=o[l];if(!s(d))return!1;var c=e[d],u=r[d];if(!1===(n=t?t.call(i,c,u,d):void 0)||void 0===n&&c!==u)return!1}return!0}},391:(e,r,t)=>{"use strict";var i=t(950);r.createRoot=i.createRoot,r.hydrateRoot=i.hydrateRoot},528:(e,r)=>{"use strict";var t=Symbol.for("react.transitional.element"),i=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),o=Symbol.for("react.strict_mode"),a=Symbol.for("react.profiler");Symbol.for("react.provider");var s=Symbol.for("react.consumer"),l=Symbol.for("react.context"),d=Symbol.for("react.forward_ref"),c=Symbol.for("react.suspense"),u=Symbol.for("react.suspense_list"),g=Symbol.for("react.memo"),p=Symbol.for("react.lazy"),h=Symbol.for("react.view_transition"),m=Symbol.for("react.client.reference");function f(e){if("object"===typeof e&&null!==e){var r=e.$$typeof;switch(r){case t:switch(e=e.type){case n:case a:case o:case c:case u:case h:return e;default:switch(e=e&&e.$$typeof){case l:case d:case p:case g:case s:return e;default:return r}}case i:return r}}}r.Hy=function(e){return"string"===typeof e||"function"===typeof e||e===n||e===a||e===o||e===c||e===u||"object"===typeof e&&null!==e&&(e.$$typeof===p||e.$$typeof===g||e.$$typeof===l||e.$$typeof===s||e.$$typeof===d||e.$$typeof===m||void 0!==e.getModuleId)},r.QP=f},579:(e,r,t)=>{"use strict";e.exports=t(153)},730:(e,r,t)=>{"use strict";var i=t(43),n=t(853);function o(e){for(var r="https://reactjs.org/docs/error-decoder.html?invariant="+e,t=1;t<arguments.length;t++)r+="&args[]="+encodeURIComponent(arguments[t]);return"Minified React error #"+e+"; visit "+r+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var a=new Set,s={};function l(e,r){d(e,r),d(e+"Capture",r)}function d(e,r){for(s[e]=r,e=0;e<r.length;e++)a.add(r[e])}var c=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),u=Object.prototype.hasOwnProperty,g=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,p={},h={};function m(e,r,t,i,n,o,a){this.acceptsBooleans=2===r||3===r||4===r,this.attributeName=i,this.attributeNamespace=n,this.mustUseProperty=t,this.propertyName=e,this.type=r,this.sanitizeURL=o,this.removeEmptyString=a}var f={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){f[e]=new m(e,0,!1,e,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var r=e[0];f[r]=new m(r,1,!1,e[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(e){f[e]=new m(e,2,!1,e.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){f[e]=new m(e,2,!1,e,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){f[e]=new m(e,3,!1,e.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(e){f[e]=new m(e,3,!0,e,null,!1,!1)}),["capture","download"].forEach(function(e){f[e]=new m(e,4,!1,e,null,!1,!1)}),["cols","rows","size","span"].forEach(function(e){f[e]=new m(e,6,!1,e,null,!1,!1)}),["rowSpan","start"].forEach(function(e){f[e]=new m(e,5,!1,e.toLowerCase(),null,!1,!1)});var x=/[\-:]([a-z])/g;function v(e){return e[1].toUpperCase()}function b(e,r,t,i){var n=f.hasOwnProperty(r)?f[r]:null;(null!==n?0!==n.type:i||!(2<r.length)||"o"!==r[0]&&"O"!==r[0]||"n"!==r[1]&&"N"!==r[1])&&(function(e,r,t,i){if(null===r||"undefined"===typeof r||function(e,r,t,i){if(null!==t&&0===t.type)return!1;switch(typeof r){case"function":case"symbol":return!0;case"boolean":return!i&&(null!==t?!t.acceptsBooleans:"data-"!==(e=e.toLowerCase().slice(0,5))&&"aria-"!==e);default:return!1}}(e,r,t,i))return!0;if(i)return!1;if(null!==t)switch(t.type){case 3:return!r;case 4:return!1===r;case 5:return isNaN(r);case 6:return isNaN(r)||1>r}return!1}(r,t,n,i)&&(t=null),i||null===n?function(e){return!!u.call(h,e)||!u.call(p,e)&&(g.test(e)?h[e]=!0:(p[e]=!0,!1))}(r)&&(null===t?e.removeAttribute(r):e.setAttribute(r,""+t)):n.mustUseProperty?e[n.propertyName]=null===t?3!==n.type&&"":t:(r=n.attributeName,i=n.attributeNamespace,null===t?e.removeAttribute(r):(t=3===(n=n.type)||4===n&&!0===t?"":""+t,i?e.setAttributeNS(i,r,t):e.setAttribute(r,t))))}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var r=e.replace(x,v);f[r]=new m(r,1,!1,e,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var r=e.replace(x,v);f[r]=new m(r,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(e){var r=e.replace(x,v);f[r]=new m(r,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(e){f[e]=new m(e,1,!1,e.toLowerCase(),null,!1,!1)}),f.xlinkHref=new m("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(e){f[e]=new m(e,1,!1,e.toLowerCase(),null,!0,!0)});var j=i.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,y=Symbol.for("react.element"),w=Symbol.for("react.portal"),k=Symbol.for("react.fragment"),_=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),C=Symbol.for("react.provider"),z=Symbol.for("react.context"),E=Symbol.for("react.forward_ref"),A=Symbol.for("react.suspense"),R=Symbol.for("react.suspense_list"),N=Symbol.for("react.memo"),T=Symbol.for("react.lazy");Symbol.for("react.scope"),Symbol.for("react.debug_trace_mode");var q=Symbol.for("react.offscreen");Symbol.for("react.legacy_hidden"),Symbol.for("react.cache"),Symbol.for("react.tracing_marker");var P=Symbol.iterator;function $(e){return null===e||"object"!==typeof e?null:"function"===typeof(e=P&&e[P]||e["@@iterator"])?e:null}var I,O=Object.assign;function L(e){if(void 0===I)try{throw Error()}catch(t){var r=t.stack.trim().match(/\n( *(at )?)/);I=r&&r[1]||""}return"\n"+I+e}var M=!1;function D(e,r){if(!e||M)return"";M=!0;var t=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(r)if(r=function(){throw Error()},Object.defineProperty(r.prototype,"props",{set:function(){throw Error()}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(r,[])}catch(d){var i=d}Reflect.construct(e,[],r)}else{try{r.call()}catch(d){i=d}e.call(r.prototype)}else{try{throw Error()}catch(d){i=d}e()}}catch(d){if(d&&i&&"string"===typeof d.stack){for(var n=d.stack.split("\n"),o=i.stack.split("\n"),a=n.length-1,s=o.length-1;1<=a&&0<=s&&n[a]!==o[s];)s--;for(;1<=a&&0<=s;a--,s--)if(n[a]!==o[s]){if(1!==a||1!==s)do{if(a--,0>--s||n[a]!==o[s]){var l="\n"+n[a].replace(" at new "," at ");return e.displayName&&l.includes("<anonymous>")&&(l=l.replace("<anonymous>",e.displayName)),l}}while(1<=a&&0<=s);break}}}finally{M=!1,Error.prepareStackTrace=t}return(e=e?e.displayName||e.name:"")?L(e):""}function F(e){switch(e.tag){case 5:return L(e.type);case 16:return L("Lazy");case 13:return L("Suspense");case 19:return L("SuspenseList");case 0:case 2:case 15:return e=D(e.type,!1);case 11:return e=D(e.type.render,!1);case 1:return e=D(e.type,!0);default:return""}}function U(e){if(null==e)return null;if("function"===typeof e)return e.displayName||e.name||null;if("string"===typeof e)return e;switch(e){case k:return"Fragment";case w:return"Portal";case S:return"Profiler";case _:return"StrictMode";case A:return"Suspense";case R:return"SuspenseList"}if("object"===typeof e)switch(e.$$typeof){case z:return(e.displayName||"Context")+".Consumer";case C:return(e._context.displayName||"Context")+".Provider";case E:var r=e.render;return(e=e.displayName)||(e=""!==(e=r.displayName||r.name||"")?"ForwardRef("+e+")":"ForwardRef"),e;case N:return null!==(r=e.displayName||null)?r:U(e.type)||"Memo";case T:r=e._payload,e=e._init;try{return U(e(r))}catch(t){}}return null}function B(e){var r=e.type;switch(e.tag){case 24:return"Cache";case 9:return(r.displayName||"Context")+".Consumer";case 10:return(r._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=(e=r.render).displayName||e.name||"",r.displayName||(""!==e?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return r;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return U(r);case 8:return r===_?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if("function"===typeof r)return r.displayName||r.name||null;if("string"===typeof r)return r}return null}function G(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":case"object":return e;default:return""}}function W(e){var r=e.type;return(e=e.nodeName)&&"input"===e.toLowerCase()&&("checkbox"===r||"radio"===r)}function H(e){e._valueTracker||(e._valueTracker=function(e){var r=W(e)?"checked":"value",t=Object.getOwnPropertyDescriptor(e.constructor.prototype,r),i=""+e[r];if(!e.hasOwnProperty(r)&&"undefined"!==typeof t&&"function"===typeof t.get&&"function"===typeof t.set){var n=t.get,o=t.set;return Object.defineProperty(e,r,{configurable:!0,get:function(){return n.call(this)},set:function(e){i=""+e,o.call(this,e)}}),Object.defineProperty(e,r,{enumerable:t.enumerable}),{getValue:function(){return i},setValue:function(e){i=""+e},stopTracking:function(){e._valueTracker=null,delete e[r]}}}}(e))}function V(e){if(!e)return!1;var r=e._valueTracker;if(!r)return!0;var t=r.getValue(),i="";return e&&(i=W(e)?e.checked?"true":"false":e.value),(e=i)!==t&&(r.setValue(e),!0)}function Q(e){if("undefined"===typeof(e=e||("undefined"!==typeof document?document:void 0)))return null;try{return e.activeElement||e.body}catch(r){return e.body}}function K(e,r){var t=r.checked;return O({},r,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=t?t:e._wrapperState.initialChecked})}function Y(e,r){var t=null==r.defaultValue?"":r.defaultValue,i=null!=r.checked?r.checked:r.defaultChecked;t=G(null!=r.value?r.value:t),e._wrapperState={initialChecked:i,initialValue:t,controlled:"checkbox"===r.type||"radio"===r.type?null!=r.checked:null!=r.value}}function J(e,r){null!=(r=r.checked)&&b(e,"checked",r,!1)}function Z(e,r){J(e,r);var t=G(r.value),i=r.type;if(null!=t)"number"===i?(0===t&&""===e.value||e.value!=t)&&(e.value=""+t):e.value!==""+t&&(e.value=""+t);else if("submit"===i||"reset"===i)return void e.removeAttribute("value");r.hasOwnProperty("value")?ee(e,r.type,t):r.hasOwnProperty("defaultValue")&&ee(e,r.type,G(r.defaultValue)),null==r.checked&&null!=r.defaultChecked&&(e.defaultChecked=!!r.defaultChecked)}function X(e,r,t){if(r.hasOwnProperty("value")||r.hasOwnProperty("defaultValue")){var i=r.type;if(!("submit"!==i&&"reset"!==i||void 0!==r.value&&null!==r.value))return;r=""+e._wrapperState.initialValue,t||r===e.value||(e.value=r),e.defaultValue=r}""!==(t=e.name)&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,""!==t&&(e.name=t)}function ee(e,r,t){"number"===r&&Q(e.ownerDocument)===e||(null==t?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+t&&(e.defaultValue=""+t))}var re=Array.isArray;function te(e,r,t,i){if(e=e.options,r){r={};for(var n=0;n<t.length;n++)r["$"+t[n]]=!0;for(t=0;t<e.length;t++)n=r.hasOwnProperty("$"+e[t].value),e[t].selected!==n&&(e[t].selected=n),n&&i&&(e[t].defaultSelected=!0)}else{for(t=""+G(t),r=null,n=0;n<e.length;n++){if(e[n].value===t)return e[n].selected=!0,void(i&&(e[n].defaultSelected=!0));null!==r||e[n].disabled||(r=e[n])}null!==r&&(r.selected=!0)}}function ie(e,r){if(null!=r.dangerouslySetInnerHTML)throw Error(o(91));return O({},r,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function ne(e,r){var t=r.value;if(null==t){if(t=r.children,r=r.defaultValue,null!=t){if(null!=r)throw Error(o(92));if(re(t)){if(1<t.length)throw Error(o(93));t=t[0]}r=t}null==r&&(r=""),t=r}e._wrapperState={initialValue:G(t)}}function oe(e,r){var t=G(r.value),i=G(r.defaultValue);null!=t&&((t=""+t)!==e.value&&(e.value=t),null==r.defaultValue&&e.defaultValue!==t&&(e.defaultValue=t)),null!=i&&(e.defaultValue=""+i)}function ae(e){var r=e.textContent;r===e._wrapperState.initialValue&&""!==r&&null!==r&&(e.value=r)}function se(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function le(e,r){return null==e||"http://www.w3.org/1999/xhtml"===e?se(r):"http://www.w3.org/2000/svg"===e&&"foreignObject"===r?"http://www.w3.org/1999/xhtml":e}var de,ce,ue=(ce=function(e,r){if("http://www.w3.org/2000/svg"!==e.namespaceURI||"innerHTML"in e)e.innerHTML=r;else{for((de=de||document.createElement("div")).innerHTML="<svg>"+r.valueOf().toString()+"</svg>",r=de.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;r.firstChild;)e.appendChild(r.firstChild)}},"undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(e,r,t,i){MSApp.execUnsafeLocalFunction(function(){return ce(e,r)})}:ce);function ge(e,r){if(r){var t=e.firstChild;if(t&&t===e.lastChild&&3===t.nodeType)return void(t.nodeValue=r)}e.textContent=r}var pe={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},he=["Webkit","ms","Moz","O"];function me(e,r,t){return null==r||"boolean"===typeof r||""===r?"":t||"number"!==typeof r||0===r||pe.hasOwnProperty(e)&&pe[e]?(""+r).trim():r+"px"}function fe(e,r){for(var t in e=e.style,r)if(r.hasOwnProperty(t)){var i=0===t.indexOf("--"),n=me(t,r[t],i);"float"===t&&(t="cssFloat"),i?e.setProperty(t,n):e[t]=n}}Object.keys(pe).forEach(function(e){he.forEach(function(r){r=r+e.charAt(0).toUpperCase()+e.substring(1),pe[r]=pe[e]})});var xe=O({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function ve(e,r){if(r){if(xe[e]&&(null!=r.children||null!=r.dangerouslySetInnerHTML))throw Error(o(137,e));if(null!=r.dangerouslySetInnerHTML){if(null!=r.children)throw Error(o(60));if("object"!==typeof r.dangerouslySetInnerHTML||!("__html"in r.dangerouslySetInnerHTML))throw Error(o(61))}if(null!=r.style&&"object"!==typeof r.style)throw Error(o(62))}}function be(e,r){if(-1===e.indexOf("-"))return"string"===typeof r.is;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var je=null;function ye(e){return(e=e.target||e.srcElement||window).correspondingUseElement&&(e=e.correspondingUseElement),3===e.nodeType?e.parentNode:e}var we=null,ke=null,_e=null;function Se(e){if(e=bn(e)){if("function"!==typeof we)throw Error(o(280));var r=e.stateNode;r&&(r=yn(r),we(e.stateNode,e.type,r))}}function Ce(e){ke?_e?_e.push(e):_e=[e]:ke=e}function ze(){if(ke){var e=ke,r=_e;if(_e=ke=null,Se(e),r)for(e=0;e<r.length;e++)Se(r[e])}}function Ee(e,r){return e(r)}function Ae(){}var Re=!1;function Ne(e,r,t){if(Re)return e(r,t);Re=!0;try{return Ee(e,r,t)}finally{Re=!1,(null!==ke||null!==_e)&&(Ae(),ze())}}function Te(e,r){var t=e.stateNode;if(null===t)return null;var i=yn(t);if(null===i)return null;t=i[r];e:switch(r){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(i=!i.disabled)||(i=!("button"===(e=e.type)||"input"===e||"select"===e||"textarea"===e)),e=!i;break e;default:e=!1}if(e)return null;if(t&&"function"!==typeof t)throw Error(o(231,r,typeof t));return t}var qe=!1;if(c)try{var Pe={};Object.defineProperty(Pe,"passive",{get:function(){qe=!0}}),window.addEventListener("test",Pe,Pe),window.removeEventListener("test",Pe,Pe)}catch(ce){qe=!1}function $e(e,r,t,i,n,o,a,s,l){var d=Array.prototype.slice.call(arguments,3);try{r.apply(t,d)}catch(c){this.onError(c)}}var Ie=!1,Oe=null,Le=!1,Me=null,De={onError:function(e){Ie=!0,Oe=e}};function Fe(e,r,t,i,n,o,a,s,l){Ie=!1,Oe=null,$e.apply(De,arguments)}function Ue(e){var r=e,t=e;if(e.alternate)for(;r.return;)r=r.return;else{e=r;do{0!==(4098&(r=e).flags)&&(t=r.return),e=r.return}while(e)}return 3===r.tag?t:null}function Be(e){if(13===e.tag){var r=e.memoizedState;if(null===r&&(null!==(e=e.alternate)&&(r=e.memoizedState)),null!==r)return r.dehydrated}return null}function Ge(e){if(Ue(e)!==e)throw Error(o(188))}function We(e){return null!==(e=function(e){var r=e.alternate;if(!r){if(null===(r=Ue(e)))throw Error(o(188));return r!==e?null:e}for(var t=e,i=r;;){var n=t.return;if(null===n)break;var a=n.alternate;if(null===a){if(null!==(i=n.return)){t=i;continue}break}if(n.child===a.child){for(a=n.child;a;){if(a===t)return Ge(n),e;if(a===i)return Ge(n),r;a=a.sibling}throw Error(o(188))}if(t.return!==i.return)t=n,i=a;else{for(var s=!1,l=n.child;l;){if(l===t){s=!0,t=n,i=a;break}if(l===i){s=!0,i=n,t=a;break}l=l.sibling}if(!s){for(l=a.child;l;){if(l===t){s=!0,t=a,i=n;break}if(l===i){s=!0,i=a,t=n;break}l=l.sibling}if(!s)throw Error(o(189))}}if(t.alternate!==i)throw Error(o(190))}if(3!==t.tag)throw Error(o(188));return t.stateNode.current===t?e:r}(e))?He(e):null}function He(e){if(5===e.tag||6===e.tag)return e;for(e=e.child;null!==e;){var r=He(e);if(null!==r)return r;e=e.sibling}return null}var Ve=n.unstable_scheduleCallback,Qe=n.unstable_cancelCallback,Ke=n.unstable_shouldYield,Ye=n.unstable_requestPaint,Je=n.unstable_now,Ze=n.unstable_getCurrentPriorityLevel,Xe=n.unstable_ImmediatePriority,er=n.unstable_UserBlockingPriority,rr=n.unstable_NormalPriority,tr=n.unstable_LowPriority,ir=n.unstable_IdlePriority,nr=null,or=null;var ar=Math.clz32?Math.clz32:function(e){return e>>>=0,0===e?32:31-(sr(e)/lr|0)|0},sr=Math.log,lr=Math.LN2;var dr=64,cr=4194304;function ur(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return 4194240&e;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return 130023424&e;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function gr(e,r){var t=e.pendingLanes;if(0===t)return 0;var i=0,n=e.suspendedLanes,o=e.pingedLanes,a=268435455&t;if(0!==a){var s=a&~n;0!==s?i=ur(s):0!==(o&=a)&&(i=ur(o))}else 0!==(a=t&~n)?i=ur(a):0!==o&&(i=ur(o));if(0===i)return 0;if(0!==r&&r!==i&&0===(r&n)&&((n=i&-i)>=(o=r&-r)||16===n&&0!==(4194240&o)))return r;if(0!==(4&i)&&(i|=16&t),0!==(r=e.entangledLanes))for(e=e.entanglements,r&=i;0<r;)n=1<<(t=31-ar(r)),i|=e[t],r&=~n;return i}function pr(e,r){switch(e){case 1:case 2:case 4:return r+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return r+5e3;default:return-1}}function hr(e){return 0!==(e=-1073741825&e.pendingLanes)?e:1073741824&e?1073741824:0}function mr(){var e=dr;return 0===(4194240&(dr<<=1))&&(dr=64),e}function fr(e){for(var r=[],t=0;31>t;t++)r.push(e);return r}function xr(e,r,t){e.pendingLanes|=r,536870912!==r&&(e.suspendedLanes=0,e.pingedLanes=0),(e=e.eventTimes)[r=31-ar(r)]=t}function vr(e,r){var t=e.entangledLanes|=r;for(e=e.entanglements;t;){var i=31-ar(t),n=1<<i;n&r|e[i]&r&&(e[i]|=r),t&=~n}}var br=0;function jr(e){return 1<(e&=-e)?4<e?0!==(268435455&e)?16:536870912:4:1}var yr,wr,kr,_r,Sr,Cr=!1,zr=[],Er=null,Ar=null,Rr=null,Nr=new Map,Tr=new Map,qr=[],Pr="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function $r(e,r){switch(e){case"focusin":case"focusout":Er=null;break;case"dragenter":case"dragleave":Ar=null;break;case"mouseover":case"mouseout":Rr=null;break;case"pointerover":case"pointerout":Nr.delete(r.pointerId);break;case"gotpointercapture":case"lostpointercapture":Tr.delete(r.pointerId)}}function Ir(e,r,t,i,n,o){return null===e||e.nativeEvent!==o?(e={blockedOn:r,domEventName:t,eventSystemFlags:i,nativeEvent:o,targetContainers:[n]},null!==r&&(null!==(r=bn(r))&&wr(r)),e):(e.eventSystemFlags|=i,r=e.targetContainers,null!==n&&-1===r.indexOf(n)&&r.push(n),e)}function Or(e){var r=vn(e.target);if(null!==r){var t=Ue(r);if(null!==t)if(13===(r=t.tag)){if(null!==(r=Be(t)))return e.blockedOn=r,void Sr(e.priority,function(){kr(t)})}else if(3===r&&t.stateNode.current.memoizedState.isDehydrated)return void(e.blockedOn=3===t.tag?t.stateNode.containerInfo:null)}e.blockedOn=null}function Lr(e){if(null!==e.blockedOn)return!1;for(var r=e.targetContainers;0<r.length;){var t=Kr(e.domEventName,e.eventSystemFlags,r[0],e.nativeEvent);if(null!==t)return null!==(r=bn(t))&&wr(r),e.blockedOn=t,!1;var i=new(t=e.nativeEvent).constructor(t.type,t);je=i,t.target.dispatchEvent(i),je=null,r.shift()}return!0}function Mr(e,r,t){Lr(e)&&t.delete(r)}function Dr(){Cr=!1,null!==Er&&Lr(Er)&&(Er=null),null!==Ar&&Lr(Ar)&&(Ar=null),null!==Rr&&Lr(Rr)&&(Rr=null),Nr.forEach(Mr),Tr.forEach(Mr)}function Fr(e,r){e.blockedOn===r&&(e.blockedOn=null,Cr||(Cr=!0,n.unstable_scheduleCallback(n.unstable_NormalPriority,Dr)))}function Ur(e){function r(r){return Fr(r,e)}if(0<zr.length){Fr(zr[0],e);for(var t=1;t<zr.length;t++){var i=zr[t];i.blockedOn===e&&(i.blockedOn=null)}}for(null!==Er&&Fr(Er,e),null!==Ar&&Fr(Ar,e),null!==Rr&&Fr(Rr,e),Nr.forEach(r),Tr.forEach(r),t=0;t<qr.length;t++)(i=qr[t]).blockedOn===e&&(i.blockedOn=null);for(;0<qr.length&&null===(t=qr[0]).blockedOn;)Or(t),null===t.blockedOn&&qr.shift()}var Br=j.ReactCurrentBatchConfig,Gr=!0;function Wr(e,r,t,i){var n=br,o=Br.transition;Br.transition=null;try{br=1,Vr(e,r,t,i)}finally{br=n,Br.transition=o}}function Hr(e,r,t,i){var n=br,o=Br.transition;Br.transition=null;try{br=4,Vr(e,r,t,i)}finally{br=n,Br.transition=o}}function Vr(e,r,t,i){if(Gr){var n=Kr(e,r,t,i);if(null===n)Bi(e,r,i,Qr,t),$r(e,i);else if(function(e,r,t,i,n){switch(r){case"focusin":return Er=Ir(Er,e,r,t,i,n),!0;case"dragenter":return Ar=Ir(Ar,e,r,t,i,n),!0;case"mouseover":return Rr=Ir(Rr,e,r,t,i,n),!0;case"pointerover":var o=n.pointerId;return Nr.set(o,Ir(Nr.get(o)||null,e,r,t,i,n)),!0;case"gotpointercapture":return o=n.pointerId,Tr.set(o,Ir(Tr.get(o)||null,e,r,t,i,n)),!0}return!1}(n,e,r,t,i))i.stopPropagation();else if($r(e,i),4&r&&-1<Pr.indexOf(e)){for(;null!==n;){var o=bn(n);if(null!==o&&yr(o),null===(o=Kr(e,r,t,i))&&Bi(e,r,i,Qr,t),o===n)break;n=o}null!==n&&i.stopPropagation()}else Bi(e,r,i,null,t)}}var Qr=null;function Kr(e,r,t,i){if(Qr=null,null!==(e=vn(e=ye(i))))if(null===(r=Ue(e)))e=null;else if(13===(t=r.tag)){if(null!==(e=Be(r)))return e;e=null}else if(3===t){if(r.stateNode.current.memoizedState.isDehydrated)return 3===r.tag?r.stateNode.containerInfo:null;e=null}else r!==e&&(e=null);return Qr=e,null}function Yr(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Ze()){case Xe:return 1;case er:return 4;case rr:case tr:return 16;case ir:return 536870912;default:return 16}default:return 16}}var Jr=null,Zr=null,Xr=null;function et(){if(Xr)return Xr;var e,r,t=Zr,i=t.length,n="value"in Jr?Jr.value:Jr.textContent,o=n.length;for(e=0;e<i&&t[e]===n[e];e++);var a=i-e;for(r=1;r<=a&&t[i-r]===n[o-r];r++);return Xr=n.slice(e,1<r?1-r:void 0)}function rt(e){var r=e.keyCode;return"charCode"in e?0===(e=e.charCode)&&13===r&&(e=13):e=r,10===e&&(e=13),32<=e||13===e?e:0}function tt(){return!0}function it(){return!1}function nt(e){function r(r,t,i,n,o){for(var a in this._reactName=r,this._targetInst=i,this.type=t,this.nativeEvent=n,this.target=o,this.currentTarget=null,e)e.hasOwnProperty(a)&&(r=e[a],this[a]=r?r(n):n[a]);return this.isDefaultPrevented=(null!=n.defaultPrevented?n.defaultPrevented:!1===n.returnValue)?tt:it,this.isPropagationStopped=it,this}return O(r.prototype,{preventDefault:function(){this.defaultPrevented=!0;var e=this.nativeEvent;e&&(e.preventDefault?e.preventDefault():"unknown"!==typeof e.returnValue&&(e.returnValue=!1),this.isDefaultPrevented=tt)},stopPropagation:function(){var e=this.nativeEvent;e&&(e.stopPropagation?e.stopPropagation():"unknown"!==typeof e.cancelBubble&&(e.cancelBubble=!0),this.isPropagationStopped=tt)},persist:function(){},isPersistent:tt}),r}var ot,at,st,lt={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},dt=nt(lt),ct=O({},lt,{view:0,detail:0}),ut=nt(ct),gt=O({},ct,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:_t,button:0,buttons:0,relatedTarget:function(e){return void 0===e.relatedTarget?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==st&&(st&&"mousemove"===e.type?(ot=e.screenX-st.screenX,at=e.screenY-st.screenY):at=ot=0,st=e),ot)},movementY:function(e){return"movementY"in e?e.movementY:at}}),pt=nt(gt),ht=nt(O({},gt,{dataTransfer:0})),mt=nt(O({},ct,{relatedTarget:0})),ft=nt(O({},lt,{animationName:0,elapsedTime:0,pseudoElement:0})),xt=O({},lt,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),vt=nt(xt),bt=nt(O({},lt,{data:0})),jt={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},yt={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},wt={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function kt(e){var r=this.nativeEvent;return r.getModifierState?r.getModifierState(e):!!(e=wt[e])&&!!r[e]}function _t(){return kt}var St=O({},ct,{key:function(e){if(e.key){var r=jt[e.key]||e.key;if("Unidentified"!==r)return r}return"keypress"===e.type?13===(e=rt(e))?"Enter":String.fromCharCode(e):"keydown"===e.type||"keyup"===e.type?yt[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:_t,charCode:function(e){return"keypress"===e.type?rt(e):0},keyCode:function(e){return"keydown"===e.type||"keyup"===e.type?e.keyCode:0},which:function(e){return"keypress"===e.type?rt(e):"keydown"===e.type||"keyup"===e.type?e.keyCode:0}}),Ct=nt(St),zt=nt(O({},gt,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0})),Et=nt(O({},ct,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:_t})),At=nt(O({},lt,{propertyName:0,elapsedTime:0,pseudoElement:0})),Rt=O({},gt,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Nt=nt(Rt),Tt=[9,13,27,32],qt=c&&"CompositionEvent"in window,Pt=null;c&&"documentMode"in document&&(Pt=document.documentMode);var $t=c&&"TextEvent"in window&&!Pt,It=c&&(!qt||Pt&&8<Pt&&11>=Pt),Ot=String.fromCharCode(32),Lt=!1;function Mt(e,r){switch(e){case"keyup":return-1!==Tt.indexOf(r.keyCode);case"keydown":return 229!==r.keyCode;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Dt(e){return"object"===typeof(e=e.detail)&&"data"in e?e.data:null}var Ft=!1;var Ut={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Bt(e){var r=e&&e.nodeName&&e.nodeName.toLowerCase();return"input"===r?!!Ut[e.type]:"textarea"===r}function Gt(e,r,t,i){Ce(i),0<(r=Wi(r,"onChange")).length&&(t=new dt("onChange","change",null,t,i),e.push({event:t,listeners:r}))}var Wt=null,Ht=null;function Vt(e){Oi(e,0)}function Qt(e){if(V(jn(e)))return e}function Kt(e,r){if("change"===e)return r}var Yt=!1;if(c){var Jt;if(c){var Zt="oninput"in document;if(!Zt){var Xt=document.createElement("div");Xt.setAttribute("oninput","return;"),Zt="function"===typeof Xt.oninput}Jt=Zt}else Jt=!1;Yt=Jt&&(!document.documentMode||9<document.documentMode)}function ei(){Wt&&(Wt.detachEvent("onpropertychange",ri),Ht=Wt=null)}function ri(e){if("value"===e.propertyName&&Qt(Ht)){var r=[];Gt(r,Ht,e,ye(e)),Ne(Vt,r)}}function ti(e,r,t){"focusin"===e?(ei(),Ht=t,(Wt=r).attachEvent("onpropertychange",ri)):"focusout"===e&&ei()}function ii(e){if("selectionchange"===e||"keyup"===e||"keydown"===e)return Qt(Ht)}function ni(e,r){if("click"===e)return Qt(r)}function oi(e,r){if("input"===e||"change"===e)return Qt(r)}var ai="function"===typeof Object.is?Object.is:function(e,r){return e===r&&(0!==e||1/e===1/r)||e!==e&&r!==r};function si(e,r){if(ai(e,r))return!0;if("object"!==typeof e||null===e||"object"!==typeof r||null===r)return!1;var t=Object.keys(e),i=Object.keys(r);if(t.length!==i.length)return!1;for(i=0;i<t.length;i++){var n=t[i];if(!u.call(r,n)||!ai(e[n],r[n]))return!1}return!0}function li(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function di(e,r){var t,i=li(e);for(e=0;i;){if(3===i.nodeType){if(t=e+i.textContent.length,e<=r&&t>=r)return{node:i,offset:r-e};e=t}e:{for(;i;){if(i.nextSibling){i=i.nextSibling;break e}i=i.parentNode}i=void 0}i=li(i)}}function ci(e,r){return!(!e||!r)&&(e===r||(!e||3!==e.nodeType)&&(r&&3===r.nodeType?ci(e,r.parentNode):"contains"in e?e.contains(r):!!e.compareDocumentPosition&&!!(16&e.compareDocumentPosition(r))))}function ui(){for(var e=window,r=Q();r instanceof e.HTMLIFrameElement;){try{var t="string"===typeof r.contentWindow.location.href}catch(i){t=!1}if(!t)break;r=Q((e=r.contentWindow).document)}return r}function gi(e){var r=e&&e.nodeName&&e.nodeName.toLowerCase();return r&&("input"===r&&("text"===e.type||"search"===e.type||"tel"===e.type||"url"===e.type||"password"===e.type)||"textarea"===r||"true"===e.contentEditable)}function pi(e){var r=ui(),t=e.focusedElem,i=e.selectionRange;if(r!==t&&t&&t.ownerDocument&&ci(t.ownerDocument.documentElement,t)){if(null!==i&&gi(t))if(r=i.start,void 0===(e=i.end)&&(e=r),"selectionStart"in t)t.selectionStart=r,t.selectionEnd=Math.min(e,t.value.length);else if((e=(r=t.ownerDocument||document)&&r.defaultView||window).getSelection){e=e.getSelection();var n=t.textContent.length,o=Math.min(i.start,n);i=void 0===i.end?o:Math.min(i.end,n),!e.extend&&o>i&&(n=i,i=o,o=n),n=di(t,o);var a=di(t,i);n&&a&&(1!==e.rangeCount||e.anchorNode!==n.node||e.anchorOffset!==n.offset||e.focusNode!==a.node||e.focusOffset!==a.offset)&&((r=r.createRange()).setStart(n.node,n.offset),e.removeAllRanges(),o>i?(e.addRange(r),e.extend(a.node,a.offset)):(r.setEnd(a.node,a.offset),e.addRange(r)))}for(r=[],e=t;e=e.parentNode;)1===e.nodeType&&r.push({element:e,left:e.scrollLeft,top:e.scrollTop});for("function"===typeof t.focus&&t.focus(),t=0;t<r.length;t++)(e=r[t]).element.scrollLeft=e.left,e.element.scrollTop=e.top}}var hi=c&&"documentMode"in document&&11>=document.documentMode,mi=null,fi=null,xi=null,vi=!1;function bi(e,r,t){var i=t.window===t?t.document:9===t.nodeType?t:t.ownerDocument;vi||null==mi||mi!==Q(i)||("selectionStart"in(i=mi)&&gi(i)?i={start:i.selectionStart,end:i.selectionEnd}:i={anchorNode:(i=(i.ownerDocument&&i.ownerDocument.defaultView||window).getSelection()).anchorNode,anchorOffset:i.anchorOffset,focusNode:i.focusNode,focusOffset:i.focusOffset},xi&&si(xi,i)||(xi=i,0<(i=Wi(fi,"onSelect")).length&&(r=new dt("onSelect","select",null,r,t),e.push({event:r,listeners:i}),r.target=mi)))}function ji(e,r){var t={};return t[e.toLowerCase()]=r.toLowerCase(),t["Webkit"+e]="webkit"+r,t["Moz"+e]="moz"+r,t}var yi={animationend:ji("Animation","AnimationEnd"),animationiteration:ji("Animation","AnimationIteration"),animationstart:ji("Animation","AnimationStart"),transitionend:ji("Transition","TransitionEnd")},wi={},ki={};function _i(e){if(wi[e])return wi[e];if(!yi[e])return e;var r,t=yi[e];for(r in t)if(t.hasOwnProperty(r)&&r in ki)return wi[e]=t[r];return e}c&&(ki=document.createElement("div").style,"AnimationEvent"in window||(delete yi.animationend.animation,delete yi.animationiteration.animation,delete yi.animationstart.animation),"TransitionEvent"in window||delete yi.transitionend.transition);var Si=_i("animationend"),Ci=_i("animationiteration"),zi=_i("animationstart"),Ei=_i("transitionend"),Ai=new Map,Ri="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Ni(e,r){Ai.set(e,r),l(r,[e])}for(var Ti=0;Ti<Ri.length;Ti++){var qi=Ri[Ti];Ni(qi.toLowerCase(),"on"+(qi[0].toUpperCase()+qi.slice(1)))}Ni(Si,"onAnimationEnd"),Ni(Ci,"onAnimationIteration"),Ni(zi,"onAnimationStart"),Ni("dblclick","onDoubleClick"),Ni("focusin","onFocus"),Ni("focusout","onBlur"),Ni(Ei,"onTransitionEnd"),d("onMouseEnter",["mouseout","mouseover"]),d("onMouseLeave",["mouseout","mouseover"]),d("onPointerEnter",["pointerout","pointerover"]),d("onPointerLeave",["pointerout","pointerover"]),l("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),l("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),l("onBeforeInput",["compositionend","keypress","textInput","paste"]),l("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),l("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Pi="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),$i=new Set("cancel close invalid load scroll toggle".split(" ").concat(Pi));function Ii(e,r,t){var i=e.type||"unknown-event";e.currentTarget=t,function(e,r,t,i,n,a,s,l,d){if(Fe.apply(this,arguments),Ie){if(!Ie)throw Error(o(198));var c=Oe;Ie=!1,Oe=null,Le||(Le=!0,Me=c)}}(i,r,void 0,e),e.currentTarget=null}function Oi(e,r){r=0!==(4&r);for(var t=0;t<e.length;t++){var i=e[t],n=i.event;i=i.listeners;e:{var o=void 0;if(r)for(var a=i.length-1;0<=a;a--){var s=i[a],l=s.instance,d=s.currentTarget;if(s=s.listener,l!==o&&n.isPropagationStopped())break e;Ii(n,s,d),o=l}else for(a=0;a<i.length;a++){if(l=(s=i[a]).instance,d=s.currentTarget,s=s.listener,l!==o&&n.isPropagationStopped())break e;Ii(n,s,d),o=l}}}if(Le)throw e=Me,Le=!1,Me=null,e}function Li(e,r){var t=r[mn];void 0===t&&(t=r[mn]=new Set);var i=e+"__bubble";t.has(i)||(Ui(r,e,2,!1),t.add(i))}function Mi(e,r,t){var i=0;r&&(i|=4),Ui(t,e,i,r)}var Di="_reactListening"+Math.random().toString(36).slice(2);function Fi(e){if(!e[Di]){e[Di]=!0,a.forEach(function(r){"selectionchange"!==r&&($i.has(r)||Mi(r,!1,e),Mi(r,!0,e))});var r=9===e.nodeType?e:e.ownerDocument;null===r||r[Di]||(r[Di]=!0,Mi("selectionchange",!1,r))}}function Ui(e,r,t,i){switch(Yr(r)){case 1:var n=Wr;break;case 4:n=Hr;break;default:n=Vr}t=n.bind(null,r,t,e),n=void 0,!qe||"touchstart"!==r&&"touchmove"!==r&&"wheel"!==r||(n=!0),i?void 0!==n?e.addEventListener(r,t,{capture:!0,passive:n}):e.addEventListener(r,t,!0):void 0!==n?e.addEventListener(r,t,{passive:n}):e.addEventListener(r,t,!1)}function Bi(e,r,t,i,n){var o=i;if(0===(1&r)&&0===(2&r)&&null!==i)e:for(;;){if(null===i)return;var a=i.tag;if(3===a||4===a){var s=i.stateNode.containerInfo;if(s===n||8===s.nodeType&&s.parentNode===n)break;if(4===a)for(a=i.return;null!==a;){var l=a.tag;if((3===l||4===l)&&((l=a.stateNode.containerInfo)===n||8===l.nodeType&&l.parentNode===n))return;a=a.return}for(;null!==s;){if(null===(a=vn(s)))return;if(5===(l=a.tag)||6===l){i=o=a;continue e}s=s.parentNode}}i=i.return}Ne(function(){var i=o,n=ye(t),a=[];e:{var s=Ai.get(e);if(void 0!==s){var l=dt,d=e;switch(e){case"keypress":if(0===rt(t))break e;case"keydown":case"keyup":l=Ct;break;case"focusin":d="focus",l=mt;break;case"focusout":d="blur",l=mt;break;case"beforeblur":case"afterblur":l=mt;break;case"click":if(2===t.button)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":l=pt;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":l=ht;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":l=Et;break;case Si:case Ci:case zi:l=ft;break;case Ei:l=At;break;case"scroll":l=ut;break;case"wheel":l=Nt;break;case"copy":case"cut":case"paste":l=vt;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":l=zt}var c=0!==(4&r),u=!c&&"scroll"===e,g=c?null!==s?s+"Capture":null:s;c=[];for(var p,h=i;null!==h;){var m=(p=h).stateNode;if(5===p.tag&&null!==m&&(p=m,null!==g&&(null!=(m=Te(h,g))&&c.push(Gi(h,m,p)))),u)break;h=h.return}0<c.length&&(s=new l(s,d,null,t,n),a.push({event:s,listeners:c}))}}if(0===(7&r)){if(l="mouseout"===e||"pointerout"===e,(!(s="mouseover"===e||"pointerover"===e)||t===je||!(d=t.relatedTarget||t.fromElement)||!vn(d)&&!d[hn])&&(l||s)&&(s=n.window===n?n:(s=n.ownerDocument)?s.defaultView||s.parentWindow:window,l?(l=i,null!==(d=(d=t.relatedTarget||t.toElement)?vn(d):null)&&(d!==(u=Ue(d))||5!==d.tag&&6!==d.tag)&&(d=null)):(l=null,d=i),l!==d)){if(c=pt,m="onMouseLeave",g="onMouseEnter",h="mouse","pointerout"!==e&&"pointerover"!==e||(c=zt,m="onPointerLeave",g="onPointerEnter",h="pointer"),u=null==l?s:jn(l),p=null==d?s:jn(d),(s=new c(m,h+"leave",l,t,n)).target=u,s.relatedTarget=p,m=null,vn(n)===i&&((c=new c(g,h+"enter",d,t,n)).target=p,c.relatedTarget=u,m=c),u=m,l&&d)e:{for(g=d,h=0,p=c=l;p;p=Hi(p))h++;for(p=0,m=g;m;m=Hi(m))p++;for(;0<h-p;)c=Hi(c),h--;for(;0<p-h;)g=Hi(g),p--;for(;h--;){if(c===g||null!==g&&c===g.alternate)break e;c=Hi(c),g=Hi(g)}c=null}else c=null;null!==l&&Vi(a,s,l,c,!1),null!==d&&null!==u&&Vi(a,u,d,c,!0)}if("select"===(l=(s=i?jn(i):window).nodeName&&s.nodeName.toLowerCase())||"input"===l&&"file"===s.type)var f=Kt;else if(Bt(s))if(Yt)f=oi;else{f=ii;var x=ti}else(l=s.nodeName)&&"input"===l.toLowerCase()&&("checkbox"===s.type||"radio"===s.type)&&(f=ni);switch(f&&(f=f(e,i))?Gt(a,f,t,n):(x&&x(e,s,i),"focusout"===e&&(x=s._wrapperState)&&x.controlled&&"number"===s.type&&ee(s,"number",s.value)),x=i?jn(i):window,e){case"focusin":(Bt(x)||"true"===x.contentEditable)&&(mi=x,fi=i,xi=null);break;case"focusout":xi=fi=mi=null;break;case"mousedown":vi=!0;break;case"contextmenu":case"mouseup":case"dragend":vi=!1,bi(a,t,n);break;case"selectionchange":if(hi)break;case"keydown":case"keyup":bi(a,t,n)}var v;if(qt)e:{switch(e){case"compositionstart":var b="onCompositionStart";break e;case"compositionend":b="onCompositionEnd";break e;case"compositionupdate":b="onCompositionUpdate";break e}b=void 0}else Ft?Mt(e,t)&&(b="onCompositionEnd"):"keydown"===e&&229===t.keyCode&&(b="onCompositionStart");b&&(It&&"ko"!==t.locale&&(Ft||"onCompositionStart"!==b?"onCompositionEnd"===b&&Ft&&(v=et()):(Zr="value"in(Jr=n)?Jr.value:Jr.textContent,Ft=!0)),0<(x=Wi(i,b)).length&&(b=new bt(b,e,null,t,n),a.push({event:b,listeners:x}),v?b.data=v:null!==(v=Dt(t))&&(b.data=v))),(v=$t?function(e,r){switch(e){case"compositionend":return Dt(r);case"keypress":return 32!==r.which?null:(Lt=!0,Ot);case"textInput":return(e=r.data)===Ot&&Lt?null:e;default:return null}}(e,t):function(e,r){if(Ft)return"compositionend"===e||!qt&&Mt(e,r)?(e=et(),Xr=Zr=Jr=null,Ft=!1,e):null;switch(e){case"paste":default:return null;case"keypress":if(!(r.ctrlKey||r.altKey||r.metaKey)||r.ctrlKey&&r.altKey){if(r.char&&1<r.char.length)return r.char;if(r.which)return String.fromCharCode(r.which)}return null;case"compositionend":return It&&"ko"!==r.locale?null:r.data}}(e,t))&&(0<(i=Wi(i,"onBeforeInput")).length&&(n=new bt("onBeforeInput","beforeinput",null,t,n),a.push({event:n,listeners:i}),n.data=v))}Oi(a,r)})}function Gi(e,r,t){return{instance:e,listener:r,currentTarget:t}}function Wi(e,r){for(var t=r+"Capture",i=[];null!==e;){var n=e,o=n.stateNode;5===n.tag&&null!==o&&(n=o,null!=(o=Te(e,t))&&i.unshift(Gi(e,o,n)),null!=(o=Te(e,r))&&i.push(Gi(e,o,n))),e=e.return}return i}function Hi(e){if(null===e)return null;do{e=e.return}while(e&&5!==e.tag);return e||null}function Vi(e,r,t,i,n){for(var o=r._reactName,a=[];null!==t&&t!==i;){var s=t,l=s.alternate,d=s.stateNode;if(null!==l&&l===i)break;5===s.tag&&null!==d&&(s=d,n?null!=(l=Te(t,o))&&a.unshift(Gi(t,l,s)):n||null!=(l=Te(t,o))&&a.push(Gi(t,l,s))),t=t.return}0!==a.length&&e.push({event:r,listeners:a})}var Qi=/\r\n?/g,Ki=/\u0000|\uFFFD/g;function Yi(e){return("string"===typeof e?e:""+e).replace(Qi,"\n").replace(Ki,"")}function Ji(e,r,t){if(r=Yi(r),Yi(e)!==r&&t)throw Error(o(425))}function Zi(){}var Xi=null,en=null;function rn(e,r){return"textarea"===e||"noscript"===e||"string"===typeof r.children||"number"===typeof r.children||"object"===typeof r.dangerouslySetInnerHTML&&null!==r.dangerouslySetInnerHTML&&null!=r.dangerouslySetInnerHTML.__html}var tn="function"===typeof setTimeout?setTimeout:void 0,nn="function"===typeof clearTimeout?clearTimeout:void 0,on="function"===typeof Promise?Promise:void 0,an="function"===typeof queueMicrotask?queueMicrotask:"undefined"!==typeof on?function(e){return on.resolve(null).then(e).catch(sn)}:tn;function sn(e){setTimeout(function(){throw e})}function ln(e,r){var t=r,i=0;do{var n=t.nextSibling;if(e.removeChild(t),n&&8===n.nodeType)if("/$"===(t=n.data)){if(0===i)return e.removeChild(n),void Ur(r);i--}else"$"!==t&&"$?"!==t&&"$!"!==t||i++;t=n}while(t);Ur(r)}function dn(e){for(;null!=e;e=e.nextSibling){var r=e.nodeType;if(1===r||3===r)break;if(8===r){if("$"===(r=e.data)||"$!"===r||"$?"===r)break;if("/$"===r)return null}}return e}function cn(e){e=e.previousSibling;for(var r=0;e;){if(8===e.nodeType){var t=e.data;if("$"===t||"$!"===t||"$?"===t){if(0===r)return e;r--}else"/$"===t&&r++}e=e.previousSibling}return null}var un=Math.random().toString(36).slice(2),gn="__reactFiber$"+un,pn="__reactProps$"+un,hn="__reactContainer$"+un,mn="__reactEvents$"+un,fn="__reactListeners$"+un,xn="__reactHandles$"+un;function vn(e){var r=e[gn];if(r)return r;for(var t=e.parentNode;t;){if(r=t[hn]||t[gn]){if(t=r.alternate,null!==r.child||null!==t&&null!==t.child)for(e=cn(e);null!==e;){if(t=e[gn])return t;e=cn(e)}return r}t=(e=t).parentNode}return null}function bn(e){return!(e=e[gn]||e[hn])||5!==e.tag&&6!==e.tag&&13!==e.tag&&3!==e.tag?null:e}function jn(e){if(5===e.tag||6===e.tag)return e.stateNode;throw Error(o(33))}function yn(e){return e[pn]||null}var wn=[],kn=-1;function _n(e){return{current:e}}function Sn(e){0>kn||(e.current=wn[kn],wn[kn]=null,kn--)}function Cn(e,r){kn++,wn[kn]=e.current,e.current=r}var zn={},En=_n(zn),An=_n(!1),Rn=zn;function Nn(e,r){var t=e.type.contextTypes;if(!t)return zn;var i=e.stateNode;if(i&&i.__reactInternalMemoizedUnmaskedChildContext===r)return i.__reactInternalMemoizedMaskedChildContext;var n,o={};for(n in t)o[n]=r[n];return i&&((e=e.stateNode).__reactInternalMemoizedUnmaskedChildContext=r,e.__reactInternalMemoizedMaskedChildContext=o),o}function Tn(e){return null!==(e=e.childContextTypes)&&void 0!==e}function qn(){Sn(An),Sn(En)}function Pn(e,r,t){if(En.current!==zn)throw Error(o(168));Cn(En,r),Cn(An,t)}function $n(e,r,t){var i=e.stateNode;if(r=r.childContextTypes,"function"!==typeof i.getChildContext)return t;for(var n in i=i.getChildContext())if(!(n in r))throw Error(o(108,B(e)||"Unknown",n));return O({},t,i)}function In(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||zn,Rn=En.current,Cn(En,e),Cn(An,An.current),!0}function On(e,r,t){var i=e.stateNode;if(!i)throw Error(o(169));t?(e=$n(e,r,Rn),i.__reactInternalMemoizedMergedChildContext=e,Sn(An),Sn(En),Cn(En,e)):Sn(An),Cn(An,t)}var Ln=null,Mn=!1,Dn=!1;function Fn(e){null===Ln?Ln=[e]:Ln.push(e)}function Un(){if(!Dn&&null!==Ln){Dn=!0;var e=0,r=br;try{var t=Ln;for(br=1;e<t.length;e++){var i=t[e];do{i=i(!0)}while(null!==i)}Ln=null,Mn=!1}catch(n){throw null!==Ln&&(Ln=Ln.slice(e+1)),Ve(Xe,Un),n}finally{br=r,Dn=!1}}return null}var Bn=[],Gn=0,Wn=null,Hn=0,Vn=[],Qn=0,Kn=null,Yn=1,Jn="";function Zn(e,r){Bn[Gn++]=Hn,Bn[Gn++]=Wn,Wn=e,Hn=r}function Xn(e,r,t){Vn[Qn++]=Yn,Vn[Qn++]=Jn,Vn[Qn++]=Kn,Kn=e;var i=Yn;e=Jn;var n=32-ar(i)-1;i&=~(1<<n),t+=1;var o=32-ar(r)+n;if(30<o){var a=n-n%5;o=(i&(1<<a)-1).toString(32),i>>=a,n-=a,Yn=1<<32-ar(r)+n|t<<n|i,Jn=o+e}else Yn=1<<o|t<<n|i,Jn=e}function eo(e){null!==e.return&&(Zn(e,1),Xn(e,1,0))}function ro(e){for(;e===Wn;)Wn=Bn[--Gn],Bn[Gn]=null,Hn=Bn[--Gn],Bn[Gn]=null;for(;e===Kn;)Kn=Vn[--Qn],Vn[Qn]=null,Jn=Vn[--Qn],Vn[Qn]=null,Yn=Vn[--Qn],Vn[Qn]=null}var to=null,io=null,no=!1,oo=null;function ao(e,r){var t=Nd(5,null,null,0);t.elementType="DELETED",t.stateNode=r,t.return=e,null===(r=e.deletions)?(e.deletions=[t],e.flags|=16):r.push(t)}function so(e,r){switch(e.tag){case 5:var t=e.type;return null!==(r=1!==r.nodeType||t.toLowerCase()!==r.nodeName.toLowerCase()?null:r)&&(e.stateNode=r,to=e,io=dn(r.firstChild),!0);case 6:return null!==(r=""===e.pendingProps||3!==r.nodeType?null:r)&&(e.stateNode=r,to=e,io=null,!0);case 13:return null!==(r=8!==r.nodeType?null:r)&&(t=null!==Kn?{id:Yn,overflow:Jn}:null,e.memoizedState={dehydrated:r,treeContext:t,retryLane:1073741824},(t=Nd(18,null,null,0)).stateNode=r,t.return=e,e.child=t,to=e,io=null,!0);default:return!1}}function lo(e){return 0!==(1&e.mode)&&0===(128&e.flags)}function co(e){if(no){var r=io;if(r){var t=r;if(!so(e,r)){if(lo(e))throw Error(o(418));r=dn(t.nextSibling);var i=to;r&&so(e,r)?ao(i,t):(e.flags=-4097&e.flags|2,no=!1,to=e)}}else{if(lo(e))throw Error(o(418));e.flags=-4097&e.flags|2,no=!1,to=e}}}function uo(e){for(e=e.return;null!==e&&5!==e.tag&&3!==e.tag&&13!==e.tag;)e=e.return;to=e}function go(e){if(e!==to)return!1;if(!no)return uo(e),no=!0,!1;var r;if((r=3!==e.tag)&&!(r=5!==e.tag)&&(r="head"!==(r=e.type)&&"body"!==r&&!rn(e.type,e.memoizedProps)),r&&(r=io)){if(lo(e))throw po(),Error(o(418));for(;r;)ao(e,r),r=dn(r.nextSibling)}if(uo(e),13===e.tag){if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))throw Error(o(317));e:{for(e=e.nextSibling,r=0;e;){if(8===e.nodeType){var t=e.data;if("/$"===t){if(0===r){io=dn(e.nextSibling);break e}r--}else"$"!==t&&"$!"!==t&&"$?"!==t||r++}e=e.nextSibling}io=null}}else io=to?dn(e.stateNode.nextSibling):null;return!0}function po(){for(var e=io;e;)e=dn(e.nextSibling)}function ho(){io=to=null,no=!1}function mo(e){null===oo?oo=[e]:oo.push(e)}var fo=j.ReactCurrentBatchConfig;function xo(e,r,t){if(null!==(e=t.ref)&&"function"!==typeof e&&"object"!==typeof e){if(t._owner){if(t=t._owner){if(1!==t.tag)throw Error(o(309));var i=t.stateNode}if(!i)throw Error(o(147,e));var n=i,a=""+e;return null!==r&&null!==r.ref&&"function"===typeof r.ref&&r.ref._stringRef===a?r.ref:(r=function(e){var r=n.refs;null===e?delete r[a]:r[a]=e},r._stringRef=a,r)}if("string"!==typeof e)throw Error(o(284));if(!t._owner)throw Error(o(290,e))}return e}function vo(e,r){throw e=Object.prototype.toString.call(r),Error(o(31,"[object Object]"===e?"object with keys {"+Object.keys(r).join(", ")+"}":e))}function bo(e){return(0,e._init)(e._payload)}function jo(e){function r(r,t){if(e){var i=r.deletions;null===i?(r.deletions=[t],r.flags|=16):i.push(t)}}function t(t,i){if(!e)return null;for(;null!==i;)r(t,i),i=i.sibling;return null}function i(e,r){for(e=new Map;null!==r;)null!==r.key?e.set(r.key,r):e.set(r.index,r),r=r.sibling;return e}function n(e,r){return(e=qd(e,r)).index=0,e.sibling=null,e}function a(r,t,i){return r.index=i,e?null!==(i=r.alternate)?(i=i.index)<t?(r.flags|=2,t):i:(r.flags|=2,t):(r.flags|=1048576,t)}function s(r){return e&&null===r.alternate&&(r.flags|=2),r}function l(e,r,t,i){return null===r||6!==r.tag?((r=Od(t,e.mode,i)).return=e,r):((r=n(r,t)).return=e,r)}function d(e,r,t,i){var o=t.type;return o===k?u(e,r,t.props.children,i,t.key):null!==r&&(r.elementType===o||"object"===typeof o&&null!==o&&o.$$typeof===T&&bo(o)===r.type)?((i=n(r,t.props)).ref=xo(e,r,t),i.return=e,i):((i=Pd(t.type,t.key,t.props,null,e.mode,i)).ref=xo(e,r,t),i.return=e,i)}function c(e,r,t,i){return null===r||4!==r.tag||r.stateNode.containerInfo!==t.containerInfo||r.stateNode.implementation!==t.implementation?((r=Ld(t,e.mode,i)).return=e,r):((r=n(r,t.children||[])).return=e,r)}function u(e,r,t,i,o){return null===r||7!==r.tag?((r=$d(t,e.mode,i,o)).return=e,r):((r=n(r,t)).return=e,r)}function g(e,r,t){if("string"===typeof r&&""!==r||"number"===typeof r)return(r=Od(""+r,e.mode,t)).return=e,r;if("object"===typeof r&&null!==r){switch(r.$$typeof){case y:return(t=Pd(r.type,r.key,r.props,null,e.mode,t)).ref=xo(e,null,r),t.return=e,t;case w:return(r=Ld(r,e.mode,t)).return=e,r;case T:return g(e,(0,r._init)(r._payload),t)}if(re(r)||$(r))return(r=$d(r,e.mode,t,null)).return=e,r;vo(e,r)}return null}function p(e,r,t,i){var n=null!==r?r.key:null;if("string"===typeof t&&""!==t||"number"===typeof t)return null!==n?null:l(e,r,""+t,i);if("object"===typeof t&&null!==t){switch(t.$$typeof){case y:return t.key===n?d(e,r,t,i):null;case w:return t.key===n?c(e,r,t,i):null;case T:return p(e,r,(n=t._init)(t._payload),i)}if(re(t)||$(t))return null!==n?null:u(e,r,t,i,null);vo(e,t)}return null}function h(e,r,t,i,n){if("string"===typeof i&&""!==i||"number"===typeof i)return l(r,e=e.get(t)||null,""+i,n);if("object"===typeof i&&null!==i){switch(i.$$typeof){case y:return d(r,e=e.get(null===i.key?t:i.key)||null,i,n);case w:return c(r,e=e.get(null===i.key?t:i.key)||null,i,n);case T:return h(e,r,t,(0,i._init)(i._payload),n)}if(re(i)||$(i))return u(r,e=e.get(t)||null,i,n,null);vo(r,i)}return null}function m(n,o,s,l){for(var d=null,c=null,u=o,m=o=0,f=null;null!==u&&m<s.length;m++){u.index>m?(f=u,u=null):f=u.sibling;var x=p(n,u,s[m],l);if(null===x){null===u&&(u=f);break}e&&u&&null===x.alternate&&r(n,u),o=a(x,o,m),null===c?d=x:c.sibling=x,c=x,u=f}if(m===s.length)return t(n,u),no&&Zn(n,m),d;if(null===u){for(;m<s.length;m++)null!==(u=g(n,s[m],l))&&(o=a(u,o,m),null===c?d=u:c.sibling=u,c=u);return no&&Zn(n,m),d}for(u=i(n,u);m<s.length;m++)null!==(f=h(u,n,m,s[m],l))&&(e&&null!==f.alternate&&u.delete(null===f.key?m:f.key),o=a(f,o,m),null===c?d=f:c.sibling=f,c=f);return e&&u.forEach(function(e){return r(n,e)}),no&&Zn(n,m),d}function f(n,s,l,d){var c=$(l);if("function"!==typeof c)throw Error(o(150));if(null==(l=c.call(l)))throw Error(o(151));for(var u=c=null,m=s,f=s=0,x=null,v=l.next();null!==m&&!v.done;f++,v=l.next()){m.index>f?(x=m,m=null):x=m.sibling;var b=p(n,m,v.value,d);if(null===b){null===m&&(m=x);break}e&&m&&null===b.alternate&&r(n,m),s=a(b,s,f),null===u?c=b:u.sibling=b,u=b,m=x}if(v.done)return t(n,m),no&&Zn(n,f),c;if(null===m){for(;!v.done;f++,v=l.next())null!==(v=g(n,v.value,d))&&(s=a(v,s,f),null===u?c=v:u.sibling=v,u=v);return no&&Zn(n,f),c}for(m=i(n,m);!v.done;f++,v=l.next())null!==(v=h(m,n,f,v.value,d))&&(e&&null!==v.alternate&&m.delete(null===v.key?f:v.key),s=a(v,s,f),null===u?c=v:u.sibling=v,u=v);return e&&m.forEach(function(e){return r(n,e)}),no&&Zn(n,f),c}return function e(i,o,a,l){if("object"===typeof a&&null!==a&&a.type===k&&null===a.key&&(a=a.props.children),"object"===typeof a&&null!==a){switch(a.$$typeof){case y:e:{for(var d=a.key,c=o;null!==c;){if(c.key===d){if((d=a.type)===k){if(7===c.tag){t(i,c.sibling),(o=n(c,a.props.children)).return=i,i=o;break e}}else if(c.elementType===d||"object"===typeof d&&null!==d&&d.$$typeof===T&&bo(d)===c.type){t(i,c.sibling),(o=n(c,a.props)).ref=xo(i,c,a),o.return=i,i=o;break e}t(i,c);break}r(i,c),c=c.sibling}a.type===k?((o=$d(a.props.children,i.mode,l,a.key)).return=i,i=o):((l=Pd(a.type,a.key,a.props,null,i.mode,l)).ref=xo(i,o,a),l.return=i,i=l)}return s(i);case w:e:{for(c=a.key;null!==o;){if(o.key===c){if(4===o.tag&&o.stateNode.containerInfo===a.containerInfo&&o.stateNode.implementation===a.implementation){t(i,o.sibling),(o=n(o,a.children||[])).return=i,i=o;break e}t(i,o);break}r(i,o),o=o.sibling}(o=Ld(a,i.mode,l)).return=i,i=o}return s(i);case T:return e(i,o,(c=a._init)(a._payload),l)}if(re(a))return m(i,o,a,l);if($(a))return f(i,o,a,l);vo(i,a)}return"string"===typeof a&&""!==a||"number"===typeof a?(a=""+a,null!==o&&6===o.tag?(t(i,o.sibling),(o=n(o,a)).return=i,i=o):(t(i,o),(o=Od(a,i.mode,l)).return=i,i=o),s(i)):t(i,o)}}var yo=jo(!0),wo=jo(!1),ko=_n(null),_o=null,So=null,Co=null;function zo(){Co=So=_o=null}function Eo(e){var r=ko.current;Sn(ko),e._currentValue=r}function Ao(e,r,t){for(;null!==e;){var i=e.alternate;if((e.childLanes&r)!==r?(e.childLanes|=r,null!==i&&(i.childLanes|=r)):null!==i&&(i.childLanes&r)!==r&&(i.childLanes|=r),e===t)break;e=e.return}}function Ro(e,r){_o=e,Co=So=null,null!==(e=e.dependencies)&&null!==e.firstContext&&(0!==(e.lanes&r)&&(bs=!0),e.firstContext=null)}function No(e){var r=e._currentValue;if(Co!==e)if(e={context:e,memoizedValue:r,next:null},null===So){if(null===_o)throw Error(o(308));So=e,_o.dependencies={lanes:0,firstContext:e}}else So=So.next=e;return r}var To=null;function qo(e){null===To?To=[e]:To.push(e)}function Po(e,r,t,i){var n=r.interleaved;return null===n?(t.next=t,qo(r)):(t.next=n.next,n.next=t),r.interleaved=t,$o(e,i)}function $o(e,r){e.lanes|=r;var t=e.alternate;for(null!==t&&(t.lanes|=r),t=e,e=e.return;null!==e;)e.childLanes|=r,null!==(t=e.alternate)&&(t.childLanes|=r),t=e,e=e.return;return 3===t.tag?t.stateNode:null}var Io=!1;function Oo(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Lo(e,r){e=e.updateQueue,r.updateQueue===e&&(r.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function Mo(e,r){return{eventTime:e,lane:r,tag:0,payload:null,callback:null,next:null}}function Do(e,r,t){var i=e.updateQueue;if(null===i)return null;if(i=i.shared,0!==(2&El)){var n=i.pending;return null===n?r.next=r:(r.next=n.next,n.next=r),i.pending=r,$o(e,t)}return null===(n=i.interleaved)?(r.next=r,qo(i)):(r.next=n.next,n.next=r),i.interleaved=r,$o(e,t)}function Fo(e,r,t){if(null!==(r=r.updateQueue)&&(r=r.shared,0!==(4194240&t))){var i=r.lanes;t|=i&=e.pendingLanes,r.lanes=t,vr(e,t)}}function Uo(e,r){var t=e.updateQueue,i=e.alternate;if(null!==i&&t===(i=i.updateQueue)){var n=null,o=null;if(null!==(t=t.firstBaseUpdate)){do{var a={eventTime:t.eventTime,lane:t.lane,tag:t.tag,payload:t.payload,callback:t.callback,next:null};null===o?n=o=a:o=o.next=a,t=t.next}while(null!==t);null===o?n=o=r:o=o.next=r}else n=o=r;return t={baseState:i.baseState,firstBaseUpdate:n,lastBaseUpdate:o,shared:i.shared,effects:i.effects},void(e.updateQueue=t)}null===(e=t.lastBaseUpdate)?t.firstBaseUpdate=r:e.next=r,t.lastBaseUpdate=r}function Bo(e,r,t,i){var n=e.updateQueue;Io=!1;var o=n.firstBaseUpdate,a=n.lastBaseUpdate,s=n.shared.pending;if(null!==s){n.shared.pending=null;var l=s,d=l.next;l.next=null,null===a?o=d:a.next=d,a=l;var c=e.alternate;null!==c&&((s=(c=c.updateQueue).lastBaseUpdate)!==a&&(null===s?c.firstBaseUpdate=d:s.next=d,c.lastBaseUpdate=l))}if(null!==o){var u=n.baseState;for(a=0,c=d=l=null,s=o;;){var g=s.lane,p=s.eventTime;if((i&g)===g){null!==c&&(c=c.next={eventTime:p,lane:0,tag:s.tag,payload:s.payload,callback:s.callback,next:null});e:{var h=e,m=s;switch(g=r,p=t,m.tag){case 1:if("function"===typeof(h=m.payload)){u=h.call(p,u,g);break e}u=h;break e;case 3:h.flags=-65537&h.flags|128;case 0:if(null===(g="function"===typeof(h=m.payload)?h.call(p,u,g):h)||void 0===g)break e;u=O({},u,g);break e;case 2:Io=!0}}null!==s.callback&&0!==s.lane&&(e.flags|=64,null===(g=n.effects)?n.effects=[s]:g.push(s))}else p={eventTime:p,lane:g,tag:s.tag,payload:s.payload,callback:s.callback,next:null},null===c?(d=c=p,l=u):c=c.next=p,a|=g;if(null===(s=s.next)){if(null===(s=n.shared.pending))break;s=(g=s).next,g.next=null,n.lastBaseUpdate=g,n.shared.pending=null}}if(null===c&&(l=u),n.baseState=l,n.firstBaseUpdate=d,n.lastBaseUpdate=c,null!==(r=n.shared.interleaved)){n=r;do{a|=n.lane,n=n.next}while(n!==r)}else null===o&&(n.shared.lanes=0);Il|=a,e.lanes=a,e.memoizedState=u}}function Go(e,r,t){if(e=r.effects,r.effects=null,null!==e)for(r=0;r<e.length;r++){var i=e[r],n=i.callback;if(null!==n){if(i.callback=null,i=t,"function"!==typeof n)throw Error(o(191,n));n.call(i)}}}var Wo={},Ho=_n(Wo),Vo=_n(Wo),Qo=_n(Wo);function Ko(e){if(e===Wo)throw Error(o(174));return e}function Yo(e,r){switch(Cn(Qo,r),Cn(Vo,e),Cn(Ho,Wo),e=r.nodeType){case 9:case 11:r=(r=r.documentElement)?r.namespaceURI:le(null,"");break;default:r=le(r=(e=8===e?r.parentNode:r).namespaceURI||null,e=e.tagName)}Sn(Ho),Cn(Ho,r)}function Jo(){Sn(Ho),Sn(Vo),Sn(Qo)}function Zo(e){Ko(Qo.current);var r=Ko(Ho.current),t=le(r,e.type);r!==t&&(Cn(Vo,e),Cn(Ho,t))}function Xo(e){Vo.current===e&&(Sn(Ho),Sn(Vo))}var ea=_n(0);function ra(e){for(var r=e;null!==r;){if(13===r.tag){var t=r.memoizedState;if(null!==t&&(null===(t=t.dehydrated)||"$?"===t.data||"$!"===t.data))return r}else if(19===r.tag&&void 0!==r.memoizedProps.revealOrder){if(0!==(128&r.flags))return r}else if(null!==r.child){r.child.return=r,r=r.child;continue}if(r===e)break;for(;null===r.sibling;){if(null===r.return||r.return===e)return null;r=r.return}r.sibling.return=r.return,r=r.sibling}return null}var ta=[];function ia(){for(var e=0;e<ta.length;e++)ta[e]._workInProgressVersionPrimary=null;ta.length=0}var na=j.ReactCurrentDispatcher,oa=j.ReactCurrentBatchConfig,aa=0,sa=null,la=null,da=null,ca=!1,ua=!1,ga=0,pa=0;function ha(){throw Error(o(321))}function ma(e,r){if(null===r)return!1;for(var t=0;t<r.length&&t<e.length;t++)if(!ai(e[t],r[t]))return!1;return!0}function fa(e,r,t,i,n,a){if(aa=a,sa=r,r.memoizedState=null,r.updateQueue=null,r.lanes=0,na.current=null===e||null===e.memoizedState?Xa:es,e=t(i,n),ua){a=0;do{if(ua=!1,ga=0,25<=a)throw Error(o(301));a+=1,da=la=null,r.updateQueue=null,na.current=rs,e=t(i,n)}while(ua)}if(na.current=Za,r=null!==la&&null!==la.next,aa=0,da=la=sa=null,ca=!1,r)throw Error(o(300));return e}function xa(){var e=0!==ga;return ga=0,e}function va(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return null===da?sa.memoizedState=da=e:da=da.next=e,da}function ba(){if(null===la){var e=sa.alternate;e=null!==e?e.memoizedState:null}else e=la.next;var r=null===da?sa.memoizedState:da.next;if(null!==r)da=r,la=e;else{if(null===e)throw Error(o(310));e={memoizedState:(la=e).memoizedState,baseState:la.baseState,baseQueue:la.baseQueue,queue:la.queue,next:null},null===da?sa.memoizedState=da=e:da=da.next=e}return da}function ja(e,r){return"function"===typeof r?r(e):r}function ya(e){var r=ba(),t=r.queue;if(null===t)throw Error(o(311));t.lastRenderedReducer=e;var i=la,n=i.baseQueue,a=t.pending;if(null!==a){if(null!==n){var s=n.next;n.next=a.next,a.next=s}i.baseQueue=n=a,t.pending=null}if(null!==n){a=n.next,i=i.baseState;var l=s=null,d=null,c=a;do{var u=c.lane;if((aa&u)===u)null!==d&&(d=d.next={lane:0,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null}),i=c.hasEagerState?c.eagerState:e(i,c.action);else{var g={lane:u,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null};null===d?(l=d=g,s=i):d=d.next=g,sa.lanes|=u,Il|=u}c=c.next}while(null!==c&&c!==a);null===d?s=i:d.next=l,ai(i,r.memoizedState)||(bs=!0),r.memoizedState=i,r.baseState=s,r.baseQueue=d,t.lastRenderedState=i}if(null!==(e=t.interleaved)){n=e;do{a=n.lane,sa.lanes|=a,Il|=a,n=n.next}while(n!==e)}else null===n&&(t.lanes=0);return[r.memoizedState,t.dispatch]}function wa(e){var r=ba(),t=r.queue;if(null===t)throw Error(o(311));t.lastRenderedReducer=e;var i=t.dispatch,n=t.pending,a=r.memoizedState;if(null!==n){t.pending=null;var s=n=n.next;do{a=e(a,s.action),s=s.next}while(s!==n);ai(a,r.memoizedState)||(bs=!0),r.memoizedState=a,null===r.baseQueue&&(r.baseState=a),t.lastRenderedState=a}return[a,i]}function ka(){}function _a(e,r){var t=sa,i=ba(),n=r(),a=!ai(i.memoizedState,n);if(a&&(i.memoizedState=n,bs=!0),i=i.queue,Ia(za.bind(null,t,i,e),[e]),i.getSnapshot!==r||a||null!==da&&1&da.memoizedState.tag){if(t.flags|=2048,Na(9,Ca.bind(null,t,i,n,r),void 0,null),null===Al)throw Error(o(349));0!==(30&aa)||Sa(t,r,n)}return n}function Sa(e,r,t){e.flags|=16384,e={getSnapshot:r,value:t},null===(r=sa.updateQueue)?(r={lastEffect:null,stores:null},sa.updateQueue=r,r.stores=[e]):null===(t=r.stores)?r.stores=[e]:t.push(e)}function Ca(e,r,t,i){r.value=t,r.getSnapshot=i,Ea(r)&&Aa(e)}function za(e,r,t){return t(function(){Ea(r)&&Aa(e)})}function Ea(e){var r=e.getSnapshot;e=e.value;try{var t=r();return!ai(e,t)}catch(i){return!0}}function Aa(e){var r=$o(e,1);null!==r&&td(r,e,1,-1)}function Ra(e){var r=va();return"function"===typeof e&&(e=e()),r.memoizedState=r.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:ja,lastRenderedState:e},r.queue=e,e=e.dispatch=Qa.bind(null,sa,e),[r.memoizedState,e]}function Na(e,r,t,i){return e={tag:e,create:r,destroy:t,deps:i,next:null},null===(r=sa.updateQueue)?(r={lastEffect:null,stores:null},sa.updateQueue=r,r.lastEffect=e.next=e):null===(t=r.lastEffect)?r.lastEffect=e.next=e:(i=t.next,t.next=e,e.next=i,r.lastEffect=e),e}function Ta(){return ba().memoizedState}function qa(e,r,t,i){var n=va();sa.flags|=e,n.memoizedState=Na(1|r,t,void 0,void 0===i?null:i)}function Pa(e,r,t,i){var n=ba();i=void 0===i?null:i;var o=void 0;if(null!==la){var a=la.memoizedState;if(o=a.destroy,null!==i&&ma(i,a.deps))return void(n.memoizedState=Na(r,t,o,i))}sa.flags|=e,n.memoizedState=Na(1|r,t,o,i)}function $a(e,r){return qa(8390656,8,e,r)}function Ia(e,r){return Pa(2048,8,e,r)}function Oa(e,r){return Pa(4,2,e,r)}function La(e,r){return Pa(4,4,e,r)}function Ma(e,r){return"function"===typeof r?(e=e(),r(e),function(){r(null)}):null!==r&&void 0!==r?(e=e(),r.current=e,function(){r.current=null}):void 0}function Da(e,r,t){return t=null!==t&&void 0!==t?t.concat([e]):null,Pa(4,4,Ma.bind(null,r,e),t)}function Fa(){}function Ua(e,r){var t=ba();r=void 0===r?null:r;var i=t.memoizedState;return null!==i&&null!==r&&ma(r,i[1])?i[0]:(t.memoizedState=[e,r],e)}function Ba(e,r){var t=ba();r=void 0===r?null:r;var i=t.memoizedState;return null!==i&&null!==r&&ma(r,i[1])?i[0]:(e=e(),t.memoizedState=[e,r],e)}function Ga(e,r,t){return 0===(21&aa)?(e.baseState&&(e.baseState=!1,bs=!0),e.memoizedState=t):(ai(t,r)||(t=mr(),sa.lanes|=t,Il|=t,e.baseState=!0),r)}function Wa(e,r){var t=br;br=0!==t&&4>t?t:4,e(!0);var i=oa.transition;oa.transition={};try{e(!1),r()}finally{br=t,oa.transition=i}}function Ha(){return ba().memoizedState}function Va(e,r,t){var i=rd(e);if(t={lane:i,action:t,hasEagerState:!1,eagerState:null,next:null},Ka(e))Ya(r,t);else if(null!==(t=Po(e,r,t,i))){td(t,e,i,ed()),Ja(t,r,i)}}function Qa(e,r,t){var i=rd(e),n={lane:i,action:t,hasEagerState:!1,eagerState:null,next:null};if(Ka(e))Ya(r,n);else{var o=e.alternate;if(0===e.lanes&&(null===o||0===o.lanes)&&null!==(o=r.lastRenderedReducer))try{var a=r.lastRenderedState,s=o(a,t);if(n.hasEagerState=!0,n.eagerState=s,ai(s,a)){var l=r.interleaved;return null===l?(n.next=n,qo(r)):(n.next=l.next,l.next=n),void(r.interleaved=n)}}catch(d){}null!==(t=Po(e,r,n,i))&&(td(t,e,i,n=ed()),Ja(t,r,i))}}function Ka(e){var r=e.alternate;return e===sa||null!==r&&r===sa}function Ya(e,r){ua=ca=!0;var t=e.pending;null===t?r.next=r:(r.next=t.next,t.next=r),e.pending=r}function Ja(e,r,t){if(0!==(4194240&t)){var i=r.lanes;t|=i&=e.pendingLanes,r.lanes=t,vr(e,t)}}var Za={readContext:No,useCallback:ha,useContext:ha,useEffect:ha,useImperativeHandle:ha,useInsertionEffect:ha,useLayoutEffect:ha,useMemo:ha,useReducer:ha,useRef:ha,useState:ha,useDebugValue:ha,useDeferredValue:ha,useTransition:ha,useMutableSource:ha,useSyncExternalStore:ha,useId:ha,unstable_isNewReconciler:!1},Xa={readContext:No,useCallback:function(e,r){return va().memoizedState=[e,void 0===r?null:r],e},useContext:No,useEffect:$a,useImperativeHandle:function(e,r,t){return t=null!==t&&void 0!==t?t.concat([e]):null,qa(4194308,4,Ma.bind(null,r,e),t)},useLayoutEffect:function(e,r){return qa(4194308,4,e,r)},useInsertionEffect:function(e,r){return qa(4,2,e,r)},useMemo:function(e,r){var t=va();return r=void 0===r?null:r,e=e(),t.memoizedState=[e,r],e},useReducer:function(e,r,t){var i=va();return r=void 0!==t?t(r):r,i.memoizedState=i.baseState=r,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:r},i.queue=e,e=e.dispatch=Va.bind(null,sa,e),[i.memoizedState,e]},useRef:function(e){return e={current:e},va().memoizedState=e},useState:Ra,useDebugValue:Fa,useDeferredValue:function(e){return va().memoizedState=e},useTransition:function(){var e=Ra(!1),r=e[0];return e=Wa.bind(null,e[1]),va().memoizedState=e,[r,e]},useMutableSource:function(){},useSyncExternalStore:function(e,r,t){var i=sa,n=va();if(no){if(void 0===t)throw Error(o(407));t=t()}else{if(t=r(),null===Al)throw Error(o(349));0!==(30&aa)||Sa(i,r,t)}n.memoizedState=t;var a={value:t,getSnapshot:r};return n.queue=a,$a(za.bind(null,i,a,e),[e]),i.flags|=2048,Na(9,Ca.bind(null,i,a,t,r),void 0,null),t},useId:function(){var e=va(),r=Al.identifierPrefix;if(no){var t=Jn;r=":"+r+"R"+(t=(Yn&~(1<<32-ar(Yn)-1)).toString(32)+t),0<(t=ga++)&&(r+="H"+t.toString(32)),r+=":"}else r=":"+r+"r"+(t=pa++).toString(32)+":";return e.memoizedState=r},unstable_isNewReconciler:!1},es={readContext:No,useCallback:Ua,useContext:No,useEffect:Ia,useImperativeHandle:Da,useInsertionEffect:Oa,useLayoutEffect:La,useMemo:Ba,useReducer:ya,useRef:Ta,useState:function(){return ya(ja)},useDebugValue:Fa,useDeferredValue:function(e){return Ga(ba(),la.memoizedState,e)},useTransition:function(){return[ya(ja)[0],ba().memoizedState]},useMutableSource:ka,useSyncExternalStore:_a,useId:Ha,unstable_isNewReconciler:!1},rs={readContext:No,useCallback:Ua,useContext:No,useEffect:Ia,useImperativeHandle:Da,useInsertionEffect:Oa,useLayoutEffect:La,useMemo:Ba,useReducer:wa,useRef:Ta,useState:function(){return wa(ja)},useDebugValue:Fa,useDeferredValue:function(e){var r=ba();return null===la?r.memoizedState=e:Ga(r,la.memoizedState,e)},useTransition:function(){return[wa(ja)[0],ba().memoizedState]},useMutableSource:ka,useSyncExternalStore:_a,useId:Ha,unstable_isNewReconciler:!1};function ts(e,r){if(e&&e.defaultProps){for(var t in r=O({},r),e=e.defaultProps)void 0===r[t]&&(r[t]=e[t]);return r}return r}function is(e,r,t,i){t=null===(t=t(i,r=e.memoizedState))||void 0===t?r:O({},r,t),e.memoizedState=t,0===e.lanes&&(e.updateQueue.baseState=t)}var ns={isMounted:function(e){return!!(e=e._reactInternals)&&Ue(e)===e},enqueueSetState:function(e,r,t){e=e._reactInternals;var i=ed(),n=rd(e),o=Mo(i,n);o.payload=r,void 0!==t&&null!==t&&(o.callback=t),null!==(r=Do(e,o,n))&&(td(r,e,n,i),Fo(r,e,n))},enqueueReplaceState:function(e,r,t){e=e._reactInternals;var i=ed(),n=rd(e),o=Mo(i,n);o.tag=1,o.payload=r,void 0!==t&&null!==t&&(o.callback=t),null!==(r=Do(e,o,n))&&(td(r,e,n,i),Fo(r,e,n))},enqueueForceUpdate:function(e,r){e=e._reactInternals;var t=ed(),i=rd(e),n=Mo(t,i);n.tag=2,void 0!==r&&null!==r&&(n.callback=r),null!==(r=Do(e,n,i))&&(td(r,e,i,t),Fo(r,e,i))}};function os(e,r,t,i,n,o,a){return"function"===typeof(e=e.stateNode).shouldComponentUpdate?e.shouldComponentUpdate(i,o,a):!r.prototype||!r.prototype.isPureReactComponent||(!si(t,i)||!si(n,o))}function as(e,r,t){var i=!1,n=zn,o=r.contextType;return"object"===typeof o&&null!==o?o=No(o):(n=Tn(r)?Rn:En.current,o=(i=null!==(i=r.contextTypes)&&void 0!==i)?Nn(e,n):zn),r=new r(t,o),e.memoizedState=null!==r.state&&void 0!==r.state?r.state:null,r.updater=ns,e.stateNode=r,r._reactInternals=e,i&&((e=e.stateNode).__reactInternalMemoizedUnmaskedChildContext=n,e.__reactInternalMemoizedMaskedChildContext=o),r}function ss(e,r,t,i){e=r.state,"function"===typeof r.componentWillReceiveProps&&r.componentWillReceiveProps(t,i),"function"===typeof r.UNSAFE_componentWillReceiveProps&&r.UNSAFE_componentWillReceiveProps(t,i),r.state!==e&&ns.enqueueReplaceState(r,r.state,null)}function ls(e,r,t,i){var n=e.stateNode;n.props=t,n.state=e.memoizedState,n.refs={},Oo(e);var o=r.contextType;"object"===typeof o&&null!==o?n.context=No(o):(o=Tn(r)?Rn:En.current,n.context=Nn(e,o)),n.state=e.memoizedState,"function"===typeof(o=r.getDerivedStateFromProps)&&(is(e,r,o,t),n.state=e.memoizedState),"function"===typeof r.getDerivedStateFromProps||"function"===typeof n.getSnapshotBeforeUpdate||"function"!==typeof n.UNSAFE_componentWillMount&&"function"!==typeof n.componentWillMount||(r=n.state,"function"===typeof n.componentWillMount&&n.componentWillMount(),"function"===typeof n.UNSAFE_componentWillMount&&n.UNSAFE_componentWillMount(),r!==n.state&&ns.enqueueReplaceState(n,n.state,null),Bo(e,t,n,i),n.state=e.memoizedState),"function"===typeof n.componentDidMount&&(e.flags|=4194308)}function ds(e,r){try{var t="",i=r;do{t+=F(i),i=i.return}while(i);var n=t}catch(o){n="\nError generating stack: "+o.message+"\n"+o.stack}return{value:e,source:r,stack:n,digest:null}}function cs(e,r,t){return{value:e,source:null,stack:null!=t?t:null,digest:null!=r?r:null}}function us(e,r){try{console.error(r.value)}catch(t){setTimeout(function(){throw t})}}var gs="function"===typeof WeakMap?WeakMap:Map;function ps(e,r,t){(t=Mo(-1,t)).tag=3,t.payload={element:null};var i=r.value;return t.callback=function(){Gl||(Gl=!0,Wl=i),us(0,r)},t}function hs(e,r,t){(t=Mo(-1,t)).tag=3;var i=e.type.getDerivedStateFromError;if("function"===typeof i){var n=r.value;t.payload=function(){return i(n)},t.callback=function(){us(0,r)}}var o=e.stateNode;return null!==o&&"function"===typeof o.componentDidCatch&&(t.callback=function(){us(0,r),"function"!==typeof i&&(null===Hl?Hl=new Set([this]):Hl.add(this));var e=r.stack;this.componentDidCatch(r.value,{componentStack:null!==e?e:""})}),t}function ms(e,r,t){var i=e.pingCache;if(null===i){i=e.pingCache=new gs;var n=new Set;i.set(r,n)}else void 0===(n=i.get(r))&&(n=new Set,i.set(r,n));n.has(t)||(n.add(t),e=Sd.bind(null,e,r,t),r.then(e,e))}function fs(e){do{var r;if((r=13===e.tag)&&(r=null===(r=e.memoizedState)||null!==r.dehydrated),r)return e;e=e.return}while(null!==e);return null}function xs(e,r,t,i,n){return 0===(1&e.mode)?(e===r?e.flags|=65536:(e.flags|=128,t.flags|=131072,t.flags&=-52805,1===t.tag&&(null===t.alternate?t.tag=17:((r=Mo(-1,1)).tag=2,Do(t,r,1))),t.lanes|=1),e):(e.flags|=65536,e.lanes=n,e)}var vs=j.ReactCurrentOwner,bs=!1;function js(e,r,t,i){r.child=null===e?wo(r,null,t,i):yo(r,e.child,t,i)}function ys(e,r,t,i,n){t=t.render;var o=r.ref;return Ro(r,n),i=fa(e,r,t,i,o,n),t=xa(),null===e||bs?(no&&t&&eo(r),r.flags|=1,js(e,r,i,n),r.child):(r.updateQueue=e.updateQueue,r.flags&=-2053,e.lanes&=~n,Gs(e,r,n))}function ws(e,r,t,i,n){if(null===e){var o=t.type;return"function"!==typeof o||Td(o)||void 0!==o.defaultProps||null!==t.compare||void 0!==t.defaultProps?((e=Pd(t.type,null,i,r,r.mode,n)).ref=r.ref,e.return=r,r.child=e):(r.tag=15,r.type=o,ks(e,r,o,i,n))}if(o=e.child,0===(e.lanes&n)){var a=o.memoizedProps;if((t=null!==(t=t.compare)?t:si)(a,i)&&e.ref===r.ref)return Gs(e,r,n)}return r.flags|=1,(e=qd(o,i)).ref=r.ref,e.return=r,r.child=e}function ks(e,r,t,i,n){if(null!==e){var o=e.memoizedProps;if(si(o,i)&&e.ref===r.ref){if(bs=!1,r.pendingProps=i=o,0===(e.lanes&n))return r.lanes=e.lanes,Gs(e,r,n);0!==(131072&e.flags)&&(bs=!0)}}return Cs(e,r,t,i,n)}function _s(e,r,t){var i=r.pendingProps,n=i.children,o=null!==e?e.memoizedState:null;if("hidden"===i.mode)if(0===(1&r.mode))r.memoizedState={baseLanes:0,cachePool:null,transitions:null},Cn(ql,Tl),Tl|=t;else{if(0===(1073741824&t))return e=null!==o?o.baseLanes|t:t,r.lanes=r.childLanes=1073741824,r.memoizedState={baseLanes:e,cachePool:null,transitions:null},r.updateQueue=null,Cn(ql,Tl),Tl|=e,null;r.memoizedState={baseLanes:0,cachePool:null,transitions:null},i=null!==o?o.baseLanes:t,Cn(ql,Tl),Tl|=i}else null!==o?(i=o.baseLanes|t,r.memoizedState=null):i=t,Cn(ql,Tl),Tl|=i;return js(e,r,n,t),r.child}function Ss(e,r){var t=r.ref;(null===e&&null!==t||null!==e&&e.ref!==t)&&(r.flags|=512,r.flags|=2097152)}function Cs(e,r,t,i,n){var o=Tn(t)?Rn:En.current;return o=Nn(r,o),Ro(r,n),t=fa(e,r,t,i,o,n),i=xa(),null===e||bs?(no&&i&&eo(r),r.flags|=1,js(e,r,t,n),r.child):(r.updateQueue=e.updateQueue,r.flags&=-2053,e.lanes&=~n,Gs(e,r,n))}function zs(e,r,t,i,n){if(Tn(t)){var o=!0;In(r)}else o=!1;if(Ro(r,n),null===r.stateNode)Bs(e,r),as(r,t,i),ls(r,t,i,n),i=!0;else if(null===e){var a=r.stateNode,s=r.memoizedProps;a.props=s;var l=a.context,d=t.contextType;"object"===typeof d&&null!==d?d=No(d):d=Nn(r,d=Tn(t)?Rn:En.current);var c=t.getDerivedStateFromProps,u="function"===typeof c||"function"===typeof a.getSnapshotBeforeUpdate;u||"function"!==typeof a.UNSAFE_componentWillReceiveProps&&"function"!==typeof a.componentWillReceiveProps||(s!==i||l!==d)&&ss(r,a,i,d),Io=!1;var g=r.memoizedState;a.state=g,Bo(r,i,a,n),l=r.memoizedState,s!==i||g!==l||An.current||Io?("function"===typeof c&&(is(r,t,c,i),l=r.memoizedState),(s=Io||os(r,t,s,i,g,l,d))?(u||"function"!==typeof a.UNSAFE_componentWillMount&&"function"!==typeof a.componentWillMount||("function"===typeof a.componentWillMount&&a.componentWillMount(),"function"===typeof a.UNSAFE_componentWillMount&&a.UNSAFE_componentWillMount()),"function"===typeof a.componentDidMount&&(r.flags|=4194308)):("function"===typeof a.componentDidMount&&(r.flags|=4194308),r.memoizedProps=i,r.memoizedState=l),a.props=i,a.state=l,a.context=d,i=s):("function"===typeof a.componentDidMount&&(r.flags|=4194308),i=!1)}else{a=r.stateNode,Lo(e,r),s=r.memoizedProps,d=r.type===r.elementType?s:ts(r.type,s),a.props=d,u=r.pendingProps,g=a.context,"object"===typeof(l=t.contextType)&&null!==l?l=No(l):l=Nn(r,l=Tn(t)?Rn:En.current);var p=t.getDerivedStateFromProps;(c="function"===typeof p||"function"===typeof a.getSnapshotBeforeUpdate)||"function"!==typeof a.UNSAFE_componentWillReceiveProps&&"function"!==typeof a.componentWillReceiveProps||(s!==u||g!==l)&&ss(r,a,i,l),Io=!1,g=r.memoizedState,a.state=g,Bo(r,i,a,n);var h=r.memoizedState;s!==u||g!==h||An.current||Io?("function"===typeof p&&(is(r,t,p,i),h=r.memoizedState),(d=Io||os(r,t,d,i,g,h,l)||!1)?(c||"function"!==typeof a.UNSAFE_componentWillUpdate&&"function"!==typeof a.componentWillUpdate||("function"===typeof a.componentWillUpdate&&a.componentWillUpdate(i,h,l),"function"===typeof a.UNSAFE_componentWillUpdate&&a.UNSAFE_componentWillUpdate(i,h,l)),"function"===typeof a.componentDidUpdate&&(r.flags|=4),"function"===typeof a.getSnapshotBeforeUpdate&&(r.flags|=1024)):("function"!==typeof a.componentDidUpdate||s===e.memoizedProps&&g===e.memoizedState||(r.flags|=4),"function"!==typeof a.getSnapshotBeforeUpdate||s===e.memoizedProps&&g===e.memoizedState||(r.flags|=1024),r.memoizedProps=i,r.memoizedState=h),a.props=i,a.state=h,a.context=l,i=d):("function"!==typeof a.componentDidUpdate||s===e.memoizedProps&&g===e.memoizedState||(r.flags|=4),"function"!==typeof a.getSnapshotBeforeUpdate||s===e.memoizedProps&&g===e.memoizedState||(r.flags|=1024),i=!1)}return Es(e,r,t,i,o,n)}function Es(e,r,t,i,n,o){Ss(e,r);var a=0!==(128&r.flags);if(!i&&!a)return n&&On(r,t,!1),Gs(e,r,o);i=r.stateNode,vs.current=r;var s=a&&"function"!==typeof t.getDerivedStateFromError?null:i.render();return r.flags|=1,null!==e&&a?(r.child=yo(r,e.child,null,o),r.child=yo(r,null,s,o)):js(e,r,s,o),r.memoizedState=i.state,n&&On(r,t,!0),r.child}function As(e){var r=e.stateNode;r.pendingContext?Pn(0,r.pendingContext,r.pendingContext!==r.context):r.context&&Pn(0,r.context,!1),Yo(e,r.containerInfo)}function Rs(e,r,t,i,n){return ho(),mo(n),r.flags|=256,js(e,r,t,i),r.child}var Ns,Ts,qs,Ps,$s={dehydrated:null,treeContext:null,retryLane:0};function Is(e){return{baseLanes:e,cachePool:null,transitions:null}}function Os(e,r,t){var i,n=r.pendingProps,a=ea.current,s=!1,l=0!==(128&r.flags);if((i=l)||(i=(null===e||null!==e.memoizedState)&&0!==(2&a)),i?(s=!0,r.flags&=-129):null!==e&&null===e.memoizedState||(a|=1),Cn(ea,1&a),null===e)return co(r),null!==(e=r.memoizedState)&&null!==(e=e.dehydrated)?(0===(1&r.mode)?r.lanes=1:"$!"===e.data?r.lanes=8:r.lanes=1073741824,null):(l=n.children,e=n.fallback,s?(n=r.mode,s=r.child,l={mode:"hidden",children:l},0===(1&n)&&null!==s?(s.childLanes=0,s.pendingProps=l):s=Id(l,n,0,null),e=$d(e,n,t,null),s.return=r,e.return=r,s.sibling=e,r.child=s,r.child.memoizedState=Is(t),r.memoizedState=$s,e):Ls(r,l));if(null!==(a=e.memoizedState)&&null!==(i=a.dehydrated))return function(e,r,t,i,n,a,s){if(t)return 256&r.flags?(r.flags&=-257,Ms(e,r,s,i=cs(Error(o(422))))):null!==r.memoizedState?(r.child=e.child,r.flags|=128,null):(a=i.fallback,n=r.mode,i=Id({mode:"visible",children:i.children},n,0,null),(a=$d(a,n,s,null)).flags|=2,i.return=r,a.return=r,i.sibling=a,r.child=i,0!==(1&r.mode)&&yo(r,e.child,null,s),r.child.memoizedState=Is(s),r.memoizedState=$s,a);if(0===(1&r.mode))return Ms(e,r,s,null);if("$!"===n.data){if(i=n.nextSibling&&n.nextSibling.dataset)var l=i.dgst;return i=l,Ms(e,r,s,i=cs(a=Error(o(419)),i,void 0))}if(l=0!==(s&e.childLanes),bs||l){if(null!==(i=Al)){switch(s&-s){case 4:n=2;break;case 16:n=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:n=32;break;case 536870912:n=268435456;break;default:n=0}0!==(n=0!==(n&(i.suspendedLanes|s))?0:n)&&n!==a.retryLane&&(a.retryLane=n,$o(e,n),td(i,e,n,-1))}return md(),Ms(e,r,s,i=cs(Error(o(421))))}return"$?"===n.data?(r.flags|=128,r.child=e.child,r=zd.bind(null,e),n._reactRetry=r,null):(e=a.treeContext,io=dn(n.nextSibling),to=r,no=!0,oo=null,null!==e&&(Vn[Qn++]=Yn,Vn[Qn++]=Jn,Vn[Qn++]=Kn,Yn=e.id,Jn=e.overflow,Kn=r),r=Ls(r,i.children),r.flags|=4096,r)}(e,r,l,n,i,a,t);if(s){s=n.fallback,l=r.mode,i=(a=e.child).sibling;var d={mode:"hidden",children:n.children};return 0===(1&l)&&r.child!==a?((n=r.child).childLanes=0,n.pendingProps=d,r.deletions=null):(n=qd(a,d)).subtreeFlags=14680064&a.subtreeFlags,null!==i?s=qd(i,s):(s=$d(s,l,t,null)).flags|=2,s.return=r,n.return=r,n.sibling=s,r.child=n,n=s,s=r.child,l=null===(l=e.child.memoizedState)?Is(t):{baseLanes:l.baseLanes|t,cachePool:null,transitions:l.transitions},s.memoizedState=l,s.childLanes=e.childLanes&~t,r.memoizedState=$s,n}return e=(s=e.child).sibling,n=qd(s,{mode:"visible",children:n.children}),0===(1&r.mode)&&(n.lanes=t),n.return=r,n.sibling=null,null!==e&&(null===(t=r.deletions)?(r.deletions=[e],r.flags|=16):t.push(e)),r.child=n,r.memoizedState=null,n}function Ls(e,r){return(r=Id({mode:"visible",children:r},e.mode,0,null)).return=e,e.child=r}function Ms(e,r,t,i){return null!==i&&mo(i),yo(r,e.child,null,t),(e=Ls(r,r.pendingProps.children)).flags|=2,r.memoizedState=null,e}function Ds(e,r,t){e.lanes|=r;var i=e.alternate;null!==i&&(i.lanes|=r),Ao(e.return,r,t)}function Fs(e,r,t,i,n){var o=e.memoizedState;null===o?e.memoizedState={isBackwards:r,rendering:null,renderingStartTime:0,last:i,tail:t,tailMode:n}:(o.isBackwards=r,o.rendering=null,o.renderingStartTime=0,o.last=i,o.tail=t,o.tailMode=n)}function Us(e,r,t){var i=r.pendingProps,n=i.revealOrder,o=i.tail;if(js(e,r,i.children,t),0!==(2&(i=ea.current)))i=1&i|2,r.flags|=128;else{if(null!==e&&0!==(128&e.flags))e:for(e=r.child;null!==e;){if(13===e.tag)null!==e.memoizedState&&Ds(e,t,r);else if(19===e.tag)Ds(e,t,r);else if(null!==e.child){e.child.return=e,e=e.child;continue}if(e===r)break e;for(;null===e.sibling;){if(null===e.return||e.return===r)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}i&=1}if(Cn(ea,i),0===(1&r.mode))r.memoizedState=null;else switch(n){case"forwards":for(t=r.child,n=null;null!==t;)null!==(e=t.alternate)&&null===ra(e)&&(n=t),t=t.sibling;null===(t=n)?(n=r.child,r.child=null):(n=t.sibling,t.sibling=null),Fs(r,!1,n,t,o);break;case"backwards":for(t=null,n=r.child,r.child=null;null!==n;){if(null!==(e=n.alternate)&&null===ra(e)){r.child=n;break}e=n.sibling,n.sibling=t,t=n,n=e}Fs(r,!0,t,null,o);break;case"together":Fs(r,!1,null,null,void 0);break;default:r.memoizedState=null}return r.child}function Bs(e,r){0===(1&r.mode)&&null!==e&&(e.alternate=null,r.alternate=null,r.flags|=2)}function Gs(e,r,t){if(null!==e&&(r.dependencies=e.dependencies),Il|=r.lanes,0===(t&r.childLanes))return null;if(null!==e&&r.child!==e.child)throw Error(o(153));if(null!==r.child){for(t=qd(e=r.child,e.pendingProps),r.child=t,t.return=r;null!==e.sibling;)e=e.sibling,(t=t.sibling=qd(e,e.pendingProps)).return=r;t.sibling=null}return r.child}function Ws(e,r){if(!no)switch(e.tailMode){case"hidden":r=e.tail;for(var t=null;null!==r;)null!==r.alternate&&(t=r),r=r.sibling;null===t?e.tail=null:t.sibling=null;break;case"collapsed":t=e.tail;for(var i=null;null!==t;)null!==t.alternate&&(i=t),t=t.sibling;null===i?r||null===e.tail?e.tail=null:e.tail.sibling=null:i.sibling=null}}function Hs(e){var r=null!==e.alternate&&e.alternate.child===e.child,t=0,i=0;if(r)for(var n=e.child;null!==n;)t|=n.lanes|n.childLanes,i|=14680064&n.subtreeFlags,i|=14680064&n.flags,n.return=e,n=n.sibling;else for(n=e.child;null!==n;)t|=n.lanes|n.childLanes,i|=n.subtreeFlags,i|=n.flags,n.return=e,n=n.sibling;return e.subtreeFlags|=i,e.childLanes=t,r}function Vs(e,r,t){var i=r.pendingProps;switch(ro(r),r.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Hs(r),null;case 1:case 17:return Tn(r.type)&&qn(),Hs(r),null;case 3:return i=r.stateNode,Jo(),Sn(An),Sn(En),ia(),i.pendingContext&&(i.context=i.pendingContext,i.pendingContext=null),null!==e&&null!==e.child||(go(r)?r.flags|=4:null===e||e.memoizedState.isDehydrated&&0===(256&r.flags)||(r.flags|=1024,null!==oo&&(ad(oo),oo=null))),Ts(e,r),Hs(r),null;case 5:Xo(r);var n=Ko(Qo.current);if(t=r.type,null!==e&&null!=r.stateNode)qs(e,r,t,i,n),e.ref!==r.ref&&(r.flags|=512,r.flags|=2097152);else{if(!i){if(null===r.stateNode)throw Error(o(166));return Hs(r),null}if(e=Ko(Ho.current),go(r)){i=r.stateNode,t=r.type;var a=r.memoizedProps;switch(i[gn]=r,i[pn]=a,e=0!==(1&r.mode),t){case"dialog":Li("cancel",i),Li("close",i);break;case"iframe":case"object":case"embed":Li("load",i);break;case"video":case"audio":for(n=0;n<Pi.length;n++)Li(Pi[n],i);break;case"source":Li("error",i);break;case"img":case"image":case"link":Li("error",i),Li("load",i);break;case"details":Li("toggle",i);break;case"input":Y(i,a),Li("invalid",i);break;case"select":i._wrapperState={wasMultiple:!!a.multiple},Li("invalid",i);break;case"textarea":ne(i,a),Li("invalid",i)}for(var l in ve(t,a),n=null,a)if(a.hasOwnProperty(l)){var d=a[l];"children"===l?"string"===typeof d?i.textContent!==d&&(!0!==a.suppressHydrationWarning&&Ji(i.textContent,d,e),n=["children",d]):"number"===typeof d&&i.textContent!==""+d&&(!0!==a.suppressHydrationWarning&&Ji(i.textContent,d,e),n=["children",""+d]):s.hasOwnProperty(l)&&null!=d&&"onScroll"===l&&Li("scroll",i)}switch(t){case"input":H(i),X(i,a,!0);break;case"textarea":H(i),ae(i);break;case"select":case"option":break;default:"function"===typeof a.onClick&&(i.onclick=Zi)}i=n,r.updateQueue=i,null!==i&&(r.flags|=4)}else{l=9===n.nodeType?n:n.ownerDocument,"http://www.w3.org/1999/xhtml"===e&&(e=se(t)),"http://www.w3.org/1999/xhtml"===e?"script"===t?((e=l.createElement("div")).innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):"string"===typeof i.is?e=l.createElement(t,{is:i.is}):(e=l.createElement(t),"select"===t&&(l=e,i.multiple?l.multiple=!0:i.size&&(l.size=i.size))):e=l.createElementNS(e,t),e[gn]=r,e[pn]=i,Ns(e,r,!1,!1),r.stateNode=e;e:{switch(l=be(t,i),t){case"dialog":Li("cancel",e),Li("close",e),n=i;break;case"iframe":case"object":case"embed":Li("load",e),n=i;break;case"video":case"audio":for(n=0;n<Pi.length;n++)Li(Pi[n],e);n=i;break;case"source":Li("error",e),n=i;break;case"img":case"image":case"link":Li("error",e),Li("load",e),n=i;break;case"details":Li("toggle",e),n=i;break;case"input":Y(e,i),n=K(e,i),Li("invalid",e);break;case"option":default:n=i;break;case"select":e._wrapperState={wasMultiple:!!i.multiple},n=O({},i,{value:void 0}),Li("invalid",e);break;case"textarea":ne(e,i),n=ie(e,i),Li("invalid",e)}for(a in ve(t,n),d=n)if(d.hasOwnProperty(a)){var c=d[a];"style"===a?fe(e,c):"dangerouslySetInnerHTML"===a?null!=(c=c?c.__html:void 0)&&ue(e,c):"children"===a?"string"===typeof c?("textarea"!==t||""!==c)&&ge(e,c):"number"===typeof c&&ge(e,""+c):"suppressContentEditableWarning"!==a&&"suppressHydrationWarning"!==a&&"autoFocus"!==a&&(s.hasOwnProperty(a)?null!=c&&"onScroll"===a&&Li("scroll",e):null!=c&&b(e,a,c,l))}switch(t){case"input":H(e),X(e,i,!1);break;case"textarea":H(e),ae(e);break;case"option":null!=i.value&&e.setAttribute("value",""+G(i.value));break;case"select":e.multiple=!!i.multiple,null!=(a=i.value)?te(e,!!i.multiple,a,!1):null!=i.defaultValue&&te(e,!!i.multiple,i.defaultValue,!0);break;default:"function"===typeof n.onClick&&(e.onclick=Zi)}switch(t){case"button":case"input":case"select":case"textarea":i=!!i.autoFocus;break e;case"img":i=!0;break e;default:i=!1}}i&&(r.flags|=4)}null!==r.ref&&(r.flags|=512,r.flags|=2097152)}return Hs(r),null;case 6:if(e&&null!=r.stateNode)Ps(e,r,e.memoizedProps,i);else{if("string"!==typeof i&&null===r.stateNode)throw Error(o(166));if(t=Ko(Qo.current),Ko(Ho.current),go(r)){if(i=r.stateNode,t=r.memoizedProps,i[gn]=r,(a=i.nodeValue!==t)&&null!==(e=to))switch(e.tag){case 3:Ji(i.nodeValue,t,0!==(1&e.mode));break;case 5:!0!==e.memoizedProps.suppressHydrationWarning&&Ji(i.nodeValue,t,0!==(1&e.mode))}a&&(r.flags|=4)}else(i=(9===t.nodeType?t:t.ownerDocument).createTextNode(i))[gn]=r,r.stateNode=i}return Hs(r),null;case 13:if(Sn(ea),i=r.memoizedState,null===e||null!==e.memoizedState&&null!==e.memoizedState.dehydrated){if(no&&null!==io&&0!==(1&r.mode)&&0===(128&r.flags))po(),ho(),r.flags|=98560,a=!1;else if(a=go(r),null!==i&&null!==i.dehydrated){if(null===e){if(!a)throw Error(o(318));if(!(a=null!==(a=r.memoizedState)?a.dehydrated:null))throw Error(o(317));a[gn]=r}else ho(),0===(128&r.flags)&&(r.memoizedState=null),r.flags|=4;Hs(r),a=!1}else null!==oo&&(ad(oo),oo=null),a=!0;if(!a)return 65536&r.flags?r:null}return 0!==(128&r.flags)?(r.lanes=t,r):((i=null!==i)!==(null!==e&&null!==e.memoizedState)&&i&&(r.child.flags|=8192,0!==(1&r.mode)&&(null===e||0!==(1&ea.current)?0===Pl&&(Pl=3):md())),null!==r.updateQueue&&(r.flags|=4),Hs(r),null);case 4:return Jo(),Ts(e,r),null===e&&Fi(r.stateNode.containerInfo),Hs(r),null;case 10:return Eo(r.type._context),Hs(r),null;case 19:if(Sn(ea),null===(a=r.memoizedState))return Hs(r),null;if(i=0!==(128&r.flags),null===(l=a.rendering))if(i)Ws(a,!1);else{if(0!==Pl||null!==e&&0!==(128&e.flags))for(e=r.child;null!==e;){if(null!==(l=ra(e))){for(r.flags|=128,Ws(a,!1),null!==(i=l.updateQueue)&&(r.updateQueue=i,r.flags|=4),r.subtreeFlags=0,i=t,t=r.child;null!==t;)e=i,(a=t).flags&=14680066,null===(l=a.alternate)?(a.childLanes=0,a.lanes=e,a.child=null,a.subtreeFlags=0,a.memoizedProps=null,a.memoizedState=null,a.updateQueue=null,a.dependencies=null,a.stateNode=null):(a.childLanes=l.childLanes,a.lanes=l.lanes,a.child=l.child,a.subtreeFlags=0,a.deletions=null,a.memoizedProps=l.memoizedProps,a.memoizedState=l.memoizedState,a.updateQueue=l.updateQueue,a.type=l.type,e=l.dependencies,a.dependencies=null===e?null:{lanes:e.lanes,firstContext:e.firstContext}),t=t.sibling;return Cn(ea,1&ea.current|2),r.child}e=e.sibling}null!==a.tail&&Je()>Ul&&(r.flags|=128,i=!0,Ws(a,!1),r.lanes=4194304)}else{if(!i)if(null!==(e=ra(l))){if(r.flags|=128,i=!0,null!==(t=e.updateQueue)&&(r.updateQueue=t,r.flags|=4),Ws(a,!0),null===a.tail&&"hidden"===a.tailMode&&!l.alternate&&!no)return Hs(r),null}else 2*Je()-a.renderingStartTime>Ul&&1073741824!==t&&(r.flags|=128,i=!0,Ws(a,!1),r.lanes=4194304);a.isBackwards?(l.sibling=r.child,r.child=l):(null!==(t=a.last)?t.sibling=l:r.child=l,a.last=l)}return null!==a.tail?(r=a.tail,a.rendering=r,a.tail=r.sibling,a.renderingStartTime=Je(),r.sibling=null,t=ea.current,Cn(ea,i?1&t|2:1&t),r):(Hs(r),null);case 22:case 23:return ud(),i=null!==r.memoizedState,null!==e&&null!==e.memoizedState!==i&&(r.flags|=8192),i&&0!==(1&r.mode)?0!==(1073741824&Tl)&&(Hs(r),6&r.subtreeFlags&&(r.flags|=8192)):Hs(r),null;case 24:case 25:return null}throw Error(o(156,r.tag))}function Qs(e,r){switch(ro(r),r.tag){case 1:return Tn(r.type)&&qn(),65536&(e=r.flags)?(r.flags=-65537&e|128,r):null;case 3:return Jo(),Sn(An),Sn(En),ia(),0!==(65536&(e=r.flags))&&0===(128&e)?(r.flags=-65537&e|128,r):null;case 5:return Xo(r),null;case 13:if(Sn(ea),null!==(e=r.memoizedState)&&null!==e.dehydrated){if(null===r.alternate)throw Error(o(340));ho()}return 65536&(e=r.flags)?(r.flags=-65537&e|128,r):null;case 19:return Sn(ea),null;case 4:return Jo(),null;case 10:return Eo(r.type._context),null;case 22:case 23:return ud(),null;default:return null}}Ns=function(e,r){for(var t=r.child;null!==t;){if(5===t.tag||6===t.tag)e.appendChild(t.stateNode);else if(4!==t.tag&&null!==t.child){t.child.return=t,t=t.child;continue}if(t===r)break;for(;null===t.sibling;){if(null===t.return||t.return===r)return;t=t.return}t.sibling.return=t.return,t=t.sibling}},Ts=function(){},qs=function(e,r,t,i){var n=e.memoizedProps;if(n!==i){e=r.stateNode,Ko(Ho.current);var o,a=null;switch(t){case"input":n=K(e,n),i=K(e,i),a=[];break;case"select":n=O({},n,{value:void 0}),i=O({},i,{value:void 0}),a=[];break;case"textarea":n=ie(e,n),i=ie(e,i),a=[];break;default:"function"!==typeof n.onClick&&"function"===typeof i.onClick&&(e.onclick=Zi)}for(c in ve(t,i),t=null,n)if(!i.hasOwnProperty(c)&&n.hasOwnProperty(c)&&null!=n[c])if("style"===c){var l=n[c];for(o in l)l.hasOwnProperty(o)&&(t||(t={}),t[o]="")}else"dangerouslySetInnerHTML"!==c&&"children"!==c&&"suppressContentEditableWarning"!==c&&"suppressHydrationWarning"!==c&&"autoFocus"!==c&&(s.hasOwnProperty(c)?a||(a=[]):(a=a||[]).push(c,null));for(c in i){var d=i[c];if(l=null!=n?n[c]:void 0,i.hasOwnProperty(c)&&d!==l&&(null!=d||null!=l))if("style"===c)if(l){for(o in l)!l.hasOwnProperty(o)||d&&d.hasOwnProperty(o)||(t||(t={}),t[o]="");for(o in d)d.hasOwnProperty(o)&&l[o]!==d[o]&&(t||(t={}),t[o]=d[o])}else t||(a||(a=[]),a.push(c,t)),t=d;else"dangerouslySetInnerHTML"===c?(d=d?d.__html:void 0,l=l?l.__html:void 0,null!=d&&l!==d&&(a=a||[]).push(c,d)):"children"===c?"string"!==typeof d&&"number"!==typeof d||(a=a||[]).push(c,""+d):"suppressContentEditableWarning"!==c&&"suppressHydrationWarning"!==c&&(s.hasOwnProperty(c)?(null!=d&&"onScroll"===c&&Li("scroll",e),a||l===d||(a=[])):(a=a||[]).push(c,d))}t&&(a=a||[]).push("style",t);var c=a;(r.updateQueue=c)&&(r.flags|=4)}},Ps=function(e,r,t,i){t!==i&&(r.flags|=4)};var Ks=!1,Ys=!1,Js="function"===typeof WeakSet?WeakSet:Set,Zs=null;function Xs(e,r){var t=e.ref;if(null!==t)if("function"===typeof t)try{t(null)}catch(i){_d(e,r,i)}else t.current=null}function el(e,r,t){try{t()}catch(i){_d(e,r,i)}}var rl=!1;function tl(e,r,t){var i=r.updateQueue;if(null!==(i=null!==i?i.lastEffect:null)){var n=i=i.next;do{if((n.tag&e)===e){var o=n.destroy;n.destroy=void 0,void 0!==o&&el(r,t,o)}n=n.next}while(n!==i)}}function il(e,r){if(null!==(r=null!==(r=r.updateQueue)?r.lastEffect:null)){var t=r=r.next;do{if((t.tag&e)===e){var i=t.create;t.destroy=i()}t=t.next}while(t!==r)}}function nl(e){var r=e.ref;if(null!==r){var t=e.stateNode;e.tag,e=t,"function"===typeof r?r(e):r.current=e}}function ol(e){var r=e.alternate;null!==r&&(e.alternate=null,ol(r)),e.child=null,e.deletions=null,e.sibling=null,5===e.tag&&(null!==(r=e.stateNode)&&(delete r[gn],delete r[pn],delete r[mn],delete r[fn],delete r[xn])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function al(e){return 5===e.tag||3===e.tag||4===e.tag}function sl(e){e:for(;;){for(;null===e.sibling;){if(null===e.return||al(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;5!==e.tag&&6!==e.tag&&18!==e.tag;){if(2&e.flags)continue e;if(null===e.child||4===e.tag)continue e;e.child.return=e,e=e.child}if(!(2&e.flags))return e.stateNode}}function ll(e,r,t){var i=e.tag;if(5===i||6===i)e=e.stateNode,r?8===t.nodeType?t.parentNode.insertBefore(e,r):t.insertBefore(e,r):(8===t.nodeType?(r=t.parentNode).insertBefore(e,t):(r=t).appendChild(e),null!==(t=t._reactRootContainer)&&void 0!==t||null!==r.onclick||(r.onclick=Zi));else if(4!==i&&null!==(e=e.child))for(ll(e,r,t),e=e.sibling;null!==e;)ll(e,r,t),e=e.sibling}function dl(e,r,t){var i=e.tag;if(5===i||6===i)e=e.stateNode,r?t.insertBefore(e,r):t.appendChild(e);else if(4!==i&&null!==(e=e.child))for(dl(e,r,t),e=e.sibling;null!==e;)dl(e,r,t),e=e.sibling}var cl=null,ul=!1;function gl(e,r,t){for(t=t.child;null!==t;)pl(e,r,t),t=t.sibling}function pl(e,r,t){if(or&&"function"===typeof or.onCommitFiberUnmount)try{or.onCommitFiberUnmount(nr,t)}catch(s){}switch(t.tag){case 5:Ys||Xs(t,r);case 6:var i=cl,n=ul;cl=null,gl(e,r,t),ul=n,null!==(cl=i)&&(ul?(e=cl,t=t.stateNode,8===e.nodeType?e.parentNode.removeChild(t):e.removeChild(t)):cl.removeChild(t.stateNode));break;case 18:null!==cl&&(ul?(e=cl,t=t.stateNode,8===e.nodeType?ln(e.parentNode,t):1===e.nodeType&&ln(e,t),Ur(e)):ln(cl,t.stateNode));break;case 4:i=cl,n=ul,cl=t.stateNode.containerInfo,ul=!0,gl(e,r,t),cl=i,ul=n;break;case 0:case 11:case 14:case 15:if(!Ys&&(null!==(i=t.updateQueue)&&null!==(i=i.lastEffect))){n=i=i.next;do{var o=n,a=o.destroy;o=o.tag,void 0!==a&&(0!==(2&o)||0!==(4&o))&&el(t,r,a),n=n.next}while(n!==i)}gl(e,r,t);break;case 1:if(!Ys&&(Xs(t,r),"function"===typeof(i=t.stateNode).componentWillUnmount))try{i.props=t.memoizedProps,i.state=t.memoizedState,i.componentWillUnmount()}catch(s){_d(t,r,s)}gl(e,r,t);break;case 21:gl(e,r,t);break;case 22:1&t.mode?(Ys=(i=Ys)||null!==t.memoizedState,gl(e,r,t),Ys=i):gl(e,r,t);break;default:gl(e,r,t)}}function hl(e){var r=e.updateQueue;if(null!==r){e.updateQueue=null;var t=e.stateNode;null===t&&(t=e.stateNode=new Js),r.forEach(function(r){var i=Ed.bind(null,e,r);t.has(r)||(t.add(r),r.then(i,i))})}}function ml(e,r){var t=r.deletions;if(null!==t)for(var i=0;i<t.length;i++){var n=t[i];try{var a=e,s=r,l=s;e:for(;null!==l;){switch(l.tag){case 5:cl=l.stateNode,ul=!1;break e;case 3:case 4:cl=l.stateNode.containerInfo,ul=!0;break e}l=l.return}if(null===cl)throw Error(o(160));pl(a,s,n),cl=null,ul=!1;var d=n.alternate;null!==d&&(d.return=null),n.return=null}catch(c){_d(n,r,c)}}if(12854&r.subtreeFlags)for(r=r.child;null!==r;)fl(r,e),r=r.sibling}function fl(e,r){var t=e.alternate,i=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(ml(r,e),xl(e),4&i){try{tl(3,e,e.return),il(3,e)}catch(f){_d(e,e.return,f)}try{tl(5,e,e.return)}catch(f){_d(e,e.return,f)}}break;case 1:ml(r,e),xl(e),512&i&&null!==t&&Xs(t,t.return);break;case 5:if(ml(r,e),xl(e),512&i&&null!==t&&Xs(t,t.return),32&e.flags){var n=e.stateNode;try{ge(n,"")}catch(f){_d(e,e.return,f)}}if(4&i&&null!=(n=e.stateNode)){var a=e.memoizedProps,s=null!==t?t.memoizedProps:a,l=e.type,d=e.updateQueue;if(e.updateQueue=null,null!==d)try{"input"===l&&"radio"===a.type&&null!=a.name&&J(n,a),be(l,s);var c=be(l,a);for(s=0;s<d.length;s+=2){var u=d[s],g=d[s+1];"style"===u?fe(n,g):"dangerouslySetInnerHTML"===u?ue(n,g):"children"===u?ge(n,g):b(n,u,g,c)}switch(l){case"input":Z(n,a);break;case"textarea":oe(n,a);break;case"select":var p=n._wrapperState.wasMultiple;n._wrapperState.wasMultiple=!!a.multiple;var h=a.value;null!=h?te(n,!!a.multiple,h,!1):p!==!!a.multiple&&(null!=a.defaultValue?te(n,!!a.multiple,a.defaultValue,!0):te(n,!!a.multiple,a.multiple?[]:"",!1))}n[pn]=a}catch(f){_d(e,e.return,f)}}break;case 6:if(ml(r,e),xl(e),4&i){if(null===e.stateNode)throw Error(o(162));n=e.stateNode,a=e.memoizedProps;try{n.nodeValue=a}catch(f){_d(e,e.return,f)}}break;case 3:if(ml(r,e),xl(e),4&i&&null!==t&&t.memoizedState.isDehydrated)try{Ur(r.containerInfo)}catch(f){_d(e,e.return,f)}break;case 4:default:ml(r,e),xl(e);break;case 13:ml(r,e),xl(e),8192&(n=e.child).flags&&(a=null!==n.memoizedState,n.stateNode.isHidden=a,!a||null!==n.alternate&&null!==n.alternate.memoizedState||(Fl=Je())),4&i&&hl(e);break;case 22:if(u=null!==t&&null!==t.memoizedState,1&e.mode?(Ys=(c=Ys)||u,ml(r,e),Ys=c):ml(r,e),xl(e),8192&i){if(c=null!==e.memoizedState,(e.stateNode.isHidden=c)&&!u&&0!==(1&e.mode))for(Zs=e,u=e.child;null!==u;){for(g=Zs=u;null!==Zs;){switch(h=(p=Zs).child,p.tag){case 0:case 11:case 14:case 15:tl(4,p,p.return);break;case 1:Xs(p,p.return);var m=p.stateNode;if("function"===typeof m.componentWillUnmount){i=p,t=p.return;try{r=i,m.props=r.memoizedProps,m.state=r.memoizedState,m.componentWillUnmount()}catch(f){_d(i,t,f)}}break;case 5:Xs(p,p.return);break;case 22:if(null!==p.memoizedState){yl(g);continue}}null!==h?(h.return=p,Zs=h):yl(g)}u=u.sibling}e:for(u=null,g=e;;){if(5===g.tag){if(null===u){u=g;try{n=g.stateNode,c?"function"===typeof(a=n.style).setProperty?a.setProperty("display","none","important"):a.display="none":(l=g.stateNode,s=void 0!==(d=g.memoizedProps.style)&&null!==d&&d.hasOwnProperty("display")?d.display:null,l.style.display=me("display",s))}catch(f){_d(e,e.return,f)}}}else if(6===g.tag){if(null===u)try{g.stateNode.nodeValue=c?"":g.memoizedProps}catch(f){_d(e,e.return,f)}}else if((22!==g.tag&&23!==g.tag||null===g.memoizedState||g===e)&&null!==g.child){g.child.return=g,g=g.child;continue}if(g===e)break e;for(;null===g.sibling;){if(null===g.return||g.return===e)break e;u===g&&(u=null),g=g.return}u===g&&(u=null),g.sibling.return=g.return,g=g.sibling}}break;case 19:ml(r,e),xl(e),4&i&&hl(e);case 21:}}function xl(e){var r=e.flags;if(2&r){try{e:{for(var t=e.return;null!==t;){if(al(t)){var i=t;break e}t=t.return}throw Error(o(160))}switch(i.tag){case 5:var n=i.stateNode;32&i.flags&&(ge(n,""),i.flags&=-33),dl(e,sl(e),n);break;case 3:case 4:var a=i.stateNode.containerInfo;ll(e,sl(e),a);break;default:throw Error(o(161))}}catch(s){_d(e,e.return,s)}e.flags&=-3}4096&r&&(e.flags&=-4097)}function vl(e,r,t){Zs=e,bl(e,r,t)}function bl(e,r,t){for(var i=0!==(1&e.mode);null!==Zs;){var n=Zs,o=n.child;if(22===n.tag&&i){var a=null!==n.memoizedState||Ks;if(!a){var s=n.alternate,l=null!==s&&null!==s.memoizedState||Ys;s=Ks;var d=Ys;if(Ks=a,(Ys=l)&&!d)for(Zs=n;null!==Zs;)l=(a=Zs).child,22===a.tag&&null!==a.memoizedState?wl(n):null!==l?(l.return=a,Zs=l):wl(n);for(;null!==o;)Zs=o,bl(o,r,t),o=o.sibling;Zs=n,Ks=s,Ys=d}jl(e)}else 0!==(8772&n.subtreeFlags)&&null!==o?(o.return=n,Zs=o):jl(e)}}function jl(e){for(;null!==Zs;){var r=Zs;if(0!==(8772&r.flags)){var t=r.alternate;try{if(0!==(8772&r.flags))switch(r.tag){case 0:case 11:case 15:Ys||il(5,r);break;case 1:var i=r.stateNode;if(4&r.flags&&!Ys)if(null===t)i.componentDidMount();else{var n=r.elementType===r.type?t.memoizedProps:ts(r.type,t.memoizedProps);i.componentDidUpdate(n,t.memoizedState,i.__reactInternalSnapshotBeforeUpdate)}var a=r.updateQueue;null!==a&&Go(r,a,i);break;case 3:var s=r.updateQueue;if(null!==s){if(t=null,null!==r.child)switch(r.child.tag){case 5:case 1:t=r.child.stateNode}Go(r,s,t)}break;case 5:var l=r.stateNode;if(null===t&&4&r.flags){t=l;var d=r.memoizedProps;switch(r.type){case"button":case"input":case"select":case"textarea":d.autoFocus&&t.focus();break;case"img":d.src&&(t.src=d.src)}}break;case 6:case 4:case 12:case 19:case 17:case 21:case 22:case 23:case 25:break;case 13:if(null===r.memoizedState){var c=r.alternate;if(null!==c){var u=c.memoizedState;if(null!==u){var g=u.dehydrated;null!==g&&Ur(g)}}}break;default:throw Error(o(163))}Ys||512&r.flags&&nl(r)}catch(p){_d(r,r.return,p)}}if(r===e){Zs=null;break}if(null!==(t=r.sibling)){t.return=r.return,Zs=t;break}Zs=r.return}}function yl(e){for(;null!==Zs;){var r=Zs;if(r===e){Zs=null;break}var t=r.sibling;if(null!==t){t.return=r.return,Zs=t;break}Zs=r.return}}function wl(e){for(;null!==Zs;){var r=Zs;try{switch(r.tag){case 0:case 11:case 15:var t=r.return;try{il(4,r)}catch(l){_d(r,t,l)}break;case 1:var i=r.stateNode;if("function"===typeof i.componentDidMount){var n=r.return;try{i.componentDidMount()}catch(l){_d(r,n,l)}}var o=r.return;try{nl(r)}catch(l){_d(r,o,l)}break;case 5:var a=r.return;try{nl(r)}catch(l){_d(r,a,l)}}}catch(l){_d(r,r.return,l)}if(r===e){Zs=null;break}var s=r.sibling;if(null!==s){s.return=r.return,Zs=s;break}Zs=r.return}}var kl,_l=Math.ceil,Sl=j.ReactCurrentDispatcher,Cl=j.ReactCurrentOwner,zl=j.ReactCurrentBatchConfig,El=0,Al=null,Rl=null,Nl=0,Tl=0,ql=_n(0),Pl=0,$l=null,Il=0,Ol=0,Ll=0,Ml=null,Dl=null,Fl=0,Ul=1/0,Bl=null,Gl=!1,Wl=null,Hl=null,Vl=!1,Ql=null,Kl=0,Yl=0,Jl=null,Zl=-1,Xl=0;function ed(){return 0!==(6&El)?Je():-1!==Zl?Zl:Zl=Je()}function rd(e){return 0===(1&e.mode)?1:0!==(2&El)&&0!==Nl?Nl&-Nl:null!==fo.transition?(0===Xl&&(Xl=mr()),Xl):0!==(e=br)?e:e=void 0===(e=window.event)?16:Yr(e.type)}function td(e,r,t,i){if(50<Yl)throw Yl=0,Jl=null,Error(o(185));xr(e,t,i),0!==(2&El)&&e===Al||(e===Al&&(0===(2&El)&&(Ol|=t),4===Pl&&sd(e,Nl)),id(e,i),1===t&&0===El&&0===(1&r.mode)&&(Ul=Je()+500,Mn&&Un()))}function id(e,r){var t=e.callbackNode;!function(e,r){for(var t=e.suspendedLanes,i=e.pingedLanes,n=e.expirationTimes,o=e.pendingLanes;0<o;){var a=31-ar(o),s=1<<a,l=n[a];-1===l?0!==(s&t)&&0===(s&i)||(n[a]=pr(s,r)):l<=r&&(e.expiredLanes|=s),o&=~s}}(e,r);var i=gr(e,e===Al?Nl:0);if(0===i)null!==t&&Qe(t),e.callbackNode=null,e.callbackPriority=0;else if(r=i&-i,e.callbackPriority!==r){if(null!=t&&Qe(t),1===r)0===e.tag?function(e){Mn=!0,Fn(e)}(ld.bind(null,e)):Fn(ld.bind(null,e)),an(function(){0===(6&El)&&Un()}),t=null;else{switch(jr(i)){case 1:t=Xe;break;case 4:t=er;break;case 16:default:t=rr;break;case 536870912:t=ir}t=Ad(t,nd.bind(null,e))}e.callbackPriority=r,e.callbackNode=t}}function nd(e,r){if(Zl=-1,Xl=0,0!==(6&El))throw Error(o(327));var t=e.callbackNode;if(wd()&&e.callbackNode!==t)return null;var i=gr(e,e===Al?Nl:0);if(0===i)return null;if(0!==(30&i)||0!==(i&e.expiredLanes)||r)r=fd(e,i);else{r=i;var n=El;El|=2;var a=hd();for(Al===e&&Nl===r||(Bl=null,Ul=Je()+500,gd(e,r));;)try{vd();break}catch(l){pd(e,l)}zo(),Sl.current=a,El=n,null!==Rl?r=0:(Al=null,Nl=0,r=Pl)}if(0!==r){if(2===r&&(0!==(n=hr(e))&&(i=n,r=od(e,n))),1===r)throw t=$l,gd(e,0),sd(e,i),id(e,Je()),t;if(6===r)sd(e,i);else{if(n=e.current.alternate,0===(30&i)&&!function(e){for(var r=e;;){if(16384&r.flags){var t=r.updateQueue;if(null!==t&&null!==(t=t.stores))for(var i=0;i<t.length;i++){var n=t[i],o=n.getSnapshot;n=n.value;try{if(!ai(o(),n))return!1}catch(s){return!1}}}if(t=r.child,16384&r.subtreeFlags&&null!==t)t.return=r,r=t;else{if(r===e)break;for(;null===r.sibling;){if(null===r.return||r.return===e)return!0;r=r.return}r.sibling.return=r.return,r=r.sibling}}return!0}(n)&&(2===(r=fd(e,i))&&(0!==(a=hr(e))&&(i=a,r=od(e,a))),1===r))throw t=$l,gd(e,0),sd(e,i),id(e,Je()),t;switch(e.finishedWork=n,e.finishedLanes=i,r){case 0:case 1:throw Error(o(345));case 2:case 5:yd(e,Dl,Bl);break;case 3:if(sd(e,i),(130023424&i)===i&&10<(r=Fl+500-Je())){if(0!==gr(e,0))break;if(((n=e.suspendedLanes)&i)!==i){ed(),e.pingedLanes|=e.suspendedLanes&n;break}e.timeoutHandle=tn(yd.bind(null,e,Dl,Bl),r);break}yd(e,Dl,Bl);break;case 4:if(sd(e,i),(4194240&i)===i)break;for(r=e.eventTimes,n=-1;0<i;){var s=31-ar(i);a=1<<s,(s=r[s])>n&&(n=s),i&=~a}if(i=n,10<(i=(120>(i=Je()-i)?120:480>i?480:1080>i?1080:1920>i?1920:3e3>i?3e3:4320>i?4320:1960*_l(i/1960))-i)){e.timeoutHandle=tn(yd.bind(null,e,Dl,Bl),i);break}yd(e,Dl,Bl);break;default:throw Error(o(329))}}}return id(e,Je()),e.callbackNode===t?nd.bind(null,e):null}function od(e,r){var t=Ml;return e.current.memoizedState.isDehydrated&&(gd(e,r).flags|=256),2!==(e=fd(e,r))&&(r=Dl,Dl=t,null!==r&&ad(r)),e}function ad(e){null===Dl?Dl=e:Dl.push.apply(Dl,e)}function sd(e,r){for(r&=~Ll,r&=~Ol,e.suspendedLanes|=r,e.pingedLanes&=~r,e=e.expirationTimes;0<r;){var t=31-ar(r),i=1<<t;e[t]=-1,r&=~i}}function ld(e){if(0!==(6&El))throw Error(o(327));wd();var r=gr(e,0);if(0===(1&r))return id(e,Je()),null;var t=fd(e,r);if(0!==e.tag&&2===t){var i=hr(e);0!==i&&(r=i,t=od(e,i))}if(1===t)throw t=$l,gd(e,0),sd(e,r),id(e,Je()),t;if(6===t)throw Error(o(345));return e.finishedWork=e.current.alternate,e.finishedLanes=r,yd(e,Dl,Bl),id(e,Je()),null}function dd(e,r){var t=El;El|=1;try{return e(r)}finally{0===(El=t)&&(Ul=Je()+500,Mn&&Un())}}function cd(e){null!==Ql&&0===Ql.tag&&0===(6&El)&&wd();var r=El;El|=1;var t=zl.transition,i=br;try{if(zl.transition=null,br=1,e)return e()}finally{br=i,zl.transition=t,0===(6&(El=r))&&Un()}}function ud(){Tl=ql.current,Sn(ql)}function gd(e,r){e.finishedWork=null,e.finishedLanes=0;var t=e.timeoutHandle;if(-1!==t&&(e.timeoutHandle=-1,nn(t)),null!==Rl)for(t=Rl.return;null!==t;){var i=t;switch(ro(i),i.tag){case 1:null!==(i=i.type.childContextTypes)&&void 0!==i&&qn();break;case 3:Jo(),Sn(An),Sn(En),ia();break;case 5:Xo(i);break;case 4:Jo();break;case 13:case 19:Sn(ea);break;case 10:Eo(i.type._context);break;case 22:case 23:ud()}t=t.return}if(Al=e,Rl=e=qd(e.current,null),Nl=Tl=r,Pl=0,$l=null,Ll=Ol=Il=0,Dl=Ml=null,null!==To){for(r=0;r<To.length;r++)if(null!==(i=(t=To[r]).interleaved)){t.interleaved=null;var n=i.next,o=t.pending;if(null!==o){var a=o.next;o.next=n,i.next=a}t.pending=i}To=null}return e}function pd(e,r){for(;;){var t=Rl;try{if(zo(),na.current=Za,ca){for(var i=sa.memoizedState;null!==i;){var n=i.queue;null!==n&&(n.pending=null),i=i.next}ca=!1}if(aa=0,da=la=sa=null,ua=!1,ga=0,Cl.current=null,null===t||null===t.return){Pl=1,$l=r,Rl=null;break}e:{var a=e,s=t.return,l=t,d=r;if(r=Nl,l.flags|=32768,null!==d&&"object"===typeof d&&"function"===typeof d.then){var c=d,u=l,g=u.tag;if(0===(1&u.mode)&&(0===g||11===g||15===g)){var p=u.alternate;p?(u.updateQueue=p.updateQueue,u.memoizedState=p.memoizedState,u.lanes=p.lanes):(u.updateQueue=null,u.memoizedState=null)}var h=fs(s);if(null!==h){h.flags&=-257,xs(h,s,l,0,r),1&h.mode&&ms(a,c,r),d=c;var m=(r=h).updateQueue;if(null===m){var f=new Set;f.add(d),r.updateQueue=f}else m.add(d);break e}if(0===(1&r)){ms(a,c,r),md();break e}d=Error(o(426))}else if(no&&1&l.mode){var x=fs(s);if(null!==x){0===(65536&x.flags)&&(x.flags|=256),xs(x,s,l,0,r),mo(ds(d,l));break e}}a=d=ds(d,l),4!==Pl&&(Pl=2),null===Ml?Ml=[a]:Ml.push(a),a=s;do{switch(a.tag){case 3:a.flags|=65536,r&=-r,a.lanes|=r,Uo(a,ps(0,d,r));break e;case 1:l=d;var v=a.type,b=a.stateNode;if(0===(128&a.flags)&&("function"===typeof v.getDerivedStateFromError||null!==b&&"function"===typeof b.componentDidCatch&&(null===Hl||!Hl.has(b)))){a.flags|=65536,r&=-r,a.lanes|=r,Uo(a,hs(a,l,r));break e}}a=a.return}while(null!==a)}jd(t)}catch(j){r=j,Rl===t&&null!==t&&(Rl=t=t.return);continue}break}}function hd(){var e=Sl.current;return Sl.current=Za,null===e?Za:e}function md(){0!==Pl&&3!==Pl&&2!==Pl||(Pl=4),null===Al||0===(268435455&Il)&&0===(268435455&Ol)||sd(Al,Nl)}function fd(e,r){var t=El;El|=2;var i=hd();for(Al===e&&Nl===r||(Bl=null,gd(e,r));;)try{xd();break}catch(n){pd(e,n)}if(zo(),El=t,Sl.current=i,null!==Rl)throw Error(o(261));return Al=null,Nl=0,Pl}function xd(){for(;null!==Rl;)bd(Rl)}function vd(){for(;null!==Rl&&!Ke();)bd(Rl)}function bd(e){var r=kl(e.alternate,e,Tl);e.memoizedProps=e.pendingProps,null===r?jd(e):Rl=r,Cl.current=null}function jd(e){var r=e;do{var t=r.alternate;if(e=r.return,0===(32768&r.flags)){if(null!==(t=Vs(t,r,Tl)))return void(Rl=t)}else{if(null!==(t=Qs(t,r)))return t.flags&=32767,void(Rl=t);if(null===e)return Pl=6,void(Rl=null);e.flags|=32768,e.subtreeFlags=0,e.deletions=null}if(null!==(r=r.sibling))return void(Rl=r);Rl=r=e}while(null!==r);0===Pl&&(Pl=5)}function yd(e,r,t){var i=br,n=zl.transition;try{zl.transition=null,br=1,function(e,r,t,i){do{wd()}while(null!==Ql);if(0!==(6&El))throw Error(o(327));t=e.finishedWork;var n=e.finishedLanes;if(null===t)return null;if(e.finishedWork=null,e.finishedLanes=0,t===e.current)throw Error(o(177));e.callbackNode=null,e.callbackPriority=0;var a=t.lanes|t.childLanes;if(function(e,r){var t=e.pendingLanes&~r;e.pendingLanes=r,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=r,e.mutableReadLanes&=r,e.entangledLanes&=r,r=e.entanglements;var i=e.eventTimes;for(e=e.expirationTimes;0<t;){var n=31-ar(t),o=1<<n;r[n]=0,i[n]=-1,e[n]=-1,t&=~o}}(e,a),e===Al&&(Rl=Al=null,Nl=0),0===(2064&t.subtreeFlags)&&0===(2064&t.flags)||Vl||(Vl=!0,Ad(rr,function(){return wd(),null})),a=0!==(15990&t.flags),0!==(15990&t.subtreeFlags)||a){a=zl.transition,zl.transition=null;var s=br;br=1;var l=El;El|=4,Cl.current=null,function(e,r){if(Xi=Gr,gi(e=ui())){if("selectionStart"in e)var t={start:e.selectionStart,end:e.selectionEnd};else e:{var i=(t=(t=e.ownerDocument)&&t.defaultView||window).getSelection&&t.getSelection();if(i&&0!==i.rangeCount){t=i.anchorNode;var n=i.anchorOffset,a=i.focusNode;i=i.focusOffset;try{t.nodeType,a.nodeType}catch(y){t=null;break e}var s=0,l=-1,d=-1,c=0,u=0,g=e,p=null;r:for(;;){for(var h;g!==t||0!==n&&3!==g.nodeType||(l=s+n),g!==a||0!==i&&3!==g.nodeType||(d=s+i),3===g.nodeType&&(s+=g.nodeValue.length),null!==(h=g.firstChild);)p=g,g=h;for(;;){if(g===e)break r;if(p===t&&++c===n&&(l=s),p===a&&++u===i&&(d=s),null!==(h=g.nextSibling))break;p=(g=p).parentNode}g=h}t=-1===l||-1===d?null:{start:l,end:d}}else t=null}t=t||{start:0,end:0}}else t=null;for(en={focusedElem:e,selectionRange:t},Gr=!1,Zs=r;null!==Zs;)if(e=(r=Zs).child,0!==(1028&r.subtreeFlags)&&null!==e)e.return=r,Zs=e;else for(;null!==Zs;){r=Zs;try{var m=r.alternate;if(0!==(1024&r.flags))switch(r.tag){case 0:case 11:case 15:case 5:case 6:case 4:case 17:break;case 1:if(null!==m){var f=m.memoizedProps,x=m.memoizedState,v=r.stateNode,b=v.getSnapshotBeforeUpdate(r.elementType===r.type?f:ts(r.type,f),x);v.__reactInternalSnapshotBeforeUpdate=b}break;case 3:var j=r.stateNode.containerInfo;1===j.nodeType?j.textContent="":9===j.nodeType&&j.documentElement&&j.removeChild(j.documentElement);break;default:throw Error(o(163))}}catch(y){_d(r,r.return,y)}if(null!==(e=r.sibling)){e.return=r.return,Zs=e;break}Zs=r.return}m=rl,rl=!1}(e,t),fl(t,e),pi(en),Gr=!!Xi,en=Xi=null,e.current=t,vl(t,e,n),Ye(),El=l,br=s,zl.transition=a}else e.current=t;if(Vl&&(Vl=!1,Ql=e,Kl=n),a=e.pendingLanes,0===a&&(Hl=null),function(e){if(or&&"function"===typeof or.onCommitFiberRoot)try{or.onCommitFiberRoot(nr,e,void 0,128===(128&e.current.flags))}catch(r){}}(t.stateNode),id(e,Je()),null!==r)for(i=e.onRecoverableError,t=0;t<r.length;t++)n=r[t],i(n.value,{componentStack:n.stack,digest:n.digest});if(Gl)throw Gl=!1,e=Wl,Wl=null,e;0!==(1&Kl)&&0!==e.tag&&wd(),a=e.pendingLanes,0!==(1&a)?e===Jl?Yl++:(Yl=0,Jl=e):Yl=0,Un()}(e,r,t,i)}finally{zl.transition=n,br=i}return null}function wd(){if(null!==Ql){var e=jr(Kl),r=zl.transition,t=br;try{if(zl.transition=null,br=16>e?16:e,null===Ql)var i=!1;else{if(e=Ql,Ql=null,Kl=0,0!==(6&El))throw Error(o(331));var n=El;for(El|=4,Zs=e.current;null!==Zs;){var a=Zs,s=a.child;if(0!==(16&Zs.flags)){var l=a.deletions;if(null!==l){for(var d=0;d<l.length;d++){var c=l[d];for(Zs=c;null!==Zs;){var u=Zs;switch(u.tag){case 0:case 11:case 15:tl(8,u,a)}var g=u.child;if(null!==g)g.return=u,Zs=g;else for(;null!==Zs;){var p=(u=Zs).sibling,h=u.return;if(ol(u),u===c){Zs=null;break}if(null!==p){p.return=h,Zs=p;break}Zs=h}}}var m=a.alternate;if(null!==m){var f=m.child;if(null!==f){m.child=null;do{var x=f.sibling;f.sibling=null,f=x}while(null!==f)}}Zs=a}}if(0!==(2064&a.subtreeFlags)&&null!==s)s.return=a,Zs=s;else e:for(;null!==Zs;){if(0!==(2048&(a=Zs).flags))switch(a.tag){case 0:case 11:case 15:tl(9,a,a.return)}var v=a.sibling;if(null!==v){v.return=a.return,Zs=v;break e}Zs=a.return}}var b=e.current;for(Zs=b;null!==Zs;){var j=(s=Zs).child;if(0!==(2064&s.subtreeFlags)&&null!==j)j.return=s,Zs=j;else e:for(s=b;null!==Zs;){if(0!==(2048&(l=Zs).flags))try{switch(l.tag){case 0:case 11:case 15:il(9,l)}}catch(w){_d(l,l.return,w)}if(l===s){Zs=null;break e}var y=l.sibling;if(null!==y){y.return=l.return,Zs=y;break e}Zs=l.return}}if(El=n,Un(),or&&"function"===typeof or.onPostCommitFiberRoot)try{or.onPostCommitFiberRoot(nr,e)}catch(w){}i=!0}return i}finally{br=t,zl.transition=r}}return!1}function kd(e,r,t){e=Do(e,r=ps(0,r=ds(t,r),1),1),r=ed(),null!==e&&(xr(e,1,r),id(e,r))}function _d(e,r,t){if(3===e.tag)kd(e,e,t);else for(;null!==r;){if(3===r.tag){kd(r,e,t);break}if(1===r.tag){var i=r.stateNode;if("function"===typeof r.type.getDerivedStateFromError||"function"===typeof i.componentDidCatch&&(null===Hl||!Hl.has(i))){r=Do(r,e=hs(r,e=ds(t,e),1),1),e=ed(),null!==r&&(xr(r,1,e),id(r,e));break}}r=r.return}}function Sd(e,r,t){var i=e.pingCache;null!==i&&i.delete(r),r=ed(),e.pingedLanes|=e.suspendedLanes&t,Al===e&&(Nl&t)===t&&(4===Pl||3===Pl&&(130023424&Nl)===Nl&&500>Je()-Fl?gd(e,0):Ll|=t),id(e,r)}function Cd(e,r){0===r&&(0===(1&e.mode)?r=1:(r=cr,0===(130023424&(cr<<=1))&&(cr=4194304)));var t=ed();null!==(e=$o(e,r))&&(xr(e,r,t),id(e,t))}function zd(e){var r=e.memoizedState,t=0;null!==r&&(t=r.retryLane),Cd(e,t)}function Ed(e,r){var t=0;switch(e.tag){case 13:var i=e.stateNode,n=e.memoizedState;null!==n&&(t=n.retryLane);break;case 19:i=e.stateNode;break;default:throw Error(o(314))}null!==i&&i.delete(r),Cd(e,t)}function Ad(e,r){return Ve(e,r)}function Rd(e,r,t,i){this.tag=e,this.key=t,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=r,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=i,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Nd(e,r,t,i){return new Rd(e,r,t,i)}function Td(e){return!(!(e=e.prototype)||!e.isReactComponent)}function qd(e,r){var t=e.alternate;return null===t?((t=Nd(e.tag,r,e.key,e.mode)).elementType=e.elementType,t.type=e.type,t.stateNode=e.stateNode,t.alternate=e,e.alternate=t):(t.pendingProps=r,t.type=e.type,t.flags=0,t.subtreeFlags=0,t.deletions=null),t.flags=14680064&e.flags,t.childLanes=e.childLanes,t.lanes=e.lanes,t.child=e.child,t.memoizedProps=e.memoizedProps,t.memoizedState=e.memoizedState,t.updateQueue=e.updateQueue,r=e.dependencies,t.dependencies=null===r?null:{lanes:r.lanes,firstContext:r.firstContext},t.sibling=e.sibling,t.index=e.index,t.ref=e.ref,t}function Pd(e,r,t,i,n,a){var s=2;if(i=e,"function"===typeof e)Td(e)&&(s=1);else if("string"===typeof e)s=5;else e:switch(e){case k:return $d(t.children,n,a,r);case _:s=8,n|=8;break;case S:return(e=Nd(12,t,r,2|n)).elementType=S,e.lanes=a,e;case A:return(e=Nd(13,t,r,n)).elementType=A,e.lanes=a,e;case R:return(e=Nd(19,t,r,n)).elementType=R,e.lanes=a,e;case q:return Id(t,n,a,r);default:if("object"===typeof e&&null!==e)switch(e.$$typeof){case C:s=10;break e;case z:s=9;break e;case E:s=11;break e;case N:s=14;break e;case T:s=16,i=null;break e}throw Error(o(130,null==e?e:typeof e,""))}return(r=Nd(s,t,r,n)).elementType=e,r.type=i,r.lanes=a,r}function $d(e,r,t,i){return(e=Nd(7,e,i,r)).lanes=t,e}function Id(e,r,t,i){return(e=Nd(22,e,i,r)).elementType=q,e.lanes=t,e.stateNode={isHidden:!1},e}function Od(e,r,t){return(e=Nd(6,e,null,r)).lanes=t,e}function Ld(e,r,t){return(r=Nd(4,null!==e.children?e.children:[],e.key,r)).lanes=t,r.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},r}function Md(e,r,t,i,n){this.tag=r,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=fr(0),this.expirationTimes=fr(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=fr(0),this.identifierPrefix=i,this.onRecoverableError=n,this.mutableSourceEagerHydrationData=null}function Dd(e,r,t,i,n,o,a,s,l){return e=new Md(e,r,t,s,l),1===r?(r=1,!0===o&&(r|=8)):r=0,o=Nd(3,null,null,r),e.current=o,o.stateNode=e,o.memoizedState={element:i,isDehydrated:t,cache:null,transitions:null,pendingSuspenseBoundaries:null},Oo(o),e}function Fd(e){if(!e)return zn;e:{if(Ue(e=e._reactInternals)!==e||1!==e.tag)throw Error(o(170));var r=e;do{switch(r.tag){case 3:r=r.stateNode.context;break e;case 1:if(Tn(r.type)){r=r.stateNode.__reactInternalMemoizedMergedChildContext;break e}}r=r.return}while(null!==r);throw Error(o(171))}if(1===e.tag){var t=e.type;if(Tn(t))return $n(e,t,r)}return r}function Ud(e,r,t,i,n,o,a,s,l){return(e=Dd(t,i,!0,e,0,o,0,s,l)).context=Fd(null),t=e.current,(o=Mo(i=ed(),n=rd(t))).callback=void 0!==r&&null!==r?r:null,Do(t,o,n),e.current.lanes=n,xr(e,n,i),id(e,i),e}function Bd(e,r,t,i){var n=r.current,o=ed(),a=rd(n);return t=Fd(t),null===r.context?r.context=t:r.pendingContext=t,(r=Mo(o,a)).payload={element:e},null!==(i=void 0===i?null:i)&&(r.callback=i),null!==(e=Do(n,r,a))&&(td(e,n,a,o),Fo(e,n,a)),a}function Gd(e){return(e=e.current).child?(e.child.tag,e.child.stateNode):null}function Wd(e,r){if(null!==(e=e.memoizedState)&&null!==e.dehydrated){var t=e.retryLane;e.retryLane=0!==t&&t<r?t:r}}function Hd(e,r){Wd(e,r),(e=e.alternate)&&Wd(e,r)}kl=function(e,r,t){if(null!==e)if(e.memoizedProps!==r.pendingProps||An.current)bs=!0;else{if(0===(e.lanes&t)&&0===(128&r.flags))return bs=!1,function(e,r,t){switch(r.tag){case 3:As(r),ho();break;case 5:Zo(r);break;case 1:Tn(r.type)&&In(r);break;case 4:Yo(r,r.stateNode.containerInfo);break;case 10:var i=r.type._context,n=r.memoizedProps.value;Cn(ko,i._currentValue),i._currentValue=n;break;case 13:if(null!==(i=r.memoizedState))return null!==i.dehydrated?(Cn(ea,1&ea.current),r.flags|=128,null):0!==(t&r.child.childLanes)?Os(e,r,t):(Cn(ea,1&ea.current),null!==(e=Gs(e,r,t))?e.sibling:null);Cn(ea,1&ea.current);break;case 19:if(i=0!==(t&r.childLanes),0!==(128&e.flags)){if(i)return Us(e,r,t);r.flags|=128}if(null!==(n=r.memoizedState)&&(n.rendering=null,n.tail=null,n.lastEffect=null),Cn(ea,ea.current),i)break;return null;case 22:case 23:return r.lanes=0,_s(e,r,t)}return Gs(e,r,t)}(e,r,t);bs=0!==(131072&e.flags)}else bs=!1,no&&0!==(1048576&r.flags)&&Xn(r,Hn,r.index);switch(r.lanes=0,r.tag){case 2:var i=r.type;Bs(e,r),e=r.pendingProps;var n=Nn(r,En.current);Ro(r,t),n=fa(null,r,i,e,n,t);var a=xa();return r.flags|=1,"object"===typeof n&&null!==n&&"function"===typeof n.render&&void 0===n.$$typeof?(r.tag=1,r.memoizedState=null,r.updateQueue=null,Tn(i)?(a=!0,In(r)):a=!1,r.memoizedState=null!==n.state&&void 0!==n.state?n.state:null,Oo(r),n.updater=ns,r.stateNode=n,n._reactInternals=r,ls(r,i,e,t),r=Es(null,r,i,!0,a,t)):(r.tag=0,no&&a&&eo(r),js(null,r,n,t),r=r.child),r;case 16:i=r.elementType;e:{switch(Bs(e,r),e=r.pendingProps,i=(n=i._init)(i._payload),r.type=i,n=r.tag=function(e){if("function"===typeof e)return Td(e)?1:0;if(void 0!==e&&null!==e){if((e=e.$$typeof)===E)return 11;if(e===N)return 14}return 2}(i),e=ts(i,e),n){case 0:r=Cs(null,r,i,e,t);break e;case 1:r=zs(null,r,i,e,t);break e;case 11:r=ys(null,r,i,e,t);break e;case 14:r=ws(null,r,i,ts(i.type,e),t);break e}throw Error(o(306,i,""))}return r;case 0:return i=r.type,n=r.pendingProps,Cs(e,r,i,n=r.elementType===i?n:ts(i,n),t);case 1:return i=r.type,n=r.pendingProps,zs(e,r,i,n=r.elementType===i?n:ts(i,n),t);case 3:e:{if(As(r),null===e)throw Error(o(387));i=r.pendingProps,n=(a=r.memoizedState).element,Lo(e,r),Bo(r,i,null,t);var s=r.memoizedState;if(i=s.element,a.isDehydrated){if(a={element:i,isDehydrated:!1,cache:s.cache,pendingSuspenseBoundaries:s.pendingSuspenseBoundaries,transitions:s.transitions},r.updateQueue.baseState=a,r.memoizedState=a,256&r.flags){r=Rs(e,r,i,t,n=ds(Error(o(423)),r));break e}if(i!==n){r=Rs(e,r,i,t,n=ds(Error(o(424)),r));break e}for(io=dn(r.stateNode.containerInfo.firstChild),to=r,no=!0,oo=null,t=wo(r,null,i,t),r.child=t;t;)t.flags=-3&t.flags|4096,t=t.sibling}else{if(ho(),i===n){r=Gs(e,r,t);break e}js(e,r,i,t)}r=r.child}return r;case 5:return Zo(r),null===e&&co(r),i=r.type,n=r.pendingProps,a=null!==e?e.memoizedProps:null,s=n.children,rn(i,n)?s=null:null!==a&&rn(i,a)&&(r.flags|=32),Ss(e,r),js(e,r,s,t),r.child;case 6:return null===e&&co(r),null;case 13:return Os(e,r,t);case 4:return Yo(r,r.stateNode.containerInfo),i=r.pendingProps,null===e?r.child=yo(r,null,i,t):js(e,r,i,t),r.child;case 11:return i=r.type,n=r.pendingProps,ys(e,r,i,n=r.elementType===i?n:ts(i,n),t);case 7:return js(e,r,r.pendingProps,t),r.child;case 8:case 12:return js(e,r,r.pendingProps.children,t),r.child;case 10:e:{if(i=r.type._context,n=r.pendingProps,a=r.memoizedProps,s=n.value,Cn(ko,i._currentValue),i._currentValue=s,null!==a)if(ai(a.value,s)){if(a.children===n.children&&!An.current){r=Gs(e,r,t);break e}}else for(null!==(a=r.child)&&(a.return=r);null!==a;){var l=a.dependencies;if(null!==l){s=a.child;for(var d=l.firstContext;null!==d;){if(d.context===i){if(1===a.tag){(d=Mo(-1,t&-t)).tag=2;var c=a.updateQueue;if(null!==c){var u=(c=c.shared).pending;null===u?d.next=d:(d.next=u.next,u.next=d),c.pending=d}}a.lanes|=t,null!==(d=a.alternate)&&(d.lanes|=t),Ao(a.return,t,r),l.lanes|=t;break}d=d.next}}else if(10===a.tag)s=a.type===r.type?null:a.child;else if(18===a.tag){if(null===(s=a.return))throw Error(o(341));s.lanes|=t,null!==(l=s.alternate)&&(l.lanes|=t),Ao(s,t,r),s=a.sibling}else s=a.child;if(null!==s)s.return=a;else for(s=a;null!==s;){if(s===r){s=null;break}if(null!==(a=s.sibling)){a.return=s.return,s=a;break}s=s.return}a=s}js(e,r,n.children,t),r=r.child}return r;case 9:return n=r.type,i=r.pendingProps.children,Ro(r,t),i=i(n=No(n)),r.flags|=1,js(e,r,i,t),r.child;case 14:return n=ts(i=r.type,r.pendingProps),ws(e,r,i,n=ts(i.type,n),t);case 15:return ks(e,r,r.type,r.pendingProps,t);case 17:return i=r.type,n=r.pendingProps,n=r.elementType===i?n:ts(i,n),Bs(e,r),r.tag=1,Tn(i)?(e=!0,In(r)):e=!1,Ro(r,t),as(r,i,n),ls(r,i,n,t),Es(null,r,i,!0,e,t);case 19:return Us(e,r,t);case 22:return _s(e,r,t)}throw Error(o(156,r.tag))};var Vd="function"===typeof reportError?reportError:function(e){console.error(e)};function Qd(e){this._internalRoot=e}function Kd(e){this._internalRoot=e}function Yd(e){return!(!e||1!==e.nodeType&&9!==e.nodeType&&11!==e.nodeType)}function Jd(e){return!(!e||1!==e.nodeType&&9!==e.nodeType&&11!==e.nodeType&&(8!==e.nodeType||" react-mount-point-unstable "!==e.nodeValue))}function Zd(){}function Xd(e,r,t,i,n){var o=t._reactRootContainer;if(o){var a=o;if("function"===typeof n){var s=n;n=function(){var e=Gd(a);s.call(e)}}Bd(r,a,e,n)}else a=function(e,r,t,i,n){if(n){if("function"===typeof i){var o=i;i=function(){var e=Gd(a);o.call(e)}}var a=Ud(r,i,e,0,null,!1,0,"",Zd);return e._reactRootContainer=a,e[hn]=a.current,Fi(8===e.nodeType?e.parentNode:e),cd(),a}for(;n=e.lastChild;)e.removeChild(n);if("function"===typeof i){var s=i;i=function(){var e=Gd(l);s.call(e)}}var l=Dd(e,0,!1,null,0,!1,0,"",Zd);return e._reactRootContainer=l,e[hn]=l.current,Fi(8===e.nodeType?e.parentNode:e),cd(function(){Bd(r,l,t,i)}),l}(t,r,e,n,i);return Gd(a)}Kd.prototype.render=Qd.prototype.render=function(e){var r=this._internalRoot;if(null===r)throw Error(o(409));Bd(e,r,null,null)},Kd.prototype.unmount=Qd.prototype.unmount=function(){var e=this._internalRoot;if(null!==e){this._internalRoot=null;var r=e.containerInfo;cd(function(){Bd(null,e,null,null)}),r[hn]=null}},Kd.prototype.unstable_scheduleHydration=function(e){if(e){var r=_r();e={blockedOn:null,target:e,priority:r};for(var t=0;t<qr.length&&0!==r&&r<qr[t].priority;t++);qr.splice(t,0,e),0===t&&Or(e)}},yr=function(e){switch(e.tag){case 3:var r=e.stateNode;if(r.current.memoizedState.isDehydrated){var t=ur(r.pendingLanes);0!==t&&(vr(r,1|t),id(r,Je()),0===(6&El)&&(Ul=Je()+500,Un()))}break;case 13:cd(function(){var r=$o(e,1);if(null!==r){var t=ed();td(r,e,1,t)}}),Hd(e,1)}},wr=function(e){if(13===e.tag){var r=$o(e,134217728);if(null!==r)td(r,e,134217728,ed());Hd(e,134217728)}},kr=function(e){if(13===e.tag){var r=rd(e),t=$o(e,r);if(null!==t)td(t,e,r,ed());Hd(e,r)}},_r=function(){return br},Sr=function(e,r){var t=br;try{return br=e,r()}finally{br=t}},we=function(e,r,t){switch(r){case"input":if(Z(e,t),r=t.name,"radio"===t.type&&null!=r){for(t=e;t.parentNode;)t=t.parentNode;for(t=t.querySelectorAll("input[name="+JSON.stringify(""+r)+'][type="radio"]'),r=0;r<t.length;r++){var i=t[r];if(i!==e&&i.form===e.form){var n=yn(i);if(!n)throw Error(o(90));V(i),Z(i,n)}}}break;case"textarea":oe(e,t);break;case"select":null!=(r=t.value)&&te(e,!!t.multiple,r,!1)}},Ee=dd,Ae=cd;var ec={usingClientEntryPoint:!1,Events:[bn,jn,yn,Ce,ze,dd]},rc={findFiberByHostInstance:vn,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},tc={bundleType:rc.bundleType,version:rc.version,rendererPackageName:rc.rendererPackageName,rendererConfig:rc.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:j.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return null===(e=We(e))?null:e.stateNode},findFiberByHostInstance:rc.findFiberByHostInstance||function(){return null},findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var ic=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!ic.isDisabled&&ic.supportsFiber)try{nr=ic.inject(tc),or=ic}catch(ce){}}r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ec,r.createPortal=function(e,r){var t=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!Yd(r))throw Error(o(200));return function(e,r,t){var i=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return{$$typeof:w,key:null==i?null:""+i,children:e,containerInfo:r,implementation:t}}(e,r,null,t)},r.createRoot=function(e,r){if(!Yd(e))throw Error(o(299));var t=!1,i="",n=Vd;return null!==r&&void 0!==r&&(!0===r.unstable_strictMode&&(t=!0),void 0!==r.identifierPrefix&&(i=r.identifierPrefix),void 0!==r.onRecoverableError&&(n=r.onRecoverableError)),r=Dd(e,1,!1,null,0,t,0,i,n),e[hn]=r.current,Fi(8===e.nodeType?e.parentNode:e),new Qd(r)},r.findDOMNode=function(e){if(null==e)return null;if(1===e.nodeType)return e;var r=e._reactInternals;if(void 0===r){if("function"===typeof e.render)throw Error(o(188));throw e=Object.keys(e).join(","),Error(o(268,e))}return e=null===(e=We(r))?null:e.stateNode},r.flushSync=function(e){return cd(e)},r.hydrate=function(e,r,t){if(!Jd(r))throw Error(o(200));return Xd(null,e,r,!0,t)},r.hydrateRoot=function(e,r,t){if(!Yd(e))throw Error(o(405));var i=null!=t&&t.hydratedSources||null,n=!1,a="",s=Vd;if(null!==t&&void 0!==t&&(!0===t.unstable_strictMode&&(n=!0),void 0!==t.identifierPrefix&&(a=t.identifierPrefix),void 0!==t.onRecoverableError&&(s=t.onRecoverableError)),r=Ud(r,null,e,1,null!=t?t:null,n,0,a,s),e[hn]=r.current,Fi(e),i)for(e=0;e<i.length;e++)n=(n=(t=i[e])._getVersion)(t._source),null==r.mutableSourceEagerHydrationData?r.mutableSourceEagerHydrationData=[t,n]:r.mutableSourceEagerHydrationData.push(t,n);return new Kd(r)},r.render=function(e,r,t){if(!Jd(r))throw Error(o(200));return Xd(null,e,r,!1,t)},r.unmountComponentAtNode=function(e){if(!Jd(e))throw Error(o(40));return!!e._reactRootContainer&&(cd(function(){Xd(null,null,e,!1,function(){e._reactRootContainer=null,e[hn]=null})}),!0)},r.unstable_batchedUpdates=dd,r.unstable_renderSubtreeIntoContainer=function(e,r,t,i){if(!Jd(t))throw Error(o(200));if(null==e||void 0===e._reactInternals)throw Error(o(38));return Xd(e,r,t,!1,i)},r.version="18.3.1-next-f1338f8080-20240426"},763:(e,r,t)=>{"use strict";e.exports=t(983)},853:(e,r,t)=>{"use strict";e.exports=t(234)},950:(e,r,t)=>{"use strict";!function e(){if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__&&"function"===typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE)try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(e)}catch(r){console.error(r)}}(),e.exports=t(730)},983:(e,r)=>{"use strict";var t="function"===typeof Symbol&&Symbol.for,i=t?Symbol.for("react.element"):60103,n=t?Symbol.for("react.portal"):60106,o=t?Symbol.for("react.fragment"):60107,a=t?Symbol.for("react.strict_mode"):60108,s=t?Symbol.for("react.profiler"):60114,l=t?Symbol.for("react.provider"):60109,d=t?Symbol.for("react.context"):60110,c=t?Symbol.for("react.async_mode"):60111,u=t?Symbol.for("react.concurrent_mode"):60111,g=t?Symbol.for("react.forward_ref"):60112,p=t?Symbol.for("react.suspense"):60113,h=t?Symbol.for("react.suspense_list"):60120,m=t?Symbol.for("react.memo"):60115,f=t?Symbol.for("react.lazy"):60116,x=t?Symbol.for("react.block"):60121,v=t?Symbol.for("react.fundamental"):60117,b=t?Symbol.for("react.responder"):60118,j=t?Symbol.for("react.scope"):60119;function y(e){if("object"===typeof e&&null!==e){var r=e.$$typeof;switch(r){case i:switch(e=e.type){case c:case u:case o:case s:case a:case p:return e;default:switch(e=e&&e.$$typeof){case d:case g:case f:case m:case l:return e;default:return r}}case n:return r}}}function w(e){return y(e)===u}r.AsyncMode=c,r.ConcurrentMode=u,r.ContextConsumer=d,r.ContextProvider=l,r.Element=i,r.ForwardRef=g,r.Fragment=o,r.Lazy=f,r.Memo=m,r.Portal=n,r.Profiler=s,r.StrictMode=a,r.Suspense=p,r.isAsyncMode=function(e){return w(e)||y(e)===c},r.isConcurrentMode=w,r.isContextConsumer=function(e){return y(e)===d},r.isContextProvider=function(e){return y(e)===l},r.isElement=function(e){return"object"===typeof e&&null!==e&&e.$$typeof===i},r.isForwardRef=function(e){return y(e)===g},r.isFragment=function(e){return y(e)===o},r.isLazy=function(e){return y(e)===f},r.isMemo=function(e){return y(e)===m},r.isPortal=function(e){return y(e)===n},r.isProfiler=function(e){return y(e)===s},r.isStrictMode=function(e){return y(e)===a},r.isSuspense=function(e){return y(e)===p},r.isValidElementType=function(e){return"string"===typeof e||"function"===typeof e||e===o||e===u||e===s||e===a||e===p||e===h||"object"===typeof e&&null!==e&&(e.$$typeof===f||e.$$typeof===m||e.$$typeof===l||e.$$typeof===d||e.$$typeof===g||e.$$typeof===v||e.$$typeof===b||e.$$typeof===j||e.$$typeof===x)},r.typeOf=y}},r={};function t(i){var n=r[i];if(void 0!==n)return n.exports;var o=r[i]={exports:{}};return e[i](o,o.exports,t),o.exports}t.n=e=>{var r=e&&e.__esModule?()=>e.default:()=>e;return t.d(r,{a:r}),r},(()=>{var e,r=Object.getPrototypeOf?e=>Object.getPrototypeOf(e):e=>e.__proto__;t.t=function(i,n){if(1&n&&(i=this(i)),8&n)return i;if("object"===typeof i&&i){if(4&n&&i.__esModule)return i;if(16&n&&"function"===typeof i.then)return i}var o=Object.create(null);t.r(o);var a={};e=e||[null,r({}),r([]),r(r)];for(var s=2&n&&i;("object"==typeof s||"function"==typeof s)&&!~e.indexOf(s);s=r(s))Object.getOwnPropertyNames(s).forEach(e=>a[e]=()=>i[e]);return a.default=()=>i,t.d(o,a),o}})(),t.d=(e,r)=>{for(var i in r)t.o(r,i)&&!t.o(e,i)&&Object.defineProperty(e,i,{enumerable:!0,get:r[i]})},t.o=(e,r)=>Object.prototype.hasOwnProperty.call(e,r),t.r=e=>{"undefined"!==typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},t.nc=void 0,(()=>{"use strict";var e={};t.r(e),t.d(e,{hasBrowserEnv:()=>td,hasStandardBrowserEnv:()=>nd,hasStandardBrowserWebWorkerEnv:()=>od,navigator:()=>id,origin:()=>ad});var r=t(43),i=t.t(r,2),n=t(391),o=t(528),a=t(324),s=t.n(a);const l=function(e){function r(e,i,l,d,g){for(var p,h,m,f,j,w=0,k=0,_=0,S=0,C=0,T=0,P=m=p=0,I=0,O=0,L=0,M=0,D=l.length,F=D-1,U="",B="",G="",W="";I<D;){if(h=l.charCodeAt(I),I===F&&0!==k+S+_+w&&(0!==k&&(h=47===k?10:47),S=_=w=0,D++,F++),0===k+S+_+w){if(I===F&&(0<O&&(U=U.replace(u,"")),0<U.trim().length)){switch(h){case 32:case 9:case 59:case 13:case 10:break;default:U+=l.charAt(I)}h=59}switch(h){case 123:for(p=(U=U.trim()).charCodeAt(0),m=1,M=++I;I<D;){switch(h=l.charCodeAt(I)){case 123:m++;break;case 125:m--;break;case 47:switch(h=l.charCodeAt(I+1)){case 42:case 47:e:{for(P=I+1;P<F;++P)switch(l.charCodeAt(P)){case 47:if(42===h&&42===l.charCodeAt(P-1)&&I+2!==P){I=P+1;break e}break;case 10:if(47===h){I=P+1;break e}}I=P}}break;case 91:h++;case 40:h++;case 34:case 39:for(;I++<F&&l.charCodeAt(I)!==h;);}if(0===m)break;I++}if(m=l.substring(M,I),0===p&&(p=(U=U.replace(c,"").trim()).charCodeAt(0)),64===p){switch(0<O&&(U=U.replace(u,"")),h=U.charCodeAt(1)){case 100:case 109:case 115:case 45:O=i;break;default:O=N}if(M=(m=r(i,O,m,h,g+1)).length,0<q&&(j=s(3,m,O=t(N,U,L),i,E,z,M,h,g,d),U=O.join(""),void 0!==j&&0===(M=(m=j.trim()).length)&&(h=0,m="")),0<M)switch(h){case 115:U=U.replace(y,a);case 100:case 109:case 45:m=U+"{"+m+"}";break;case 107:m=(U=U.replace(x,"$1 $2"))+"{"+m+"}",m=1===R||2===R&&o("@"+m,3)?"@-webkit-"+m+"@"+m:"@"+m;break;default:m=U+m,112===d&&(B+=m,m="")}else m=""}else m=r(i,t(i,U,L),m,d,g+1);G+=m,m=L=O=P=p=0,U="",h=l.charCodeAt(++I);break;case 125:case 59:if(1<(M=(U=(0<O?U.replace(u,""):U).trim()).length))switch(0===P&&(p=U.charCodeAt(0),45===p||96<p&&123>p)&&(M=(U=U.replace(" ",":")).length),0<q&&void 0!==(j=s(1,U,i,e,E,z,B.length,d,g,d))&&0===(M=(U=j.trim()).length)&&(U="\0\0"),p=U.charCodeAt(0),h=U.charCodeAt(1),p){case 0:break;case 64:if(105===h||99===h){W+=U+l.charAt(I);break}default:58!==U.charCodeAt(M-1)&&(B+=n(U,p,h,U.charCodeAt(2)))}L=O=P=p=0,U="",h=l.charCodeAt(++I)}}switch(h){case 13:case 10:47===k?k=0:0===1+p&&107!==d&&0<U.length&&(O=1,U+="\0"),0<q*$&&s(0,U,i,e,E,z,B.length,d,g,d),z=1,E++;break;case 59:case 125:if(0===k+S+_+w){z++;break}default:switch(z++,f=l.charAt(I),h){case 9:case 32:if(0===S+w+k)switch(C){case 44:case 58:case 9:case 32:f="";break;default:32!==h&&(f=" ")}break;case 0:f="\\0";break;case 12:f="\\f";break;case 11:f="\\v";break;case 38:0===S+k+w&&(O=L=1,f="\f"+f);break;case 108:if(0===S+k+w+A&&0<P)switch(I-P){case 2:112===C&&58===l.charCodeAt(I-3)&&(A=C);case 8:111===T&&(A=T)}break;case 58:0===S+k+w&&(P=I);break;case 44:0===k+_+S+w&&(O=1,f+="\r");break;case 34:case 39:0===k&&(S=S===h?0:0===S?h:S);break;case 91:0===S+k+_&&w++;break;case 93:0===S+k+_&&w--;break;case 41:0===S+k+w&&_--;break;case 40:if(0===S+k+w){if(0===p)if(2*C+3*T===533);else p=1;_++}break;case 64:0===k+_+S+w+P+m&&(m=1);break;case 42:case 47:if(!(0<S+w+_))switch(k){case 0:switch(2*h+3*l.charCodeAt(I+1)){case 235:k=47;break;case 220:M=I,k=42}break;case 42:47===h&&42===C&&M+2!==I&&(33===l.charCodeAt(M+2)&&(B+=l.substring(M,I+1)),f="",k=0)}}0===k&&(U+=f)}T=C,C=h,I++}if(0<(M=B.length)){if(O=i,0<q&&(void 0!==(j=s(2,B,O,e,E,z,M,d,g,d))&&0===(B=j).length))return W+B+G;if(B=O.join(",")+"{"+B+"}",0!==R*A){switch(2!==R||o(B,2)||(A=0),A){case 111:B=B.replace(b,":-moz-$1")+B;break;case 112:B=B.replace(v,"::-webkit-input-$1")+B.replace(v,"::-moz-$1")+B.replace(v,":-ms-input-$1")+B}A=0}}return W+B+G}function t(e,r,t){var n=r.trim().split(m);r=n;var o=n.length,a=e.length;switch(a){case 0:case 1:var s=0;for(e=0===a?"":e[0]+" ";s<o;++s)r[s]=i(e,r[s],t).trim();break;default:var l=s=0;for(r=[];s<o;++s)for(var d=0;d<a;++d)r[l++]=i(e[d]+" ",n[s],t).trim()}return r}function i(e,r,t){var i=r.charCodeAt(0);switch(33>i&&(i=(r=r.trim()).charCodeAt(0)),i){case 38:return r.replace(f,"$1"+e.trim());case 58:return e.trim()+r.replace(f,"$1"+e.trim());default:if(0<1*t&&0<r.indexOf("\f"))return r.replace(f,(58===e.charCodeAt(0)?"":"$1")+e.trim())}return e+r}function n(e,r,t,i){var a=e+";",s=2*r+3*t+4*i;if(944===s){e=a.indexOf(":",9)+1;var l=a.substring(e,a.length-1).trim();return l=a.substring(0,e).trim()+l+";",1===R||2===R&&o(l,1)?"-webkit-"+l+l:l}if(0===R||2===R&&!o(a,1))return a;switch(s){case 1015:return 97===a.charCodeAt(10)?"-webkit-"+a+a:a;case 951:return 116===a.charCodeAt(3)?"-webkit-"+a+a:a;case 963:return 110===a.charCodeAt(5)?"-webkit-"+a+a:a;case 1009:if(100!==a.charCodeAt(4))break;case 969:case 942:return"-webkit-"+a+a;case 978:return"-webkit-"+a+"-moz-"+a+a;case 1019:case 983:return"-webkit-"+a+"-moz-"+a+"-ms-"+a+a;case 883:if(45===a.charCodeAt(8))return"-webkit-"+a+a;if(0<a.indexOf("image-set(",11))return a.replace(C,"$1-webkit-$2")+a;break;case 932:if(45===a.charCodeAt(4))switch(a.charCodeAt(5)){case 103:return"-webkit-box-"+a.replace("-grow","")+"-webkit-"+a+"-ms-"+a.replace("grow","positive")+a;case 115:return"-webkit-"+a+"-ms-"+a.replace("shrink","negative")+a;case 98:return"-webkit-"+a+"-ms-"+a.replace("basis","preferred-size")+a}return"-webkit-"+a+"-ms-"+a+a;case 964:return"-webkit-"+a+"-ms-flex-"+a+a;case 1023:if(99!==a.charCodeAt(8))break;return"-webkit-box-pack"+(l=a.substring(a.indexOf(":",15)).replace("flex-","").replace("space-between","justify"))+"-webkit-"+a+"-ms-flex-pack"+l+a;case 1005:return p.test(a)?a.replace(g,":-webkit-")+a.replace(g,":-moz-")+a:a;case 1e3:switch(r=(l=a.substring(13).trim()).indexOf("-")+1,l.charCodeAt(0)+l.charCodeAt(r)){case 226:l=a.replace(j,"tb");break;case 232:l=a.replace(j,"tb-rl");break;case 220:l=a.replace(j,"lr");break;default:return a}return"-webkit-"+a+"-ms-"+l+a;case 1017:if(-1===a.indexOf("sticky",9))break;case 975:switch(r=(a=e).length-10,s=(l=(33===a.charCodeAt(r)?a.substring(0,r):a).substring(e.indexOf(":",7)+1).trim()).charCodeAt(0)+(0|l.charCodeAt(7))){case 203:if(111>l.charCodeAt(8))break;case 115:a=a.replace(l,"-webkit-"+l)+";"+a;break;case 207:case 102:a=a.replace(l,"-webkit-"+(102<s?"inline-":"")+"box")+";"+a.replace(l,"-webkit-"+l)+";"+a.replace(l,"-ms-"+l+"box")+";"+a}return a+";";case 938:if(45===a.charCodeAt(5))switch(a.charCodeAt(6)){case 105:return l=a.replace("-items",""),"-webkit-"+a+"-webkit-box-"+l+"-ms-flex-"+l+a;case 115:return"-webkit-"+a+"-ms-flex-item-"+a.replace(k,"")+a;default:return"-webkit-"+a+"-ms-flex-line-pack"+a.replace("align-content","").replace(k,"")+a}break;case 973:case 989:if(45!==a.charCodeAt(3)||122===a.charCodeAt(4))break;case 931:case 953:if(!0===S.test(e))return 115===(l=e.substring(e.indexOf(":")+1)).charCodeAt(0)?n(e.replace("stretch","fill-available"),r,t,i).replace(":fill-available",":stretch"):a.replace(l,"-webkit-"+l)+a.replace(l,"-moz-"+l.replace("fill-",""))+a;break;case 962:if(a="-webkit-"+a+(102===a.charCodeAt(5)?"-ms-"+a:"")+a,211===t+i&&105===a.charCodeAt(13)&&0<a.indexOf("transform",10))return a.substring(0,a.indexOf(";",27)+1).replace(h,"$1-webkit-$2")+a}return a}function o(e,r){var t=e.indexOf(1===r?":":"{"),i=e.substring(0,3!==r?t:10);return t=e.substring(t+1,e.length-1),P(2!==r?i:i.replace(_,"$1"),t,r)}function a(e,r){var t=n(r,r.charCodeAt(0),r.charCodeAt(1),r.charCodeAt(2));return t!==r+";"?t.replace(w," or ($1)").substring(4):"("+r+")"}function s(e,r,t,i,n,o,a,s,l,c){for(var u,g=0,p=r;g<q;++g)switch(u=T[g].call(d,e,p,t,i,n,o,a,s,l,c)){case void 0:case!1:case!0:case null:break;default:p=u}if(p!==r)return p}function l(e){return void 0!==(e=e.prefix)&&(P=null,e?"function"!==typeof e?R=1:(R=2,P=e):R=0),l}function d(e,t){var i=e;if(33>i.charCodeAt(0)&&(i=i.trim()),i=[i],0<q){var n=s(-1,t,i,i,E,z,0,0,0,0);void 0!==n&&"string"===typeof n&&(t=n)}var o=r(N,i,t,0,0);return 0<q&&(void 0!==(n=s(-2,o,i,i,E,z,o.length,0,0,0))&&(o=n)),A=0,z=E=1,o}var c=/^\0+/g,u=/[\0\r\f]/g,g=/: */g,p=/zoo|gra/,h=/([,: ])(transform)/g,m=/,\r+?/g,f=/([\t\r\n ])*\f?&/g,x=/@(k\w+)\s*(\S*)\s*/,v=/::(place)/g,b=/:(read-only)/g,j=/[svh]\w+-[tblr]{2}/,y=/\(\s*(.*)\s*\)/g,w=/([\s\S]*?);/g,k=/-self|flex-/g,_=/[^]*?(:[rp][el]a[\w-]+)[^]*/,S=/stretch|:\s*\w+\-(?:conte|avail)/,C=/([^-])(image-set\()/,z=1,E=1,A=0,R=1,N=[],T=[],q=0,P=null,$=0;return d.use=function e(r){switch(r){case void 0:case null:q=T.length=0;break;default:if("function"===typeof r)T[q++]=r;else if("object"===typeof r)for(var t=0,i=r.length;t<i;++t)e(r[t]);else $=0|!!r}return e},d.set=l,void 0!==e&&l(e),d};const d={animationIterationCount:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1};function c(e){var r=Object.create(null);return function(t){return void 0===r[t]&&(r[t]=e(t)),r[t]}}var u=/^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|disableRemotePlayback|download|draggable|encType|enterKeyHint|fetchpriority|fetchPriority|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,g=c(function(e){return u.test(e)||111===e.charCodeAt(0)&&110===e.charCodeAt(1)&&e.charCodeAt(2)<91}),p=t(219),h=t.n(p);function m(){return(m=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])}return e}).apply(this,arguments)}var f=function(e,r){for(var t=[e[0]],i=0,n=r.length;i<n;i+=1)t.push(r[i],e[i+1]);return t},x=function(e){return null!==e&&"object"==typeof e&&"[object Object]"===(e.toString?e.toString():Object.prototype.toString.call(e))&&!(0,o.QP)(e)},v=Object.freeze([]),b=Object.freeze({});function j(e){return"function"==typeof e}function y(e){return e.displayName||e.name||"Component"}function w(e){return e&&"string"==typeof e.styledComponentId}var k="undefined"!=typeof process&&void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}&&({NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.REACT_APP_SC_ATTR||{NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.SC_ATTR)||"data-styled",_="undefined"!=typeof window&&"HTMLElement"in window,S=Boolean("boolean"==typeof SC_DISABLE_SPEEDY?SC_DISABLE_SPEEDY:"undefined"!=typeof process&&void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}&&(void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.REACT_APP_SC_DISABLE_SPEEDY&&""!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.REACT_APP_SC_DISABLE_SPEEDY?"false"!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.REACT_APP_SC_DISABLE_SPEEDY&&{NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.REACT_APP_SC_DISABLE_SPEEDY:void 0!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.SC_DISABLE_SPEEDY&&""!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.SC_DISABLE_SPEEDY&&("false"!=={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.SC_DISABLE_SPEEDY&&{NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.SC_DISABLE_SPEEDY)));function C(e){for(var r=arguments.length,t=new Array(r>1?r-1:0),i=1;i<r;i++)t[i-1]=arguments[i];throw new Error("An error occurred. See https://git.io/JUIaE#"+e+" for more information."+(t.length>0?" Args: "+t.join(", "):""))}var z=function(){function e(e){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=e}var r=e.prototype;return r.indexOfGroup=function(e){for(var r=0,t=0;t<e;t++)r+=this.groupSizes[t];return r},r.insertRules=function(e,r){if(e>=this.groupSizes.length){for(var t=this.groupSizes,i=t.length,n=i;e>=n;)(n<<=1)<0&&C(16,""+e);this.groupSizes=new Uint32Array(n),this.groupSizes.set(t),this.length=n;for(var o=i;o<n;o++)this.groupSizes[o]=0}for(var a=this.indexOfGroup(e+1),s=0,l=r.length;s<l;s++)this.tag.insertRule(a,r[s])&&(this.groupSizes[e]++,a++)},r.clearGroup=function(e){if(e<this.length){var r=this.groupSizes[e],t=this.indexOfGroup(e),i=t+r;this.groupSizes[e]=0;for(var n=t;n<i;n++)this.tag.deleteRule(t)}},r.getGroup=function(e){var r="";if(e>=this.length||0===this.groupSizes[e])return r;for(var t=this.groupSizes[e],i=this.indexOfGroup(e),n=i+t,o=i;o<n;o++)r+=this.tag.getRule(o)+"/*!sc*/\n";return r},e}(),E=new Map,A=new Map,R=1,N=function(e){if(E.has(e))return E.get(e);for(;A.has(R);)R++;var r=R++;return E.set(e,r),A.set(r,e),r},T=function(e){return A.get(e)},q=function(e,r){r>=R&&(R=r+1),E.set(e,r),A.set(r,e)},P="style["+k+'][data-styled-version="5.3.11"]',$=new RegExp("^"+k+'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)'),I=function(e,r,t){for(var i,n=t.split(","),o=0,a=n.length;o<a;o++)(i=n[o])&&e.registerName(r,i)},O=function(e,r){for(var t=(r.textContent||"").split("/*!sc*/\n"),i=[],n=0,o=t.length;n<o;n++){var a=t[n].trim();if(a){var s=a.match($);if(s){var l=0|parseInt(s[1],10),d=s[2];0!==l&&(q(d,l),I(e,d,s[3]),e.getTag().insertRules(l,i)),i.length=0}else i.push(a)}}},L=function(){return t.nc},M=function(e){var r=document.head,t=e||r,i=document.createElement("style"),n=function(e){for(var r=e.childNodes,t=r.length;t>=0;t--){var i=r[t];if(i&&1===i.nodeType&&i.hasAttribute(k))return i}}(t),o=void 0!==n?n.nextSibling:null;i.setAttribute(k,"active"),i.setAttribute("data-styled-version","5.3.11");var a=L();return a&&i.setAttribute("nonce",a),t.insertBefore(i,o),i},D=function(){function e(e){var r=this.element=M(e);r.appendChild(document.createTextNode("")),this.sheet=function(e){if(e.sheet)return e.sheet;for(var r=document.styleSheets,t=0,i=r.length;t<i;t++){var n=r[t];if(n.ownerNode===e)return n}C(17)}(r),this.length=0}var r=e.prototype;return r.insertRule=function(e,r){try{return this.sheet.insertRule(r,e),this.length++,!0}catch(e){return!1}},r.deleteRule=function(e){this.sheet.deleteRule(e),this.length--},r.getRule=function(e){var r=this.sheet.cssRules[e];return void 0!==r&&"string"==typeof r.cssText?r.cssText:""},e}(),F=function(){function e(e){var r=this.element=M(e);this.nodes=r.childNodes,this.length=0}var r=e.prototype;return r.insertRule=function(e,r){if(e<=this.length&&e>=0){var t=document.createTextNode(r),i=this.nodes[e];return this.element.insertBefore(t,i||null),this.length++,!0}return!1},r.deleteRule=function(e){this.element.removeChild(this.nodes[e]),this.length--},r.getRule=function(e){return e<this.length?this.nodes[e].textContent:""},e}(),U=function(){function e(e){this.rules=[],this.length=0}var r=e.prototype;return r.insertRule=function(e,r){return e<=this.length&&(this.rules.splice(e,0,r),this.length++,!0)},r.deleteRule=function(e){this.rules.splice(e,1),this.length--},r.getRule=function(e){return e<this.length?this.rules[e]:""},e}(),B=_,G={isServer:!_,useCSSOMInjection:!S},W=function(){function e(e,r,t){void 0===e&&(e=b),void 0===r&&(r={}),this.options=m({},G,{},e),this.gs=r,this.names=new Map(t),this.server=!!e.isServer,!this.server&&_&&B&&(B=!1,function(e){for(var r=document.querySelectorAll(P),t=0,i=r.length;t<i;t++){var n=r[t];n&&"active"!==n.getAttribute(k)&&(O(e,n),n.parentNode&&n.parentNode.removeChild(n))}}(this))}e.registerId=function(e){return N(e)};var r=e.prototype;return r.reconstructWithOptions=function(r,t){return void 0===t&&(t=!0),new e(m({},this.options,{},r),this.gs,t&&this.names||void 0)},r.allocateGSInstance=function(e){return this.gs[e]=(this.gs[e]||0)+1},r.getTag=function(){return this.tag||(this.tag=(t=(r=this.options).isServer,i=r.useCSSOMInjection,n=r.target,e=t?new U(n):i?new D(n):new F(n),new z(e)));var e,r,t,i,n},r.hasNameForId=function(e,r){return this.names.has(e)&&this.names.get(e).has(r)},r.registerName=function(e,r){if(N(e),this.names.has(e))this.names.get(e).add(r);else{var t=new Set;t.add(r),this.names.set(e,t)}},r.insertRules=function(e,r,t){this.registerName(e,r),this.getTag().insertRules(N(e),t)},r.clearNames=function(e){this.names.has(e)&&this.names.get(e).clear()},r.clearRules=function(e){this.getTag().clearGroup(N(e)),this.clearNames(e)},r.clearTag=function(){this.tag=void 0},r.toString=function(){return function(e){for(var r=e.getTag(),t=r.length,i="",n=0;n<t;n++){var o=T(n);if(void 0!==o){var a=e.names.get(o),s=r.getGroup(n);if(a&&s&&a.size){var l=k+".g"+n+'[id="'+o+'"]',d="";void 0!==a&&a.forEach(function(e){e.length>0&&(d+=e+",")}),i+=""+s+l+'{content:"'+d+'"}/*!sc*/\n'}}}return i}(this)},e}(),H=/(a)(d)/gi,V=function(e){return String.fromCharCode(e+(e>25?39:97))};function Q(e){var r,t="";for(r=Math.abs(e);r>52;r=r/52|0)t=V(r%52)+t;return(V(r%52)+t).replace(H,"$1-$2")}var K=function(e,r){for(var t=r.length;t;)e=33*e^r.charCodeAt(--t);return e},Y=function(e){return K(5381,e)};function J(e){for(var r=0;r<e.length;r+=1){var t=e[r];if(j(t)&&!w(t))return!1}return!0}var Z=Y("5.3.11"),X=function(){function e(e,r,t){this.rules=e,this.staticRulesId="",this.isStatic=(void 0===t||t.isStatic)&&J(e),this.componentId=r,this.baseHash=K(Z,r),this.baseStyle=t,W.registerId(r)}return e.prototype.generateAndInjectStyles=function(e,r,t){var i=this.componentId,n=[];if(this.baseStyle&&n.push(this.baseStyle.generateAndInjectStyles(e,r,t)),this.isStatic&&!t.hash)if(this.staticRulesId&&r.hasNameForId(i,this.staticRulesId))n.push(this.staticRulesId);else{var o=xe(this.rules,e,r,t).join(""),a=Q(K(this.baseHash,o)>>>0);if(!r.hasNameForId(i,a)){var s=t(o,"."+a,void 0,i);r.insertRules(i,a,s)}n.push(a),this.staticRulesId=a}else{for(var l=this.rules.length,d=K(this.baseHash,t.hash),c="",u=0;u<l;u++){var g=this.rules[u];if("string"==typeof g)c+=g;else if(g){var p=xe(g,e,r,t),h=Array.isArray(p)?p.join(""):p;d=K(d,h+u),c+=h}}if(c){var m=Q(d>>>0);if(!r.hasNameForId(i,m)){var f=t(c,"."+m,void 0,i);r.insertRules(i,m,f)}n.push(m)}}return n.join(" ")},e}(),ee=/^\s*\/\/.*$/gm,re=[":","[",".","#"];function te(e){var r,t,i,n,o=void 0===e?b:e,a=o.options,s=void 0===a?b:a,d=o.plugins,c=void 0===d?v:d,u=new l(s),g=[],p=function(e){function r(r){if(r)try{e(r+"}")}catch(e){}}return function(t,i,n,o,a,s,l,d,c,u){switch(t){case 1:if(0===c&&64===i.charCodeAt(0))return e(i+";"),"";break;case 2:if(0===d)return i+"/*|*/";break;case 3:switch(d){case 102:case 112:return e(n[0]+i),"";default:return i+(0===u?"/*|*/":"")}case-2:i.split("/*|*/}").forEach(r)}}}(function(e){g.push(e)}),h=function(e,i,o){return 0===i&&-1!==re.indexOf(o[t.length])||o.match(n)?e:"."+r};function m(e,o,a,s){void 0===s&&(s="&");var l=e.replace(ee,""),d=o&&a?a+" "+o+" { "+l+" }":l;return r=s,t=o,i=new RegExp("\\"+t+"\\b","g"),n=new RegExp("(\\"+t+"\\b){2,}"),u(a||!o?"":o,d)}return u.use([].concat(c,[function(e,r,n){2===e&&n.length&&n[0].lastIndexOf(t)>0&&(n[0]=n[0].replace(i,h))},p,function(e){if(-2===e){var r=g;return g=[],r}}])),m.hash=c.length?c.reduce(function(e,r){return r.name||C(15),K(e,r.name)},5381).toString():"",m}var ie=r.createContext(),ne=(ie.Consumer,r.createContext()),oe=(ne.Consumer,new W),ae=te();function se(){return(0,r.useContext)(ie)||oe}function le(){return(0,r.useContext)(ne)||ae}function de(e){var t=(0,r.useState)(e.stylisPlugins),i=t[0],n=t[1],o=se(),a=(0,r.useMemo)(function(){var r=o;return e.sheet?r=e.sheet:e.target&&(r=r.reconstructWithOptions({target:e.target},!1)),e.disableCSSOMInjection&&(r=r.reconstructWithOptions({useCSSOMInjection:!1})),r},[e.disableCSSOMInjection,e.sheet,e.target]),l=(0,r.useMemo)(function(){return te({options:{prefix:!e.disableVendorPrefixes},plugins:i})},[e.disableVendorPrefixes,i]);return(0,r.useEffect)(function(){s()(i,e.stylisPlugins)||n(e.stylisPlugins)},[e.stylisPlugins]),r.createElement(ie.Provider,{value:a},r.createElement(ne.Provider,{value:l},e.children))}var ce=function(){function e(e,r){var t=this;this.inject=function(e,r){void 0===r&&(r=ae);var i=t.name+r.hash;e.hasNameForId(t.id,i)||e.insertRules(t.id,i,r(t.rules,i,"@keyframes"))},this.toString=function(){return C(12,String(t.name))},this.name=e,this.id="sc-keyframes-"+e,this.rules=r}return e.prototype.getName=function(e){return void 0===e&&(e=ae),this.name+e.hash},e}(),ue=/([A-Z])/,ge=/([A-Z])/g,pe=/^ms-/,he=function(e){return"-"+e.toLowerCase()};function me(e){return ue.test(e)?e.replace(ge,he).replace(pe,"-ms-"):e}var fe=function(e){return null==e||!1===e||""===e};function xe(e,r,t,i){if(Array.isArray(e)){for(var n,o=[],a=0,s=e.length;a<s;a+=1)""!==(n=xe(e[a],r,t,i))&&(Array.isArray(n)?o.push.apply(o,n):o.push(n));return o}return fe(e)?"":w(e)?"."+e.styledComponentId:j(e)?"function"!=typeof(l=e)||l.prototype&&l.prototype.isReactComponent||!r?e:xe(e(r),r,t,i):e instanceof ce?t?(e.inject(t,i),e.getName(i)):e:x(e)?function e(r,t){var i,n,o=[];for(var a in r)r.hasOwnProperty(a)&&!fe(r[a])&&(Array.isArray(r[a])&&r[a].isCss||j(r[a])?o.push(me(a)+":",r[a],";"):x(r[a])?o.push.apply(o,e(r[a],a)):o.push(me(a)+": "+(i=a,(null==(n=r[a])||"boolean"==typeof n||""===n?"":"number"!=typeof n||0===n||i in d||i.startsWith("--")?String(n).trim():n+"px")+";")));return t?[t+" {"].concat(o,["}"]):o}(e):e.toString();var l}var ve=function(e){return Array.isArray(e)&&(e.isCss=!0),e};function be(e){for(var r=arguments.length,t=new Array(r>1?r-1:0),i=1;i<r;i++)t[i-1]=arguments[i];return j(e)||x(e)?ve(xe(f(v,[e].concat(t)))):0===t.length&&1===e.length&&"string"==typeof e[0]?e:ve(xe(f(e,t)))}new Set;var je=function(e,r,t){return void 0===t&&(t=b),e.theme!==t.theme&&e.theme||r||t.theme},ye=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,we=/(^-|-$)/g;function ke(e){return e.replace(ye,"-").replace(we,"")}var _e=function(e){return Q(Y(e)>>>0)};function Se(e){return"string"==typeof e&&!0}var Ce=function(e){return"function"==typeof e||"object"==typeof e&&null!==e&&!Array.isArray(e)},ze=function(e){return"__proto__"!==e&&"constructor"!==e&&"prototype"!==e};function Ee(e,r,t){var i=e[t];Ce(r)&&Ce(i)?Ae(i,r):e[t]=r}function Ae(e){for(var r=arguments.length,t=new Array(r>1?r-1:0),i=1;i<r;i++)t[i-1]=arguments[i];for(var n=0,o=t;n<o.length;n++){var a=o[n];if(Ce(a))for(var s in a)ze(s)&&Ee(e,a[s],s)}return e}var Re=r.createContext();Re.Consumer;function Ne(e){var t=(0,r.useContext)(Re),i=(0,r.useMemo)(function(){return function(e,r){return e?j(e)?e(r):Array.isArray(e)||"object"!=typeof e?C(8):r?m({},r,{},e):e:C(14)}(e.theme,t)},[e.theme,t]);return e.children?r.createElement(Re.Provider,{value:i},e.children):null}var Te={};function qe(e,t,i){var n=w(e),o=!Se(e),a=t.attrs,s=void 0===a?v:a,l=t.componentId,d=void 0===l?function(e,r){var t="string"!=typeof e?"sc":ke(e);Te[t]=(Te[t]||0)+1;var i=t+"-"+_e("5.3.11"+t+Te[t]);return r?r+"-"+i:i}(t.displayName,t.parentComponentId):l,c=t.displayName,u=void 0===c?function(e){return Se(e)?"styled."+e:"Styled("+y(e)+")"}(e):c,p=t.displayName&&t.componentId?ke(t.displayName)+"-"+t.componentId:t.componentId||d,f=n&&e.attrs?Array.prototype.concat(e.attrs,s).filter(Boolean):s,x=t.shouldForwardProp;n&&e.shouldForwardProp&&(x=t.shouldForwardProp?function(r,i,n){return e.shouldForwardProp(r,i,n)&&t.shouldForwardProp(r,i,n)}:e.shouldForwardProp);var k,_=new X(i,p,n?e.componentStyle:void 0),S=_.isStatic&&0===s.length,C=function(e,t){return function(e,t,i,n){var o=e.attrs,a=e.componentStyle,s=e.defaultProps,l=e.foldedComponentIds,d=e.shouldForwardProp,c=e.styledComponentId,u=e.target,p=function(e,r,t){void 0===e&&(e=b);var i=m({},r,{theme:e}),n={};return t.forEach(function(e){var r,t,o,a=e;for(r in j(a)&&(a=a(i)),a)i[r]=n[r]="className"===r?(t=n[r],o=a[r],t&&o?t+" "+o:t||o):a[r]}),[i,n]}(je(t,(0,r.useContext)(Re),s)||b,t,o),h=p[0],f=p[1],x=function(e,r,t){var i=se(),n=le();return r?e.generateAndInjectStyles(b,i,n):e.generateAndInjectStyles(t,i,n)}(a,n,h),v=i,y=f.$as||t.$as||f.as||t.as||u,w=Se(y),k=f!==t?m({},t,{},f):t,_={};for(var S in k)"$"!==S[0]&&"as"!==S&&("forwardedAs"===S?_.as=k[S]:(d?d(S,g,y):!w||g(S))&&(_[S]=k[S]));return t.style&&f.style!==t.style&&(_.style=m({},t.style,{},f.style)),_.className=Array.prototype.concat(l,c,x!==c?x:null,t.className,f.className).filter(Boolean).join(" "),_.ref=v,(0,r.createElement)(y,_)}(k,e,t,S)};return C.displayName=u,(k=r.forwardRef(C)).attrs=f,k.componentStyle=_,k.displayName=u,k.shouldForwardProp=x,k.foldedComponentIds=n?Array.prototype.concat(e.foldedComponentIds,e.styledComponentId):v,k.styledComponentId=p,k.target=n?e.target:e,k.withComponent=function(e){var r=t.componentId,n=function(e,r){if(null==e)return{};var t,i,n={},o=Object.keys(e);for(i=0;i<o.length;i++)t=o[i],r.indexOf(t)>=0||(n[t]=e[t]);return n}(t,["componentId"]),o=r&&r+"-"+(Se(e)?e:ke(y(e)));return qe(e,m({},n,{attrs:f,componentId:o}),i)},Object.defineProperty(k,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(r){this._foldedDefaultProps=n?Ae({},e.defaultProps,r):r}}),Object.defineProperty(k,"toString",{value:function(){return"."+k.styledComponentId}}),o&&h()(k,e,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0,withComponent:!0}),k}var Pe=function(e){return function e(r,t,i){if(void 0===i&&(i=b),!(0,o.Hy)(t))return C(1,String(t));var n=function(){return r(t,i,be.apply(void 0,arguments))};return n.withConfig=function(n){return e(r,t,m({},i,{},n))},n.attrs=function(n){return e(r,t,m({},i,{attrs:Array.prototype.concat(i.attrs,n).filter(Boolean)}))},n}(qe,e)};["a","abbr","address","area","article","aside","audio","b","base","bdi","bdo","big","blockquote","body","br","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","head","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","keygen","label","legend","li","link","main","map","mark","marquee","menu","menuitem","meta","meter","nav","noscript","object","ol","optgroup","option","output","p","param","picture","pre","progress","q","rp","rt","ruby","s","samp","script","section","select","small","source","span","strong","style","sub","summary","sup","table","tbody","td","textarea","tfoot","th","thead","time","title","tr","track","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","text","textPath","tspan"].forEach(function(e){Pe[e]=Pe(e)});!function(){function e(e,r){this.rules=e,this.componentId=r,this.isStatic=J(e),W.registerId(this.componentId+1)}var r=e.prototype;r.createStyles=function(e,r,t,i){var n=i(xe(this.rules,r,t,i).join(""),""),o=this.componentId+e;t.insertRules(o,o,n)},r.removeStyles=function(e,r){r.clearRules(this.componentId+e)},r.renderStyles=function(e,r,t,i){e>2&&W.registerId(this.componentId+e),this.removeStyles(e,t),this.createStyles(e,r,t,i)}}();function $e(e){for(var r=arguments.length,t=new Array(r>1?r-1:0),i=1;i<r;i++)t[i-1]=arguments[i];var n=be.apply(void 0,[e].concat(t)).join(""),o=_e(n);return new ce(o,n)}!function(){function e(){var e=this;this._emitSheetCSS=function(){var r=e.instance.toString();if(!r)return"";var t=L();return"<style "+[t&&'nonce="'+t+'"',k+'="true"','data-styled-version="5.3.11"'].filter(Boolean).join(" ")+">"+r+"</style>"},this.getStyleTags=function(){return e.sealed?C(2):e._emitSheetCSS()},this.getStyleElement=function(){var t;if(e.sealed)return C(2);var i=((t={})[k]="",t["data-styled-version"]="5.3.11",t.dangerouslySetInnerHTML={__html:e.instance.toString()},t),n=L();return n&&(i.nonce=n),[r.createElement("style",m({},i,{key:"sc-0-0"}))]},this.seal=function(){e.sealed=!0},this.instance=new W({isServer:!0}),this.sealed=!1}var t=e.prototype;t.collectStyles=function(e){return this.sealed?C(2):r.createElement(de,{sheet:this.instance},e)},t.interleaveWithNodeStream=function(e){return C(3)}}();const Ie=Pe;var Oe,Le=t(950),Me=t.t(Le,2);function De(){return De=Object.assign?Object.assign.bind():function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])}return e},De.apply(this,arguments)}!function(e){e.Pop="POP",e.Push="PUSH",e.Replace="REPLACE"}(Oe||(Oe={}));const Fe="popstate";function Ue(e,r){if(!1===e||null===e||"undefined"===typeof e)throw new Error(r)}function Be(e,r){if(!e){"undefined"!==typeof console&&console.warn(r);try{throw new Error(r)}catch(t){}}}function Ge(e,r){return{usr:e.state,key:e.key,idx:r}}function We(e,r,t,i){return void 0===t&&(t=null),De({pathname:"string"===typeof e?e:e.pathname,search:"",hash:""},"string"===typeof r?Ve(r):r,{state:t,key:r&&r.key||i||Math.random().toString(36).substr(2,8)})}function He(e){let{pathname:r="/",search:t="",hash:i=""}=e;return t&&"?"!==t&&(r+="?"===t.charAt(0)?t:"?"+t),i&&"#"!==i&&(r+="#"===i.charAt(0)?i:"#"+i),r}function Ve(e){let r={};if(e){let t=e.indexOf("#");t>=0&&(r.hash=e.substr(t),e=e.substr(0,t));let i=e.indexOf("?");i>=0&&(r.search=e.substr(i),e=e.substr(0,i)),e&&(r.pathname=e)}return r}function Qe(e,r,t,i){void 0===i&&(i={});let{window:n=document.defaultView,v5Compat:o=!1}=i,a=n.history,s=Oe.Pop,l=null,d=c();function c(){return(a.state||{idx:null}).idx}function u(){s=Oe.Pop;let e=c(),r=null==e?null:e-d;d=e,l&&l({action:s,location:p.location,delta:r})}function g(e){let r="null"!==n.location.origin?n.location.origin:n.location.href,t="string"===typeof e?e:He(e);return t=t.replace(/ $/,"%20"),Ue(r,"No window.location.(origin|href) available to create URL for href: "+t),new URL(t,r)}null==d&&(d=0,a.replaceState(De({},a.state,{idx:d}),""));let p={get action(){return s},get location(){return e(n,a)},listen(e){if(l)throw new Error("A history only accepts one active listener");return n.addEventListener(Fe,u),l=e,()=>{n.removeEventListener(Fe,u),l=null}},createHref:e=>r(n,e),createURL:g,encodeLocation(e){let r=g(e);return{pathname:r.pathname,search:r.search,hash:r.hash}},push:function(e,r){s=Oe.Push;let i=We(p.location,e,r);t&&t(i,e),d=c()+1;let u=Ge(i,d),g=p.createHref(i);try{a.pushState(u,"",g)}catch(h){if(h instanceof DOMException&&"DataCloneError"===h.name)throw h;n.location.assign(g)}o&&l&&l({action:s,location:p.location,delta:1})},replace:function(e,r){s=Oe.Replace;let i=We(p.location,e,r);t&&t(i,e),d=c();let n=Ge(i,d),u=p.createHref(i);a.replaceState(n,"",u),o&&l&&l({action:s,location:p.location,delta:0})},go:e=>a.go(e)};return p}var Ke;!function(e){e.data="data",e.deferred="deferred",e.redirect="redirect",e.error="error"}(Ke||(Ke={}));new Set(["lazy","caseSensitive","path","id","index","children"]);function Ye(e,r,t){return void 0===t&&(t="/"),Je(e,r,t,!1)}function Je(e,r,t,i){let n=ur(("string"===typeof r?Ve(r):r).pathname||"/",t);if(null==n)return null;let o=Ze(e);!function(e){e.sort((e,r)=>e.score!==r.score?r.score-e.score:function(e,r){let t=e.length===r.length&&e.slice(0,-1).every((e,t)=>e===r[t]);return t?e[e.length-1]-r[r.length-1]:0}(e.routesMeta.map(e=>e.childrenIndex),r.routesMeta.map(e=>e.childrenIndex)))}(o);let a=null;for(let s=0;null==a&&s<o.length;++s){let e=cr(n);a=lr(o[s],e,i)}return a}function Ze(e,r,t,i){void 0===r&&(r=[]),void 0===t&&(t=[]),void 0===i&&(i="");let n=(e,n,o)=>{let a={relativePath:void 0===o?e.path||"":o,caseSensitive:!0===e.caseSensitive,childrenIndex:n,route:e};a.relativePath.startsWith("/")&&(Ue(a.relativePath.startsWith(i),'Absolute route path "'+a.relativePath+'" nested under path "'+i+'" is not valid. An absolute child route path must start with the combined path of all its parent routes.'),a.relativePath=a.relativePath.slice(i.length));let s=fr([i,a.relativePath]),l=t.concat(a);e.children&&e.children.length>0&&(Ue(!0!==e.index,'Index routes must not have child routes. Please remove all child routes from route path "'+s+'".'),Ze(e.children,r,l,s)),(null!=e.path||e.index)&&r.push({path:s,score:sr(s,e.index),routesMeta:l})};return e.forEach((e,r)=>{var t;if(""!==e.path&&null!=(t=e.path)&&t.includes("?"))for(let i of Xe(e.path))n(e,r,i);else n(e,r)}),r}function Xe(e){let r=e.split("/");if(0===r.length)return[];let[t,...i]=r,n=t.endsWith("?"),o=t.replace(/\?$/,"");if(0===i.length)return n?[o,""]:[o];let a=Xe(i.join("/")),s=[];return s.push(...a.map(e=>""===e?o:[o,e].join("/"))),n&&s.push(...a),s.map(r=>e.startsWith("/")&&""===r?"/":r)}const er=/^:[\w-]+$/,rr=3,tr=2,ir=1,nr=10,or=-2,ar=e=>"*"===e;function sr(e,r){let t=e.split("/"),i=t.length;return t.some(ar)&&(i+=or),r&&(i+=tr),t.filter(e=>!ar(e)).reduce((e,r)=>e+(er.test(r)?rr:""===r?ir:nr),i)}function lr(e,r,t){void 0===t&&(t=!1);let{routesMeta:i}=e,n={},o="/",a=[];for(let s=0;s<i.length;++s){let e=i[s],l=s===i.length-1,d="/"===o?r:r.slice(o.length)||"/",c=dr({path:e.relativePath,caseSensitive:e.caseSensitive,end:l},d),u=e.route;if(!c&&l&&t&&!i[i.length-1].route.index&&(c=dr({path:e.relativePath,caseSensitive:e.caseSensitive,end:!1},d)),!c)return null;Object.assign(n,c.params),a.push({params:n,pathname:fr([o,c.pathname]),pathnameBase:xr(fr([o,c.pathnameBase])),route:u}),"/"!==c.pathnameBase&&(o=fr([o,c.pathnameBase]))}return a}function dr(e,r){"string"===typeof e&&(e={path:e,caseSensitive:!1,end:!0});let[t,i]=function(e,r,t){void 0===r&&(r=!1);void 0===t&&(t=!0);Be("*"===e||!e.endsWith("*")||e.endsWith("/*"),'Route path "'+e+'" will be treated as if it were "'+e.replace(/\*$/,"/*")+'" because the `*` character must always follow a `/` in the pattern. To get rid of this warning, please change the route path to "'+e.replace(/\*$/,"/*")+'".');let i=[],n="^"+e.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(e,r,t)=>(i.push({paramName:r,isOptional:null!=t}),t?"/?([^\\/]+)?":"/([^\\/]+)"));e.endsWith("*")?(i.push({paramName:"*"}),n+="*"===e||"/*"===e?"(.*)$":"(?:\\/(.+)|\\/*)$"):t?n+="\\/*$":""!==e&&"/"!==e&&(n+="(?:(?=\\/|$))");let o=new RegExp(n,r?void 0:"i");return[o,i]}(e.path,e.caseSensitive,e.end),n=r.match(t);if(!n)return null;let o=n[0],a=o.replace(/(.)\/+$/,"$1"),s=n.slice(1);return{params:i.reduce((e,r,t)=>{let{paramName:i,isOptional:n}=r;if("*"===i){let e=s[t]||"";a=o.slice(0,o.length-e.length).replace(/(.)\/+$/,"$1")}const l=s[t];return e[i]=n&&!l?void 0:(l||"").replace(/%2F/g,"/"),e},{}),pathname:o,pathnameBase:a,pattern:e}}function cr(e){try{return e.split("/").map(e=>decodeURIComponent(e).replace(/\//g,"%2F")).join("/")}catch(r){return Be(!1,'The URL path "'+e+'" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent encoding ('+r+")."),e}}function ur(e,r){if("/"===r)return e;if(!e.toLowerCase().startsWith(r.toLowerCase()))return null;let t=r.endsWith("/")?r.length-1:r.length,i=e.charAt(t);return i&&"/"!==i?null:e.slice(t)||"/"}function gr(e,r,t,i){return"Cannot include a '"+e+"' character in a manually specified `to."+r+"` field ["+JSON.stringify(i)+"].  Please separate it out to the `to."+t+'` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.'}function pr(e){return e.filter((e,r)=>0===r||e.route.path&&e.route.path.length>0)}function hr(e,r){let t=pr(e);return r?t.map((e,r)=>r===t.length-1?e.pathname:e.pathnameBase):t.map(e=>e.pathnameBase)}function mr(e,r,t,i){let n;void 0===i&&(i=!1),"string"===typeof e?n=Ve(e):(n=De({},e),Ue(!n.pathname||!n.pathname.includes("?"),gr("?","pathname","search",n)),Ue(!n.pathname||!n.pathname.includes("#"),gr("#","pathname","hash",n)),Ue(!n.search||!n.search.includes("#"),gr("#","search","hash",n)));let o,a=""===e||""===n.pathname,s=a?"/":n.pathname;if(null==s)o=t;else{let e=r.length-1;if(!i&&s.startsWith("..")){let r=s.split("/");for(;".."===r[0];)r.shift(),e-=1;n.pathname=r.join("/")}o=e>=0?r[e]:"/"}let l=function(e,r){void 0===r&&(r="/");let{pathname:t,search:i="",hash:n=""}="string"===typeof e?Ve(e):e,o=t?t.startsWith("/")?t:function(e,r){let t=r.replace(/\/+$/,"").split("/");return e.split("/").forEach(e=>{".."===e?t.length>1&&t.pop():"."!==e&&t.push(e)}),t.length>1?t.join("/"):"/"}(t,r):r;return{pathname:o,search:vr(i),hash:br(n)}}(n,o),d=s&&"/"!==s&&s.endsWith("/"),c=(a||"."===s)&&t.endsWith("/");return l.pathname.endsWith("/")||!d&&!c||(l.pathname+="/"),l}const fr=e=>e.join("/").replace(/\/\/+/g,"/"),xr=e=>e.replace(/\/+$/,"").replace(/^\/*/,"/"),vr=e=>e&&"?"!==e?e.startsWith("?")?e:"?"+e:"",br=e=>e&&"#"!==e?e.startsWith("#")?e:"#"+e:"";Error;function jr(e){return null!=e&&"number"===typeof e.status&&"string"===typeof e.statusText&&"boolean"===typeof e.internal&&"data"in e}const yr=["post","put","patch","delete"],wr=(new Set(yr),["get",...yr]);new Set(wr),new Set([301,302,303,307,308]),new Set([307,308]);Symbol("deferred");function kr(){return kr=Object.assign?Object.assign.bind():function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])}return e},kr.apply(this,arguments)}const _r=r.createContext(null);const Sr=r.createContext(null);const Cr=r.createContext(null);const zr=r.createContext(null);const Er=r.createContext({outlet:null,matches:[],isDataRoute:!1});const Ar=r.createContext(null);function Rr(){return null!=r.useContext(zr)}function Nr(){return Rr()||Ue(!1),r.useContext(zr).location}function Tr(e){r.useContext(Cr).static||r.useLayoutEffect(e)}function qr(){let{isDataRoute:e}=r.useContext(Er);return e?function(){let{router:e}=Gr(Ur.UseNavigateStable),t=Hr(Br.UseNavigateStable),i=r.useRef(!1);return Tr(()=>{i.current=!0}),r.useCallback(function(r,n){void 0===n&&(n={}),i.current&&("number"===typeof r?e.navigate(r):e.navigate(r,kr({fromRouteId:t},n)))},[e,t])}():function(){Rr()||Ue(!1);let e=r.useContext(_r),{basename:t,future:i,navigator:n}=r.useContext(Cr),{matches:o}=r.useContext(Er),{pathname:a}=Nr(),s=JSON.stringify(hr(o,i.v7_relativeSplatPath)),l=r.useRef(!1);return Tr(()=>{l.current=!0}),r.useCallback(function(r,i){if(void 0===i&&(i={}),!l.current)return;if("number"===typeof r)return void n.go(r);let o=mr(r,JSON.parse(s),a,"path"===i.relative);null==e&&"/"!==t&&(o.pathname="/"===o.pathname?t:fr([t,o.pathname])),(i.replace?n.replace:n.push)(o,i.state,i)},[t,n,s,a,e])}()}function Pr(){let{matches:e}=r.useContext(Er),t=e[e.length-1];return t?t.params:{}}function $r(e,t){let{relative:i}=void 0===t?{}:t,{future:n}=r.useContext(Cr),{matches:o}=r.useContext(Er),{pathname:a}=Nr(),s=JSON.stringify(hr(o,n.v7_relativeSplatPath));return r.useMemo(()=>mr(e,JSON.parse(s),a,"path"===i),[e,s,a,i])}function Ir(e,t,i,n){Rr()||Ue(!1);let{navigator:o}=r.useContext(Cr),{matches:a}=r.useContext(Er),s=a[a.length-1],l=s?s.params:{},d=(s&&s.pathname,s?s.pathnameBase:"/");s&&s.route;let c,u=Nr();if(t){var g;let e="string"===typeof t?Ve(t):t;"/"===d||(null==(g=e.pathname)?void 0:g.startsWith(d))||Ue(!1),c=e}else c=u;let p=c.pathname||"/",h=p;if("/"!==d){let e=d.replace(/^\//,"").split("/");h="/"+p.replace(/^\//,"").split("/").slice(e.length).join("/")}let m=Ye(e,{pathname:h});let f=Fr(m&&m.map(e=>Object.assign({},e,{params:Object.assign({},l,e.params),pathname:fr([d,o.encodeLocation?o.encodeLocation(e.pathname).pathname:e.pathname]),pathnameBase:"/"===e.pathnameBase?d:fr([d,o.encodeLocation?o.encodeLocation(e.pathnameBase).pathname:e.pathnameBase])})),a,i,n);return t&&f?r.createElement(zr.Provider,{value:{location:kr({pathname:"/",search:"",hash:"",state:null,key:"default"},c),navigationType:Oe.Pop}},f):f}function Or(){let e=function(){var e;let t=r.useContext(Ar),i=Wr(Br.UseRouteError),n=Hr(Br.UseRouteError);if(void 0!==t)return t;return null==(e=i.errors)?void 0:e[n]}(),t=jr(e)?e.status+" "+e.statusText:e instanceof Error?e.message:JSON.stringify(e),i=e instanceof Error?e.stack:null,n="rgba(200,200,200, 0.5)",o={padding:"0.5rem",backgroundColor:n};return r.createElement(r.Fragment,null,r.createElement("h2",null,"Unexpected Application Error!"),r.createElement("h3",{style:{fontStyle:"italic"}},t),i?r.createElement("pre",{style:o},i):null,null)}const Lr=r.createElement(Or,null);class Mr extends r.Component{constructor(e){super(e),this.state={location:e.location,revalidation:e.revalidation,error:e.error}}static getDerivedStateFromError(e){return{error:e}}static getDerivedStateFromProps(e,r){return r.location!==e.location||"idle"!==r.revalidation&&"idle"===e.revalidation?{error:e.error,location:e.location,revalidation:e.revalidation}:{error:void 0!==e.error?e.error:r.error,location:r.location,revalidation:e.revalidation||r.revalidation}}componentDidCatch(e,r){console.error("React Router caught the following error during render",e,r)}render(){return void 0!==this.state.error?r.createElement(Er.Provider,{value:this.props.routeContext},r.createElement(Ar.Provider,{value:this.state.error,children:this.props.component})):this.props.children}}function Dr(e){let{routeContext:t,match:i,children:n}=e,o=r.useContext(_r);return o&&o.static&&o.staticContext&&(i.route.errorElement||i.route.ErrorBoundary)&&(o.staticContext._deepestRenderedBoundaryId=i.route.id),r.createElement(Er.Provider,{value:t},n)}function Fr(e,t,i,n){var o;if(void 0===t&&(t=[]),void 0===i&&(i=null),void 0===n&&(n=null),null==e){var a;if(!i)return null;if(i.errors)e=i.matches;else{if(!(null!=(a=n)&&a.v7_partialHydration&&0===t.length&&!i.initialized&&i.matches.length>0))return null;e=i.matches}}let s=e,l=null==(o=i)?void 0:o.errors;if(null!=l){let e=s.findIndex(e=>e.route.id&&void 0!==(null==l?void 0:l[e.route.id]));e>=0||Ue(!1),s=s.slice(0,Math.min(s.length,e+1))}let d=!1,c=-1;if(i&&n&&n.v7_partialHydration)for(let r=0;r<s.length;r++){let e=s[r];if((e.route.HydrateFallback||e.route.hydrateFallbackElement)&&(c=r),e.route.id){let{loaderData:r,errors:t}=i,n=e.route.loader&&void 0===r[e.route.id]&&(!t||void 0===t[e.route.id]);if(e.route.lazy||n){d=!0,s=c>=0?s.slice(0,c+1):[s[0]];break}}}return s.reduceRight((e,n,o)=>{let a,u=!1,g=null,p=null;var h;i&&(a=l&&n.route.id?l[n.route.id]:void 0,g=n.route.errorElement||Lr,d&&(c<0&&0===o?(h="route-fallback",!1||Vr[h]||(Vr[h]=!0),u=!0,p=null):c===o&&(u=!0,p=n.route.hydrateFallbackElement||null)));let m=t.concat(s.slice(0,o+1)),f=()=>{let t;return t=a?g:u?p:n.route.Component?r.createElement(n.route.Component,null):n.route.element?n.route.element:e,r.createElement(Dr,{match:n,routeContext:{outlet:e,matches:m,isDataRoute:null!=i},children:t})};return i&&(n.route.ErrorBoundary||n.route.errorElement||0===o)?r.createElement(Mr,{location:i.location,revalidation:i.revalidation,component:g,error:a,children:f(),routeContext:{outlet:null,matches:m,isDataRoute:!0}}):f()},null)}var Ur=function(e){return e.UseBlocker="useBlocker",e.UseRevalidator="useRevalidator",e.UseNavigateStable="useNavigate",e}(Ur||{}),Br=function(e){return e.UseBlocker="useBlocker",e.UseLoaderData="useLoaderData",e.UseActionData="useActionData",e.UseRouteError="useRouteError",e.UseNavigation="useNavigation",e.UseRouteLoaderData="useRouteLoaderData",e.UseMatches="useMatches",e.UseRevalidator="useRevalidator",e.UseNavigateStable="useNavigate",e.UseRouteId="useRouteId",e}(Br||{});function Gr(e){let t=r.useContext(_r);return t||Ue(!1),t}function Wr(e){let t=r.useContext(Sr);return t||Ue(!1),t}function Hr(e){let t=function(){let e=r.useContext(Er);return e||Ue(!1),e}(),i=t.matches[t.matches.length-1];return i.route.id||Ue(!1),i.route.id}const Vr={};function Qr(e,r){null==e||e.v7_startTransition,void 0===(null==e?void 0:e.v7_relativeSplatPath)&&(!r||r.v7_relativeSplatPath),r&&(r.v7_fetcherPersist,r.v7_normalizeFormMethod,r.v7_partialHydration,r.v7_skipActionErrorRevalidation)}i.startTransition;function Kr(e){let{to:t,replace:i,state:n,relative:o}=e;Rr()||Ue(!1);let{future:a,static:s}=r.useContext(Cr),{matches:l}=r.useContext(Er),{pathname:d}=Nr(),c=qr(),u=mr(t,hr(l,a.v7_relativeSplatPath),d,"path"===o),g=JSON.stringify(u);return r.useEffect(()=>c(JSON.parse(g),{replace:i,state:n,relative:o}),[c,g,o,i,n]),null}function Yr(e){Ue(!1)}function Jr(e){let{basename:t="/",children:i=null,location:n,navigationType:o=Oe.Pop,navigator:a,static:s=!1,future:l}=e;Rr()&&Ue(!1);let d=t.replace(/^\/*/,"/"),c=r.useMemo(()=>({basename:d,navigator:a,static:s,future:kr({v7_relativeSplatPath:!1},l)}),[d,l,a,s]);"string"===typeof n&&(n=Ve(n));let{pathname:u="/",search:g="",hash:p="",state:h=null,key:m="default"}=n,f=r.useMemo(()=>{let e=ur(u,d);return null==e?null:{location:{pathname:e,search:g,hash:p,state:h,key:m},navigationType:o}},[d,u,g,p,h,m,o]);return null==f?null:r.createElement(Cr.Provider,{value:c},r.createElement(zr.Provider,{children:i,value:f}))}function Zr(e){let{children:r,location:t}=e;return Ir(Xr(r),t)}new Promise(()=>{});r.Component;function Xr(e,t){void 0===t&&(t=[]);let i=[];return r.Children.forEach(e,(e,n)=>{if(!r.isValidElement(e))return;let o=[...t,n];if(e.type===r.Fragment)return void i.push.apply(i,Xr(e.props.children,o));e.type!==Yr&&Ue(!1),e.props.index&&e.props.children&&Ue(!1);let a={id:e.props.id||o.join("-"),caseSensitive:e.props.caseSensitive,element:e.props.element,Component:e.props.Component,index:e.props.index,path:e.props.path,loader:e.props.loader,action:e.props.action,errorElement:e.props.errorElement,ErrorBoundary:e.props.ErrorBoundary,hasErrorBoundary:null!=e.props.ErrorBoundary||null!=e.props.errorElement,shouldRevalidate:e.props.shouldRevalidate,handle:e.props.handle,lazy:e.props.lazy};e.props.children&&(a.children=Xr(e.props.children,o)),i.push(a)}),i}function et(){return et=Object.assign?Object.assign.bind():function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])}return e},et.apply(this,arguments)}function rt(e,r){if(null==e)return{};var t,i,n={},o=Object.keys(e);for(i=0;i<o.length;i++)t=o[i],r.indexOf(t)>=0||(n[t]=e[t]);return n}function tt(e){return void 0===e&&(e=""),new URLSearchParams("string"===typeof e||Array.isArray(e)||e instanceof URLSearchParams?e:Object.keys(e).reduce((r,t)=>{let i=e[t];return r.concat(Array.isArray(i)?i.map(e=>[t,e]):[[t,i]])},[]))}new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);const it=["onClick","relative","reloadDocument","replace","state","target","to","preventScrollReset","viewTransition"];try{window.__reactRouterVersion="6"}catch(xE){}new Map;const nt=i.startTransition;Me.flushSync,i.useId;function ot(e){let{basename:t,children:i,future:n,window:o}=e,a=r.useRef();var s;null==a.current&&(a.current=(void 0===(s={window:o,v5Compat:!0})&&(s={}),Qe(function(e,r){let{pathname:t,search:i,hash:n}=e.location;return We("",{pathname:t,search:i,hash:n},r.state&&r.state.usr||null,r.state&&r.state.key||"default")},function(e,r){return"string"===typeof r?r:He(r)},null,s)));let l=a.current,[d,c]=r.useState({action:l.action,location:l.location}),{v7_startTransition:u}=n||{},g=r.useCallback(e=>{u&&nt?nt(()=>c(e)):c(e)},[c,u]);return r.useLayoutEffect(()=>l.listen(g),[l,g]),r.useEffect(()=>Qr(n),[n]),r.createElement(Jr,{basename:t,children:i,location:d.location,navigationType:d.action,navigator:l,future:n})}const at="undefined"!==typeof window&&"undefined"!==typeof window.document&&"undefined"!==typeof window.document.createElement,st=/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,lt=r.forwardRef(function(e,t){let i,{onClick:n,relative:o,reloadDocument:a,replace:s,state:l,target:d,to:c,preventScrollReset:u,viewTransition:g}=e,p=rt(e,it),{basename:h}=r.useContext(Cr),m=!1;if("string"===typeof c&&st.test(c)&&(i=c,at))try{let e=new URL(window.location.href),r=c.startsWith("//")?new URL(e.protocol+c):new URL(c),t=ur(r.pathname,h);r.origin===e.origin&&null!=t?c=t+r.search+r.hash:m=!0}catch(xE){}let f=function(e,t){let{relative:i}=void 0===t?{}:t;Rr()||Ue(!1);let{basename:n,navigator:o}=r.useContext(Cr),{hash:a,pathname:s,search:l}=$r(e,{relative:i}),d=s;return"/"!==n&&(d="/"===s?n:fr([n,s])),o.createHref({pathname:d,search:l,hash:a})}(c,{relative:o}),x=function(e,t){let{target:i,replace:n,state:o,preventScrollReset:a,relative:s,viewTransition:l}=void 0===t?{}:t,d=qr(),c=Nr(),u=$r(e,{relative:s});return r.useCallback(r=>{if(function(e,r){return 0===e.button&&(!r||"_self"===r)&&!function(e){return!!(e.metaKey||e.altKey||e.ctrlKey||e.shiftKey)}(e)}(r,i)){r.preventDefault();let t=void 0!==n?n:He(c)===He(u);d(e,{replace:t,state:o,preventScrollReset:a,relative:s,viewTransition:l})}},[c,d,u,n,o,i,e,a,s,l])}(c,{replace:s,state:l,target:d,preventScrollReset:u,relative:o,viewTransition:g});return r.createElement("a",et({},p,{href:i||f,onClick:m||a?n:function(e){n&&n(e),e.defaultPrevented||x(e)},ref:t,target:d}))});var dt,ct;function ut(e){let t=r.useRef(tt(e)),i=r.useRef(!1),n=Nr(),o=r.useMemo(()=>function(e,r){let t=tt(e);return r&&r.forEach((e,i)=>{t.has(i)||r.getAll(i).forEach(e=>{t.append(i,e)})}),t}(n.search,i.current?null:t.current),[n.search]),a=qr(),s=r.useCallback((e,r)=>{const t=tt("function"===typeof e?e(o):e);i.current=!0,a("?"+t,r)},[a,o]);return[o,s]}(function(e){e.UseScrollRestoration="useScrollRestoration",e.UseSubmit="useSubmit",e.UseSubmitFetcher="useSubmitFetcher",e.UseFetcher="useFetcher",e.useViewTransitionState="useViewTransitionState"})(dt||(dt={})),function(e){e.UseFetcher="useFetcher",e.UseFetchers="useFetchers",e.UseScrollRestoration="useScrollRestoration"}(ct||(ct={}));var gt=t(579);const pt=e=>{let{children:t}=e;r.useEffect(()=>{const e=window.location.pathname,r=window.location.search;if(e.includes("?/")||r.includes("?/")){const t=e.replace(/\?\//g,"/")+r.replace(/\?\//g,"")+window.location.hash;console.log("\ud83d\udd27 RouterWrapper: Cleaning URL before router init:",t),window.history.replaceState(null,"",t)}},[]);try{return(0,gt.jsx)(ot,{children:t})}catch(i){return console.error("\ud83d\udea8 RouterWrapper: BrowserRouter failed:",i),window.location.href="/",(0,gt.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",minHeight:"100vh",background:"#f0f0f0"},children:(0,gt.jsx)("div",{children:"Redirecting..."})})}},ht=[{id:1,email:"admin@top-league.org",password:"Borini",nome:"Admin",cognome:"TopLeague",ruolo:"superadmin",token:"mock-superadmin-token-2025"},{id:2,email:"user@test.com",password:"password123",nome:"User",cognome:"Test",ruolo:"user",token:"mock-user-token-2025"},{id:3,email:"manager@test.com",password:"password123",nome:"Manager",cognome:"Test",ruolo:"admin",token:"mock-manager-token-2025"}];let mt=[{id:1,nome:"Serie A",descrizione:"Lega Serie A",admin_id:1,admin_nome:"Admin TopLeague",admin_email:"admin@top-league.org",created_at:"2025-01-01",stato:"attiva",modalita:"standard",is_pubblica:!0,numero_squadre:20,squadre_con_proprietario:15,numero_giocatori:400,config:{max_squadre:20,budget_iniziale:1e6}},{id:2,nome:"Premier League",descrizione:"Lega Premier League",admin_id:1,admin_nome:"Admin TopLeague",admin_email:"admin@top-league.org",created_at:"2025-01-02",stato:"attiva",modalita:"standard",is_pubblica:!0,numero_squadre:20,squadre_con_proprietario:18,numero_giocatori:380,config:{max_squadre:20,budget_iniziale:1e6}},{id:3,nome:"Bundesliga",descrizione:"Lega Bundesliga",admin_id:3,admin_nome:"Manager Test",admin_email:"manager@test.com",created_at:"2025-01-03",stato:"attiva",modalita:"advanced",is_pubblica:!1,numero_squadre:18,squadre_con_proprietario:12,numero_giocatori:324,config:{max_squadre:18,budget_iniziale:8e5}},{id:4,nome:"Lega Calcio 2025",descrizione:"Lega creata dinamicamente",admin_id:1,admin_nome:"Admin TopLeague",admin_email:"admin@top-league.org",created_at:"2025-01-15T10:30:00Z",stato:"attiva",modalita:"standard",is_pubblica:!0,numero_squadre:16,squadre_con_proprietario:8,numero_giocatori:288,config:{max_squadre:16,budget_iniziale:75e4}},{id:5,nome:"Fantasy League Pro",descrizione:"Lega professionale fantasy football",admin_id:1,admin_nome:"Admin TopLeague",admin_email:"admin@top-league.org",created_at:"2025-01-16T14:45:00Z",stato:"attiva",modalita:"pro",is_pubblica:!0,numero_squadre:12,squadre_con_proprietario:10,numero_giocatori:216,config:{max_squadre:12,budget_iniziale:5e5}},{id:6,nome:"Champions League",descrizione:"Lega europea di elite",admin_id:1,admin_nome:"Admin TopLeague",admin_email:"admin@top-league.org",created_at:"2025-01-17T09:15:00Z",stato:"attiva",modalita:"elite",is_pubblica:!1,numero_squadre:32,squadre_con_proprietario:25,numero_giocatori:576,config:{max_squadre:32,budget_iniziale:15e5}},{id:7,nome:"Lega Amatoriale",descrizione:"Lega per principianti",admin_id:3,admin_nome:"Manager Test",admin_email:"manager@test.com",created_at:"2025-01-18T16:20:00Z",stato:"attiva",modalita:"amateur",is_pubblica:!0,numero_squadre:10,squadre_con_proprietario:6,numero_giocatori:180,config:{max_squadre:10,budget_iniziale:3e5}}];const ft=[{id:1,nome:"Juventus",lega_id:1,punti:85,posizione:1,budget:1e6,utente_id:2},{id:2,nome:"Milan",lega_id:1,punti:82,posizione:2,budget:95e4,utente_id:3},{id:3,nome:"Manchester United",lega_id:2,punti:78,posizione:1,budget:12e5,utente_id:2},{id:4,nome:"Bayern Munich",lega_id:3,punti:90,posizione:1,budget:15e5,utente_id:3}],xt=[{id:1,nome:"Lautaro Martinez",ruolo:"A",squadra:"Inter",valore:5e7,lega_id:1,squadra_id:1},{id:2,nome:"Federico Chiesa",ruolo:"A",squadra:"Juventus",valore:45e6,lega_id:1,squadra_id:1},{id:3,nome:"Rafael Le\xe3o",ruolo:"A",squadra:"Milan",valore:4e7,lega_id:1,squadra_id:2},{id:4,nome:"Marcus Rashford",ruolo:"A",squadra:"Manchester United",valore:35e6,lega_id:2,squadra_id:3},{id:5,nome:"Harry Kane",ruolo:"A",squadra:"Bayern Munich",valore:6e7,lega_id:3,squadra_id:4}],vt=[{id:1,tipo:"offerta",messaggio:"Nuova offerta ricevuta",stato:"non_letta",created_at:"2025-01-01T10:00:00Z",utente_id:2},{id:2,tipo:"sistema",messaggio:"Benvenuto in TopLeague!",stato:"letta",created_at:"2025-01-01T09:00:00Z",utente_id:2},{id:3,tipo:"richiesta",messaggio:"Richiesta unione squadra",stato:"non_letta",created_at:"2025-01-01T11:00:00Z",utente_id:3}],bt=[{id:1,giocatore_id:1,squadra_offerta:1,squadra_ricevente:2,valore:5e7,stato:"in_attesa",created_at:"2025-01-01T10:00:00Z"},{id:2,giocatore_id:2,squadra_offerta:2,squadra_ricevente:1,valore:45e6,stato:"accettata",created_at:"2025-01-01T09:00:00Z"}],jt=[{id:1,tipo:"unione_squadra",stato:"in_attesa",lega_id:1,utente_id:2,created_at:"2025-01-01T10:00:00Z"},{id:2,tipo:"modifica_giocatore",stato:"approvata",lega_id:1,utente_id:3,created_at:"2025-01-01T09:00:00Z"}],yt=async e=>{console.log("\ud83d\udd0d MOCK API: Login attempt",e);const r=ht.find(r=>r.email===e.email&&r.password===e.password);if(r)return{user:{id:r.id,email:r.email,nome:r.nome,cognome:r.cognome,ruolo:r.ruolo},token:r.token};throw new Error("Credenziali non valide")},wt=async e=>{console.log("\ud83d\udd0d MOCK API: Register attempt",e);if(ht.find(r=>r.email===e.email))throw new Error("Email gi\xe0 registrata");const r={id:ht.length+1,...e,token:`mock-token-${Date.now()}`};return ht.push(r),{user:{id:r.id,email:r.email,nome:r.nome,cognome:r.cognome,ruolo:r.ruolo},token:r.token}},kt=async()=>{console.log("\ud83d\udd0d MOCK API: Verify user");const e=ht.find(e=>1===e.id);return{user:{id:e.id,email:e.email,nome:e.nome,cognome:e.cognome,ruolo:e.ruolo}}},_t=async()=>(console.log("\ud83d\udd0d MOCK API: Get leghe"),{leghe:mt}),St=async()=>(console.log("\ud83d\udd0d MOCK API: Get leghe by user"),{leghe:mt.filter(e=>1===e.admin_id)}),Ct=async()=>(console.log("\ud83d\udd0d MOCK API: Get leghe admin"),{leghe:mt.filter(e=>1===e.admin_id)}),zt=async()=>(console.log("\ud83d\udd0d MOCK API: Get all leghe"),{leghe:mt}),Et=async()=>(console.log("\ud83d\udd0d MOCK API: Get richieste admin"),{richieste:jt}),At=async e=>{console.log("\ud83d\udd0d MOCK API: Create lega",e);const r={id:Math.max(...mt.map(e=>e.id))+1,nome:e.nome||"Nuova Lega",descrizione:e.descrizione||"Lega creata dinamicamente",admin_id:1,created_at:(new Date).toISOString(),stato:"attiva",config:{max_squadre:e.max_squadre||20,budget_iniziale:e.budget_iniziale||1e6,modalita:e.modalita||"standard",is_pubblica:e.is_pubblica||!0,password:e.password||null,min_giocatori:e.min_giocatori||18,max_giocatori:e.max_giocatori||25,roster_ab:e.roster_ab||!1,cantera:e.cantera||!1,contratti:e.contratti||!1,triggers:e.triggers||!1}};return mt.push(r),console.log("\u2705 MOCK API: Lega creata con successo:",r),{success:!0,lega:r}},Rt=async e=>{console.log("\ud83d\udd0d MOCK API: Delete lega",e);const r=mt.length;return mt=mt.filter(r=>r.id!==parseInt(e)),mt.length<r?(console.log("\u2705 MOCK API: Lega eliminata con successo"),{success:!0,message:"Lega eliminata con successo"}):(console.log("\u274c MOCK API: Lega non trovata o gi\xe0 eliminata"),{success:!1,message:"Lega non trovata o gi\xe0 eliminata"})},Nt=async()=>(console.log("\ud83d\udd0d MOCK API: Get squadre"),{squadre:ft}),Tt=async()=>(console.log("\ud83d\udd0d MOCK API: Get squadre by user"),{squadre:ft.filter(e=>2===e.utente_id)}),qt=async e=>{console.log("\ud83d\udd0d MOCK API: Get my team",e);return ft.find(r=>r.lega_id===parseInt(e)&&2===r.utente_id)||null},Pt=async()=>(console.log("\ud83d\udd0d MOCK API: Get giocatori"),{giocatori:xt}),$t=async()=>(console.log("\ud83d\udd0d MOCK API: Get notifiche"),{notifiche:vt}),It=async()=>(console.log("\ud83d\udd0d MOCK API: Get notifiche by user"),{notifiche:vt.filter(e=>2===e.utente_id)}),Ot=async()=>(console.log("\ud83d\udd0d MOCK API: Get offerte"),{offerte:bt}),Lt=async e=>{console.log("\ud83d\udd0d MOCK API: Create offerta",e);const r={id:bt.length+1,...e,created_at:(new Date).toISOString()};return bt.push(r),{success:!0,offerta:r}},Mt=async e=>{console.log("\ud83d\udd0d MOCK API: Get roster",e);const r=xt.filter(r=>r.squadra_id===parseInt(e));return{rosterA:r.slice(0,Math.ceil(r.length/2)),rosterB:r.slice(Math.ceil(r.length/2)),squadra_id:e}},Dt=async e=>(console.log("\ud83d\udd0d MOCK API: Move player",e),{success:!0,message:"Giocatore spostato con successo"}),Ft=async()=>(console.log("\ud83d\udd0d MOCK API: Get subadmins"),{subadmins:[]}),Ut=async()=>(console.log("\ud83d\udd0d MOCK API: Get all subadmins"),{subadmins:[]}),Bt=async()=>(console.log("\ud83d\udd0d MOCK API: Get richieste"),{richieste:jt}),Gt=async()=>(console.log("\ud83d\udd0d MOCK API: Get richieste by user"),{richieste:jt.filter(e=>2===e.utente_id)}),Wt=async e=>(console.log("\ud83d\udd0d MOCK API: Get tornei by lega",e),{tornei:[]}),Ht=async e=>(console.log("\ud83d\udd0d MOCK API: Get torneo by id",e),null),Vt=async e=>(console.log("\ud83d\udd0d MOCK API: Create torneo",e),{success:!0,torneo:{id:1,...e}}),Qt=async(e,r)=>(console.log("\ud83d\udd0d MOCK API: Update torneo",e,r),{success:!0}),Kt=async e=>(console.log("\ud83d\udd0d MOCK API: Delete torneo",e),{success:!0}),Yt=async(e,r)=>(console.log("\ud83d\udd0d MOCK API: Calcola giornata",e,r),{success:!0}),Jt=async e=>(console.log("\ud83d\udd0d MOCK API: Aggiorna classifica",e),{success:!0}),Zt=async()=>(console.log("\ud83d\udd0d MOCK API: Get all users"),{users:ht}),Xt=e=>(console.error("\ud83d\udea8 MOCK API ERROR:",e),{success:!1,error:e.message||"Errore sconosciuto"}),ei=async function(e){let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};console.log("\ud83d\udd0d MOCK FETCH:",e,r);try{const t=e.split("/api")[1]||e;switch(t){case"/auth/login":if("POST"===r.method){const e=JSON.parse(r.body),t=await yt(e);return{ok:!0,json:async()=>t}}break;case"/auth/register":if("POST"===r.method){const e=JSON.parse(r.body),t=await wt(e);return{ok:!0,json:async()=>t}}break;case"/auth/verify-user":if("GET"===r.method){const e=await kt();return{ok:!0,json:async()=>e}}break;case"/auth/verify":if("GET"===r.method){const e=await kt();return{ok:!0,json:async()=>e}}break;case"/leghe":if("GET"===r.method){const e=await _t();return{ok:!0,json:async()=>e}}break;case"/leghe/user-leagues":if("GET"===r.method){const e=await St();return{ok:!0,json:async()=>e}}break;case"/leghe/admin":if("GET"===r.method){const e=await Ct();return{ok:!0,json:async()=>e}}break;case"/leghe/all":if("GET"===r.method){const e=await zt();return{ok:!0,json:async()=>e}}break;case"/leghe/create":if("POST"===r.method){const e=await At(r.body?JSON.parse(r.body):{});return{ok:!0,json:async()=>e}}break;case"/leghe/":if("DELETE"===r.method){const e=t.split("/")[2],r=await Rt(e);return{ok:!0,json:async()=>r}}break;case"/leghe/richieste/admin":if("GET"===r.method){const e=await Et();return{ok:!0,json:async()=>e}}break;case"/squadre":if("GET"===r.method){const e=await Nt();return{ok:!0,json:async()=>e}}break;case"/squadre/utente":if("GET"===r.method){const e=await Tt();return{ok:!0,json:async()=>e}}break;case"/squadre/my-team":if("GET"===r.method){const e=await qt(1);return{ok:!0,json:async()=>e}}break;case"/giocatori":if("GET"===r.method){const e=await Pt();return{ok:!0,json:async()=>e}}break;case"/notifiche":if("GET"===r.method){const e=await $t();return{ok:!0,json:async()=>e}}break;case"/notifiche/utente":if("GET"===r.method){const e=await It();return{ok:!0,json:async()=>e}}break;case"/offerte":if("GET"===r.method){const e=await Ot();return{ok:!0,json:async()=>e}}break;case"/offerte/crea":if("POST"===r.method){const e=JSON.parse(r.body),t=await Lt(e);return{ok:!0,json:async()=>t}}break;case"/offerte/roster/1":if("GET"===r.method){const e=await Mt(1);return{ok:!0,json:async()=>e}}break;case"/offerte/roster/move-player":if("POST"===r.method){const e=JSON.parse(r.body),t=await Dt(e);return{ok:!0,json:async()=>t}}break;case"/subadmin/check-all":if("GET"===r.method){const e=await Ft();return{ok:!0,json:async()=>e}}break;case"/subadmin/all":if("GET"===r.method){const e=await Ut();return{ok:!0,json:async()=>e}}break;case"/auth/all-users":if("GET"===r.method){const e=await Zt();return{ok:!0,json:async()=>e}}break;case"/richieste/subadmin":if("GET"===r.method){const e=await Bt();return{ok:!0,json:async()=>e}}break;case"/richieste/utente":if("GET"===r.method){const e=await Gt();return{ok:!0,json:async()=>e}}break;case"/tornei/lega/":if("GET"===r.method){const e=t.split("/")[3],r=await Wt(e);return{ok:!0,json:async()=>r}}break;case"/tornei/":if(!t.includes("/lega/")&&!t.includes("/calcola-giornata")&&!t.includes("/aggiorna-classifica")&&"GET"===r.method){const e=t.split("/")[2],r=await Ht(e);return{ok:!0,json:async()=>r}}break;case"/tornei":if(!t.includes("/lega/")&&!t.includes("/calcola-giornata")&&!t.includes("/aggiorna-classifica")&&"POST"===r.method){const e=await Vt(r.body?JSON.parse(r.body):{});return{ok:!0,json:async()=>e}}break;case"/tornei/":if(!t.includes("/lega/")&&!t.includes("/calcola-giornata")&&!t.includes("/aggiorna-classifica")&&"PUT"===r.method){const e=t.split("/")[2],i=await Qt(e,r.body?JSON.parse(r.body):{});return{ok:!0,json:async()=>i}}break;case"/tornei/":if(!t.includes("/lega/")&&!t.includes("/calcola-giornata")&&!t.includes("/aggiorna-classifica")&&"DELETE"===r.method){const e=t.split("/")[2],r=await Kt(e);return{ok:!0,json:async()=>r}}break;case"/calcola-giornata":if("POST"===r.method){const e=t.split("/")[2],i=r.body?JSON.parse(r.body):{},n=await Yt(e,i.giornata);return{ok:!0,json:async()=>n}}break;case"/aggiorna-classifica":if("POST"===r.method){const e=t.split("/")[2],r=await Jt(e);return{ok:!0,json:async()=>r}}}}catch(t){return{ok:!1,status:500,json:async()=>Xt(t)}}},ri="https://www.top-league.org/api";console.log("API_BASE_URL:",ri),console.log("NODE_ENV:","production"),console.log("Frontend version:","1.0.12"),console.log("Build timestamp:",(new Date).toISOString());console.log("\ud83d\udd27 MOCK API ENABLED - Using mock data for all requests");const ti=(e,r)=>{if(!r)return!0;for(const[t,i]of Object.entries(r)){if(!(t in e))return console.warn(`\u26a0\ufe0f Missing required field: ${t}`),!1;if("array"===i&&!Array.isArray(e[t]))return console.warn(`\u26a0\ufe0f Expected array for field: ${t}`),!1;if("object"===i&&"object"!==typeof e[t])return console.warn(`\u26a0\ufe0f Expected object for field: ${t}`),!1;if("boolean"===i&&"boolean"!==typeof e[t])return console.warn(`\u26a0\ufe0f Expected boolean for field: ${t}`),!1}return!0},ii=async function(e){let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null;const i=e.startsWith("http")?e:`${ri}${e}`;console.log("Making request to:",i,"with options:",r);{console.log("\ud83d\udd27 Using MOCK API for:",i);const e=await ei(i,r),n=await e.json();if(console.log("\ud83d\udd27 MOCK API response:",n),t&&!ti(n,t))throw new Error("Risposta mock API non valida");return{ok:!0,data:n,status:200}}},ni={get:function(e){return ii(e,{method:"GET"},arguments.length>2&&void 0!==arguments[2]?arguments[2]:null)},post:function(e){let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:null,t=arguments.length>3&&void 0!==arguments[3]?arguments[3]:null;return ii(e,{method:"POST",body:r?JSON.stringify(r):null},t)},put:function(e){let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:null,t=arguments.length>3&&void 0!==arguments[3]?arguments[3]:null;return ii(e,{method:"PUT",body:r?JSON.stringify(r):null},t)},delete:function(e){return ii(e,{method:"DELETE"},arguments.length>2&&void 0!==arguments[2]?arguments[2]:null)}},oi=async e=>{console.log("\ud83d\udd0d AUTH API: Login attempt with credentials:",{email:e.email,password:"***"});try{console.log("\ud83d\udd0d AUTH API: Making request to /auth/login");const r=await ni.post("/auth/login",e);if(console.log("\ud83d\udd0d AUTH API: Response received:",{hasResponse:!!r,responseType:typeof r,hasUser:!(null===r||void 0===r||!r.user),hasToken:!(null===r||void 0===r||!r.token),userKeys:null!==r&&void 0!==r&&r.user?Object.keys(r.user):"no user",timestamp:(new Date).toISOString()}),!r)throw console.error("\ud83d\udea8 AUTH API ERROR: No response received"),new Error("No response received from server");if(!r.user)throw console.error("\ud83d\udea8 AUTH API ERROR: Response missing user property"),console.error("\ud83d\udea8 Full response:",r),new Error("Invalid response: missing user data");if(!r.token)throw console.error("\ud83d\udea8 AUTH API ERROR: Response missing token property"),console.error("\ud83d\udea8 Full response:",r),new Error("Invalid response: missing token");return console.log("\ud83d\udd0d AUTH API: Response validation passed, returning data"),console.log("\ud83d\udd0d AUTH API: User data:",{id:r.user.id,email:r.user.email,username:r.user.username,ruolo:r.user.ruolo}),r}catch(i){var r,t;throw console.error("\ud83d\udea8 AUTH API ERROR:",i),console.error("\ud83d\udea8 Error message:",i.message),console.error("\ud83d\udea8 Error response:",null===(r=i.response)||void 0===r?void 0:r.data),console.error("\ud83d\udea8 Error status:",null===(t=i.response)||void 0===t?void 0:t.status),i}},ai=e=>ni.post("/auth/check-availability",e),si=Ie.div`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 10px;
  border-radius: 8px;
  font-size: 12px;
  font-family: monospace;
  z-index: 9999;
  max-width: 300px;
  display: ${e=>e.$show?"block":"none"};
`,li=Ie.div`
  font-weight: bold;
  margin-bottom: 5px;
  color: #00ff00;
`,di=Ie.div`
  margin: 2px 0;
  font-size: 11px;
`,ci=Ie.button`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  border: none;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 10px;
  cursor: pointer;
  z-index: 10000;
  display: ${e=>e.$show?"none":"block"};
`;let ui={totalRequests:0,cacheHits:0,deduplicationHits:0,uniqueRequests:0,lastReset:Date.now()};const gi=e=>{switch(ui.totalRequests++,e){case"cache":ui.cacheHits++;break;case"deduplication":ui.deduplicationHits++;break;case"unique":ui.uniqueRequests++}},pi=()=>{const[e,t]=(0,r.useState)(!1),[i,n]=(0,r.useState)(ui);(0,r.useEffect)(()=>{const e=setInterval(()=>{n({...ui})},1e3);return()=>clearInterval(e)},[]);const o=i.totalRequests>0?((i.cacheHits+i.deduplicationHits)/i.totalRequests*100).toFixed(1):0,a=Math.floor((Date.now()-i.lastReset)/1e3);return(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(ci,{$show:e,onClick:()=>t(!e),children:"\ud83d\udcca API"}),(0,gt.jsxs)(si,{$show:e,children:[(0,gt.jsx)(li,{children:"API Monitor"}),(0,gt.jsxs)(di,{children:["Total Requests: ",i.totalRequests]}),(0,gt.jsxs)(di,{children:["Cache Hits: ",i.cacheHits]}),(0,gt.jsxs)(di,{children:["Deduplication: ",i.deduplicationHits]}),(0,gt.jsxs)(di,{children:["Unique Requests: ",i.uniqueRequests]}),(0,gt.jsxs)(di,{children:["Hit Rate: ",o,"%"]}),(0,gt.jsxs)(di,{children:["Uptime: ",a,"s"]}),(0,gt.jsx)("button",{onClick:()=>{ui={totalRequests:0,cacheHits:0,deduplicationHits:0,uniqueRequests:0,lastReset:Date.now()},n(ui)},style:{background:"#ff4444",color:"white",border:"none",padding:"2px 6px",borderRadius:"3px",fontSize:"10px",cursor:"pointer",marginTop:"5px"},children:"Reset"})]})]})},hi=new Map,mi=new Map,fi=new Map,xi=async function(e,r){let t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:3e4;if(!function(e){let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:1e3;const t=Date.now(),i=fi.get(e)||0;return t-i<r?(console.log(`\u23f1\ufe0f Debounced call for: ${e} (${r-(t-i)}ms remaining)`),!1):(fi.set(e,t),!0)}(e,2e3)){const i=hi.get(e);return i?(console.log(`\u23f1\ufe0f Returning cached data for debounced call: ${e}`),gi("cache"),i.data):(await new Promise(e=>setTimeout(e,1e3)),xi(e,r,t))}if(mi.has(e))return console.log(`\ud83d\udd04 Request deduplication hit for: ${e}`),gi("deduplication"),mi.get(e);const i=hi.get(e);if(i&&Date.now()-i.timestamp<t)return console.log(`\ud83d\udcbe Cache hit for: ${e}`),gi("cache"),i.data;console.log(`\ud83c\udf10 New API request for: ${e}`),gi("unique");const n=r().then(r=>(hi.set(e,{data:r,timestamp:Date.now()}),mi.delete(e),r)).catch(r=>{throw mi.delete(e),r});return mi.set(e,n),n},vi=async(e,r)=>xi(`notifiche_${r}`,()=>ni.get("/notifiche",e),3e4),bi=async(e,r)=>xi(`squadre_utente_${r}`,()=>ni.get("/squadre/utente",e),6e4),ji=async(e,r)=>xi(`leghe_user_${r}`,()=>ni.get("/leghe/user-leagues",e),6e4),yi=async e=>xi(`subadmin_check_${e?e.substring(0,20):"anonymous"}`,()=>ni.get("/subadmin/check-all",e),6e4),wi=e=>{e?(e=>{if(e)for(const r of hi.keys())r.includes(e)&&hi.delete(r);else hi.clear()})(e.toString()):hi.clear(),mi.clear()},ki=(0,r.createContext)(null),_i=e=>{let{children:t}=e;console.log("\ud83d\udd0d AuthProvider: Component mounted");const[i,n]=(0,r.useState)(null),[o,a]=(0,r.useState)(localStorage.getItem("token")),[s,l]=(0,r.useState)(!0);(0,r.useEffect)(()=>{if(o)try{const e=localStorage.getItem("user");if(e&&"undefined"!==e&&"null"!==e){const r=JSON.parse(e);r&&n(r)}}catch(e){console.error("Error parsing user data:",e),localStorage.removeItem("token"),localStorage.removeItem("user"),a(null)}l(!1)},[]);const d=()=>{wi(null===i||void 0===i?void 0:i.id),n(null),a(null),localStorage.removeItem("token"),localStorage.removeItem("user")};return(0,gt.jsx)(ki.Provider,{value:{user:i,token:o,loading:s,loginUser:(e,r)=>{n(e),a(r),localStorage.setItem("token",r),localStorage.setItem("user",JSON.stringify(e))},logoutUser:d,refreshUserData:async()=>{if(o)try{const e=await(async e=>xi(`verify_user_${e?e.substring(0,20):"anonymous"}`,()=>ni.get("/auth/verify-user",e),6e4))(o);e&&e.user&&(n(e.user),localStorage.setItem("user",JSON.stringify(e.user)),console.log("User data refreshed successfully"))}catch(t){var e,r;console.error("Failed to refresh user data:",t),(null!==(e=t.message)&&void 0!==e&&e.includes("401")||null!==(r=t.message)&&void 0!==r&&r.includes("Token"))&&"/login"!==window.location.pathname&&"/register"!==window.location.pathname&&d()}}},children:t})},Si=()=>{const e=(0,r.useContext)(ki);if(!e)throw new Error("useAuth must be used within an AuthProvider");return e},Ci=(0,r.createContext)(),zi=()=>{const e=(0,r.useContext)(Ci);if(!e)throw new Error("useNotification must be used within a NotificationProvider");return e},Ei=Ie.div`
    position: fixed;
    top: 120px;
    right: 20px;
    z-index: 1000;
    max-width: 250px;
`,Ai=Ie.div`
    background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
    color: white;
    padding: 0.5rem;
    border-radius: 6px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    cursor: pointer;
    transition: all 0.3s ease;
    transform: translateX(${e=>e.$show?"0":"100%"});
    opacity: ${e=>e.$show?"1":"0"};
    position: relative;
    
    &:hover {
        transform: translateX(-3px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }
`,Ri=Ie.button`
    position: absolute;
    top: 2px;
    right: 2px;
    background: none;
    border: none;
    color: rgba(255, 255, 255, 0.8);
    font-size: 12px;
    cursor: pointer;
    padding: 1px;
    border-radius: 2px;
    transition: all 0.2s ease;
    width: 16px;
    height: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    
    &:hover {
        background: rgba(255, 255, 255, 0.2);
        color: white;
    }
`,Ni=Ie.span`
    background: #007bff;
    color: white;
    border-radius: 50%;
    width: 14px;
    height: 14px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 8px;
    font-weight: bold;
    margin-left: 4px;
`,Ti=Ie.div`
    font-weight: 600;
    margin-bottom: 0.2rem;
    font-size: 0.75rem;
    padding-right: 20px;
    color: white;
`,qi=Ie.div`
    font-size: 0.7rem;
    color: rgba(255, 255, 255, 0.9);
    line-height: 1.2;
    margin-bottom: 0.2rem;
`,Pi=Ie.div`
    font-size: 0.65rem;
    color: rgba(255, 255, 255, 0.7);
`,$i=e=>{let{children:t}=e;const{user:i,token:n}=Si(),o=qr(),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)(0),[c,u]=(0,r.useState)(!1),[g,p]=(0,r.useState)(null),[h,m]=(0,r.useState)(!1),[f,x]=(0,r.useState)(new Set),v=e=>{x(r=>new Set([...r,e]))},b=()=>a.filter(e=>!e.letta&&1!==e.letto&&!f.has(e.id));(0,r.useEffect)(()=>{if(!i||!n)return;const e=async()=>{try{var e;const r=await vi(n,i.id),t=((null===r||void 0===r||null===(e=r.data)||void 0===e?void 0:e.notifiche)||(null===r||void 0===r?void 0:r.notifiche)||[]).map(e=>({...e,letta:e.letta||1===e.letto,letto:e.letto||(e.letta?1:0)}));s(t),d(t.filter(e=>!e.letta).length||0)}catch(r){console.error("Errore caricamento notifiche:",r)}};e();const r=setInterval(()=>{h||(m(!0),e().finally(()=>{m(!1)}))},3e5);return()=>{clearInterval(r),m(!1)}},[i,n,h]),(0,r.useEffect)(()=>{const e=b();if(console.log("\ud83d\udd0d NotificationSystem: unviewedNotifications:",e),console.log("\ud83d\udd0d NotificationSystem: showNotification:",c),console.log("\ud83d\udd0d NotificationSystem: viewedNotifications:",f),e.length>0&&!c){console.log("\ud83d\udd0d NotificationSystem: Showing notification"),u(!0);const e=setTimeout(()=>{y()},8e3);return()=>clearTimeout(e)}0===e.length&&(console.log("\ud83d\udd0d NotificationSystem: No unviewed notifications"),u(!1))},[a,c,f]);const j=async e=>{try{let r=await ni.post(`/notifiche/${e}/read`,{},n);r||(r=await ni.put(`/notifiche/${e}/letta`,{},n)),r&&(s(r=>r.map(r=>r.id===e?{...r,letta:!0,letto:1}:r)),d(e=>Math.max(0,e-1)))}catch(r){console.error("Errore marcatura notifica come letta:",r)}},y=()=>{u(!1);const e=b()[0];e&&(v(e.id),s(r=>r.map(r=>r.id===e.id?{...r,letta:!0,letto:1}:r)),d(e=>Math.max(0,e-1)),j(e.id))},w=e=>{const r=new Date(e),t=new Date-r,i=Math.floor(t/6e4),n=Math.floor(t/36e5),o=Math.floor(t/864e5);return i<1?"Ora":i<60?`${i}m fa`:n<24?`${n}h fa`:o<7?`${o}g fa`:r.toLocaleDateString("it-IT")},k=e=>{switch(e){case"trasferimento":return"trasferimento";case"offerta":return"offerta";case"sistema":default:return"sistema";case"richiesta_ingresso":return"richiesta_ingresso";case"risposta_richiesta":return"risposta_richiesta";case"risposta_richiesta_admin":return"risposta_richiesta_admin";case"richiesta_unione_squadra":return"richiesta_unione_squadra";case"risposta_richiesta_unione":return"risposta_richiesta_unione"}},_={addNotification:function(e){let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"info",t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:5e3;const i=Date.now()+Math.random(),n={id:i,message:e,type:r};s(e=>[...e,n]),t>0&&setTimeout(()=>{s(e=>e.filter(e=>e.id!==i))},t)},removeNotification:e=>{s(r=>r.filter(r=>r.id!==e))},markAsRead:j,markAllAsRead:async()=>{try{await ni.put("/notifiche/tutte-lette",{},n),s(e=>e.map(e=>({...e,letta:!0,letto:1}))),d(0)}catch(e){console.error("Errore marcatura tutte notifiche come lette:",e)}},showModal:e=>{p(e)},hideModal:()=>{p(null)},showErrorModal:function(e,r){p({type:"error",title:e,message:r,onConfirm:arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,showCancel:!1})},showConfirmModal:function(e,r,t){p({type:"confirm",title:e,message:r,onConfirm:t,onCancel:arguments.length>3&&void 0!==arguments[3]?arguments[3]:null})},showSuccessModal:function(e,r){p({type:"success",title:e,message:r,onConfirm:arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,showCancel:!1})},notifications:a};return(0,gt.jsxs)(Ci.Provider,{value:_,children:[t,c&&(()=>{const e=b(),r=e[0];return r?(0,gt.jsx)(Ei,{children:(0,gt.jsxs)(Ai,{$type:k(r.tipo),$show:c,onClick:()=>{return e=r,u(!1),v(e.id),s(r=>r.map(r=>r.id===e.id?{...r,letta:!0,letto:1}:r)),d(e=>Math.max(0,e-1)),j(e.id),void o("/notifiche");var e},children:[(0,gt.jsx)(Ri,{onClick:e=>{e.stopPropagation(),y()},children:"\xd7"}),(0,gt.jsxs)(Ti,{children:[r.titolo||"Notifica",e.length>1&&(0,gt.jsx)(Ni,{children:e.length})]}),(0,gt.jsx)(qi,{children:r.messaggio}),(0,gt.jsx)(Pi,{children:w(r.data_creazione)})]})}):(u(!1),null)})()]})},Ii=async e=>ni.get("/subadmin/all",e),Oi=async(e,r)=>ni.get(`/subadmin/lega/${e}`,r),Li=async(e,r,t,i)=>ni.post("/subadmin/add",{legaId:e,userId:r,permissions:t},i),Mi=async(e,r,t)=>ni.delete("/subadmin/remove",t),Di=async(e,r)=>ni.get(`/subadmin/pending/${e}`,r),Fi=async e=>ni.get("/subadmin/pending/subadmin",e),Ui=async(e,r)=>{const t=e?`/subadmin/history/${e}`:"/subadmin/history";return ni.get(t,r)},Bi=async e=>ni.get("/subadmin/check-all",e),Gi=async(e,r)=>ni.post("/subadmin/request",e,r),Wi=()=>{const{token:e,user:t}=Si(),[i,n]=(0,r.useState)([]),[o,a]=(0,r.useState)(!1),[s,l]=(0,r.useState)(""),[d,c]=(0,r.useState)(!1),u=async()=>{if(!e)return n([]),void c(!1);const r=await(async()=>{if(!e)return!1;try{return(await yi(e)).isSubadmin||!1}catch(s){return console.error("Errore nel controllo subadmin:",s),!1}})();if(c(r),r){a(!0),l("");try{const r=await Fi(e);n(r.changes||[])}catch(t){l(t.message),console.error("Errore nel caricamento modifiche in attesa:",t),n([])}finally{a(!1)}}else n([])};return(0,r.useEffect)(()=>{u();const e=setInterval(()=>{d&&(console.log("\ud83d\udd04 Polling subadmin changes - timestamp:",(new Date).toISOString()),u())},3e5);return()=>clearInterval(e)},[e,d]),{pendingChanges:i,loading:o,error:s,isSubadmin:d,refresh:u}},Hi=Ie.nav`
  background: white;
  padding: 0.75rem 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  border-bottom: 1px solid #e5e5e7;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  
  @media (max-width: 768px) {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    padding: 0.5rem 1rem;
  }
`,Vi=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  
  @media (max-width: 768px) {
    gap: 0.5rem;
  }
`,Qi=Ie(lt)`
  color: #5856d6;
  text-decoration: none;
  font-size: 1.2rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  @media (max-width: 768px) {
    font-size: 1rem;
  }
`,Ki=Ie.div`
  display: flex;
  align-items: center;
  gap: 1.5rem;
  
  @media (max-width: 768px) {
    display: none;
  }
`,Yi=Ie.button`
  display: none;
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  padding: 0.5rem;
  color: #5856d6;
  
  @media (max-width: 768px) {
    display: block;
    font-size: 1.3rem;
  }
`,Ji=Ie.div`
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 1001;
  backdrop-filter: blur(10px);
  transition: opacity 0.3s ease;
  opacity: ${e=>e.$isOpen?1:0};
  pointer-events: ${e=>e.$isOpen?"auto":"none"};
  
  @media (max-width: 768px) {
    display: block;
  }
`,Zi=Ie.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  background: white;
  padding: 1rem;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  max-height: 100vh;
  overflow-y: auto;
  transform: translateX(${e=>e.$isOpen?"0":"-100%"});
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  @media (max-width: 768px) {
    padding: 0.75rem;
  }
`,Xi=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 1rem;
  border-bottom: 1px solid #e5e5e7;
  margin-bottom: 1rem;
  
  @media (max-width: 768px) {
    padding-bottom: 0.75rem;
    margin-bottom: 0.75rem;
  }
`,en=Ie.button`
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #5856d6;
  
  @media (max-width: 768px) {
    font-size: 1.3rem;
  }
`,rn=Ie(lt)`
  display: block;
  width: 100%;
  padding: 1rem 1.5rem;
  color: #1d1d1f;
  text-decoration: none;
  font-size: 1.1rem;
  font-weight: 500;
  background: white;
  border: none;
  border-radius: 12px;
  margin-bottom: 0.5rem;
  text-align: left;
  transition: all 0.2s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  
  &:hover {
    background-color: #f8f9fa;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  }
  
  &.active {
    background: linear-gradient(135deg, #5856d6 0%, #7c3aed 100%);
    color: white;
    box-shadow: 0 4px 12px rgba(88, 86, 214, 0.3);
  }
  
  @media (max-width: 768px) {
    padding: 0.75rem 1rem;
    font-size: 1rem;
    margin-bottom: 0.25rem;
  }
`,tn=Ie.div`
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
  margin-bottom: 1rem;
  
  @media (max-width: 768px) {
    padding: 0.75rem;
    margin-bottom: 0.75rem;
  }
`,nn=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-top: 1rem;
  
  @media (max-width: 768px) {
    margin-top: 0.75rem;
  }
`,on=Ie.button`
  width: 100%;
  background: white;
  color: #1d1d1f;
  border: none;
  padding: 1rem 1.5rem;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin-bottom: 0.5rem;
  text-align: left;
  display: flex;
  align-items: center;
  justify-content: space-between;
  
  &:hover {
    background-color: #f8f9fa;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  }
  
  &.logout {
    color: #ff3b30;
    background: #fff5f5;
    
    &:hover {
      background: #fed7d7;
    }
  }
  
  @media (max-width: 768px) {
    padding: 0.75rem 1rem;
    font-size: 0.9rem;
    margin-bottom: 0.25rem;
  }
`,an=Ie(lt)`
  color: #86868b;
  text-decoration: none;
  padding: 0.5rem 0.75rem;
  border-radius: 6px;
  font-size: 0.85rem;
  font-weight: 500;
  transition: all 0.2s;
  
  &:hover {
    background-color: #f8f9fa;
    color: #5856d6;
  }
  
  &.active {
    background-color: #5856d6;
    color: white;
  }
`,sn=(Ie.div`
  position: relative;
  display: inline-block;
`,Ie.button`
  background: none;
  border: none;
  color: #86868b;
  cursor: pointer;
  padding: 0.5rem 0.75rem;
  border-radius: 6px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.85rem;
  font-weight: 500;
  
  &:hover {
    background-color: #f8f9fa;
    color: #5856d6;
  }
`,Ie.div`
  position: absolute;
  top: 100%;
  right: 0;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  min-width: 180px;
  z-index: 1000;
  display: ${e=>e.$isOpen?"block":"none"};
  border: 1px solid #e5e5e7;
`,Ie(lt)`
  display: block;
  padding: 0.75rem 1rem;
  color: #1d1d1f;
  text-decoration: none;
  border-bottom: 1px solid #f0f0f0;
  font-size: 0.85rem;
  
  &:last-child {
    border-bottom: none;
  }
  
  &:hover {
    background-color: #f8f9fa;
  }
`,Ie.button`
  display: block;
  width: 100%;
  padding: 0.75rem 1rem;
  background: none;
  border: none;
  color: #ff3b30;
  cursor: pointer;
  text-align: left;
  border-bottom: 1px solid #f0f0f0;
  font-size: 0.85rem;
  
  &:hover {
    background-color: #f8f9fa;
  }
`,Ie.span`
  color: #86868b;
  font-size: 0.85rem;
  font-weight: 500;
  
  @media (max-width: 768px) {
    font-size: 0.8rem;
  }
`),ln=Ie(lt)`
  background: #ff3b30;
  color: white;
  text-decoration: none;
  padding: 0.4rem 0.8rem;
  border-radius: 6px;
  font-size: 0.8rem;
  font-weight: 500;
  transition: all 0.2s;
  
  &:hover {
    background: #d70015;
    transform: translateY(-1px);
  }
  
  @media (max-width: 768px) {
    padding: 0.3rem 0.6rem;
    font-size: 0.75rem;
  }
`,dn=()=>{const{user:e,token:t,logoutUser:i,refreshUserData:n}=Si(),{notifications:o,markSubadminRequestsAsRead:a}=zi(),{pendingChanges:s}=Wi(),l=qr(),d=Nr(),[c,u]=(0,r.useState)(!1),[g,p]=(0,r.useState)(0),[h,m]=(0,r.useState)(!1),[f,x]=(0,r.useState)([]),v=e&&("admin"===e.ruolo||"superadmin"===e.ruolo||"SuperAdmin"===e.ruolo||e.leghe_admin&&e.leghe_admin.length>0),b=e&&("superadmin"===e.ruolo||"SuperAdmin"===e.ruolo);(0,r.useEffect)(()=>{if(e&&t){("admin"===e.ruolo||"superadmin"===e.ruolo||"SuperAdmin"===e.ruolo)&&(!e.leghe_admin||0===e.leghe_admin.length)&&(console.log("Detected incomplete user data, refreshing..."),n())}},[e,t,n]),(0,r.useEffect)(()=>{(async()=>{if(e&&t&&v)try{const r=await(async(e,r)=>xi(`richieste_admin_${r}`,()=>ni.get("/leghe/richieste/admin",e),3e4))(t,e.id);p(r.richieste?r.richieste.length:0)}catch(r){console.error("Errore nel recupero richieste admin pendenti:",r),p(0)}else p(0)})()},[e,t,v]),(0,r.useEffect)(()=>{(async()=>{if(e&&t)try{const e=await yi(t);m(e.isSubadmin||!1),x(e.leagues||[])}catch(r){console.error("Errore nel controllo subadmin:",r),m(!1),x([])}else m(!1),x([])})()},[e,t]);const j=e=>d.pathname===e,y=()=>{u(!1)};return(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(Hi,{children:(0,gt.jsxs)(Vi,{children:[(0,gt.jsx)(Qi,{to:"/",children:"TopLeague"}),(0,gt.jsx)(Ki,{children:(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(an,{to:"/",className:j("/")?"active":"",children:"Home"}),(0,gt.jsx)(an,{to:"/leghe",className:j("/leghe")?"active":"",children:"Leghe"}),e&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(an,{to:"/area-manager",className:j("/area-manager")?"active":"",children:"Area Manager"}),v&&(0,gt.jsx)("div",{style:{position:"relative",display:"inline-block"},children:(0,gt.jsxs)(an,{to:"/area-admin",className:j("/area-admin")?"active":"",children:["Area Admin",g>0&&(0,gt.jsx)("span",{style:{background:"#ff3b30",color:"white",borderRadius:"50%",width:"18px",height:"18px",display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",fontWeight:"600",marginLeft:"0.5rem"},children:g>9?"9+":g})]})}),b&&(0,gt.jsx)("div",{style:{position:"relative",display:"inline-block"},children:(0,gt.jsx)(an,{to:"/super-admin-dashboard",className:j("/super-admin-dashboard")?"active":"",children:"Super Admin"})}),h&&(0,gt.jsx)("div",{style:{position:"relative",display:"inline-block"},children:(0,gt.jsxs)(an,{to:"/subadmin-area",className:j("/subadmin-area")?"active":"",children:["Subadmin",(()=>{const e=o.filter(e=>("subadmin_request"===e.tipo||"subadmin_response"===e.tipo||"richiesta_ingresso"===e.tipo)&&(!e.letto||0===e.letto));return e.length>0&&(0,gt.jsx)("span",{style:{background:"#ff3b30",color:"white",borderRadius:"50%",width:"18px",height:"18px",display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",fontWeight:"600",marginLeft:"0.5rem"},children:e.length>9?"9+":e.length})})()]})})]})]})}),(0,gt.jsx)(Yi,{onClick:()=>u(!0),children:"\u2630"}),e?(0,gt.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"1rem"},children:[(0,gt.jsx)("div",{style:{position:"relative",display:"inline-block"},children:(0,gt.jsxs)("button",{onClick:()=>l("/notifiche"),style:{background:"none",border:"none",color:"#86868b",cursor:"pointer",padding:"0.5rem",borderRadius:"6px",fontSize:"1.2rem",display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.2s"},title:"Notifiche",children:["\ud83d\udd14",(()=>{const e=o.filter(e=>!e.letto||0===e.letto).length;return e>0&&(0,gt.jsx)("span",{style:{position:"absolute",top:"-5px",right:"-5px",background:"#ff3b30",color:"white",borderRadius:"50%",width:"18px",height:"18px",display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",fontWeight:"600",border:"2px solid white"},children:e>9?"9+":e})})()]})}),(0,gt.jsx)(sn,{children:e.username||e.nome}),(0,gt.jsx)("button",{onClick:n,style:{background:"none",border:"1px solid #5856d6",color:"#5856d6",padding:"0.4rem 0.8rem",borderRadius:"6px",fontSize:"0.8rem",cursor:"pointer",transition:"all 0.2s"},title:"Aggiorna dati utente",children:"\ud83d\udd04"}),(0,gt.jsx)(ln,{to:"/",onClick:()=>{i(),l("/")},children:"Logout"})]}):(0,gt.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"1rem"},children:[(0,gt.jsx)(an,{to:"/login",className:j("/login")?"active":"",children:"Login"}),(0,gt.jsx)(an,{to:"/register",className:j("/register")?"active":"",children:"Registrati"})]})]})}),(0,gt.jsx)(Ji,{$isOpen:c,onClick:y,children:(0,gt.jsxs)(Zi,{$isOpen:c,onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(Xi,{children:[(0,gt.jsx)(Qi,{to:"/",onClick:y,children:"TopLeague"}),(0,gt.jsx)(en,{onClick:y,children:"\u2715"})]}),e&&(0,gt.jsxs)(tn,{children:[(0,gt.jsx)("div",{style:{fontWeight:"bold",marginBottom:"0.5rem"},children:e.username||e.nome}),(0,gt.jsx)("div",{style:{fontSize:"0.9rem",color:"#666"},children:e.email})]}),(0,gt.jsxs)("div",{style:{marginBottom:"1rem"},children:[(0,gt.jsx)(rn,{to:"/",className:j("/")?"active":"",onClick:y,children:"Home"}),(0,gt.jsx)(rn,{to:"/leghe",className:j("/leghe")?"active":"",onClick:y,children:"Leghe"}),e&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(rn,{to:"/area-manager",className:j("/area-manager")?"active":"",onClick:y,children:"Area Manager"}),v&&(0,gt.jsxs)(rn,{to:"/area-admin",className:j("/area-admin")?"active":"",onClick:y,children:["Area Admin",g>0&&(0,gt.jsx)("span",{style:{background:"#ff3b30",color:"white",borderRadius:"50%",width:"18px",height:"18px",display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",fontWeight:"600",marginLeft:"auto"},children:g>9?"9+":g})]}),b&&(0,gt.jsx)(rn,{to:"/super-admin-dashboard",className:j("/super-admin-dashboard")?"active":"",onClick:y,children:"Super Admin"}),h&&(0,gt.jsxs)(rn,{to:"/subadmin-area",className:j("/subadmin-area")?"active":"",onClick:y,children:["Subadmin",(()=>{const e=o.filter(e=>("subadmin_request"===e.tipo||"subadmin_response"===e.tipo||"richiesta_ingresso"===e.tipo)&&(!e.letto||0===e.letto));return e.length>0&&(0,gt.jsx)("span",{style:{background:"#ff3b30",color:"white",borderRadius:"50%",width:"18px",height:"18px",display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",fontWeight:"600",marginLeft:"auto"},children:e.length>9?"9+":e.length})})()]})]})]}),e?(0,gt.jsxs)(nn,{children:[(0,gt.jsxs)(on,{onClick:()=>{l("/notifiche"),setTimeout(()=>{u(!1)},100)},children:["Notifiche",(()=>{const e=o.filter(e=>!e.letto||0===e.letto).length;return e>0&&(0,gt.jsx)("span",{style:{background:"#ff3b30",color:"white",borderRadius:"50%",width:"18px",height:"18px",display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",fontWeight:"600"},children:e>9?"9+":e})})()]}),(0,gt.jsx)(on,{onClick:()=>{n(),y()},children:"Aggiorna Dati"}),(0,gt.jsx)(on,{className:"logout",onClick:()=>{i(),l("/"),y()},children:"Logout"})]}):(0,gt.jsxs)("div",{style:{marginTop:"1rem"},children:[(0,gt.jsx)(rn,{to:"/login",onClick:y,children:"Login"}),(0,gt.jsx)(rn,{to:"/register",onClick:y,children:"Registrati"})]})]})})]})};function cn(e){let{children:r}=e;const{user:t,loading:i}=Si(),n=Nr();return i?(0,gt.jsx)("div",{children:"Loading..."}):t?r:(sessionStorage.setItem("redirectAfterLogin",n.pathname+n.search),(0,gt.jsx)(Kr,{to:"/login",replace:!0}))}const un=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
`,gn=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  width: 100%;
  max-width: 450px;
`,pn=Ie.div`
  text-align: center;
  margin-bottom: 2rem;
`,hn=Ie.h1`
  color: #5856d6;
  font-size: 2rem;
  font-weight: 700;
  margin: 0;
  margin-bottom: 0.5rem;
`,mn=Ie.p`
  color: #86868b;
  margin: 0;
  font-size: 1rem;
`,fn=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,xn=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,vn=Ie.label`
  color: #1d1d1f;
  font-weight: 600;
  font-size: 0.9rem;
`,bn=Ie.input`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #5856d6;
  }
  
  &::placeholder {
    color: #86868b;
  }
`,jn=Ie.button`
  background: #5856d6;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background: #4a4ac4;
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,yn=Ie.div`
  background: #f8d7da;
  color: #721c24;
  padding: 12px;
  border-radius: 8px;
  border: 1px solid #f5c6cb;
  font-size: 0.9rem;
  text-align: center;
`,wn=Ie(lt)`
  display: block;
  text-align: center;
  margin-top: 1.5rem;
  color: #5856d6;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.2s;

  &:hover {
    color: #4a4ac4;
    text-decoration: underline;
  }
`,kn=Ie.div`
  display: flex;
  align-items: center;
  margin: 1.5rem 0;
  color: #86868b;
  font-size: 0.9rem;
  
  &::before,
  &::after {
    content: '';
    flex: 1;
    height: 1px;
    background: #e5e5e7;
  }
  
  &::before {
    margin-right: 1rem;
  }
  
  &::after {
    margin-left: 1rem;
  }
`;const _n=function(){const[e,t]=(0,r.useState)({emailOrUsername:"",password:""}),[i,n]=(0,r.useState)(""),[o,a]=(0,r.useState)(!1),s=qr(),{loginUser:l}=Si(),d=e=>{const{name:r,value:i}=e.target;t(e=>({...e,[r]:i}))};return(0,gt.jsx)(un,{children:(0,gt.jsxs)(gn,{children:[(0,gt.jsxs)(pn,{children:[(0,gt.jsx)(hn,{children:"TopLeague"}),(0,gt.jsx)(mn,{children:"Fantasy Football League Management"})]}),(0,gt.jsxs)(fn,{onSubmit:async r=>{r.preventDefault(),n(""),a(!0);try{const r=await oi({email:e.emailOrUsername,password:(null===e||void 0===e?void 0:e.password)||""});l(r.user,r.token);const t=sessionStorage.getItem("redirectAfterLogin");t?(sessionStorage.removeItem("redirectAfterLogin"),s(t)):s("/")}catch(t){n(t.message||"Errore durante il login")}finally{a(!1)}},children:[i&&(0,gt.jsx)(yn,{children:i}),(0,gt.jsxs)(xn,{children:[(0,gt.jsx)(vn,{htmlFor:"emailOrUsername",children:"Email o Username"}),(0,gt.jsx)(bn,{type:"text",id:"emailOrUsername",name:"emailOrUsername",value:e.emailOrUsername,onChange:d,placeholder:"Inserisci email o username",required:!0})]}),(0,gt.jsxs)(xn,{children:[(0,gt.jsx)(vn,{htmlFor:"password",children:"Password"}),(0,gt.jsx)(bn,{type:"password",id:"password",name:"password",value:(null===e||void 0===e?void 0:e.password)||"",onChange:d,placeholder:"Inserisci la tua password",required:!0})]}),(0,gt.jsx)(jn,{type:"submit",disabled:o,children:o?"Accesso in corso...":"Accedi"})]}),(0,gt.jsx)(kn,{children:"oppure"}),(0,gt.jsx)(wn,{to:"/register",children:"Non hai un account? Registrati qui"})]})})},Sn=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
`,Cn=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  width: 100%;
  max-width: 600px;
`,zn=Ie.div`
  text-align: center;
  margin-bottom: 2rem;
`,En=Ie.h1`
  color: #5856d6;
  font-size: 2rem;
  font-weight: 700;
  margin: 0;
  margin-bottom: 0.5rem;
`,An=Ie.p`
  color: #86868b;
  margin: 0;
  font-size: 1rem;
`,Rn=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,Nn=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,Tn=Ie.label`
  color: #1d1d1f;
  font-weight: 600;
  font-size: 0.9rem;
`,qn=Ie.span`
  color: #dc3545;
  margin-left: 4px;
`,Pn=Ie.input`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #5856d6;
  }
  
  &::placeholder {
    color: #86868b;
  }
  
  &.valid {
    border-color: #28a745;
  }
  
  &.invalid {
    border-color: #dc3545;
  }
  
  &.checking {
    border-color: #ffc107;
  }
`,$n=Ie.select`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #5856d6;
  }
`,In=Ie.button`
  background: #5856d6;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background: #4a4ac4;
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,On=Ie.div`
  background: #f8d7da;
  color: #721c24;
  padding: 12px;
  border-radius: 8px;
  border: 1px solid #f5c6cb;
  font-size: 0.9rem;
  text-align: center;
`,Ln=Ie.div`
  background: #d4edda;
  color: #155724;
  padding: 12px;
  border-radius: 8px;
  border: 1px solid #c3e6cb;
  font-size: 0.9rem;
  text-align: center;
`,Mn=Ie(lt)`
  display: block;
  text-align: center;
  margin-top: 1.5rem;
  color: #5856d6;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.2s;

  &:hover {
    color: #4a4ac4;
    text-decoration: underline;
  }
`,Dn=Ie.div`
  display: flex;
  align-items: center;
  margin: 1.5rem 0;
  color: #86868b;
  font-size: 0.9rem;
  
  &::before,
  &::after {
    content: '';
    flex: 1;
    height: 1px;
    background: #e5e5e7;
  }
  
  &::before {
    margin-right: 1rem;
  }
  
  &::after {
    margin-left: 1rem;
  }
`,Fn=Ie.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  
  @media (max-width: 600px) {
    grid-template-columns: 1fr;
  }
`,Un=(Ie.h3`
  color: #1d1d1f;
  margin: 0 0 1rem 0;
  font-size: 1.1rem;
  font-weight: 600;
  padding-bottom: 0.5rem;
  border-bottom: 2px solid #f0f0f0;
`,Ie.div`
  font-size: 0.8rem;
  margin-top: 0.25rem;
  
  &.valid {
    color: #28a745;
  }
  
  &.invalid {
    color: #dc3545;
  }
  
  &.checking {
    color: #ffc107;
  }
`);const Bn=function(){const[e,t]=(0,r.useState)({nome:"",cognome:"",username:"",email:"",password:"",confermaPassword:"",provenienza:"",squadra_cuore:"",come_conosciuto:""}),[i,n]=(0,r.useState)(""),[o,a]=(0,r.useState)(""),[s,l]=(0,r.useState)(!1),[d,c]=(0,r.useState)({email:{status:"neutral",message:""},username:{status:"neutral",message:""}});qr(),(0,r.useEffect)(()=>{const r=setTimeout(()=>{e.email&&e.email.includes("@")&&u(e.email)},500);return()=>clearTimeout(r)},[e.email]),(0,r.useEffect)(()=>{const r=setTimeout(()=>{e.username&&e.username.length>=3&&g(e.username)},500);return()=>clearTimeout(r)},[e.username]);const u=async e=>{c(e=>({...e,email:{status:"checking",message:"Verificando disponibilit\xe0..."}}));try{const r=await ai({email:e});c(e=>({...e,email:{status:r.email.available?"valid":"invalid",message:r.email.message}}))}catch(r){c(e=>({...e,email:{status:"neutral",message:""}}))}},g=async e=>{c(e=>({...e,username:{status:"checking",message:"Verificando disponibilit\xe0..."}}));try{const r=await ai({username:e});c(e=>({...e,username:{status:r.username.available?"valid":"invalid",message:r.username.message}}))}catch(r){c(e=>({...e,username:{status:"neutral",message:""}}))}},p=e=>{const{name:r,value:i}=e.target;t(e=>({...e,[r]:i}))};return(0,gt.jsx)(Sn,{children:(0,gt.jsxs)(Cn,{children:[(0,gt.jsxs)(zn,{children:[(0,gt.jsx)(En,{children:"TopLeague"}),(0,gt.jsx)(An,{children:"Registrazione"})]}),(0,gt.jsxs)(Rn,{onSubmit:async r=>{if(r.preventDefault(),n(""),a(""),!(null!==e&&void 0!==e&&e.password||""!==e.confermaPassword))return null!==e&&void 0!==e&&e.password,void n("La password deve essere di almeno 6 caratteri");n("Le password non coincidono")},children:[i&&(0,gt.jsx)(On,{children:i}),o&&(0,gt.jsx)(Ln,{children:o}),(0,gt.jsxs)(Fn,{children:[(0,gt.jsxs)(Nn,{children:[(0,gt.jsxs)(Tn,{htmlFor:"nome",children:["Nome",(0,gt.jsx)(qn,{children:"*"})]}),(0,gt.jsx)(Pn,{type:"text",id:"nome",name:"nome",value:e.nome,onChange:p,placeholder:"Il tuo nome",required:!0})]}),(0,gt.jsxs)(Nn,{children:[(0,gt.jsxs)(Tn,{htmlFor:"cognome",children:["Cognome",(0,gt.jsx)(qn,{children:"*"})]}),(0,gt.jsx)(Pn,{type:"text",id:"cognome",name:"cognome",value:e.cognome,onChange:p,placeholder:"Il tuo cognome",required:!0})]})]}),(0,gt.jsxs)(Nn,{children:[(0,gt.jsxs)(Tn,{htmlFor:"username",children:["Username",(0,gt.jsx)(qn,{children:"*"})]}),(0,gt.jsx)(Pn,{type:"text",id:"username",name:"username",value:e.username,onChange:p,placeholder:"Scegli un username",className:d.username.status,required:!0}),d.username.message&&(0,gt.jsx)(Un,{className:d.username.status,children:d.username.message})]}),(0,gt.jsxs)(Nn,{children:[(0,gt.jsxs)(Tn,{htmlFor:"email",children:["Email",(0,gt.jsx)(qn,{children:"*"})]}),(0,gt.jsx)(Pn,{type:"email",id:"email",name:"email",value:e.email,onChange:p,placeholder:"La tua email",className:d.email.status,required:!0}),d.email.message&&(0,gt.jsx)(Un,{className:d.email.status,children:d.email.message})]}),(0,gt.jsxs)(Fn,{children:[(0,gt.jsxs)(Nn,{children:[(0,gt.jsxs)(Tn,{htmlFor:"password",children:["Password",(0,gt.jsx)(qn,{children:"*"})]}),(0,gt.jsx)(Pn,{type:"password",id:"password",name:"password",value:(null===e||void 0===e?void 0:e.password)||"",onChange:p,placeholder:"Scegli una password",required:!0})]}),(0,gt.jsxs)(Nn,{children:[(0,gt.jsxs)(Tn,{htmlFor:"confermaPassword",children:["Conferma Password",(0,gt.jsx)(qn,{children:"*"})]}),(0,gt.jsx)(Pn,{type:"password",id:"confermaPassword",name:"confermaPassword",value:e.confermaPassword,onChange:p,placeholder:"Conferma la password",required:!0})]})]}),(0,gt.jsxs)(Nn,{children:[(0,gt.jsx)(Tn,{htmlFor:"provenienza",children:"Provenienza"}),(0,gt.jsx)(Pn,{type:"text",id:"provenienza",name:"provenienza",value:e.provenienza,onChange:p,placeholder:"La tua citt\xe0/regione"})]}),(0,gt.jsxs)(Nn,{children:[(0,gt.jsx)(Tn,{htmlFor:"squadra_cuore",children:"Squadra del Cuore"}),(0,gt.jsx)(Pn,{type:"text",id:"squadra_cuore",name:"squadra_cuore",value:e.squadra_cuore,onChange:p,placeholder:"La tua squadra preferita"})]}),(0,gt.jsxs)(Nn,{children:[(0,gt.jsx)(Tn,{htmlFor:"come_conosciuto",children:"Come ci hai conosciuto"}),(0,gt.jsxs)($n,{id:"come_conosciuto",name:"come_conosciuto",value:e.come_conosciuto,onChange:p,children:[(0,gt.jsx)("option",{value:"",children:"Seleziona un'opzione"}),(0,gt.jsx)("option",{value:"Presidente di Lega",children:"Presidente di Lega"}),(0,gt.jsx)("option",{value:"Amico",children:"Amico"}),(0,gt.jsx)("option",{value:"Radio",children:"Radio"}),(0,gt.jsx)("option",{value:"Podcast",children:"Podcast"}),(0,gt.jsx)("option",{value:"Instagram",children:"Instagram"}),(0,gt.jsx)("option",{value:"Twitter",children:"Twitter"}),(0,gt.jsx)("option",{value:"Facebook",children:"Facebook"}),(0,gt.jsx)("option",{value:"Altro",children:"Altro"})]})]}),(0,gt.jsx)(In,{type:"submit",disabled:s||"valid"!==d.email.status||"valid"!==d.username.status,children:s?"Registrazione in corso...":"Registrati"}),(0,gt.jsx)(Dn,{children:"oppure"}),(0,gt.jsx)(Mn,{to:"/login",children:"Hai gi\xe0 un account? Fai login qui"})]})]})})};async function Gn(e,r){return ni.get(`/offerte/movimenti/${e}`,r)}const Wn=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
  
  @media (max-width: 768px) {
    padding: 0.5rem;
  }
`,Hn=Ie.div`
  background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
  border-radius: 20px;
  padding: 3rem 2rem;
  text-align: center;
  color: white;
  margin-bottom: 2rem;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="rgba(255,255,255,0.1)"/><circle cx="80" cy="40" r="1.5" fill="rgba(255,255,255,0.1)"/><circle cx="40" cy="80" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="90" r="1.5" fill="rgba(255,255,255,0.1)"/></svg>');
    opacity: 0.3;
  }
  
  @media (max-width: 768px) {
    padding: 2rem 1rem;
    border-radius: 12px;
    margin-bottom: 1rem;
  }
`,Vn=Ie.h1`
  font-size: 3rem;
  font-weight: 700;
  margin-bottom: 1rem;
  position: relative;
  z-index: 1;
  
  @media (max-width: 768px) {
    font-size: 1.8rem;
  }
  
  @media (max-width: 480px) {
    font-size: 1.5rem;
  }
`,Qn=Ie.p`
  font-size: 1.2rem;
  margin-bottom: 2rem;
  opacity: 0.9;
  position: relative;
  z-index: 1;
  
  @media (max-width: 768px) {
    font-size: 1rem;
    margin-bottom: 1.5rem;
  }
  
  @media (max-width: 480px) {
    font-size: 0.9rem;
  }
`,Kn=Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
  position: relative;
  z-index: 1;
`,Yn=Ie(lt)`
  background: ${e=>e.$primary?"linear-gradient(135deg, #ff6b35 0%, #f7931e 100%)":"rgba(255,255,255,0.2)"};
  color: white;
  padding: 1rem 2rem;
  border-radius: 50px;
  text-decoration: none;
  font-weight: 600;
  font-size: 1.1rem;
  transition: all 0.3s ease;
  border: 2px solid ${e=>e.$primary?"transparent":"rgba(255,255,255,0.3)"};
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    background: ${e=>e.$primary?"linear-gradient(135deg, #e55a2b 0%, #e0851a 100%)":"rgba(255,255,255,0.3)"};
  }
  
  @media (max-width: 768px) {
    padding: 0.8rem 1.5rem;
    font-size: 1rem;
  }
`,Jn=Ie.img`
  width: 100%;
  max-width: 600px;
  margin: 0 auto 1.5rem auto;
  display: block;
  border-radius: 18px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.10);
`,Zn=Ie(lt)`
  background: ${e=>e.$primary?"linear-gradient(135deg, #667eea 0%, #764ba2 100%)":"linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%)"};
  color: white;
  padding: 0.7rem 1.5rem;
  border-radius: 30px;
  min-width: 160px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  text-align: center;
  display: inline-block;
  font-weight: 600;
  font-size: 1.05rem;
  border: none;
  text-decoration: none;
  transition: all 0.3s;
  cursor: pointer;
  &:hover {
    filter: brightness(0.95);
    transform: translateY(-2px);
  }
`,Xn=Ie.tr`
  background: #f8f9fa;
`,eo=Ie.td`
  padding: 0;
  border-bottom: 1px solid #dee2e6;
`,ro=Ie.div`
  padding: 1.5rem;
`,to=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 0.75rem;
  margin-bottom: 1.5rem;
`,io=Ie.button`
  background: linear-gradient(135deg, #6f42c1 0%, #5a2d91 100%);
  color: white;
  border: none;
  padding: 0.75rem 0.5rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.75rem;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
`,no=(Ie.div`
  background: white;
  border-radius: 8px;
  padding: 1rem;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin-top: 1.5rem;
`,Ie.h4`
  color: #333;
  margin: 0 0 1rem 0;
  font-size: 1rem;
  font-weight: 600;
`,Ie.div`
  padding: 0.5rem 0;
  border-bottom: 1px solid #eee;
  font-size: 0.9rem;
  color: #333;
  
  &:last-child {
    border-bottom: none;
  }
`,Ie.button`
  background: linear-gradient(135deg, #007AFF 0%, #0056b3 100%);
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  font-size: 0.8rem;
  
  &:hover {
    transform: translateY(-1px);
  }
`),oo=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  
  @media (max-width: 600px) {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
    padding: 1rem;
  }
`,ao=Ie.h1`
  color: #1d1d1f;
  margin: 0;
  font-size: 1.5rem;
  font-weight: 600;
  
  @media (max-width: 768px) {
    font-size: 1.3rem;
  }
  
  @media (max-width: 480px) {
    font-size: 1.1rem;
  }
`,so=Ie.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  color: #86868b;
  font-size: 0.9rem;
  
  @media (max-width: 600px) {
    flex-direction: column;
    gap: 0.5rem;
    font-size: 0.8rem;
  }
`,lo=Ie.span`
  font-weight: 600;
  color: #1d1d1f;
`,co=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  display: flex;
  justify-content: center;
  
  @media (max-width: 768px) {
    padding: 1rem;
  }
`,uo=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  
  @media (max-width: 768px) {
    padding: 1rem;
  }
`,go=Ie.h2`
  color: #1d1d1f;
  margin: 0 0 1rem 0;
  font-size: 1.1rem;
  font-weight: 600;
`,po=Ie.table`
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 1rem;
`,ho=Ie.th`
  background: #5856d6;
  color: white;
  padding: 0.75rem 0.5rem;
  text-align: left;
  font-weight: 600;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.2s;
  
  &:hover {
    background: #4a4ac7;
  }
  
  &:first-child {
    border-top-left-radius: 8px;
  }
  
  &:last-child {
    border-top-right-radius: 8px;
  }
  
  ${e=>e.$sortable&&`\n    &::after {\n      content: '${"asc"===e.$sortDirection?"\u25b2":"desc"===e.$sortDirection?"\u25bc":"\u2195"}';\n      position: absolute;\n      right: 0.5rem;\n      color: white;\n      font-size: 0.8rem;\n    }\n  `}
`,mo=Ie.td`
  padding: 0.75rem;
  border-bottom: 1px solid #e5e5e7;
  font-size: 0.9rem;
`,fo=Ie(lt)`
  color: #5856d6;
  text-decoration: none;
  font-weight: 500;
  
  &:hover {
    text-decoration: underline;
  }
`,xo=Ie.span`
  padding: 0.25rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  
  ${e=>"pubblica"===e.$status&&"\n    background: #d4edda;\n    color: #155724;\n  "}
  
  ${e=>"privata"===e.$status&&"\n    background: #f8d7da;\n    color: #721c24;\n  "}
`,vo=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,bo=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,jo=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1.2rem;
  flex-wrap: wrap;
  width: 100%;
  margin-bottom: 1rem;

  @media (max-width: 600px) {
    flex-direction: column;
    gap: 0.7rem;
    width: 100%;
  }
`,yo=(Ie.button`
  background: linear-gradient(135deg, #007AFF 0%, #0056b3 100%);
  color: white;
  border: none;
  padding: 0.5rem 1.2rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  font-size: 0.95rem;
  transition: transform 0.2s;
  &:hover {
    transform: translateY(-1px);
    background: linear-gradient(135deg, #0056b3 0%, #007AFF 100%);
  }
  
  @media (max-width: 768px) {
    padding: 0.4rem 1rem;
    font-size: 0.9rem;
  }
  
  @media (max-width: 480px) {
    padding: 0.3rem 0.8rem;
    font-size: 0.85rem;
  }
`,Ie.span`
  font-weight: 600;
  color: #28a745;
`,Ie.button`
  display: none;
  @media (max-width: 768px) {
    display: block;
    margin: 1.5rem auto 0 auto;
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
    color: white;
    border: none;
    border-radius: 30px;
    padding: 0.9rem 2rem;
    font-size: 1.1rem;
    font-weight: 600;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    cursor: pointer;
    transition: all 0.2s;
    &:hover {
      filter: brightness(0.95);
      transform: translateY(-2px);
    }
  }
`),wo=Ie.div`
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
`,ko=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem 1.5rem;
  max-width: 350px;
  width: 90%;
  text-align: center;
  box-shadow: 0 10px 30px rgba(0,0,0,0.18);
`,_o=Ie.h3`
  color: #ff6b35;
  margin-bottom: 1rem;
`,So=Ie.p`
  color: #333;
  font-size: 1.05rem;
  margin-bottom: 1.5rem;
`,Co=Ie.button`
  background: #eee;
  color: #333;
  border: none;
  border-radius: 8px;
  padding: 0.7rem 1.5rem;
  font-weight: 600;
  cursor: pointer;
  margin-top: 0.5rem;
  &:hover { background: #ddd; }
`,zo=()=>{const{user:e,token:t}=Si(),i=qr(),[n,o]=(0,r.useState)(!0),[a,s]=(0,r.useState)(null),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)([]),[g,p]=(0,r.useState)([]),[h,m]=(0,r.useState)([]),[f,x]=(0,r.useState)([]),[v,b]=(0,r.useState)("nome"),[j,y]=(0,r.useState)("asc"),[w,k]=(0,r.useState)("nome"),[_,S]=(0,r.useState)("asc"),[C,z]=(0,r.useState)([]),[E,A]=(0,r.useState)(null),[R,N]=(0,r.useState)(!1),[T,q]=(0,r.useState)(null);(0,r.useEffect)(()=>{const e=window.navigator.userAgent;/android/i.test(e)?q("android"):/iphone|ipad|ipod/i.test(e)?q("ios"):q(null)},[]),(0,r.useEffect)(()=>{(async()=>{if(e&&t){try{var r,i,n,a,l;o(!0);const s=await ji(t,e.id);d((null===s||void 0===s||null===(r=s.data)||void 0===r?void 0:r.leghe)||(null===s||void 0===s?void 0:s.leghe)||[]);const c=await ji(t,e.id),g=(null===c||void 0===c||null===(i=c.data)||void 0===i?void 0:i.leghe)||(null===c||void 0===c?void 0:c.leghe)||[];u(g);const h=await bi(t,e.id);p((null===h||void 0===h||null===(n=h.data)||void 0===n?void 0:n.squadre)||(null===h||void 0===h?void 0:h.squadre)||[]);const f=await vi(t,e.id);m((null===f||void 0===f||null===(a=f.data)||void 0===a?void 0:a.notifiche)||(null===f||void 0===f?void 0:f.notifiche)||[]);const v=(null===h||void 0===h||null===(l=h.data)||void 0===l?void 0:l.squadre)||(null===h||void 0===h?void 0:h.squadre)||[],b=(null===v||void 0===v?void 0:v.map(e=>e&&null!==e&&void 0!==e&&e.lega_id?Gn(e.lega_id,t):(console.warn("\ud83d\udd0d Home: Squadra o lega_id undefined, skipping"),Promise.resolve([]))))||[],j=(await Promise.all(b)).flatMap(e=>{var r;return(null===e||void 0===e||null===(r=e.data)||void 0===r?void 0:r.movimenti)||(null===e||void 0===e?void 0:e.movimenti)||[]});x(j)}catch(c){s(c.message)}o(!1)}else o(!1)})()},[e,t]),(0,r.useEffect)(()=>{const e=()=>{};return window.addEventListener("focus",e),()=>window.removeEventListener("focus",e)},[]);const P=e=>{v===e?y("asc"===j?"desc":"asc"):(b(e),y("asc"))},$=(null===h||void 0===h?void 0:h.filter(e=>!e.letta&&!e.letto).length)||0,I=async e=>{await(async e=>{try{await ni.put(`/notifiche/${e}/letta`,{},t),m(r=>r.map(r=>r.id===e?{...r,letta:!0,letto:1}:r))}catch(a){console.error("Errore marcatura notifica come letta:",a)}})(e.id),i("/notifiche")};if(!e||!t)return(0,gt.jsxs)(Wn,{children:[(0,gt.jsxs)(Hn,{children:[(0,gt.jsx)(Vn,{children:"TopLeague"}),(0,gt.jsx)(Qn,{children:"La piattaforma definitiva per gestire il tuo Fantacalcio con stile professionale"}),(0,gt.jsxs)(Kn,{children:[(0,gt.jsx)(Yn,{to:"/login",$primary:!0,children:"Login"}),(0,gt.jsx)(Yn,{to:"/register",children:"Registrati"})]}),(0,gt.jsx)(yo,{onClick:()=>N(!0),children:"\ud83d\udcf2 Salva nella Home"})]}),R&&(0,gt.jsx)(wo,{onClick:()=>N(!1),children:(0,gt.jsxs)(ko,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsx)(_o,{children:"Aggiungi a Home"}),"ios"===T?(0,gt.jsxs)(So,{children:["Su ",(0,gt.jsx)("b",{children:"iPhone/iPad"}),":",(0,gt.jsx)("br",{}),"Premi il pulsante ",(0,gt.jsx)("b",{children:"Condividi"})," ",(0,gt.jsx)("span",{style:{fontSize:"1.3em"},children:"\u2934\ufe0f"})," in basso e poi ",(0,gt.jsx)("b",{children:'"Aggiungi a Home"'}),".",(0,gt.jsx)("br",{}),(0,gt.jsx)("br",{}),(0,gt.jsx)("img",{src:"https://developer.apple.com/design/human-interface-guidelines/images/intro/intro-share-action_2x.png",alt:"share",style:{width:60,margin:"0.5em auto"}})]}):"android"===T?(0,gt.jsxs)(So,{children:["Su ",(0,gt.jsx)("b",{children:"Android"}),":",(0,gt.jsx)("br",{}),"Premi il menu ",(0,gt.jsx)("b",{children:"\u22ee"})," in alto a destra e poi ",(0,gt.jsx)("b",{children:'"Aggiungi a schermata Home"'}),".",(0,gt.jsx)("br",{}),(0,gt.jsx)("br",{}),(0,gt.jsx)("img",{src:"https://i.imgur.com/2yQF1Qp.png",alt:"android add",style:{width:60,margin:"0.5em auto"}})]}):(0,gt.jsx)(So,{children:"Usa questa funzione da un dispositivo mobile per aggiungere TopLeague alla schermata Home!"}),(0,gt.jsx)(Co,{onClick:()=>N(!1),children:"Chiudi"})]})})]});if(n)return(0,gt.jsx)(Wn,{children:(0,gt.jsx)(vo,{children:"Caricamento dashboard..."})});if(a)return(0,gt.jsx)(Wn,{children:(0,gt.jsxs)(bo,{children:["Errore: ",a]})});const O=(L=l,[...L].sort((e,r)=>{let t=e[v],i=r[v];return null!==t&&void 0!==t||(t=""),null!==i&&void 0!==i||(i=""),t=String(t).toLowerCase(),i=String(i).toLowerCase(),"asc"===j?t.localeCompare(i):i.localeCompare(t)})).slice(0,3);var L;(M=g,M.sort((e,r)=>{let t,i;switch(w){case"nome":default:t=(null===e||void 0===e?void 0:e.nome)||"Nome",i=(null===r||void 0===r?void 0:r.nome)||"Nome";break;case"club_level":t=e.club_level||1,i=r.club_level||1;break;case"casse_societarie":t=e.casse_societarie||0,i=r.casse_societarie||0}return"asc"===_?t>i?1:-1:t<i?1:-1})).slice(0,3);var M;return(0,gt.jsxs)(Wn,{children:[(0,gt.jsxs)(oo,{children:[(0,gt.jsx)(ao,{children:"Benvenuto in TopLeague"}),(0,gt.jsxs)(so,{children:[(0,gt.jsxs)(lo,{children:[null===e||void 0===e?void 0:e.nome," ",null===e||void 0===e?void 0:e.cognome]}),(0,gt.jsx)("span",{children:"\u2022"}),(0,gt.jsx)("span",{children:null===e||void 0===e?void 0:e.email})]})]}),(0,gt.jsx)(co,{children:(0,gt.jsxs)("div",{style:{width:"100%"},children:[(0,gt.jsx)(Jn,{src:"https://topleague-frontend-new.onrender.com/TLprova.png",alt:"TopLeague"}),(0,gt.jsxs)(jo,{children:[(0,gt.jsx)(Zn,{to:"/crea-lega",$primary:!0,children:"Crea Lega"}),(0,gt.jsx)(Zn,{to:"/unisciti-lega",children:"Unisciti a Lega"})]})]})}),((null===g||void 0===g?void 0:g.length)||0)>0&&(0,gt.jsxs)(uo,{children:[(0,gt.jsx)(go,{children:"Area Manager"}),(0,gt.jsxs)(po,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(ho,{children:"Squadra"}),(0,gt.jsx)(ho,{children:"Club Level"}),(0,gt.jsx)(ho,{children:"Torneo"}),(0,gt.jsx)(ho,{children:"Ingaggi"}),(0,gt.jsx)(ho,{children:"Casse Societarie"}),(0,gt.jsx)(ho,{children:"Valore Attuale"}),(0,gt.jsx)(ho,{children:"Giocatori"}),(0,gt.jsx)(ho,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:null===g||void 0===g?void 0:g.map(e=>{var t;let n=0,o=0,a=0;Array.isArray(null===e||void 0===e?void 0:e.giocatori)&&(null===e||void 0===e||null===(t=e.giocatori)||void 0===t?void 0:t.length)>0?(n=e.giocatori.reduce((e,r)=>e+(parseInt(null===r||void 0===r?void 0:r.quotazione_attuale)||0),0),o=e.giocatori.reduce((e,r)=>e+(parseInt(null===r||void 0===r?void 0:r.costo_attuale)||0),0),a=e.giocatori.length):"number"===typeof(null===e||void 0===e?void 0:e.numero_giocatori)&&(a=e.numero_giocatori);const s=(null===e||void 0===e?void 0:e.max_giocatori)||30,l=e.logo_url,d=e.torneo_nome||"N/A",c=(null===e||void 0===e?void 0:e.casse_societarie)||0,u=(g=null===e||void 0===e?void 0:e.id,null===h||void 0===h?void 0:h.filter(e=>e.squadra_id===g).length);var g;const p=C.includes(e.id);return(0,gt.jsxs)(r.Fragment,{children:[(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(mo,{children:(0,gt.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"0.5rem"},children:[l?(0,gt.jsx)("img",{src:`https://topleaguem.onrender.com/uploads/${l}`,alt:"logo",style:{width:32,height:32,borderRadius:"50%",objectFit:"cover",background:"#eee"}}):(0,gt.jsx)("img",{src:"data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iMTYiIGZpbGw9IiNGRkZGRkYiIHN0cm9rZT0iI0U1RTVFNyIgc3Ryb2tlLXdpZHRoPSIxIi8+CjxwYXRoIGQ9Ik0xNiA4QzE4LjIwOTEgOCAyMCA5Ljc5MDg2IDIwIDEyQzIwIDE0LjIwOTEgMTguMjA5MSAxNiAxNiAxNkMxMy43OTA5IDE2IDEyIDE0LjIwOTEgMTIgMTJDMTIgOS43OTA4NiAxMy43OTA5IDggMTYgOFoiIGZpbGw9IiM5OTk5OTkiLz4KPHBhdGggZD0iTTggMjRDMTAuMjA5MSAyNCAxMiAyMi4yMDkxIDEyIDIwQzEyIDE3Ljc5MDkgMTAuMjA5MSAxNiA4IDE2QzUuNzkwODYgMTYgNCAxNy43OTA5IDQgMjBDNCAyMi4yMDkxIDUuNzkwODYgMjQgOCAyNFoiIGZpbGw9IiM5OTk5OTkiLz4KPHBhdGggZD0iTTI0IDI0QzI2LjIwOTEgMjQgMjggMjIuMjA5MSAyOCAyMEMyOCAxNy43OTA5IDI2LjIwOTEgMTYgMjQgMTZDMjEuNzkwOSAxNiAyMCAxNy43OTA5IDIwIDIwQzIwIDIyLjIwOTEgMjEuNzkwOSAyNCAyNCAyNFoiIGZpbGw9IiM5OTk5OTkiLz4KPC9zdmc+",alt:"logo",style:{width:32,height:32,borderRadius:"50%",objectFit:"cover",background:"#eee"}}),(0,gt.jsx)("span",{style:{fontWeight:600,cursor:"pointer",color:"#FF8C42"},onClick:()=>i(`/gestione-squadra/${null===e||void 0===e?void 0:e.lega_id}`),children:(null===e||void 0===e?void 0:e.nome)||"Nome"})]})}),(0,gt.jsx)(mo,{children:e.club_level||1}),(0,gt.jsx)(mo,{children:d}),(0,gt.jsxs)(mo,{children:["FM ",o.toLocaleString()]}),(0,gt.jsxs)(mo,{children:["FM ",c.toLocaleString()]}),(0,gt.jsxs)(mo,{children:["FM ",n.toLocaleString()]}),(0,gt.jsxs)(mo,{children:[a,"/",s]}),(0,gt.jsx)(mo,{children:(0,gt.jsx)(no,{onClick:()=>(e=>{z(r=>r.includes(e)?r.filter(r=>r!==e):[...r,e])})(e.id),children:p?"Chiudi":"Gestisci"})})]}),p&&(0,gt.jsx)(Xn,{children:(0,gt.jsx)(eo,{colSpan:"8",children:(0,gt.jsx)(ro,{children:(0,gt.jsxs)(to,{children:[(0,gt.jsx)(io,{onClick:()=>i(`/gestione-squadra/${null===e||void 0===e?void 0:e.lega_id}`),children:"Visualizza"}),(0,gt.jsxs)(io,{onClick:()=>i(`/notifiche?squadra=${e.id}`),children:["Notifiche (",u,")"]}),(0,gt.jsx)(io,{onClick:()=>i(`/proponi-offerta?squadra=${e.id}`),children:"Proponi Offerta"}),(0,gt.jsx)(io,{onClick:()=>i(`/richiesta-admin?squadra=${e.id}`),children:"Richiesta Admin"}),(0,gt.jsx)(io,{onClick:()=>i(`/log-squadra/${e.id}`),children:"Log"})]})})})})]},e.id)})})]})]}),((null===l||void 0===l?void 0:l.length)||0)>0&&(0,gt.jsxs)(uo,{children:[(0,gt.jsx)(go,{children:"Area Admin"}),(0,gt.jsxs)(po,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(ho,{$sortable:!0,$sortDirection:"nome"===v?j:null,onClick:()=>P("nome"),children:"Nome Lega"}),(0,gt.jsx)(ho,{$sortable:!0,$sortDirection:"modalita"===v?j:null,onClick:()=>P("modalita"),children:"Modalit\xe0"}),(0,gt.jsx)(ho,{$sortable:!0,$sortDirection:"is_pubblica"===v?j:null,onClick:()=>P("is_pubblica"),children:"Tipo"}),(0,gt.jsx)(ho,{$sortable:!0,$sortDirection:"squadre_assegnate"===v?j:null,onClick:()=>P("squadre_assegnate"),children:"Squadre"})]})}),(0,gt.jsx)("tbody",{children:null===O||void 0===O?void 0:O.map(e=>(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(mo,{children:(0,gt.jsx)(fo,{to:`/lega/${e.id}`,children:(null===e||void 0===e?void 0:e.nome)||"Nome"})}),(0,gt.jsx)(mo,{children:(null===e||void 0===e?void 0:e.modalita)||"N/A"}),(0,gt.jsx)(mo,{children:(0,gt.jsx)(xo,{$status:null!==e&&void 0!==e&&e.is_pubblica?"pubblica":"privata",children:null!==e&&void 0!==e&&e.is_pubblica?"Pubblica":"Privata"})}),(0,gt.jsxs)(mo,{children:[e.squadre_assegnate||0,"/",e.numero_squadre_totali||0]})]},e.id))})]})]}),((null===h||void 0===h?void 0:h.length)||0)>0&&0===((null===l||void 0===l?void 0:l.length)||0)&&(0,gt.jsxs)(uo,{children:[(0,gt.jsxs)(go,{children:["Notifiche Recenti",$>0&&(0,gt.jsx)("span",{style:{backgroundColor:"#007bff",color:"white",borderRadius:"50%",padding:"2px 8px",fontSize:"0.8rem",marginLeft:"10px",cursor:"pointer"},onClick:async()=>{await(async()=>{try{await ni.put("/notifiche/tutte-lette",{},t),m(e=>e.map(e=>({...e,letta:!0,letto:1})))}catch(a){console.error("Errore marcatura tutte notifiche come lette:",a)}})(),i("/notifiche")},children:$})]}),h.slice(0,5).map(e=>(0,gt.jsxs)("div",{style:{padding:"1rem",borderBottom:"1px solid #e5e5e7",backgroundColor:e.letta?"transparent":"#f8f9fa",cursor:"pointer"},onClick:()=>I(e),children:[(0,gt.jsx)("div",{style:{fontWeight:"600",marginBottom:"0.5rem"},children:e.titolo}),(0,gt.jsx)("div",{style:{color:"#666",fontSize:"0.9rem"},children:e.messaggio}),(0,gt.jsx)("div",{style:{color:"#999",fontSize:"0.8rem",marginTop:"0.5rem"},children:new Date(e.created_at).toLocaleDateString("it-IT")})]},e.id))]})]})};async function Eo(e){return ni.get("/leghe",e)}async function Ao(e,r){return ni.get(`/leghe/${e}`,r)}async function Ro(e,r){return ni.get(`/leghe/${e}/squadre`,r)}async function No(e){return ni.get("/leghe/admin",e)}async function To(e){return ni.get("/leghe/all",e)}async function qo(e,r){return ni.delete(`/leghe/${e}`,r)}const Po=async(e,r)=>ni.get(`/leghe/${e}/squadre-disponibili`,r),$o=async e=>ni.get("/leghe/richieste/utente",e);async function Io(e,r){return ni.get(`/squadre/${e}`,r)}async function Oo(e,r){return ni.get(`/squadre/lega/${e}`,r)}async function Lo(e){return ni.get("/squadre/utente",e)}async function Mo(e,r){return ni.get(`/squadre/${e}/giocatori`,r)}const Do=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`,Fo=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  max-width: 600px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
`,Uo=Ie.h2`
  color: #333;
  margin: 0 0 1.5rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Bo=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,Go=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,Wo=Ie.label`
  font-weight: 600;
  color: #333;
`,Ho=Ie.input`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`,Vo=(Ie.select`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`,Ie.textarea`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  min-height: 100px;
  resize: vertical;
  font-family: inherit;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`),Qo=Ie.div`
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
`,Ko=Ie.button`
  background: ${e=>e.$secondary?"#6c757d":"linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%)"};
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,Yo=Ie.div`
  background: #f8f9fa;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
`,Jo=Ie.h3`
  margin: 0 0 0.5rem 0;
  color: #333;
  font-size: 1.1rem;
`,Zo=Ie.div`
  color: #666;
  font-size: 0.9rem;
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
`,Xo=Ie.div`
  background: #f8f9fa;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
`,ea=Ie.h4`
  margin: 0 0 1rem 0;
  color: #333;
  font-size: 1rem;
`,ra=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 0.5rem;
  margin-bottom: 1rem;
`,ta=Ie.div`
  border: 2px solid ${e=>e.$selected?"#FFA94D":e.$available?"#28a745":"#6c757d"};
  border-radius: 6px;
  padding: 0.5rem;
  background: ${e=>e.$selected?"#fff3e0":e.$available?"#f8fff9":"#f8f9fa"};
  cursor: ${e=>e.$available?"pointer":"not-allowed"};
  transition: all 0.2s;
  opacity: ${e=>e.$available?1:.6};
  
  &:hover {
    ${e=>e.$available&&"\n      border-color: #FFA94D;\n      background: #fff3e0;\n    "}
  }
`,ia=Ie.div`
  font-weight: 600;
  color: #333;
  font-size: 0.85rem;
  text-align: center;
  margin-bottom: 0.25rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`,na=Ie.div`
  font-size: 0.7rem;
  color: ${e=>e.$available?"#28a745":"#6c757d"};
  font-weight: 500;
  text-align: center;
  text-transform: uppercase;
`,oa=Ie.div`
  text-align: center;
  color: #666;
  padding: 2rem;
`,aa=Ie.div`
  color: #dc3545;
  background: #f8d7da;
  border: 1px solid #f5c6cb;
  border-radius: 6px;
  padding: 0.75rem;
  margin-bottom: 1rem;
`,sa=e=>{let{lega:t,onClose:i,onSuccess:n}=e;const{token:o}=Si(),[a,s]=(0,r.useState)({messaggio:"",password:"",squadra_id:""}),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)([]),[g,p]=(0,r.useState)(!1),[h,m]=(0,r.useState)(!0),[f,x]=(0,r.useState)("");(0,r.useEffect)(()=>{(async()=>{try{m(!0);const e=await Po(t.id,o);d(e.squadre_disponibili||[]),u(e.squadre_assegnate||[])}catch(e){x("Errore nel caricamento delle squadre disponibili"),console.error("Errore nel caricamento squadre:",e)}finally{m(!1)}})()},[t.id,o]);const v=e=>{s(r=>({...r,[e.target.name]:e.target.value}))};if(h)return(0,gt.jsx)(Do,{onClick:i,children:(0,gt.jsx)(Fo,{onClick:e=>e.stopPropagation(),children:(0,gt.jsx)(oa,{children:"Caricamento squadre disponibili..."})})});const b=[...l,...c];return(0,gt.jsx)(Do,{onClick:i,children:(0,gt.jsxs)(Fo,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(Uo,{children:["\ud83d\udd17 Richiedi Ingresso - ",null===t||void 0===t?void 0:t.nome]}),(0,gt.jsxs)(Yo,{children:[(0,gt.jsx)(Jo,{children:null===t||void 0===t?void 0:t.nome}),(0,gt.jsxs)(Zo,{children:[(0,gt.jsxs)("span",{children:["Modalit\xe0: ",(null===t||void 0===t?void 0:t.modalita)||""]}),(0,gt.jsxs)("span",{children:["Tipo: ",null!==t&&void 0!==t&&t.is_pubblica?"Pubblica":"Privata"]}),(0,gt.jsxs)("span",{children:["Squadre: ",(null===t||void 0===t?void 0:t.squadre_assegnate)||0,"/",(null===t||void 0===t?void 0:t.numero_squadre_totali)||0]})]})]}),(0,gt.jsxs)(Xo,{children:[(0,gt.jsx)(ea,{children:"Seleziona una Squadra Disponibile *"}),0===b.length?(0,gt.jsx)("div",{style:{textAlign:"center",color:"#666",padding:"1rem"},children:"Nessuna squadra in questa lega."}):(0,gt.jsx)(ra,{children:b.map(e=>{const r=1===e.is_orfana,t=(null===a||void 0===a?void 0:a.squadra_id)===e.id.toString();return(0,gt.jsxs)(ta,{$selected:t,$available:r,onClick:()=>{return r&&(t=e.id,void s(e=>({...e,squadra_id:t.toString()})));var t},children:[(0,gt.jsx)(ia,{children:e.nome}),(0,gt.jsx)(na,{$available:r,children:r?"Disponibile":"Assegnata"})]},e.id)})})]}),(0,gt.jsxs)(Bo,{onSubmit:async e=>{if(e.preventDefault(),null!==a&&void 0!==a&&a.squadra_id)if(null!==a&&void 0!==a&&a.messaggio){p(!0),x("");try{const e={messaggio:(null===a||void 0===a?void 0:a.messaggio)||"",squadra_id:(null===a||void 0===a?void 0:a.squadra_id)||""};null!==t&&void 0!==t&&t.is_pubblica||null===a||void 0===a||!a.password||(e.password=a.password),await(async(e,r,t)=>ni.post(`/leghe/${e}/richiedi-ingresso`,r,t))(t.id,e,o);const r=l.find(e=>e.id===parseInt((null===a||void 0===a?void 0:a.squadra_id)||""));n(`Richiesta di ingresso inviata con successo per la squadra "${null===r||void 0===r?void 0:r.nome}" nella lega "${t.nome}"!`),i()}catch(r){x(r.message||"Errore nell'invio della richiesta")}finally{p(!1)}}else x("Inserisci un messaggio per la tua richiesta");else x("Seleziona una squadra")},children:[(0,gt.jsxs)(Go,{children:[(0,gt.jsx)(Wo,{children:"Messaggio di Presentazione *"}),(0,gt.jsx)(Vo,{name:"messaggio",value:a.messaggio,onChange:v,placeholder:"Presentati e spiega perch\xe9 vorresti unirti a questa lega...",required:!0})]}),!(null!==t&&void 0!==t&&t.is_pubblica)&&(0,gt.jsxs)(Go,{children:[(0,gt.jsx)(Wo,{children:"Password Lega (se richiesta)"}),(0,gt.jsx)(Ho,{type:"password",name:"password",value:(null===a||void 0===a?void 0:a.password)||"",onChange:v,placeholder:"Inserisci la password della lega se richiesta"})]}),f&&(0,gt.jsx)(aa,{children:f}),(0,gt.jsxs)(Qo,{children:[(0,gt.jsx)(Ko,{type:"submit",disabled:g||!(null!==a&&void 0!==a&&a.squadra_id),children:g?"Invio...":"Invia Richiesta"}),(0,gt.jsx)(Ko,{type:"button",$secondary:!0,onClick:i,children:"Annulla"})]})]})]})})},la=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,da=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 500px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
`,ca=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #eee;
`,ua=Ie.h2`
  margin: 0;
  color: #333;
  font-size: 1.5rem;
`,ga=Ie.button`
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #666;
  
  &:hover {
    color: #333;
  }
`,pa=Ie.div`
  margin-bottom: 1.5rem;
`,ha=Ie.p`
  color: #666;
  margin-bottom: 1.5rem;
  line-height: 1.5;
`,ma=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
`,fa=Ie.button`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border: 2px solid ${e=>e.$selected?"#007AFF":"#eee"};
  border-radius: 8px;
  background: ${e=>e.$selected?"#f0f8ff":"white"};
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    border-color: #007AFF;
    background: #f0f8ff;
  }
`,xa=Ie.span`
  font-weight: 600;
  color: #333;
`,va=Ie.span`
  font-size: 0.8rem;
  color: #666;
`,ba=Ie.div`
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  padding-top: 1rem;
  border-top: 1px solid #eee;
`,ja=Ie.button`
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,ya=Ie(ja)`
  background: #6c757d;
  color: white;
  
  &:hover:not(:disabled) {
    background: #5a6268;
  }
`,wa=Ie(ja)`
  background: linear-gradient(135deg, #007AFF 0%, #0056b3 100%);
  color: white;
  
  &:hover:not(:disabled) {
    transform: translateY(-1px);
  }
`,ka=Ie.div`
  color: #dc3545;
  background: #f8d7da;
  border: 1px solid #f5c6cb;
  border-radius: 6px;
  padding: 0.75rem;
  margin-bottom: 1rem;
`,_a=Ie.div`
  color: #666;
  text-align: center;
  padding: 2rem;
`,Sa=e=>{let{lega:t,onClose:i,onSuccess:n}=e;const{token:o}=Si(),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)(null),[c,u]=(0,r.useState)(!0),[g,p]=(0,r.useState)(!1),[h,m]=(0,r.useState)("");(0,r.useEffect)(()=>{(async()=>{try{u(!0);const e=await Po(t.id,o);s(e.squadre_disponibili||[])}catch(e){m("Errore nel caricamento delle squadre disponibili"),console.error("Errore nel caricamento squadre:",e)}finally{u(!1)}})()},[t.id,o]);return c?(0,gt.jsx)(la,{children:(0,gt.jsx)(da,{children:(0,gt.jsx)(_a,{children:"Caricamento squadre disponibili..."})})}):(0,gt.jsx)(la,{onClick:i,children:(0,gt.jsxs)(da,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(ca,{children:[(0,gt.jsxs)(ua,{children:["Seleziona Squadra - ",t.nome]}),(0,gt.jsx)(ga,{onClick:i,children:"\xd7"})]}),(0,gt.jsxs)(pa,{children:[(0,gt.jsx)(ha,{children:"Come amministratore di questa lega, puoi scegliere direttamente una squadra disponibile senza inviare richieste."}),h&&(0,gt.jsx)(ka,{children:h}),0===a.length?(0,gt.jsx)("div",{style:{textAlign:"center",color:"#666",padding:"2rem"},children:"Nessuna squadra disponibile in questa lega."}):(0,gt.jsx)(ma,{children:a.map(e=>(0,gt.jsxs)(fa,{$selected:(null===l||void 0===l?void 0:l.id)===e.id,onClick:()=>d(e),children:[(0,gt.jsx)(xa,{children:e.nome}),(0,gt.jsx)(va,{children:"Disponibile"})]},e.id))})]}),(0,gt.jsxs)(ba,{children:[(0,gt.jsx)(ya,{onClick:i,disabled:g,children:"Annulla"}),(0,gt.jsx)(wa,{onClick:async()=>{if(l)try{p(!0),m(""),await async function(e,r){return ni.post(`/squadre/${e}/assign`,{},r)}(l.id,o),n(`Squadra "${l.nome}" assegnata con successo!`),i()}catch(e){m("Errore nell'assegnazione della squadra: "+(e.message||"Errore sconosciuto")),console.error("Errore assegnazione squadra:",e)}finally{p(!1)}},disabled:!l||g,children:g?"Assegnazione...":"Assegna Squadra"})]})]})})},Ca=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`,za=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,Ea=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Aa=Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
`,Ra=Ie.h2`
  font-size: 0.9rem;
  color: #86868b;
  margin: 0 0 1rem 0;
  font-weight: 500;
`,Na=Ie.div`
  display: flex;
  gap: 1rem;
  
  @media (max-width: 600px) {
    flex-direction: column;
  }
`,Ta=Ie(lt)`
  background: #007AFF;
  color: white;
  text-decoration: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.9rem;
  transition: background-color 0.2s;
  
  &:hover {
    background: #0056b3;
  }
`,qa=Ie(Ta)`
  background: #ff9500;
  
  &:hover {
    background: #e6850e;
  }
`,Pa=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border: 1px solid #f0f0f0;
`,$a=Ie.h3`
  color: #333;
  margin: 0 0 1rem 0;
  font-size: 1.2rem;
`,Ia=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1.2rem;
  margin-bottom: 0.5rem;
`,Oa=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,La=Ie.label`
  font-weight: 600;
  color: #333;
  font-size: 0.9rem;
`,Ma=Ie.select`
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 0.9rem;
  background: white;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`,Da=Ie.input`
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 0.9rem;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`,Fa=(Ie.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  background: white;
  cursor: pointer;
  transition: border-color 0.2s;
  
  &:hover {
    border-color: #FFA94D;
  }
  
  input[type="checkbox"] {
    width: 16px;
    height: 16px;
    cursor: pointer;
  }
  
  label {
    cursor: pointer;
    font-size: 0.9rem;
    color: #333;
    font-weight: 500;
  }
`,Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
`),Ua=Ie.button`
  background: ${e=>e.$primary?"linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%)":"#6c757d"};
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  font-size: 0.9rem;
  
  &:hover {
    transform: translateY(-1px);
  }
`,Ba=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border: 1px solid #f0f0f0;
`,Ga=Ie.table`
  width: 100%;
  border-collapse: collapse;
`,Wa=Ie.th`
  background: #5856d6;
  color: white;
  padding: 0.75rem 0.5rem;
  text-align: left;
  font-weight: 600;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.2s;
  
  &:hover {
    background: #4a4ac7;
  }
  
  &:first-child {
    border-top-left-radius: 8px;
  }
  
  &:last-child {
    border-top-right-radius: 8px;
  }
  
  ${e=>e.$sortable&&`\n    &::after {\n      content: '${"asc"===e.$sortDirection?"\u25b2":"desc"===e.$sortDirection?"\u25bc":"\u2195"}';\n      position: absolute;\n      right: 0.5rem;\n      color: white;\n      font-size: 0.8rem;\n    }\n  `}
`,Ha=Ie.td`
  padding: 1rem;
  border-bottom: 1px solid #dee2e6;
  color: #333;
  vertical-align: middle;
`,Va=Ie(lt)`
  color: #007bff;
  text-decoration: none;
  font-weight: 600;
  
  &:hover {
    color: #0056b3;
    text-decoration: underline;
  }
`,Qa=Ie.span`
  background: ${e=>"pubblica"===e.$status?"#28a745":"#6c757d"};
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
`,Ka=(Ie.span`
  background: ${e=>e.active?"#d4edda":"#f8f9fa"};
  color: ${e=>e.active?"#155724":"#666"};
  padding: 0.25rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 500;
  margin-right: 0.25rem;
  margin-bottom: 0.25rem;
  display: inline-block;
`,Ie.button`
  background: ${e=>e.$isManage?"linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%)":"linear-gradient(135deg, #28a745 0%, #20c997 100%)"};
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  font-size: 0.8rem;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`),Ya=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,Ja=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,Za=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
  text-align: center;
`,Xa=Ie.div`
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-weight: 600;
  background: ${e=>e.$success?"#d4edda":"#f8d7da"};
  color: ${e=>e.$success?"#155724":"#721c24"};
`,es=Ie.tr`
  background: #f8f9fa;
`,rs=Ie.td`
  padding: 0;
  border-bottom: 1px solid #dee2e6;
`,ts=Ie.div`
  padding: 1.5rem;
`,is=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
`,ns=Ie.div`
  text-align: center;
  padding: 1rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,os=Ie.div`
  color: #666;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 0.5rem;
`,as=Ie.div`
  color: #333;
  font-size: 1.1rem;
  font-weight: 600;
`,ss=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 0.75rem;
  margin-bottom: 1.5rem;
`,ls=Ie.button`
  background: linear-gradient(135deg, #6f42c1 0%, #5a2d91 100%);
  color: white;
  border: none;
  padding: 0.75rem 0.5rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.75rem;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
`,ds=Ie.div`
  display: flex;
  justify-content: center;
  margin-top: 1.5rem;
`,cs=Ie.div`
  display: flex;
  border-radius: 999px;
  background: #e9ecef;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
  overflow: hidden;
  width: 340px;
`,us=Ie.button`
  flex: 1;
  padding: 0.8rem 0;
  font-size: 1.1rem;
  font-weight: 600;
  border: none;
  outline: none;
  cursor: pointer;
  background: ${e=>e.$active?"#d4edda":"#f8f9fa"};
  color: ${e=>e.$active?"#155724":"#666"};
  transition: background 0.2s, color 0.2s;
`,gs=()=>{const{token:e,user:t}=Si(),i=qr(),[n,o]=(0,r.useState)([]),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)(!0),[c,u]=(0,r.useState)(""),[g,p]=(0,r.useState)(""),[h,m]=(0,r.useState)(!1),[f,x]=(0,r.useState)(null),[v,b]=(0,r.useState)(!1),[j,y]=(0,r.useState)([]),[w,k]=(0,r.useState)(null),[_,S]=(0,r.useState)("nome"),[C,z]=(0,r.useState)("asc"),[E,A]=(0,r.useState)({tipo:"tutti",stato:"tutti",squadreMin:"",squadreMax:"",soloMieLeghe:!0});(0,r.useEffect)(()=>{m(!1),b(!1),x(null)},[]),(0,r.useEffect)(()=>{h&&console.log("\ud83d\udea8 POPUP JOIN APERTO - showJoinForm:",h,"selectedLega:",null===f||void 0===f?void 0:f.nome)},[h,f]),(0,r.useEffect)(()=>{e&&async function(){d(!0),u("");try{var r,t,i;console.log("\ud83d\udd0d Leghe: Starting fetchData"),console.log("\ud83d\udd0d Leghe: Token available:",!!e);const[n,a,l]=await Promise.all([Eo(e),$o(e),Lo(e)]);console.log("\ud83d\udd0d Leghe: Leghe response:",n),console.log("\ud83d\udd0d Leghe: Richieste response:",a),console.log("\ud83d\udd0d Leghe: Squadre response:",l);const d=(null===n||void 0===n?void 0:n.data)||n,c=(null===a||void 0===a?void 0:a.data)||a,u=(null===l||void 0===l?void 0:l.data)||l;o((null===d||void 0===d?void 0:d.leghe)||[]),s((null===c||void 0===c?void 0:c.richieste)||[]),y((null===u||void 0===u?void 0:u.squadre)||[]),console.log("\ud83d\udd0d Leghe: Leghe set:",(null===(r=d.leghe)||void 0===r?void 0:r.length)||0),console.log("\ud83d\udd0d Leghe: Richieste set:",(null===(t=c.richieste)||void 0===t?void 0:t.length)||0),console.log("\ud83d\udd0d Leghe: Squadre set:",(null===(i=u.squadre)||void 0===i?void 0:i.length)||0)}catch(n){console.error("\u274c Leghe: Error in fetchData:",n),u(n.message)}d(!1)}()},[e]);const R=e=>{if(e.is_iscritto)return!1;return!a.some(r=>(null===r||void 0===r?void 0:r.lega_id)===(null===e||void 0===e?void 0:e.id))&&!!e.ha_squadre_disponibili},N=e=>e.admin_id===(null===t||void 0===t?void 0:t.id),T=e=>j.some(r=>(null===r||void 0===r?void 0:r.lega_id)===(null===e||void 0===e?void 0:e.id)),q=e=>{if(e.is_iscritto)return"Hai gi\xe0 una squadra in questa lega";const r=a.find(r=>(null===r||void 0===r?void 0:r.lega_id)===(null===e||void 0===e?void 0:e.id));if(r)switch(r.stato){case"in_attesa":return"Richiesta in attesa di risposta";case"accettata":return"Richiesta accettata";case"rifiutata":return"Richiesta rifiutata";default:return"Hai gi\xe0 una richiesta per questa lega"}return e.ha_squadre_disponibili?null:"Nessuna squadra disponibile"},P=e=>{_===e?z("asc"===C?"desc":"asc"):(S(e),z("asc"))},$=e=>{if(console.log("\ud83d\udd0d handleRichiediIngresso chiamato per lega:",e.nome),N(e))return console.log("\ud83d\udc51 Utente \xe8 admin della lega, mostro selettore admin"),x(e),void b(!0);if(!R(e)){const r=q(e);return console.log("\u274c Utente non pu\xf2 richiedere:",r),u(r),void setTimeout(()=>u(""),3e3)}console.log("\u2705 Utente pu\xf2 richiedere, apro form richiesta"),x(e),m(!0)},I=async r=>{p(r);try{var t,i,n;const[r,a,l]=await Promise.all([Eo(e),$o(e),Lo(e)]);o((null===r||void 0===r||null===(t=r.data)||void 0===t?void 0:t.leghe)||(null===r||void 0===r?void 0:r.leghe)||[]),s((null===a||void 0===a||null===(i=a.data)||void 0===i?void 0:i.richieste)||(null===a||void 0===a?void 0:a.richieste)||[]),y((null===l||void 0===l||null===(n=l.data)||void 0===n?void 0:n.squadre)||(null===l||void 0===l?void 0:l.squadre)||[])}catch(a){console.error("Errore nel ricaricamento dati:",a)}},O=(e,r)=>{A(t=>({...t,[e]:r}))},L=e=>{A(r=>({...r,soloMieLeghe:e}))};if(l)return(0,gt.jsx)(Ca,{children:(0,gt.jsx)(Ya,{children:"Caricamento leghe..."})});if(c&&!g)return(0,gt.jsx)(Ca,{children:(0,gt.jsxs)(Ja,{children:["Errore: ",c]})});const M=(D=n||[],console.log("\ud83d\udd0d Leghe: filterLeghe chiamata con:",(null===D||void 0===D?void 0:D.length)||0,"leghe"),console.log("\ud83d\udd0d Leghe: filters:",E),D.filter(e=>{if(console.log("\ud83d\udd0d Leghe: Controllando lega:",e.nome),E.soloMieLeghe){const r=N(e),t=T(e);if(console.log("\ud83d\udd0d Leghe: soloMieLeghe=true, isAdmin:",r,"hasTeam:",t),!r&&!t)return console.log("\ud83d\udd0d Leghe: Nascondendo lega (non \xe8 dell'utente):",e.nome),!1}else{const r=N(e),t=T(e);if(console.log("\ud83d\udd0d Leghe: soloMieLeghe=false, isAdmin:",r,"hasTeam:",t),r||t)return console.log("\ud83d\udd0d Leghe: Nascondendo lega (utente ha accesso):",e.nome),!1}if("tutti"!==E.tipo){if("pubblica"===E.tipo&&(null===e||void 0===e||!e.is_pubblica))return!1;if("privata"===E.tipo&&null!==e&&void 0!==e&&e.is_pubblica)return!1}if("tutti"!==E.stato){const r=(e=>(e.squadre_assegnate||0)>=(e.numero_squadre_totali||0))(e);if("completa"===E.stato&&!r)return!1;if("non_completa"===E.stato&&r)return!1}return!(E.squadreMin&&((null===e||void 0===e?void 0:e.max_squadre)||0)<parseInt(E.squadreMin))&&!(E.squadreMax&&((null===e||void 0===e?void 0:e.max_squadre)||0)>parseInt(E.squadreMax))}));var D;const F=(U=M,[...U].sort((e,r)=>{let t=e[_],i=r[_];return null!==t&&void 0!==t||(t=""),null!==i&&void 0!==i||(i=""),t=String(t).toLowerCase(),i=String(i).toLowerCase(),"asc"===C?t.localeCompare(i):i.localeCompare(t)}));var U;return(0,gt.jsxs)(Ca,{children:[(0,gt.jsx)(za,{onClick:()=>i(-1),children:"\u2190 Torna indietro"}),g&&(0,gt.jsx)(Xa,{$success:!0,children:g}),c&&(0,gt.jsx)(Xa,{$success:!1,children:c}),(0,gt.jsxs)(Ea,{children:[(0,gt.jsx)(Aa,{children:"Leghe Disponibili"}),(0,gt.jsx)(Ra,{children:"Esplora e unisciti alle leghe fantasy football"}),(0,gt.jsx)(Na,{children:(0,gt.jsx)(qa,{to:"/crea-lega",children:"Crea una Lega"})})]}),(0,gt.jsxs)(Pa,{children:[(0,gt.jsx)($a,{children:"Filtri"}),(0,gt.jsxs)(Ia,{children:[(0,gt.jsxs)(Oa,{children:[(0,gt.jsx)(La,{children:"Tipo"}),(0,gt.jsxs)(Ma,{value:E.tipo,onChange:e=>O("tipo",e.target.value),children:[(0,gt.jsx)("option",{value:"tutti",children:"Tutti i tipi"}),(0,gt.jsx)("option",{value:"pubblica",children:"Pubblica"}),(0,gt.jsx)("option",{value:"privata",children:"Privata"})]})]}),(0,gt.jsxs)(Oa,{children:[(0,gt.jsx)(La,{children:"Stato"}),(0,gt.jsxs)(Ma,{value:E.stato,onChange:e=>O("stato",e.target.value),children:[(0,gt.jsx)("option",{value:"tutti",children:"Tutti gli stati"}),(0,gt.jsx)("option",{value:"completa",children:"Completa"}),(0,gt.jsx)("option",{value:"non_completa",children:"Non completa"})]})]}),(0,gt.jsxs)(Oa,{children:[(0,gt.jsx)(La,{children:"Numero squadre nella lega (min)"}),(0,gt.jsx)(Da,{type:"number",min:"0",value:E.squadreMin,onChange:e=>O("squadreMin",e.target.value),placeholder:"Min"})]}),(0,gt.jsxs)(Oa,{children:[(0,gt.jsx)(La,{children:"Numero squadre nella lega (max)"}),(0,gt.jsx)(Da,{type:"number",min:"0",value:E.squadreMax,onChange:e=>O("squadreMax",e.target.value),placeholder:"Max"})]})]}),(0,gt.jsx)(Fa,{children:(0,gt.jsx)(Ua,{onClick:()=>{A({tipo:"tutti",stato:"tutti",squadreMin:"",squadreMax:"",soloMieLeghe:!1})},children:"Cancella Filtri"})}),(0,gt.jsx)(ds,{children:(0,gt.jsxs)(cs,{children:[(0,gt.jsx)(us,{$active:E.soloMieLeghe,onClick:()=>L(!0),children:"Le tue Leghe"}),(0,gt.jsx)(us,{$active:!E.soloMieLeghe,onClick:()=>L(!1),children:"Leghe Disponibili"})]})})]}),0===F.length?(0,gt.jsx)(Za,{children:(0,gt.jsxs)("div",{children:[(0,gt.jsx)("h3",{children:"Nessuna lega disponibile"}),(0,gt.jsx)("p",{children:"Non ci sono leghe che corrispondono ai filtri selezionati."})]})}):(0,gt.jsx)(Ba,{children:(0,gt.jsxs)(Ga,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Wa,{$sortable:!0,$sortDirection:"nome"===_?C:null,onClick:()=>P("nome"),children:"Nome Lega"}),(0,gt.jsx)(Wa,{$sortable:!0,$sortDirection:"admin_nome"===_?C:null,onClick:()=>P("admin_nome"),children:"Admin"}),(0,gt.jsx)(Wa,{$sortable:!0,$sortDirection:"modalita"===_?C:null,onClick:()=>P("modalita"),children:"Modalit\xe0"}),(0,gt.jsx)(Wa,{$sortable:!0,$sortDirection:"is_pubblica"===_?C:null,onClick:()=>P("is_pubblica"),children:"Tipo"}),(0,gt.jsx)(Wa,{$sortable:!0,$sortDirection:"squadre_assegnate"===_?C:null,onClick:()=>P("squadre_assegnate"),children:"Squadre"}),(0,gt.jsx)(Wa,{$sortable:!0,$sortDirection:"squadre_disponibili"===_?C:null,onClick:()=>P("squadre_disponibili"),children:"Disponibili"}),(0,gt.jsx)(Wa,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:F.map(e=>{const t=R(e),n=q(e),o=N(e),a=T(e),s=(l=e.id,j.find(e=>(null===e||void 0===e?void 0:e.lega_id)===l));var l;const d=w===e.id;return(0,gt.jsxs)(r.Fragment,{children:[(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Ha,{children:(0,gt.jsx)(Va,{to:`/lega/${e.id}`,children:e.nome})}),(0,gt.jsx)(Ha,{children:e.admin_nome||"N/A"}),(0,gt.jsx)(Ha,{children:(null===e||void 0===e?void 0:e.modalita)||"N/A"}),(0,gt.jsx)(Ha,{children:(0,gt.jsx)(Qa,{$status:null!==e&&void 0!==e&&e.is_pubblica?"pubblica":"privata",children:null!==e&&void 0!==e&&e.is_pubblica?"Pubblica":"Privata"})}),(0,gt.jsxs)(Ha,{children:[e.squadre_assegnate||0,"/",e.numero_squadre_totali||0]}),(0,gt.jsx)(Ha,{children:e.squadre_disponibili||0}),(0,gt.jsx)(Ha,{children:o?a?(0,gt.jsx)(Ka,{$isManage:!0,onClick:()=>(e=>{k(w===e?null:e)})(e.id),title:"Gestisci Squadra",children:"Gestisci"}):(0,gt.jsx)(Ka,{onClick:()=>$(e),title:"Seleziona Squadra",children:"Seleziona Squadra"}):(0,gt.jsx)(Ka,{onClick:()=>$(e),disabled:!t,title:n||"Richiedi Ingresso",children:t?"Richiedi Ingresso":n||"Non Disponibile"})})]}),d&&s&&(0,gt.jsx)(es,{children:(0,gt.jsx)(rs,{colSpan:"7",children:(0,gt.jsxs)(ts,{children:[(0,gt.jsxs)(is,{children:[(0,gt.jsxs)(ns,{children:[(0,gt.jsx)(os,{children:"Squadra"}),(0,gt.jsx)(as,{children:s.nome})]}),(0,gt.jsxs)(ns,{children:[(0,gt.jsx)(os,{children:"Lega"}),(0,gt.jsx)(as,{children:e.nome})]}),(0,gt.jsxs)(ns,{children:[(0,gt.jsx)(os,{children:"Admin"}),(0,gt.jsx)(as,{children:e.admin_nome||"N/A"})]}),(0,gt.jsxs)(ns,{children:[(0,gt.jsx)(os,{children:"Modalit\xe0"}),(0,gt.jsx)(as,{children:(null===e||void 0===e?void 0:e.modalita)||"N/A"})]})]}),(0,gt.jsxs)(ss,{children:[(0,gt.jsx)(ls,{onClick:()=>i(`/squadra/${s.id}`),children:"Dettagli Squadra"}),(0,gt.jsx)(ls,{onClick:()=>i(`/lega/${e.id}`),children:"Dettagli Lega"}),(0,gt.jsx)(ls,{onClick:()=>i("/area-manager"),children:"Area Manager"})]})]})})})]},e.id)})})]})}),h&&f&&(0,gt.jsx)(sa,{lega:f,onClose:()=>{m(!1),x(null)},onSuccess:I}),v&&f&&(0,gt.jsx)(Sa,{lega:f,onClose:()=>{b(!1),x(null)},onSuccess:I})]})},ps=Ie.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
`,hs=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,ms=Ie.form`
  background: #fff;
  padding: 2rem;
  border-radius: 16px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
`,fs=Ie.h2`
  color: #333;
  margin-bottom: 2rem;
  text-align: center;
  font-size: 2rem;
`,xs=Ie.div`
  margin-bottom: 1.5rem;
`,vs=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
`,bs=Ie.input`
  width: 100%;
  padding: 12px;
  border: 2px solid #e1e5e9;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`,js=Ie.select`
  width: 100%;
  padding: 12px;
  border: 2px solid #e1e5e9;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`,ys=Ie.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  margin-top: 0.5rem;
`,ws=Ie.label`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 6px;
  transition: background-color 0.2s;
  
  &:hover {
    background-color: #f8f9fa;
  }
  
  input[type="checkbox"] {
    width: auto;
    margin: 0;
  }
`,ks=Ie.div`
  margin-top: 0.5rem;
  
  input[type="file"] {
    width: 100%;
    padding: 8px;
    border: 2px dashed #e1e5e9;
    border-radius: 8px;
    background: #f8f9fa;
    
    &:focus {
      outline: none;
      border-color: #FFA94D;
    }
  }
`,_s=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
`,Ss=Ie.button`
  width: 100%;
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  color: white;
  border: none;
  border-radius: 8px;
  padding: 16px;
  font-weight: 700;
  font-size: 1.1rem;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(255, 169, 77, 0.3);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,Cs=Ie.div`
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  text-align: center;
  font-weight: 600;
  
  &.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
  }
  
  &.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
  }
`,zs=()=>{var e;const{user:t,token:i}=Si(),n=qr(),[o,a]=(0,r.useState)({nome:"",modalita:"Serie A Classic",is_pubblica:!0,password:"",max_squadre:"",min_giocatori:"",max_giocatori:"",roster_ab:!1,cantera:!1,contratti:!1,triggers:!1,fantacalcio_url:"",fantacalcio_username:"",fantacalcio_password:"",scraping_automatico:!1}),[s,l]=(0,r.useState)(null),[d,c]=(0,r.useState)(null),[u,g]=(0,r.useState)(""),[p,h]=(0,r.useState)(!1),[m,f]=(0,r.useState)([]),[x,v]=(0,r.useState)(!1),[b,j]=(0,r.useState)(!1),[y,w]=(0,r.useState)(null),k=e=>{const{name:r,value:t,type:i,checked:n}=e.target;a(e=>({...e,[r]:"checkbox"===i?n:t}))},_=e=>{"excel"===e.target.name&&l(e.target.files[0]),"pdf"===e.target.name&&c(e.target.files[0])};return(0,gt.jsxs)(ps,{children:[(0,gt.jsx)(hs,{onClick:()=>n(-1),children:"\u2190 Torna indietro"}),(0,gt.jsxs)(ms,{onSubmit:async e=>{var r,p;if(e.preventDefault(),g(""),h(!1),v(!0),null===o||void 0===o||null===(r=o.nome)||void 0===r||!r.trim())return g("Il nome della lega \xe8 obbligatorio"),void v(!1);if((null===o||void 0===o||!o.is_pubblica)&&(null===o||void 0===o||null===(p=o.password)||void 0===p||!p.trim()))return g("La password \xe8 obbligatoria per le leghe private"),void v(!1);if(!s)return g("Carica un file Excel con le squadre"),void v(!1);if(null!==o&&void 0!==o&&o.scraping_automatico){var m,x,b;if(null===o||void 0===o||null===(m=o.fantacalcio_url)||void 0===m||!m.trim())return g("URL Fantacalcio richiesto per lo scraping automatico"),void v(!1);if(null===o||void 0===o||null===(x=o.fantacalcio_username)||void 0===x||!x.trim())return g("Username Fantacalcio richiesto per lo scraping automatico"),void v(!1);if(null===o||void 0===o||null===(b=o.fantacalcio_password)||void 0===b||!b.trim())return g("Password Fantacalcio richiesta per lo scraping automatico"),void v(!1)}try{var j;const e=await async function(e,r){var t,i,n,o,a;console.log("\ud83d\udd0d [creaLega] Inizio creazione lega..."),console.log("\ud83d\udd0d [creaLega] Dati ricevuti:",{nome:e.nome,modalita:e.modalita,admin_id:e.admin_id,is_pubblica:e.is_pubblica,max_squadre:e.max_squadre,min_giocatori:e.min_giocatori,max_giocatori:e.max_giocatori,excel_size:null===(t=e.excel)||void 0===t?void 0:t.size,excel_name:null===(i=e.excel)||void 0===i?void 0:i.name,excel_type:null===(n=e.excel)||void 0===n?void 0:n.type,pdf_size:null===(o=e.regolamento_pdf)||void 0===o?void 0:o.size,pdf_name:null===(a=e.regolamento_pdf)||void 0===a?void 0:a.name});const s=new FormData;Object.entries(e).forEach(e=>{let[r,t]=e;void 0!==t&&null!==t&&(s.append(r,t),console.log(`\ud83d\udd0d [creaLega] Aggiunto al FormData: ${r} = ${t instanceof File?`File(${t.size} bytes, ${t.type})`:t}`))}),console.log("\ud83d\udd0d [creaLega] FormData creato, invio richiesta..."),console.log("\ud83d\udd0d [creaLega] FormData entries:");for(let[l,d]of s.entries())console.log(`  ${l}: ${d instanceof File?`File(${d.size} bytes, ${d.type})`:d}`);try{const e=await ni.postFormData("/leghe/create",s,r);return console.log("\u2705 [creaLega] Risposta server:",e),e}catch(u){throw console.error("\u274c [creaLega] Errore durante la creazione:",u),u}}({...o,admin_id:null===t||void 0===t?void 0:t.id,excel:s,regolamento_pdf:d},i);h(!0),e.warnings&&null!==(j=e.warnings)&&void 0!==j&&j.length&&f(e.warnings),h(!0),a({nome:"",modalita:"Serie A Classic",is_pubblica:!0,password:"",max_squadre:"",min_giocatori:"",max_giocatori:"",roster_ab:!1,cantera:!1,contratti:!1,triggers:!1,fantacalcio_url:"",fantacalcio_username:"",fantacalcio_password:"",scraping_automatico:!1}),l(null),c(null),setTimeout(()=>{n("/area-admin")},2e3)}catch(y){y.message&&y.message.includes("Nome lega duplicato")||y.message&&y.message.includes("Esiste gi\xe0 una lega con questo nome")?g("Esiste gi\xe0 una lega con questo nome. Scegli un nome diverso."):g(y.message||"Errore durante la creazione della lega")}finally{v(!1)}},children:[(0,gt.jsx)(fs,{children:"\ud83c\udfc6 Crea Nuova Lega"}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"Nome Lega *"}),(0,gt.jsx)(bs,{name:"nome",placeholder:"Inserisci il nome della lega",value:(null===o||void 0===o?void 0:o.nome)||"Nome",onChange:k,required:!0})]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"Modalit\xe0 *"}),(0,gt.jsxs)(js,{name:"modalita",value:(null===o||void 0===o?void 0:o.modalita)||"",onChange:k,children:[(0,gt.jsx)("option",{value:"Serie A Classic",children:"Serie A Classic"}),(0,gt.jsx)("option",{value:"Serie A Mantra",children:"Serie A Mantra"}),(0,gt.jsx)("option",{value:"Euroleghe Classic",children:"Euroleghe Classic"}),(0,gt.jsx)("option",{value:"Euroleghe Mantra",children:"Euroleghe Mantra"})]})]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsxs)(vs,{children:[(0,gt.jsx)("input",{type:"checkbox",name:"is_pubblica",checked:(null===o||void 0===o?void 0:o.is_pubblica)||!1,onChange:k})," ","Lega Pubblica"]}),!(null!==o&&void 0!==o&&o.is_pubblica)||!1]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"Configurazione Squadre"}),(0,gt.jsxs)(_s,{children:[(0,gt.jsx)(bs,{name:"max_squadre",type:"number",placeholder:"Numero massimo squadre",value:(null===o||void 0===o?void 0:o.max_squadre)||"",onChange:k}),(0,gt.jsx)(bs,{name:"min_giocatori",type:"number",placeholder:"Min giocatori per squadra",value:(null===o||void 0===o?void 0:o.min_giocatori)||"",onChange:k}),(0,gt.jsx)(bs,{name:"max_giocatori",type:"number",placeholder:"Max giocatori per squadra",value:(null===o||void 0===o?void 0:o.max_giocatori)||"",onChange:k})]})]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"Funzionalit\xe0 Avanzate"}),(0,gt.jsxs)(ys,{children:[(0,gt.jsxs)(ws,{children:[(0,gt.jsx)("input",{type:"checkbox",name:"roster_ab",checked:(null===o||void 0===o?void 0:o.roster_ab)||!1,onChange:k}),"Roster A/B"]}),(0,gt.jsxs)(ws,{children:[(0,gt.jsx)("input",{type:"checkbox",name:"cantera",checked:(null===o||void 0===o?void 0:o.cantera)||!1,onChange:k}),"Cantera"]}),(0,gt.jsxs)(ws,{children:[(0,gt.jsx)("input",{type:"checkbox",name:"contratti",checked:(null===o||void 0===o?void 0:o.contratti)||!1,onChange:k}),"Contratti"]}),(0,gt.jsxs)(ws,{children:[(0,gt.jsx)("input",{type:"checkbox",name:"triggers",checked:(null===o||void 0===o?void 0:o.triggers)||!1,onChange:k}),"Triggers"]})]})]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"\ud83d\udd17 Configurazione Scraping Automatico (Opzionale)"}),(0,gt.jsx)("small",{style:{color:"#666",marginBottom:"1rem",display:"block"},children:"Configura l'importazione automatica dei dati da una piattaforma esterna"}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"URL Lega Fantacalcio"}),(0,gt.jsx)(bs,{name:"fantacalcio_url",type:"url",placeholder:"https://esempio-url-piattaforma/lega/...",value:o.fantacalcio_url,onChange:k}),(0,gt.jsx)("small",{style:{color:"#666",marginTop:"0.5rem",display:"block"},children:"L'URL della tua lega sulla piattaforma esterna"})]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"Username Fantacalcio"}),(0,gt.jsx)(bs,{name:"fantacalcio_username",type:"text",placeholder:"Il tuo username sulla piattaforma esterna",value:o.fantacalcio_username,onChange:k})]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"Password Fantacalcio"}),(0,gt.jsx)(bs,{name:"fantacalcio_password",type:"password",placeholder:"La tua password sulla piattaforma esterna",value:o.fantacalcio_password,onChange:k}),(0,gt.jsx)("small",{style:{color:"#666",marginTop:"0.5rem",display:"block"},children:"Le credenziali sono necessarie per accedere ai dati della lega"})]}),(0,gt.jsxs)(ws,{style:{marginTop:"1rem"},children:[(0,gt.jsx)("input",{type:"checkbox",name:"scraping_automatico",checked:o.scraping_automatico,onChange:k}),"Abilita scraping automatico (aggiorna dati ogni 3 ore)"]}),(o.fantacalcio_url||o.fantacalcio_username||o.fantacalcio_password)&&(0,gt.jsxs)("div",{style:{marginTop:"1rem",padding:"1rem",backgroundColor:"#f8f9fa",borderRadius:"8px"},children:[(0,gt.jsx)("button",{type:"button",onClick:async()=>{var e,r,t;if(null!==o&&void 0!==o&&null!==(e=o.fantacalcio_url)&&void 0!==e&&e.trim()&&null!==o&&void 0!==o&&null!==(r=o.fantacalcio_username)&&void 0!==r&&r.trim()&&null!==o&&void 0!==o&&null!==(t=o.fantacalcio_password)&&void 0!==t&&t.trim()){j(!0),w(null),g("");try{const e=await fetch("https://topleaguem.onrender.com/api/scraping/puppeteer/league",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${i}`},body:JSON.stringify({leagueUrl:(null===o||void 0===o?void 0:o.fantacalcio_url)||"",username:(null===o||void 0===o?void 0:o.fantacalcio_username)||"",password:(null===o||void 0===o?void 0:o.fantacalcio_password)||""})}),r=e.data;e.ok?w({success:!0,message:"\u2705 Connessione riuscita! Credenziali valide.",data:r.data}):w({success:!1,message:`\u274c Errore: ${r.error}`})}catch(n){w({success:!1,message:`\u274c Errore di connessione: ${n.message}`})}finally{j(!1)}}else g("Compila tutti i campi Fantacalcio per testare lo scraping")},disabled:b||!o.fantacalcio_url.trim()||!o.fantacalcio_username.trim()||!o.fantacalcio_password.trim(),style:{background:"#007bff",color:"white",border:"none",borderRadius:"6px",padding:"8px 16px",cursor:"pointer",marginBottom:"1rem"},children:b?"\ud83d\udd04 Test in corso...":"\ud83e\uddea Testa Connessione"}),y&&(0,gt.jsxs)("div",{style:{padding:"0.75rem",borderRadius:"6px",backgroundColor:y.success?"#d4edda":"#f8d7da",color:y.success?"#155724":"#721c24",border:"1px solid "+(y.success?"#c3e6cb":"#f5c6cb")},children:[y.message,y.success&&y.data&&(0,gt.jsxs)("div",{style:{marginTop:"0.5rem",fontSize:"0.9rem"},children:[(0,gt.jsx)("strong",{children:"Dati trovati:"}),y.data.rose&&(0,gt.jsxs)("div",{children:["\ud83d\udcca ",(null===(e=y.data.rose)||void 0===e?void 0:e.length)||0," squadre trovate"]})]})]})]})]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"Regolamento PDF (opzionale)"}),(0,gt.jsx)(ks,{children:(0,gt.jsx)("input",{type:"file",name:"pdf",accept:"application/pdf",onChange:_})})]}),(0,gt.jsxs)(xs,{children:[(0,gt.jsx)(vs,{children:"File Excel Squadre *"}),(0,gt.jsx)(ks,{children:(0,gt.jsx)("input",{type:"file",name:"excel",accept:".xls,.xlsx",onChange:_,required:!0})}),(0,gt.jsx)("small",{style:{color:"#666",marginTop:"0.5rem",display:"block"},children:"Il file Excel deve contenere le squadre con i relativi giocatori"})]}),u&&(0,gt.jsx)(Cs,{className:"error",children:u}),(null===m||void 0===m?void 0:m.length)||!1,"        ",p&&(0,gt.jsx)(Cs,{className:"success",children:"Lega creata con successo! Reindirizzamento in corso..."}),(0,gt.jsx)(Ss,{type:"submit",disabled:x,children:x?"Creazione in corso...":"Crea Lega"})]})]})},Es=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`,As=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,Rs=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
`,Ns=Ie.h1`
  color: #333;
  margin: 0;
  font-size: 2rem;
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,Ts=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
`,qs=Ie.form`
  display: flex;
  gap: 1rem;
  align-items: end;
`,Ps=Ie.div`
  flex: 1;
`,$s=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
  font-weight: 600;
`,Is=Ie.input`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
`,Os=Ie.select`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
`,Ls=Ie.button`
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
`,Ms=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border: 1px solid #f0f0f0;
`,Ds=Ie.table`
  width: 100%;
  border-collapse: collapse;
`,Fs=Ie.th`
  background: #f8f9fa;
  padding: 1rem;
  text-align: left;
  font-weight: 600;
  color: #333;
  border-bottom: 2px solid #dee2e6;
  cursor: pointer;
  user-select: none;
  position: relative;
  
  &:hover {
    background: #e9ecef;
  }
  
  ${e=>e.$sortable&&`\n    &::after {\n      content: '${"asc"===e.$sortDirection?"\u25b2":"desc"===e.$sortDirection?"\u25bc":"\u2195"}';\n      position: absolute;\n      right: 0.5rem;\n      color: #666;\n      font-size: 0.8rem;\n    }\n  `}
`,Us=Ie.td`
  padding: 1rem;
  border-bottom: 1px solid #dee2e6;
  color: #333;
  vertical-align: middle;
`,Bs=Ie(lt)`
  color: #007bff;
  text-decoration: none;
  font-weight: 600;
  
  &:hover {
    color: #0056b3;
    text-decoration: underline;
  }
`,Gs=Ie.span`
  background: ${e=>"pubblica"===e.$status?"#28a745":"#6c757d"};
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
`,Ws=Ie.button`
  background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  font-size: 0.8rem;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,Hs=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,Vs=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,Qs=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
  text-align: center;
`,Ks=Ie.div`
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-weight: 600;
  background: ${e=>e.$success?"#d4edda":"#f8d7da"};
  color: ${e=>e.$success?"#155724":"#721c24"};
`,Ys=()=>{const{token:e,user:t}=Si(),i=qr(),[n,o]=(0,r.useState)([]),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)(!0),[g,p]=(0,r.useState)(""),[h,m]=(0,r.useState)(""),[f,x]=(0,r.useState)(""),[v,b]=(0,r.useState)(""),[j,y]=(0,r.useState)(!1),[w,k]=(0,r.useState)(null),[_,S]=(0,r.useState)(!1),[C,z]=(0,r.useState)([]),[E,A]=(0,r.useState)("nome"),[R,N]=(0,r.useState)("asc");(0,r.useEffect)(()=>{e&&async function(){u(!0),p("");try{var r,t,i,n;const[a,l]=await Promise.all([Eo(e),$o(e)]);o((null===a||void 0===a||null===(r=a.data)||void 0===r?void 0:r.leghe)||(null===a||void 0===a?void 0:a.leghe)||[]),s((null===a||void 0===a||null===(t=a.data)||void 0===t?void 0:t.leghe)||(null===a||void 0===a?void 0:a.leghe)||[]),d((null===l||void 0===l||null===(i=l.data)||void 0===i?void 0:i.richieste)||(null===l||void 0===l?void 0:l.richieste)||[]);const c=await Lo(e);z((null===c||void 0===c||null===(n=c.data)||void 0===n?void 0:n.squadre)||(null===c||void 0===c?void 0:c.squadre)||[])}catch(a){p(a.message)}u(!1)}()},[e]);const T=e=>{if(e.is_iscritto)return!1;return!l.some(r=>(null===r||void 0===r?void 0:r.lega_id)===(null===e||void 0===e?void 0:e.id))&&!!e.ha_squadre_disponibili},q=e=>C.some(r=>(null===r||void 0===r?void 0:r.lega_id)===(null===e||void 0===e?void 0:e.id)),P=e=>{if(e.is_iscritto)return"Hai gi\xe0 una squadra in questa lega";const r=l.find(r=>(null===r||void 0===r?void 0:r.lega_id)===(null===e||void 0===e?void 0:e.id));if(r)switch(r.stato){case"in_attesa":return"Richiesta in attesa di risposta";case"accettata":return"Richiesta accettata";case"rifiutata":return"Richiesta rifiutata";default:return"Hai gi\xe0 una richiesta per questa lega"}return e.ha_squadre_disponibili?null:"Nessuna squadra disponibile"},$=e=>{E===e?N("asc"===R?"desc":"asc"):(A(e),N("asc"))};(0,r.useEffect)(()=>{let e=n;var r;h&&(e=e.filter(e=>{var r;return e.nome.toLowerCase().includes(h.toLowerCase())||(null===(r=e.admin_nome)||void 0===r?void 0:r.toLowerCase().includes(h.toLowerCase()))})),f&&(e=e.filter(e=>((null===e||void 0===e?void 0:e.modalita)||"")===f)),r=e,e=[...r].sort((e,r)=>{let t=e[E],i=r[E];return null!==t&&void 0!==t||(t=""),null!==i&&void 0!==i||(i=""),t=String(t).toLowerCase(),i=String(i).toLowerCase(),"asc"===R?t.localeCompare(i):i.localeCompare(t)}),s(e)},[n,h,f,E,R]);const I=e=>{if((e=>e.admin_id===(null===t||void 0===t?void 0:t.id))(e))return k(e),void S(!0);if(!T(e)){const r=P(e);return p(r),void setTimeout(()=>p(""),3e3)}k(e),y(!0)},O=async r=>{b(r);try{var t,i,n,a;const[r,l,c]=await Promise.all([Eo(e),$o(e),Lo(e)]);o((null===r||void 0===r||null===(t=r.data)||void 0===t?void 0:t.leghe)||(null===r||void 0===r?void 0:r.leghe)||[]),s((null===r||void 0===r||null===(i=r.data)||void 0===i?void 0:i.leghe)||(null===r||void 0===r?void 0:r.leghe)||[]),d((null===l||void 0===l||null===(n=l.data)||void 0===n?void 0:n.richieste)||(null===l||void 0===l?void 0:l.richieste)||[]),z((null===c||void 0===c||null===(a=c.data)||void 0===a?void 0:a.squadre)||(null===c||void 0===c?void 0:c.squadre)||[])}catch(l){console.error("Errore nel ricaricamento dati:",l)}},L=[...new Set(n.map(e=>(null===e||void 0===e?void 0:e.modalita)||"").filter(Boolean))];return c?(0,gt.jsx)(Es,{children:(0,gt.jsx)(Hs,{children:"Caricamento leghe disponibili..."})}):g&&!v?(0,gt.jsx)(Es,{children:(0,gt.jsxs)(Vs,{children:["Errore: ",g]})}):(0,gt.jsxs)(Es,{children:[(0,gt.jsx)(As,{onClick:()=>i(-1),children:"\u2190 Torna indietro"}),(0,gt.jsx)(Rs,{children:(0,gt.jsx)(Ns,{children:"\ud83d\udd17 Unisciti a una Lega"})}),v&&(0,gt.jsx)(Ks,{$success:!0,children:v}),g&&(0,gt.jsx)(Ks,{$success:!1,children:g}),(0,gt.jsx)(Ts,{children:(0,gt.jsxs)(qs,{onSubmit:e=>e.preventDefault(),children:[(0,gt.jsxs)(Ps,{children:[(0,gt.jsx)($s,{children:"Cerca Lega"}),(0,gt.jsx)(Is,{type:"text",placeholder:"Nome lega o admin...",value:h,onChange:e=>m(e.target.value)})]}),(0,gt.jsxs)(Ps,{children:[(0,gt.jsx)($s,{children:"Modalit\xe0"}),(0,gt.jsxs)(Os,{value:f,onChange:e=>x(e.target.value),children:[(0,gt.jsx)("option",{value:"",children:"Tutte le modalit\xe0"}),L.map(e=>(0,gt.jsx)("option",{value:e,children:e},e))]})]}),(0,gt.jsx)(Ls,{type:"submit",children:"Cerca"})]})}),0===a.length?(0,gt.jsx)(Qs,{children:(0,gt.jsxs)("div",{children:[(0,gt.jsx)("h3",{children:"Nessuna lega trovata"}),(0,gt.jsx)("p",{children:"Non ci sono leghe disponibili con i criteri di ricerca selezionati."})]})}):(0,gt.jsx)(Ms,{children:(0,gt.jsxs)(Ds,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Fs,{$sortable:!0,$sortDirection:"nome"===E?R:null,onClick:()=>$("nome"),children:"Nome Lega"}),(0,gt.jsx)(Fs,{$sortable:!0,$sortDirection:"admin_nome"===E?R:null,onClick:()=>$("admin_nome"),children:"Admin"}),(0,gt.jsx)(Fs,{$sortable:!0,$sortDirection:"modalita"===E?R:null,onClick:()=>$("modalita"),children:"Modalit\xe0"}),(0,gt.jsx)(Fs,{$sortable:!0,$sortDirection:"is_pubblica"===E?R:null,onClick:()=>$("is_pubblica"),children:"Tipo"}),(0,gt.jsx)(Fs,{$sortable:!0,$sortDirection:"squadre_assegnate"===E?R:null,onClick:()=>$("squadre_assegnate"),children:"Squadre"}),(0,gt.jsx)(Fs,{$sortable:!0,$sortDirection:"squadre_disponibili"===E?R:null,onClick:()=>$("squadre_disponibili"),children:"Disponibili"}),(0,gt.jsx)(Fs,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:a.map(e=>{const r=T(e),n=P(e);return(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Us,{children:(0,gt.jsx)(Bs,{to:`/lega/${e.id}`,children:e.nome})}),(0,gt.jsx)(Us,{children:e.admin_nome||"N/A"}),(0,gt.jsx)(Us,{children:(null===e||void 0===e?void 0:e.modalita)||"N/A"}),(0,gt.jsx)(Us,{children:(0,gt.jsx)(Gs,{$status:null!==e&&void 0!==e&&e.is_pubblica?"pubblica":"privata",children:null!==e&&void 0!==e&&e.is_pubblica?"Pubblica":"Privata"})}),(0,gt.jsxs)(Us,{children:[e.squadre_assegnate||0,"/",e.numero_squadre_totali||0]}),(0,gt.jsx)(Us,{children:e.squadre_disponibili||0}),(0,gt.jsx)(Us,{children:e.admin_id===(null===t||void 0===t?void 0:t.id)?q(e)?(0,gt.jsx)(Ws,{onClick:()=>i("/area-manager"),title:"Gestisci Squadra",children:"Gestisci"}):(0,gt.jsx)(Ws,{onClick:()=>I(e),title:"Seleziona Squadra",children:"Seleziona Squadra"}):(0,gt.jsx)(Ws,{onClick:()=>I(e),disabled:!r,title:n||"Richiedi Ingresso",children:r?"Richiedi Ingresso":n||"Non Disponibile"})})]},e.id)})})]})}),j&&w&&(0,gt.jsx)(sa,{lega:w,onClose:()=>{y(!1),k(null)},onSuccess:O}),_&&w&&(0,gt.jsx)(Sa,{lega:w,onClose:()=>{S(!1),k(null)},onSuccess:O})]})};function Js(e,r){return function(){return e.apply(r,arguments)}}const{toString:Zs}=Object.prototype,{getPrototypeOf:Xs}=Object,{iterator:el,toStringTag:rl}=Symbol,tl=(il=Object.create(null),e=>{const r=Zs.call(e);return il[r]||(il[r]=r.slice(8,-1).toLowerCase())});var il;const nl=e=>(e=e.toLowerCase(),r=>tl(r)===e),ol=e=>r=>typeof r===e,{isArray:al}=Array,sl=ol("undefined");function ll(e){return null!==e&&!sl(e)&&null!==e.constructor&&!sl(e.constructor)&&ul(e.constructor.isBuffer)&&e.constructor.isBuffer(e)}const dl=nl("ArrayBuffer");const cl=ol("string"),ul=ol("function"),gl=ol("number"),pl=e=>null!==e&&"object"===typeof e,hl=e=>{if("object"!==tl(e))return!1;const r=Xs(e);return(null===r||r===Object.prototype||null===Object.getPrototypeOf(r))&&!(rl in e)&&!(el in e)},ml=nl("Date"),fl=nl("File"),xl=nl("Blob"),vl=nl("FileList"),bl=nl("URLSearchParams"),[jl,yl,wl,kl]=["ReadableStream","Request","Response","Headers"].map(nl);function _l(e,r){let t,i,{allOwnKeys:n=!1}=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};if(null!==e&&"undefined"!==typeof e)if("object"!==typeof e&&(e=[e]),al(e))for(t=0,i=e.length;t<i;t++)r.call(null,e[t],t,e);else{if(ll(e))return;const i=n?Object.getOwnPropertyNames(e):Object.keys(e),o=i.length;let a;for(t=0;t<o;t++)a=i[t],r.call(null,e[a],a,e)}}function Sl(e,r){if(ll(e))return null;r=r.toLowerCase();const t=Object.keys(e);let i,n=t.length;for(;n-- >0;)if(i=t[n],r===i.toLowerCase())return i;return null}const Cl="undefined"!==typeof globalThis?globalThis:"undefined"!==typeof self?self:"undefined"!==typeof window?window:global,zl=e=>!sl(e)&&e!==Cl;const El=(Al="undefined"!==typeof Uint8Array&&Xs(Uint8Array),e=>Al&&e instanceof Al);var Al;const Rl=nl("HTMLFormElement"),Nl=(e=>{let{hasOwnProperty:r}=e;return(e,t)=>r.call(e,t)})(Object.prototype),Tl=nl("RegExp"),ql=(e,r)=>{const t=Object.getOwnPropertyDescriptors(e),i={};_l(t,(t,n)=>{let o;!1!==(o=r(t,n,e))&&(i[n]=o||t)}),Object.defineProperties(e,i)};const Pl=nl("AsyncFunction"),$l=((e,r)=>{return e?setImmediate:r?(t=`axios@${Math.random()}`,i=[],Cl.addEventListener("message",e=>{let{source:r,data:n}=e;r===Cl&&n===t&&i.length&&i.shift()()},!1),e=>{i.push(e),Cl.postMessage(t,"*")}):e=>setTimeout(e);var t,i})("function"===typeof setImmediate,ul(Cl.postMessage)),Il="undefined"!==typeof queueMicrotask?queueMicrotask.bind(Cl):"undefined"!==typeof process&&process.nextTick||$l,Ol={isArray:al,isArrayBuffer:dl,isBuffer:ll,isFormData:e=>{let r;return e&&("function"===typeof FormData&&e instanceof FormData||ul(e.append)&&("formdata"===(r=tl(e))||"object"===r&&ul(e.toString)&&"[object FormData]"===e.toString()))},isArrayBufferView:function(e){let r;return r="undefined"!==typeof ArrayBuffer&&ArrayBuffer.isView?ArrayBuffer.isView(e):e&&e.buffer&&dl(e.buffer),r},isString:cl,isNumber:gl,isBoolean:e=>!0===e||!1===e,isObject:pl,isPlainObject:hl,isEmptyObject:e=>{if(!pl(e)||ll(e))return!1;try{return 0===Object.keys(e).length&&Object.getPrototypeOf(e)===Object.prototype}catch(xE){return!1}},isReadableStream:jl,isRequest:yl,isResponse:wl,isHeaders:kl,isUndefined:sl,isDate:ml,isFile:fl,isBlob:xl,isRegExp:Tl,isFunction:ul,isStream:e=>pl(e)&&ul(e.pipe),isURLSearchParams:bl,isTypedArray:El,isFileList:vl,forEach:_l,merge:function e(){const{caseless:r}=zl(this)&&this||{},t={},i=(i,n)=>{const o=r&&Sl(t,n)||n;hl(t[o])&&hl(i)?t[o]=e(t[o],i):hl(i)?t[o]=e({},i):al(i)?t[o]=i.slice():t[o]=i};for(let n=0,o=arguments.length;n<o;n++)arguments[n]&&_l(arguments[n],i);return t},extend:function(e,r,t){let{allOwnKeys:i}=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{};return _l(r,(r,i)=>{t&&ul(r)?e[i]=Js(r,t):e[i]=r},{allOwnKeys:i}),e},trim:e=>e.trim?e.trim():e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,""),stripBOM:e=>(65279===e.charCodeAt(0)&&(e=e.slice(1)),e),inherits:(e,r,t,i)=>{e.prototype=Object.create(r.prototype,i),e.prototype.constructor=e,Object.defineProperty(e,"super",{value:r.prototype}),t&&Object.assign(e.prototype,t)},toFlatObject:(e,r,t,i)=>{let n,o,a;const s={};if(r=r||{},null==e)return r;do{for(n=Object.getOwnPropertyNames(e),o=n.length;o-- >0;)a=n[o],i&&!i(a,e,r)||s[a]||(r[a]=e[a],s[a]=!0);e=!1!==t&&Xs(e)}while(e&&(!t||t(e,r))&&e!==Object.prototype);return r},kindOf:tl,kindOfTest:nl,endsWith:(e,r,t)=>{e=String(e),(void 0===t||t>e.length)&&(t=e.length),t-=r.length;const i=e.indexOf(r,t);return-1!==i&&i===t},toArray:e=>{if(!e)return null;if(al(e))return e;let r=e.length;if(!gl(r))return null;const t=new Array(r);for(;r-- >0;)t[r]=e[r];return t},forEachEntry:(e,r)=>{const t=(e&&e[el]).call(e);let i;for(;(i=t.next())&&!i.done;){const t=i.value;r.call(e,t[0],t[1])}},matchAll:(e,r)=>{let t;const i=[];for(;null!==(t=e.exec(r));)i.push(t);return i},isHTMLForm:Rl,hasOwnProperty:Nl,hasOwnProp:Nl,reduceDescriptors:ql,freezeMethods:e=>{ql(e,(r,t)=>{if(ul(e)&&-1!==["arguments","caller","callee"].indexOf(t))return!1;const i=e[t];ul(i)&&(r.enumerable=!1,"writable"in r?r.writable=!1:r.set||(r.set=()=>{throw Error("Can not rewrite read-only method '"+t+"'")}))})},toObjectSet:(e,r)=>{const t={},i=e=>{e.forEach(e=>{t[e]=!0})};return al(e)?i(e):i(String(e).split(r)),t},toCamelCase:e=>e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g,function(e,r,t){return r.toUpperCase()+t}),noop:()=>{},toFiniteNumber:(e,r)=>null!=e&&Number.isFinite(e=+e)?e:r,findKey:Sl,global:Cl,isContextDefined:zl,isSpecCompliantForm:function(e){return!!(e&&ul(e.append)&&"FormData"===e[rl]&&e[el])},toJSONObject:e=>{const r=new Array(10),t=(e,i)=>{if(pl(e)){if(r.indexOf(e)>=0)return;if(ll(e))return e;if(!("toJSON"in e)){r[i]=e;const n=al(e)?[]:{};return _l(e,(e,r)=>{const o=t(e,i+1);!sl(o)&&(n[r]=o)}),r[i]=void 0,n}}return e};return t(e,0)},isAsyncFn:Pl,isThenable:e=>e&&(pl(e)||ul(e))&&ul(e.then)&&ul(e.catch),setImmediate:$l,asap:Il,isIterable:e=>null!=e&&ul(e[el])};function Ll(e,r,t,i,n){Error.call(this),Error.captureStackTrace?Error.captureStackTrace(this,this.constructor):this.stack=(new Error).stack,this.message=e,this.name="AxiosError",r&&(this.code=r),t&&(this.config=t),i&&(this.request=i),n&&(this.response=n,this.status=n.status?n.status:null)}Ol.inherits(Ll,Error,{toJSON:function(){return{message:this.message,name:this.name,description:this.description,number:this.number,fileName:this.fileName,lineNumber:this.lineNumber,columnNumber:this.columnNumber,stack:this.stack,config:Ol.toJSONObject(this.config),code:this.code,status:this.status}}});const Ml=Ll.prototype,Dl={};["ERR_BAD_OPTION_VALUE","ERR_BAD_OPTION","ECONNABORTED","ETIMEDOUT","ERR_NETWORK","ERR_FR_TOO_MANY_REDIRECTS","ERR_DEPRECATED","ERR_BAD_RESPONSE","ERR_BAD_REQUEST","ERR_CANCELED","ERR_NOT_SUPPORT","ERR_INVALID_URL"].forEach(e=>{Dl[e]={value:e}}),Object.defineProperties(Ll,Dl),Object.defineProperty(Ml,"isAxiosError",{value:!0}),Ll.from=(e,r,t,i,n,o)=>{const a=Object.create(Ml);return Ol.toFlatObject(e,a,function(e){return e!==Error.prototype},e=>"isAxiosError"!==e),Ll.call(a,e.message,r,t,i,n),a.cause=e,a.name=e.name,o&&Object.assign(a,o),a};const Fl=Ll;function Ul(e){return Ol.isPlainObject(e)||Ol.isArray(e)}function Bl(e){return Ol.endsWith(e,"[]")?e.slice(0,-2):e}function Gl(e,r,t){return e?e.concat(r).map(function(e,r){return e=Bl(e),!t&&r?"["+e+"]":e}).join(t?".":""):r}const Wl=Ol.toFlatObject(Ol,{},null,function(e){return/^is[A-Z]/.test(e)});const Hl=function(e,r,t){if(!Ol.isObject(e))throw new TypeError("target must be an object");r=r||new FormData;const i=(t=Ol.toFlatObject(t,{metaTokens:!0,dots:!1,indexes:!1},!1,function(e,r){return!Ol.isUndefined(r[e])})).metaTokens,n=t.visitor||d,o=t.dots,a=t.indexes,s=(t.Blob||"undefined"!==typeof Blob&&Blob)&&Ol.isSpecCompliantForm(r);if(!Ol.isFunction(n))throw new TypeError("visitor must be a function");function l(e){if(null===e)return"";if(Ol.isDate(e))return e.toISOString();if(Ol.isBoolean(e))return e.toString();if(!s&&Ol.isBlob(e))throw new Fl("Blob is not supported. Use a Buffer instead.");return Ol.isArrayBuffer(e)||Ol.isTypedArray(e)?s&&"function"===typeof Blob?new Blob([e]):Buffer.from(e):e}function d(e,t,n){let s=e;if(e&&!n&&"object"===typeof e)if(Ol.endsWith(t,"{}"))t=i?t:t.slice(0,-2),e=JSON.stringify(e);else if(Ol.isArray(e)&&function(e){return Ol.isArray(e)&&!e.some(Ul)}(e)||(Ol.isFileList(e)||Ol.endsWith(t,"[]"))&&(s=Ol.toArray(e)))return t=Bl(t),s.forEach(function(e,i){!Ol.isUndefined(e)&&null!==e&&r.append(!0===a?Gl([t],i,o):null===a?t:t+"[]",l(e))}),!1;return!!Ul(e)||(r.append(Gl(n,t,o),l(e)),!1)}const c=[],u=Object.assign(Wl,{defaultVisitor:d,convertValue:l,isVisitable:Ul});if(!Ol.isObject(e))throw new TypeError("data must be an object");return function e(t,i){if(!Ol.isUndefined(t)){if(-1!==c.indexOf(t))throw Error("Circular reference detected in "+i.join("."));c.push(t),Ol.forEach(t,function(t,o){!0===(!(Ol.isUndefined(t)||null===t)&&n.call(r,t,Ol.isString(o)?o.trim():o,i,u))&&e(t,i?i.concat(o):[o])}),c.pop()}}(e),r};function Vl(e){const r={"!":"%21","'":"%27","(":"%28",")":"%29","~":"%7E","%20":"+","%00":"\0"};return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g,function(e){return r[e]})}function Ql(e,r){this._pairs=[],e&&Hl(e,this,r)}const Kl=Ql.prototype;Kl.append=function(e,r){this._pairs.push([e,r])},Kl.toString=function(e){const r=e?function(r){return e.call(this,r,Vl)}:Vl;return this._pairs.map(function(e){return r(e[0])+"="+r(e[1])},"").join("&")};const Yl=Ql;function Jl(e){return encodeURIComponent(e).replace(/%3A/gi,":").replace(/%24/g,"$").replace(/%2C/gi,",").replace(/%20/g,"+").replace(/%5B/gi,"[").replace(/%5D/gi,"]")}function Zl(e,r,t){if(!r)return e;const i=t&&t.encode||Jl;Ol.isFunction(t)&&(t={serialize:t});const n=t&&t.serialize;let o;if(o=n?n(r,t):Ol.isURLSearchParams(r)?r.toString():new Yl(r,t).toString(i),o){const r=e.indexOf("#");-1!==r&&(e=e.slice(0,r)),e+=(-1===e.indexOf("?")?"?":"&")+o}return e}const Xl=class{constructor(){this.handlers=[]}use(e,r,t){return this.handlers.push({fulfilled:e,rejected:r,synchronous:!!t&&t.synchronous,runWhen:t?t.runWhen:null}),this.handlers.length-1}eject(e){this.handlers[e]&&(this.handlers[e]=null)}clear(){this.handlers&&(this.handlers=[])}forEach(e){Ol.forEach(this.handlers,function(r){null!==r&&e(r)})}},ed={silentJSONParsing:!0,forcedJSONParsing:!0,clarifyTimeoutError:!1},rd={isBrowser:!0,classes:{URLSearchParams:"undefined"!==typeof URLSearchParams?URLSearchParams:Yl,FormData:"undefined"!==typeof FormData?FormData:null,Blob:"undefined"!==typeof Blob?Blob:null},protocols:["http","https","file","blob","url","data"]},td="undefined"!==typeof window&&"undefined"!==typeof document,id="object"===typeof navigator&&navigator||void 0,nd=td&&(!id||["ReactNative","NativeScript","NS"].indexOf(id.product)<0),od="undefined"!==typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope&&"function"===typeof self.importScripts,ad=td&&window.location.href||"http://localhost",sd={...e,...rd};const ld=function(e){function r(e,t,i,n){let o=e[n++];if("__proto__"===o)return!0;const a=Number.isFinite(+o),s=n>=e.length;if(o=!o&&Ol.isArray(i)?i.length:o,s)return Ol.hasOwnProp(i,o)?i[o]=[i[o],t]:i[o]=t,!a;i[o]&&Ol.isObject(i[o])||(i[o]=[]);return r(e,t,i[o],n)&&Ol.isArray(i[o])&&(i[o]=function(e){const r={},t=Object.keys(e);let i;const n=t.length;let o;for(i=0;i<n;i++)o=t[i],r[o]=e[o];return r}(i[o])),!a}if(Ol.isFormData(e)&&Ol.isFunction(e.entries)){const t={};return Ol.forEachEntry(e,(e,i)=>{r(function(e){return Ol.matchAll(/\w+|\[(\w*)]/g,e).map(e=>"[]"===e[0]?"":e[1]||e[0])}(e),i,t,0)}),t}return null};const dd={transitional:ed,adapter:["xhr","http","fetch"],transformRequest:[function(e,r){const t=r.getContentType()||"",i=t.indexOf("application/json")>-1,n=Ol.isObject(e);n&&Ol.isHTMLForm(e)&&(e=new FormData(e));if(Ol.isFormData(e))return i?JSON.stringify(ld(e)):e;if(Ol.isArrayBuffer(e)||Ol.isBuffer(e)||Ol.isStream(e)||Ol.isFile(e)||Ol.isBlob(e)||Ol.isReadableStream(e))return e;if(Ol.isArrayBufferView(e))return e.buffer;if(Ol.isURLSearchParams(e))return r.setContentType("application/x-www-form-urlencoded;charset=utf-8",!1),e.toString();let o;if(n){if(t.indexOf("application/x-www-form-urlencoded")>-1)return function(e,r){return Hl(e,new sd.classes.URLSearchParams,{visitor:function(e,r,t,i){return sd.isNode&&Ol.isBuffer(e)?(this.append(r,e.toString("base64")),!1):i.defaultVisitor.apply(this,arguments)},...r})}(e,this.formSerializer).toString();if((o=Ol.isFileList(e))||t.indexOf("multipart/form-data")>-1){const r=this.env&&this.env.FormData;return Hl(o?{"files[]":e}:e,r&&new r,this.formSerializer)}}return n||i?(r.setContentType("application/json",!1),function(e,r,t){if(Ol.isString(e))try{return(r||JSON.parse)(e),Ol.trim(e)}catch(xE){if("SyntaxError"!==xE.name)throw xE}return(t||JSON.stringify)(e)}(e)):e}],transformResponse:[function(e){const r=this.transitional||dd.transitional,t=r&&r.forcedJSONParsing,i="json"===this.responseType;if(Ol.isResponse(e)||Ol.isReadableStream(e))return e;if(e&&Ol.isString(e)&&(t&&!this.responseType||i)){const t=!(r&&r.silentJSONParsing)&&i;try{return JSON.parse(e)}catch(xE){if(t){if("SyntaxError"===xE.name)throw Fl.from(xE,Fl.ERR_BAD_RESPONSE,this,null,this.response);throw xE}}}return e}],timeout:0,xsrfCookieName:"XSRF-TOKEN",xsrfHeaderName:"X-XSRF-TOKEN",maxContentLength:-1,maxBodyLength:-1,env:{FormData:sd.classes.FormData,Blob:sd.classes.Blob},validateStatus:function(e){return e>=200&&e<300},headers:{common:{Accept:"application/json, text/plain, */*","Content-Type":void 0}}};Ol.forEach(["delete","get","head","post","put","patch"],e=>{dd.headers[e]={}});const cd=dd,ud=Ol.toObjectSet(["age","authorization","content-length","content-type","etag","expires","from","host","if-modified-since","if-unmodified-since","last-modified","location","max-forwards","proxy-authorization","referer","retry-after","user-agent"]),gd=Symbol("internals");function pd(e){return e&&String(e).trim().toLowerCase()}function hd(e){return!1===e||null==e?e:Ol.isArray(e)?e.map(hd):String(e)}function md(e,r,t,i,n){return Ol.isFunction(i)?i.call(this,r,t):(n&&(r=t),Ol.isString(r)?Ol.isString(i)?-1!==r.indexOf(i):Ol.isRegExp(i)?i.test(r):void 0:void 0)}class fd{constructor(e){e&&this.set(e)}set(e,r,t){const i=this;function n(e,r,t){const n=pd(r);if(!n)throw new Error("header name must be a non-empty string");const o=Ol.findKey(i,n);(!o||void 0===i[o]||!0===t||void 0===t&&!1!==i[o])&&(i[o||r]=hd(e))}const o=(e,r)=>Ol.forEach(e,(e,t)=>n(e,t,r));if(Ol.isPlainObject(e)||e instanceof this.constructor)o(e,r);else if(Ol.isString(e)&&(e=e.trim())&&!/^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim()))o((e=>{const r={};let t,i,n;return e&&e.split("\n").forEach(function(e){n=e.indexOf(":"),t=e.substring(0,n).trim().toLowerCase(),i=e.substring(n+1).trim(),!t||r[t]&&ud[t]||("set-cookie"===t?r[t]?r[t].push(i):r[t]=[i]:r[t]=r[t]?r[t]+", "+i:i)}),r})(e),r);else if(Ol.isObject(e)&&Ol.isIterable(e)){let t,i,n={};for(const r of e){if(!Ol.isArray(r))throw TypeError("Object iterator must return a key-value pair");n[i=r[0]]=(t=n[i])?Ol.isArray(t)?[...t,r[1]]:[t,r[1]]:r[1]}o(n,r)}else null!=e&&n(r,e,t);return this}get(e,r){if(e=pd(e)){const t=Ol.findKey(this,e);if(t){const e=this[t];if(!r)return e;if(!0===r)return function(e){const r=Object.create(null),t=/([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;let i;for(;i=t.exec(e);)r[i[1]]=i[2];return r}(e);if(Ol.isFunction(r))return r.call(this,e,t);if(Ol.isRegExp(r))return r.exec(e);throw new TypeError("parser must be boolean|regexp|function")}}}has(e,r){if(e=pd(e)){const t=Ol.findKey(this,e);return!(!t||void 0===this[t]||r&&!md(0,this[t],t,r))}return!1}delete(e,r){const t=this;let i=!1;function n(e){if(e=pd(e)){const n=Ol.findKey(t,e);!n||r&&!md(0,t[n],n,r)||(delete t[n],i=!0)}}return Ol.isArray(e)?e.forEach(n):n(e),i}clear(e){const r=Object.keys(this);let t=r.length,i=!1;for(;t--;){const n=r[t];e&&!md(0,this[n],n,e,!0)||(delete this[n],i=!0)}return i}normalize(e){const r=this,t={};return Ol.forEach(this,(i,n)=>{const o=Ol.findKey(t,n);if(o)return r[o]=hd(i),void delete r[n];const a=e?function(e){return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g,(e,r,t)=>r.toUpperCase()+t)}(n):String(n).trim();a!==n&&delete r[n],r[a]=hd(i),t[a]=!0}),this}concat(){for(var e=arguments.length,r=new Array(e),t=0;t<e;t++)r[t]=arguments[t];return this.constructor.concat(this,...r)}toJSON(e){const r=Object.create(null);return Ol.forEach(this,(t,i)=>{null!=t&&!1!==t&&(r[i]=e&&Ol.isArray(t)?t.join(", "):t)}),r}[Symbol.iterator](){return Object.entries(this.toJSON())[Symbol.iterator]()}toString(){return Object.entries(this.toJSON()).map(e=>{let[r,t]=e;return r+": "+t}).join("\n")}getSetCookie(){return this.get("set-cookie")||[]}get[Symbol.toStringTag](){return"AxiosHeaders"}static from(e){return e instanceof this?e:new this(e)}static concat(e){const r=new this(e);for(var t=arguments.length,i=new Array(t>1?t-1:0),n=1;n<t;n++)i[n-1]=arguments[n];return i.forEach(e=>r.set(e)),r}static accessor(e){const r=(this[gd]=this[gd]={accessors:{}}).accessors,t=this.prototype;function i(e){const i=pd(e);r[i]||(!function(e,r){const t=Ol.toCamelCase(" "+r);["get","set","has"].forEach(i=>{Object.defineProperty(e,i+t,{value:function(e,t,n){return this[i].call(this,r,e,t,n)},configurable:!0})})}(t,e),r[i]=!0)}return Ol.isArray(e)?e.forEach(i):i(e),this}}fd.accessor(["Content-Type","Content-Length","Accept","Accept-Encoding","User-Agent","Authorization"]),Ol.reduceDescriptors(fd.prototype,(e,r)=>{let{value:t}=e,i=r[0].toUpperCase()+r.slice(1);return{get:()=>t,set(e){this[i]=e}}}),Ol.freezeMethods(fd);const xd=fd;function vd(e,r){const t=this||cd,i=r||t,n=xd.from(i.headers);let o=i.data;return Ol.forEach(e,function(e){o=e.call(t,o,n.normalize(),r?r.status:void 0)}),n.normalize(),o}function bd(e){return!(!e||!e.__CANCEL__)}function jd(e,r,t){Fl.call(this,null==e?"canceled":e,Fl.ERR_CANCELED,r,t),this.name="CanceledError"}Ol.inherits(jd,Fl,{__CANCEL__:!0});const yd=jd;function wd(e,r,t){const i=t.config.validateStatus;t.status&&i&&!i(t.status)?r(new Fl("Request failed with status code "+t.status,[Fl.ERR_BAD_REQUEST,Fl.ERR_BAD_RESPONSE][Math.floor(t.status/100)-4],t.config,t.request,t)):e(t)}const kd=function(e,r){e=e||10;const t=new Array(e),i=new Array(e);let n,o=0,a=0;return r=void 0!==r?r:1e3,function(s){const l=Date.now(),d=i[a];n||(n=l),t[o]=s,i[o]=l;let c=a,u=0;for(;c!==o;)u+=t[c++],c%=e;if(o=(o+1)%e,o===a&&(a=(a+1)%e),l-n<r)return;const g=d&&l-d;return g?Math.round(1e3*u/g):void 0}};const _d=function(e,r){let t,i,n=0,o=1e3/r;const a=function(r){let o=arguments.length>1&&void 0!==arguments[1]?arguments[1]:Date.now();n=o,t=null,i&&(clearTimeout(i),i=null),e(...r)};return[function(){const e=Date.now(),r=e-n;for(var s=arguments.length,l=new Array(s),d=0;d<s;d++)l[d]=arguments[d];r>=o?a(l,e):(t=l,i||(i=setTimeout(()=>{i=null,a(t)},o-r)))},()=>t&&a(t)]},Sd=function(e,r){let t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:3,i=0;const n=kd(50,250);return _d(t=>{const o=t.loaded,a=t.lengthComputable?t.total:void 0,s=o-i,l=n(s);i=o;e({loaded:o,total:a,progress:a?o/a:void 0,bytes:s,rate:l||void 0,estimated:l&&a&&o<=a?(a-o)/l:void 0,event:t,lengthComputable:null!=a,[r?"download":"upload"]:!0})},t)},Cd=(e,r)=>{const t=null!=e;return[i=>r[0]({lengthComputable:t,total:e,loaded:i}),r[1]]},zd=e=>function(){for(var r=arguments.length,t=new Array(r),i=0;i<r;i++)t[i]=arguments[i];return Ol.asap(()=>e(...t))},Ed=sd.hasStandardBrowserEnv?((e,r)=>t=>(t=new URL(t,sd.origin),e.protocol===t.protocol&&e.host===t.host&&(r||e.port===t.port)))(new URL(sd.origin),sd.navigator&&/(msie|trident)/i.test(sd.navigator.userAgent)):()=>!0,Ad=sd.hasStandardBrowserEnv?{write(e,r,t,i,n,o){const a=[e+"="+encodeURIComponent(r)];Ol.isNumber(t)&&a.push("expires="+new Date(t).toGMTString()),Ol.isString(i)&&a.push("path="+i),Ol.isString(n)&&a.push("domain="+n),!0===o&&a.push("secure"),document.cookie=a.join("; ")},read(e){const r=document.cookie.match(new RegExp("(^|;\\s*)("+e+")=([^;]*)"));return r?decodeURIComponent(r[3]):null},remove(e){this.write(e,"",Date.now()-864e5)}}:{write(){},read:()=>null,remove(){}};function Rd(e,r,t){let i=!/^([a-z][a-z\d+\-.]*:)?\/\//i.test(r);return e&&(i||0==t)?function(e,r){return r?e.replace(/\/?\/$/,"")+"/"+r.replace(/^\/+/,""):e}(e,r):r}const Nd=e=>e instanceof xd?{...e}:e;function Td(e,r){r=r||{};const t={};function i(e,r,t,i){return Ol.isPlainObject(e)&&Ol.isPlainObject(r)?Ol.merge.call({caseless:i},e,r):Ol.isPlainObject(r)?Ol.merge({},r):Ol.isArray(r)?r.slice():r}function n(e,r,t,n){return Ol.isUndefined(r)?Ol.isUndefined(e)?void 0:i(void 0,e,0,n):i(e,r,0,n)}function o(e,r){if(!Ol.isUndefined(r))return i(void 0,r)}function a(e,r){return Ol.isUndefined(r)?Ol.isUndefined(e)?void 0:i(void 0,e):i(void 0,r)}function s(t,n,o){return o in r?i(t,n):o in e?i(void 0,t):void 0}const l={url:o,method:o,data:o,baseURL:a,transformRequest:a,transformResponse:a,paramsSerializer:a,timeout:a,timeoutMessage:a,withCredentials:a,withXSRFToken:a,adapter:a,responseType:a,xsrfCookieName:a,xsrfHeaderName:a,onUploadProgress:a,onDownloadProgress:a,decompress:a,maxContentLength:a,maxBodyLength:a,beforeRedirect:a,transport:a,httpAgent:a,httpsAgent:a,cancelToken:a,socketPath:a,responseEncoding:a,validateStatus:s,headers:(e,r,t)=>n(Nd(e),Nd(r),0,!0)};return Ol.forEach(Object.keys({...e,...r}),function(i){const o=l[i]||n,a=o(e[i],r[i],i);Ol.isUndefined(a)&&o!==s||(t[i]=a)}),t}const qd=e=>{const r=Td({},e);let t,{data:i,withXSRFToken:n,xsrfHeaderName:o,xsrfCookieName:a,headers:s,auth:l}=r;if(r.headers=s=xd.from(s),r.url=Zl(Rd(r.baseURL,r.url,r.allowAbsoluteUrls),e.params,e.paramsSerializer),l&&s.set("Authorization","Basic "+btoa((l.username||"")+":"+(l.password?unescape(encodeURIComponent(l.password)):""))),Ol.isFormData(i))if(sd.hasStandardBrowserEnv||sd.hasStandardBrowserWebWorkerEnv)s.setContentType(void 0);else if(!1!==(t=s.getContentType())){const[e,...r]=t?t.split(";").map(e=>e.trim()).filter(Boolean):[];s.setContentType([e||"multipart/form-data",...r].join("; "))}if(sd.hasStandardBrowserEnv&&(n&&Ol.isFunction(n)&&(n=n(r)),n||!1!==n&&Ed(r.url))){const e=o&&a&&Ad.read(a);e&&s.set(o,e)}return r},Pd="undefined"!==typeof XMLHttpRequest&&function(e){return new Promise(function(r,t){const i=qd(e);let n=i.data;const o=xd.from(i.headers).normalize();let a,s,l,d,c,{responseType:u,onUploadProgress:g,onDownloadProgress:p}=i;function h(){d&&d(),c&&c(),i.cancelToken&&i.cancelToken.unsubscribe(a),i.signal&&i.signal.removeEventListener("abort",a)}let m=new XMLHttpRequest;function f(){if(!m)return;const i=xd.from("getAllResponseHeaders"in m&&m.getAllResponseHeaders());wd(function(e){r(e),h()},function(e){t(e),h()},{data:u&&"text"!==u&&"json"!==u?m.response:m.responseText,status:m.status,statusText:m.statusText,headers:i,config:e,request:m}),m=null}m.open(i.method.toUpperCase(),i.url,!0),m.timeout=i.timeout,"onloadend"in m?m.onloadend=f:m.onreadystatechange=function(){m&&4===m.readyState&&(0!==m.status||m.responseURL&&0===m.responseURL.indexOf("file:"))&&setTimeout(f)},m.onabort=function(){m&&(t(new Fl("Request aborted",Fl.ECONNABORTED,e,m)),m=null)},m.onerror=function(){t(new Fl("Network Error",Fl.ERR_NETWORK,e,m)),m=null},m.ontimeout=function(){let r=i.timeout?"timeout of "+i.timeout+"ms exceeded":"timeout exceeded";const n=i.transitional||ed;i.timeoutErrorMessage&&(r=i.timeoutErrorMessage),t(new Fl(r,n.clarifyTimeoutError?Fl.ETIMEDOUT:Fl.ECONNABORTED,e,m)),m=null},void 0===n&&o.setContentType(null),"setRequestHeader"in m&&Ol.forEach(o.toJSON(),function(e,r){m.setRequestHeader(r,e)}),Ol.isUndefined(i.withCredentials)||(m.withCredentials=!!i.withCredentials),u&&"json"!==u&&(m.responseType=i.responseType),p&&([l,c]=Sd(p,!0),m.addEventListener("progress",l)),g&&m.upload&&([s,d]=Sd(g),m.upload.addEventListener("progress",s),m.upload.addEventListener("loadend",d)),(i.cancelToken||i.signal)&&(a=r=>{m&&(t(!r||r.type?new yd(null,e,m):r),m.abort(),m=null)},i.cancelToken&&i.cancelToken.subscribe(a),i.signal&&(i.signal.aborted?a():i.signal.addEventListener("abort",a)));const x=function(e){const r=/^([-+\w]{1,25})(:?\/\/|:)/.exec(e);return r&&r[1]||""}(i.url);x&&-1===sd.protocols.indexOf(x)?t(new Fl("Unsupported protocol "+x+":",Fl.ERR_BAD_REQUEST,e)):m.send(n||null)})},$d=(e,r)=>{const{length:t}=e=e?e.filter(Boolean):[];if(r||t){let t,i=new AbortController;const n=function(e){if(!t){t=!0,a();const r=e instanceof Error?e:this.reason;i.abort(r instanceof Fl?r:new yd(r instanceof Error?r.message:r))}};let o=r&&setTimeout(()=>{o=null,n(new Fl(`timeout ${r} of ms exceeded`,Fl.ETIMEDOUT))},r);const a=()=>{e&&(o&&clearTimeout(o),o=null,e.forEach(e=>{e.unsubscribe?e.unsubscribe(n):e.removeEventListener("abort",n)}),e=null)};e.forEach(e=>e.addEventListener("abort",n));const{signal:s}=i;return s.unsubscribe=()=>Ol.asap(a),s}},Id=function*(e,r){let t=e.byteLength;if(!r||t<r)return void(yield e);let i,n=0;for(;n<t;)i=n+r,yield e.slice(n,i),n=i},Od=async function*(e){if(e[Symbol.asyncIterator])return void(yield*e);const r=e.getReader();try{for(;;){const{done:e,value:t}=await r.read();if(e)break;yield t}}finally{await r.cancel()}},Ld=(e,r,t,i)=>{const n=async function*(e,r){for await(const t of Od(e))yield*Id(t,r)}(e,r);let o,a=0,s=e=>{o||(o=!0,i&&i(e))};return new ReadableStream({async pull(e){try{const{done:r,value:i}=await n.next();if(r)return s(),void e.close();let o=i.byteLength;if(t){let e=a+=o;t(e)}e.enqueue(new Uint8Array(i))}catch(r){throw s(r),r}},cancel:e=>(s(e),n.return())},{highWaterMark:2})},Md="function"===typeof fetch&&"function"===typeof Request&&"function"===typeof Response,Dd=Md&&"function"===typeof ReadableStream,Fd=Md&&("function"===typeof TextEncoder?(Ud=new TextEncoder,e=>Ud.encode(e)):async e=>new Uint8Array(await new Response(e).arrayBuffer()));var Ud;const Bd=function(e){try{for(var r=arguments.length,t=new Array(r>1?r-1:0),i=1;i<r;i++)t[i-1]=arguments[i];return!!e(...t)}catch(xE){return!1}},Gd=Dd&&Bd(()=>{let e=!1;const r=new Request(sd.origin,{body:new ReadableStream,method:"POST",get duplex(){return e=!0,"half"}}).headers.has("Content-Type");return e&&!r}),Wd=Dd&&Bd(()=>Ol.isReadableStream(new Response("").body)),Hd={stream:Wd&&(e=>e.body)};var Vd;Md&&(Vd=new Response,["text","arrayBuffer","blob","formData","stream"].forEach(e=>{!Hd[e]&&(Hd[e]=Ol.isFunction(Vd[e])?r=>r[e]():(r,t)=>{throw new Fl(`Response type '${e}' is not supported`,Fl.ERR_NOT_SUPPORT,t)})}));const Qd=async(e,r)=>{const t=Ol.toFiniteNumber(e.getContentLength());return null==t?(async e=>{if(null==e)return 0;if(Ol.isBlob(e))return e.size;if(Ol.isSpecCompliantForm(e)){const r=new Request(sd.origin,{method:"POST",body:e});return(await r.arrayBuffer()).byteLength}return Ol.isArrayBufferView(e)||Ol.isArrayBuffer(e)?e.byteLength:(Ol.isURLSearchParams(e)&&(e+=""),Ol.isString(e)?(await Fd(e)).byteLength:void 0)})(r):t},Kd=Md&&(async e=>{let{url:r,method:t,data:i,signal:n,cancelToken:o,timeout:a,onDownloadProgress:s,onUploadProgress:l,responseType:d,headers:c,withCredentials:u="same-origin",fetchOptions:g}=qd(e);d=d?(d+"").toLowerCase():"text";let p,h=$d([n,o&&o.toAbortSignal()],a);const m=h&&h.unsubscribe&&(()=>{h.unsubscribe()});let f;try{if(l&&Gd&&"get"!==t&&"head"!==t&&0!==(f=await Qd(c,i))){let e,t=new Request(r,{method:"POST",body:i,duplex:"half"});if(Ol.isFormData(i)&&(e=t.headers.get("content-type"))&&c.setContentType(e),t.body){const[e,r]=Cd(f,Sd(zd(l)));i=Ld(t.body,65536,e,r)}}Ol.isString(u)||(u=u?"include":"omit");const n="credentials"in Request.prototype;p=new Request(r,{...g,signal:h,method:t.toUpperCase(),headers:c.normalize().toJSON(),body:i,duplex:"half",credentials:n?u:void 0});let o=await fetch(p,g);const a=Wd&&("stream"===d||"response"===d);if(Wd&&(s||a&&m)){const e={};["status","statusText","headers"].forEach(r=>{e[r]=o[r]});const r=Ol.toFiniteNumber(o.headers.get("content-length")),[t,i]=s&&Cd(r,Sd(zd(s),!0))||[];o=new Response(Ld(o.body,65536,t,()=>{i&&i(),m&&m()}),e)}d=d||"text";let x=await Hd[Ol.findKey(Hd,d)||"text"](o,e);return!a&&m&&m(),await new Promise((r,t)=>{wd(r,t,{data:x,headers:xd.from(o.headers),status:o.status,statusText:o.statusText,config:e,request:p})})}catch(x){if(m&&m(),x&&"TypeError"===x.name&&/Load failed|fetch/i.test(x.message))throw Object.assign(new Fl("Network Error",Fl.ERR_NETWORK,e,p),{cause:x.cause||x});throw Fl.from(x,x&&x.code,e,p)}}),Yd={http:null,xhr:Pd,fetch:Kd};Ol.forEach(Yd,(e,r)=>{if(e){try{Object.defineProperty(e,"name",{value:r})}catch(xE){}Object.defineProperty(e,"adapterName",{value:r})}});const Jd=e=>`- ${e}`,Zd=e=>Ol.isFunction(e)||null===e||!1===e,Xd=e=>{e=Ol.isArray(e)?e:[e];const{length:r}=e;let t,i;const n={};for(let o=0;o<r;o++){let r;if(t=e[o],i=t,!Zd(t)&&(i=Yd[(r=String(t)).toLowerCase()],void 0===i))throw new Fl(`Unknown adapter '${r}'`);if(i)break;n[r||"#"+o]=i}if(!i){const e=Object.entries(n).map(e=>{let[r,t]=e;return`adapter ${r} `+(!1===t?"is not supported by the environment":"is not available in the build")});let t=r?e.length>1?"since :\n"+e.map(Jd).join("\n"):" "+Jd(e[0]):"as no adapter specified";throw new Fl("There is no suitable adapter to dispatch the request "+t,"ERR_NOT_SUPPORT")}return i};function ec(e){if(e.cancelToken&&e.cancelToken.throwIfRequested(),e.signal&&e.signal.aborted)throw new yd(null,e)}function rc(e){ec(e),e.headers=xd.from(e.headers),e.data=vd.call(e,e.transformRequest),-1!==["post","put","patch"].indexOf(e.method)&&e.headers.setContentType("application/x-www-form-urlencoded",!1);return Xd(e.adapter||cd.adapter)(e).then(function(r){return ec(e),r.data=vd.call(e,e.transformResponse,r),r.headers=xd.from(r.headers),r},function(r){return bd(r)||(ec(e),r&&r.response&&(r.response.data=vd.call(e,e.transformResponse,r.response),r.response.headers=xd.from(r.response.headers))),Promise.reject(r)})}const tc="1.11.0",ic={};["object","boolean","number","function","string","symbol"].forEach((e,r)=>{ic[e]=function(t){return typeof t===e||"a"+(r<1?"n ":" ")+e}});const nc={};ic.transitional=function(e,r,t){function i(e,r){return"[Axios v"+tc+"] Transitional option '"+e+"'"+r+(t?". "+t:"")}return(t,n,o)=>{if(!1===e)throw new Fl(i(n," has been removed"+(r?" in "+r:"")),Fl.ERR_DEPRECATED);return r&&!nc[n]&&(nc[n]=!0,console.warn(i(n," has been deprecated since v"+r+" and will be removed in the near future"))),!e||e(t,n,o)}},ic.spelling=function(e){return(r,t)=>(console.warn(`${t} is likely a misspelling of ${e}`),!0)};const oc={assertOptions:function(e,r,t){if("object"!==typeof e)throw new Fl("options must be an object",Fl.ERR_BAD_OPTION_VALUE);const i=Object.keys(e);let n=i.length;for(;n-- >0;){const o=i[n],a=r[o];if(a){const r=e[o],t=void 0===r||a(r,o,e);if(!0!==t)throw new Fl("option "+o+" must be "+t,Fl.ERR_BAD_OPTION_VALUE);continue}if(!0!==t)throw new Fl("Unknown option "+o,Fl.ERR_BAD_OPTION)}},validators:ic},ac=oc.validators;class sc{constructor(e){this.defaults=e||{},this.interceptors={request:new Xl,response:new Xl}}async request(e,r){try{return await this._request(e,r)}catch(t){if(t instanceof Error){let e={};Error.captureStackTrace?Error.captureStackTrace(e):e=new Error;const r=e.stack?e.stack.replace(/^.+\n/,""):"";try{t.stack?r&&!String(t.stack).endsWith(r.replace(/^.+\n.+\n/,""))&&(t.stack+="\n"+r):t.stack=r}catch(xE){}}throw t}}_request(e,r){"string"===typeof e?(r=r||{}).url=e:r=e||{},r=Td(this.defaults,r);const{transitional:t,paramsSerializer:i,headers:n}=r;void 0!==t&&oc.assertOptions(t,{silentJSONParsing:ac.transitional(ac.boolean),forcedJSONParsing:ac.transitional(ac.boolean),clarifyTimeoutError:ac.transitional(ac.boolean)},!1),null!=i&&(Ol.isFunction(i)?r.paramsSerializer={serialize:i}:oc.assertOptions(i,{encode:ac.function,serialize:ac.function},!0)),void 0!==r.allowAbsoluteUrls||(void 0!==this.defaults.allowAbsoluteUrls?r.allowAbsoluteUrls=this.defaults.allowAbsoluteUrls:r.allowAbsoluteUrls=!0),oc.assertOptions(r,{baseUrl:ac.spelling("baseURL"),withXsrfToken:ac.spelling("withXSRFToken")},!0),r.method=(r.method||this.defaults.method||"get").toLowerCase();let o=n&&Ol.merge(n.common,n[r.method]);n&&Ol.forEach(["delete","get","head","post","put","patch","common"],e=>{delete n[e]}),r.headers=xd.concat(o,n);const a=[];let s=!0;this.interceptors.request.forEach(function(e){"function"===typeof e.runWhen&&!1===e.runWhen(r)||(s=s&&e.synchronous,a.unshift(e.fulfilled,e.rejected))});const l=[];let d;this.interceptors.response.forEach(function(e){l.push(e.fulfilled,e.rejected)});let c,u=0;if(!s){const e=[rc.bind(this),void 0];for(e.unshift(...a),e.push(...l),c=e.length,d=Promise.resolve(r);u<c;)d=d.then(e[u++],e[u++]);return d}c=a.length;let g=r;for(u=0;u<c;){const e=a[u++],r=a[u++];try{g=e(g)}catch(p){r.call(this,p);break}}try{d=rc.call(this,g)}catch(p){return Promise.reject(p)}for(u=0,c=l.length;u<c;)d=d.then(l[u++],l[u++]);return d}getUri(e){return Zl(Rd((e=Td(this.defaults,e)).baseURL,e.url,e.allowAbsoluteUrls),e.params,e.paramsSerializer)}}Ol.forEach(["delete","get","head","options"],function(e){sc.prototype[e]=function(r,t){return this.request(Td(t||{},{method:e,url:r,data:(t||{}).data}))}}),Ol.forEach(["post","put","patch"],function(e){function r(r){return function(t,i,n){return this.request(Td(n||{},{method:e,headers:r?{"Content-Type":"multipart/form-data"}:{},url:t,data:i}))}}sc.prototype[e]=r(),sc.prototype[e+"Form"]=r(!0)});const lc=sc;class dc{constructor(e){if("function"!==typeof e)throw new TypeError("executor must be a function.");let r;this.promise=new Promise(function(e){r=e});const t=this;this.promise.then(e=>{if(!t._listeners)return;let r=t._listeners.length;for(;r-- >0;)t._listeners[r](e);t._listeners=null}),this.promise.then=e=>{let r;const i=new Promise(e=>{t.subscribe(e),r=e}).then(e);return i.cancel=function(){t.unsubscribe(r)},i},e(function(e,i,n){t.reason||(t.reason=new yd(e,i,n),r(t.reason))})}throwIfRequested(){if(this.reason)throw this.reason}subscribe(e){this.reason?e(this.reason):this._listeners?this._listeners.push(e):this._listeners=[e]}unsubscribe(e){if(!this._listeners)return;const r=this._listeners.indexOf(e);-1!==r&&this._listeners.splice(r,1)}toAbortSignal(){const e=new AbortController,r=r=>{e.abort(r)};return this.subscribe(r),e.signal.unsubscribe=()=>this.unsubscribe(r),e.signal}static source(){let e;return{token:new dc(function(r){e=r}),cancel:e}}}const cc=dc;const uc={Continue:100,SwitchingProtocols:101,Processing:102,EarlyHints:103,Ok:200,Created:201,Accepted:202,NonAuthoritativeInformation:203,NoContent:204,ResetContent:205,PartialContent:206,MultiStatus:207,AlreadyReported:208,ImUsed:226,MultipleChoices:300,MovedPermanently:301,Found:302,SeeOther:303,NotModified:304,UseProxy:305,Unused:306,TemporaryRedirect:307,PermanentRedirect:308,BadRequest:400,Unauthorized:401,PaymentRequired:402,Forbidden:403,NotFound:404,MethodNotAllowed:405,NotAcceptable:406,ProxyAuthenticationRequired:407,RequestTimeout:408,Conflict:409,Gone:410,LengthRequired:411,PreconditionFailed:412,PayloadTooLarge:413,UriTooLong:414,UnsupportedMediaType:415,RangeNotSatisfiable:416,ExpectationFailed:417,ImATeapot:418,MisdirectedRequest:421,UnprocessableEntity:422,Locked:423,FailedDependency:424,TooEarly:425,UpgradeRequired:426,PreconditionRequired:428,TooManyRequests:429,RequestHeaderFieldsTooLarge:431,UnavailableForLegalReasons:451,InternalServerError:500,NotImplemented:501,BadGateway:502,ServiceUnavailable:503,GatewayTimeout:504,HttpVersionNotSupported:505,VariantAlsoNegotiates:506,InsufficientStorage:507,LoopDetected:508,NotExtended:510,NetworkAuthenticationRequired:511};Object.entries(uc).forEach(e=>{let[r,t]=e;uc[t]=r});const gc=uc;const pc=function e(r){const t=new lc(r),i=Js(lc.prototype.request,t);return Ol.extend(i,lc.prototype,t,{allOwnKeys:!0}),Ol.extend(i,t,null,{allOwnKeys:!0}),i.create=function(t){return e(Td(r,t))},i}(cd);pc.Axios=lc,pc.CanceledError=yd,pc.CancelToken=cc,pc.isCancel=bd,pc.VERSION=tc,pc.toFormData=Hl,pc.AxiosError=Fl,pc.Cancel=pc.CanceledError,pc.all=function(e){return Promise.all(e)},pc.spread=function(e){return function(r){return e.apply(null,r)}},pc.isAxiosError=function(e){return Ol.isObject(e)&&!0===e.isAxiosError},pc.mergeConfig=Td,pc.AxiosHeaders=xd,pc.formToJSON=e=>ld(Ol.isHTMLForm(e)?new FormData(e):e),pc.getAdapter=Xd,pc.HttpStatusCode=gc,pc.default=pc;const hc=pc,mc="ionos"==={NODE_ENV:"production",PUBLIC_URL:"",WDS_SOCKET_HOST:void 0,WDS_SOCKET_PATH:void 0,WDS_SOCKET_PORT:void 0,FAST_REFRESH:!0,REACT_APP_API_URL:"http://localhost:3001",REACT_APP_WS_URL:"ws://localhost:3001",REACT_APP_ENV:"development"}.REACT_APP_HOSTING;let fc;fc="localhost"===window.location.hostname||"127.0.0.1"===window.location.hostname?"http://localhost:3001/api":mc||"top-league.org"===window.location.hostname?"https://www.top-league.org/api":"https://topleaguem.onrender.com/api";const xc=hc.create({baseURL:fc,withCredentials:!1,timeout:1e4});const vc=async function(e){let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:3;try{return await xc(e)}catch(t){if(r>0&&("ECONNABORTED"===t.code||t.message.includes("Network Error")))return console.log(`\ud83d\udd04 Retry attempt ${4-r} for ${e.url}`),await new Promise(e=>setTimeout(e,1e3*(4-r))),vc(e,r-1);throw t}};xc.interceptors.response.use(e=>e,e=>{var r,t,i,n,o,a,s,l,d,c,u,g;console.error("\ud83d\udea8 API Error:",{url:null===(r=e.config)||void 0===r?void 0:r.url,method:null===(t=e.config)||void 0===t?void 0:t.method,status:null===(i=e.response)||void 0===i?void 0:i.status,statusText:null===(n=e.response)||void 0===n?void 0:n.statusText,message:e.message,data:null===(o=e.response)||void 0===o?void 0:o.data});const p=new CustomEvent("fetch-error",{detail:{error:{status:null===(a=e.response)||void 0===a?void 0:a.status,message:e.message,url:null===(s=e.config)||void 0===s?void 0:s.url,data:null===(l=e.response)||void 0===l?void 0:l.data}}});return window.dispatchEvent(p),401===(null===(d=e.response)||void 0===d?void 0:d.status)?(e.customMessage="Sessione scaduta o non autorizzato. Effettua di nuovo il login.",localStorage.removeItem("token"),window.location.href="/login"):503===(null===(c=e.response)||void 0===c?void 0:c.status)?e.customMessage="Servizio temporaneamente non disponibile. Riprova tra qualche minuto.":404===(null===(u=e.response)||void 0===u?void 0:u.status)?e.customMessage="Risorsa non trovata.":(null===(g=e.response)||void 0===g?void 0:g.status)>=500?e.customMessage="Errore del server. Riprova pi\xf9 tardi.":"ECONNABORTED"===e.code?e.customMessage="Timeout della richiesta. Verifica la connessione.":e.message.includes("Network Error")&&(e.customMessage="Errore di rete. Verifica la connessione."),Promise.reject(e)});const bc=async function(e,r,t,i){let n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:null;try{const o={method:e,url:r,data:t,headers:i?{Authorization:`Bearer ${i}`}:{}},a=await vc(o);if(n&&!((e,r)=>{if(!r)return!0;for(const[t,i]of Object.entries(r)){if(!(t in e))return console.warn(`\u26a0\ufe0f Missing required field: ${t}`),!1;if("array"===i&&!Array.isArray(e[t]))return console.warn(`\u26a0\ufe0f Expected array for field: ${t}`),!1;if("object"===i&&"object"!==typeof e[t])return console.warn(`\u26a0\ufe0f Expected object for field: ${t}`),!1}return!0})(a.data,n))throw new Error("Risposta API non valida");return{ok:!0,data:a.data}}catch(o){throw console.error("\ud83d\udea8 apiRequest failed:",{method:e,url:r,error:o.customMessage||o.message}),new Error(o.customMessage||o.message||"Errore sconosciuto")}},jc=xc,yc=async(e,r)=>bc("DELETE",`/tornei/${e}`,null,r),wc=async(e,r)=>bc("GET",`/tornei/lega/${e}`,null,r),kc=async(e,r)=>bc("GET",`/tornei/${e}`,null,r),_c=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
`,Sc=(Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
`,Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #86868b;
`),Cc=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #dc3545;
`,zc=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,Ec=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Ac=Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
`,Rc=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 1rem;
  margin-bottom: 1rem;
`,Nc=Ie.div`
  text-align: center;
  padding: 0.75rem;
  background: #f8f9fa;
  border-radius: 8px;
`,Tc=Ie.div`
  font-size: 0.75rem;
  color: #86868b;
  font-weight: 500;
  margin-bottom: 0.25rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,qc=Ie.div`
  font-size: 0.9rem;
  font-weight: 600;
  color: #1d1d1f;
`,Pc=Ie.div`
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
`,$c=Ie.span`
  background: ${e=>e.$active?"#007AFF":"#e5e5e7"};
  color: ${e=>e.$active?"white":"#86868b"};
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 500;
`,Ic=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
`,Oc=Ie.div`
  background: white;
  padding: 1rem;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  text-align: center;
`,Lc=Ie.div`
  font-size: 0.8rem;
  color: #86868b;
  font-weight: 500;
  margin-bottom: 0.5rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,Mc=Ie.div`
  font-size: 1.1rem;
  font-weight: 600;
  color: #1d1d1f;
`,Dc=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Fc=Ie.h2`
  font-size: 1.1rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
`,Uc=Ie.div`
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: 1rem;
`,Bc=Ie.label`
  font-size: 0.85rem;
  font-weight: 500;
  color: #1d1d1f;
`,Gc=Ie.select`
  padding: 0.5rem;
  border: 1px solid #e5e5e7;
  border-radius: 6px;
  font-size: 0.85rem;
  background: white;
  color: #1d1d1f;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Wc=Ie.div`
  overflow-x: auto;
`,Hc=Ie.table`
  width: 100%;
  border-collapse: collapse;
  font-size: 0.85rem;
`,Vc=Ie.th`
  background: #5856d6;
  color: white;
  padding: 0.75rem 0.5rem;
  text-align: center;
  font-weight: 600;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  
  &:first-child {
    border-top-left-radius: 8px;
  }
  
  &:last-child {
    border-top-right-radius: 8px;
  }
`,Qc=Ie.td`
  padding: 0.75rem 0.5rem;
  border-bottom: 1px solid #e5e5e7;
  color: #1d1d1f;
  text-align: center;
`,Kc=Ie.span`
  font-weight: 600;
  color: #28a745;
  font-size: 0.8rem;
`,Yc=Ie.span`
  font-weight: 600;
  color: #dc3545;
  font-size: 0.8rem;
`,Jc=Ie(lt)`
  color: #E67E22;
  font-weight: 700;
  text-decoration: none;
  cursor: pointer;
  transition: color 0.2s;
  
  &:hover {
    color: #D35400;
    text-decoration: underline;
  }
`,Zc=(Ie.span`
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 500;
  background: ${e=>e.$orphan?"#ffebee":"#e8f5e8"};
  color: ${e=>e.$orphan?"#c62828":"#2e7d32"};
`,Ie.button`
  background: #ff3b30;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 500;
  font-size: 0.8rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background: #d70015;
    transform: translateY(-1px);
  }
`),Xc=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,eu=Ie.div`
  background: white;
  padding: 1.5rem;
  border-radius: 12px;
  max-width: 400px;
  text-align: center;
  margin: 1rem;
`,ru=Ie.h3`
  color: #ff3b30;
  margin: 0 0 1rem 0;
  font-size: 1.1rem;
  font-weight: 600;
`,tu=Ie.p`
  color: #86868b;
  margin: 0 0 1rem 0;
  font-size: 0.9rem;
  line-height: 1.4;
`,iu=Ie.div`
  display: flex;
  gap: 0.75rem;
  justify-content: center;
`,nu=Ie.button`
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 6px;
  font-weight: 500;
  font-size: 0.8rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &.cancel {
    background: #e5e5e7;
    color: #1d1d1f;
  }
  
  &.confirm {
    background: #ff3b30;
    color: white;
  }
  
  &:hover {
    transform: translateY(-1px);
  }
`,ou=Ie.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ff9500 0%, #e6850e 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  font-weight: 700;
  margin: 0 auto;
`,au=e=>{let{setCurrentLeague:t,setCurrentTeam:i}=e;const{token:n,user:o}=Si(),{id:a}=Pr(),s=qr(),[l,d]=(0,r.useState)(null),[c,u]=(0,r.useState)([]),[g,p]=(0,r.useState)(!0),[h,m]=(0,r.useState)(""),[f,x]=(0,r.useState)(!1),[v,b]=(0,r.useState)(!1),[j,y]=(0,r.useState)(""),[w,k]=(0,r.useState)("all"),[_,S]=(0,r.useState)([{id:"all",name:"Tutti i Tornei"}]);(0,r.useEffect)(()=>{n&&async function(){p(!0),m("");try{var e,r,o,s;const[l,c,g]=await Promise.all([Ao(a,n),Ro(a,n),wc(a,n)]);d((null===l||void 0===l||null===(e=l.data)||void 0===e?void 0:e.lega)||(null===l||void 0===l?void 0:l.lega)),t&&t((null===l||void 0===l||null===(r=l.data)||void 0===r?void 0:r.lega)||(null===l||void 0===l?void 0:l.lega)),i&&i(null),u((null===c||void 0===c||null===(o=c.data)||void 0===o?void 0:o.squadre)||(null===c||void 0===c?void 0:c.squadre)||[]);const p=(null===g||void 0===g||null===(s=g.data)||void 0===s?void 0:s.tornei)||(null===g||void 0===g?void 0:g.tornei)||[],h=[{id:"all",name:"Tutti i Tornei"},...null===p||void 0===p?void 0:p.map(e=>{var r;return{id:(null===e||void 0===e||null===(r=e.id)||void 0===r?void 0:r.toString())||"",name:(null===e||void 0===e?void 0:e.nome)||"Nome"}}),{id:"na",name:"N/A (Senza Torneo)"}];S(h)}catch(l){m(l.message)}p(!1)}()},[a,n,t,i]);const C=e=>{if(!e&&0!==e)return"FM 0";return`FM ${(parseFloat(e)||0).toLocaleString()}`},z="all"===w?c:null===c||void 0===c?void 0:c.filter(e=>{var r;return"na"===w?!(null!==e&&void 0!==e&&e.tornei)||0===((null===e||void 0===e||null===(r=e.tornei)||void 0===r?void 0:r.length)||0):(null===e||void 0===e?void 0:e.tornei)&&(null===e||void 0===e?void 0:e.tornei.some(e=>(null===e||void 0===e?void 0:e.id)===parseInt(w)||(null===e||void 0===e?void 0:e.id)===w))});if(g)return(0,gt.jsx)(_c,{children:(0,gt.jsx)(Sc,{children:"Caricamento lega..."})});if(h)return(0,gt.jsx)(_c,{children:(0,gt.jsxs)(Cc,{children:["Errore: ",h]})});if(!l)return(0,gt.jsx)(_c,{children:(0,gt.jsx)(Cc,{children:"Lega non trovata"})});const E={totalSquadre:(null===c||void 0===c?void 0:c.length)||0,squadreConProprietario:null===c||void 0===c?void 0:c.filter(e=>e.proprietario_id).length,squadreOrfane:null===c||void 0===c?void 0:c.filter(e=>e.is_orfana).length,valoreTotale:null===c||void 0===c?void 0:c.reduce((e,r)=>e+((null===r||void 0===r?void 0:r.valore_squadra)||0),0),casseTotali:null===c||void 0===c?void 0:c.reduce((e,r)=>e+((null===r||void 0===r?void 0:r.casse_societarie)||0),0),costoSalarialeTotale:null===c||void 0===c?void 0:c.reduce((e,r)=>e+((null===r||void 0===r?void 0:r.costo_salariale_totale)||0),0),costoSalarialeAnnual:null===c||void 0===c?void 0:c.reduce((e,r)=>e+((null===r||void 0===r?void 0:r.costo_salariale_annuale)||0),0)},A=l&&(l.admin_id===(null===o||void 0===o?void 0:o.id)||"superadmin"===(null===o||void 0===o?void 0:o.ruolo));return(0,gt.jsxs)(_c,{children:[(0,gt.jsx)(zc,{onClick:()=>s(-1),children:"\u2190 Torna indietro"}),(0,gt.jsxs)(Ec,{children:[(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1rem"},children:[(0,gt.jsx)(Ac,{children:(null===l||void 0===l?void 0:l.nome)||"Nome"}),A&&(0,gt.jsx)(Zc,{onClick:()=>x(!0),children:"\ud83d\uddd1\ufe0f Cancella Lega"})]}),(0,gt.jsxs)(Rc,{children:[(0,gt.jsxs)(Nc,{children:[(0,gt.jsx)(Tc,{children:"Modalit\xe0"}),(0,gt.jsx)(qc,{children:(null===l||void 0===l?void 0:l.modalita)||"N/A"})]}),(0,gt.jsxs)(Nc,{children:[(0,gt.jsx)(Tc,{children:"Tipo"}),(0,gt.jsx)(qc,{children:null!==l&&void 0!==l&&l.is_pubblica?"Pubblica":"Privata"})]}),(0,gt.jsxs)(Nc,{children:[(0,gt.jsx)(Tc,{children:"Squadre"}),(0,gt.jsxs)(qc,{children:[E.squadreConProprietario,"/",E.totalSquadre]})]}),(0,gt.jsxs)(Nc,{children:[(0,gt.jsx)(Tc,{children:"Admin"}),(0,gt.jsx)(qc,{children:"Tu"})]})]}),(0,gt.jsxs)(Pc,{children:[(null===l||void 0===l?void 0:l.roster_ab)&&(0,gt.jsx)($c,{$active:!0,children:"Roster A/B"}),(null===l||void 0===l?void 0:l.cantera)&&(0,gt.jsx)($c,{$active:!0,children:"Cantera"}),(null===l||void 0===l?void 0:l.contratti)&&(0,gt.jsx)($c,{$active:!0,children:"Contratti"}),(null===l||void 0===l?void 0:l.triggers)&&(0,gt.jsx)($c,{$active:!0,children:"Triggers"})]})]}),(0,gt.jsxs)(Ic,{children:[(0,gt.jsxs)(Oc,{color:"#667eea",children:[(0,gt.jsx)(Lc,{children:"Monte Ingaggi Totale"}),(0,gt.jsx)(Mc,{children:C(E.valoreTotale)})]}),(0,gt.jsxs)(Oc,{color:"#28a745",children:[(0,gt.jsx)(Lc,{children:"Totale Casse Societarie"}),(0,gt.jsx)(Mc,{children:C(E.casseTotali)})]}),(0,gt.jsxs)(Oc,{color:"#dc3545",children:[(0,gt.jsx)(Lc,{children:"Monte Ingaggi"}),(0,gt.jsx)(Mc,{children:C(E.costoSalarialeAnnual)})]})]}),(0,gt.jsxs)(Dc,{children:[(0,gt.jsx)(Fc,{children:"Squadre della Lega"}),(0,gt.jsxs)(Uc,{children:[(0,gt.jsx)(Bc,{children:"Filtra per Torneo:"}),(0,gt.jsx)(Gc,{value:w,onChange:e=>k(e.target.value),children:null===_||void 0===_?void 0:_.map(e=>(0,gt.jsx)("option",{value:e.id,children:e.name},e.id))})]}),(0,gt.jsx)(Wc,{children:(0,gt.jsxs)(Hc,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Vc,{}),(0,gt.jsx)(Vc,{children:"Nome Squadra"}),(0,gt.jsx)(Vc,{children:"Proprietario"}),(0,gt.jsx)(Vc,{children:"Club Level"}),(0,gt.jsx)(Vc,{children:"Torneo"}),(0,gt.jsx)(Vc,{children:"Ingaggi"}),(0,gt.jsx)(Vc,{children:"Crediti Residui"}),(0,gt.jsx)(Vc,{children:"Valore Attuale"}),(0,gt.jsx)(Vc,{children:"Giocatori"})]})}),(0,gt.jsx)("tbody",{children:null===z||void 0===z?void 0:z.map(e=>{var r,t,i;return(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Qc,{children:e.logo_url?(0,gt.jsx)("img",{src:`https://topleaguem.onrender.com/uploads/${e.logo_url}`,alt:"Logo squadra",style:{width:60,height:60,borderRadius:"50%",objectFit:"cover"}}):(0,gt.jsx)(ou,{children:((null===e||void 0===e?void 0:e.nome)||"Nome").charAt(0).toUpperCase()})}),(0,gt.jsx)(Qc,{children:(0,gt.jsx)(Jc,{to:`/squadra/${e.id}`,children:(null===e||void 0===e?void 0:e.nome)||"Nome"})}),(0,gt.jsx)(Qc,{children:e.proprietario_username?(0,gt.jsx)("span",{style:{color:"#28a745",fontWeight:"600"},children:e.proprietario_username}):(0,gt.jsx)("span",{style:{color:"#dc3545",fontStyle:"italic"},children:"N/A"})}),(0,gt.jsx)(Qc,{children:(null===e||void 0===e?void 0:e.club_level)||1}),(0,gt.jsx)(Qc,{children:null!==e&&void 0!==e&&e.tornei&&((null===(r=e.tornei)||void 0===r?void 0:r.length)||0)>0?null===(t=e.tornei)||void 0===t?void 0:t.map(e=>(null===e||void 0===e?void 0:e.nome)||"Nome").join(", "):"Nessun torneo"}),(0,gt.jsx)(Qc,{children:(0,gt.jsx)(Kc,{children:C((null===e||void 0===e?void 0:e.valore_squadra)||0)})}),(0,gt.jsx)(Qc,{children:(0,gt.jsx)(Kc,{children:C((null===e||void 0===e?void 0:e.casse_societarie)||0)})}),(0,gt.jsx)(Qc,{children:(0,gt.jsx)(Yc,{children:C((null===e||void 0===e?void 0:e.valore_attuale_qa)||0)})}),(0,gt.jsx)(Qc,{children:(null===e||void 0===e||null===(i=e.giocatori)||void 0===i?void 0:i.length)||0})]},e.id)})})]})})]}),f&&(0,gt.jsx)(Xc,{children:(0,gt.jsxs)(eu,{children:[(0,gt.jsx)(ru,{children:"\u26a0\ufe0f Conferma Eliminazione"}),(0,gt.jsxs)(tu,{children:["Sei sicuro di voler eliminare la lega ",(0,gt.jsxs)("strong",{children:['"',(null===l||void 0===l?void 0:l.nome)||"Nome",'"']}),"?",(0,gt.jsx)("br",{}),"Questa azione \xe8 ",(0,gt.jsx)("strong",{children:"IRREVERSIBILE"})," e eliminer\xe0:"]}),(0,gt.jsxs)("ul",{style:{textAlign:"left",marginBottom:"2rem"},children:[(0,gt.jsx)("li",{children:"Tutte le squadre della lega"}),(0,gt.jsx)("li",{children:"Tutti i giocatori"}),(0,gt.jsx)("li",{children:"Tutte le offerte e contratti"}),(0,gt.jsx)("li",{children:"Tutte le notifiche"}),(0,gt.jsx)("li",{children:"Tutti i log"})]}),(0,gt.jsx)(tu,{children:(0,gt.jsx)("strong",{children:'Digita "ELIMINA" per confermare:'})}),(0,gt.jsx)("input",{type:"text",placeholder:"ELIMINA",value:j,onChange:e=>y(e.target.value),style:{width:"100%",padding:"0.5rem",marginBottom:"1rem",border:"ELIMINA"===j?"1px solid #28a745":"1px solid #dc3545",borderRadius:"4px"}}),(0,gt.jsxs)(iu,{children:[(0,gt.jsx)(nu,{className:"cancel",onClick:()=>{x(!1),y("")},disabled:v,children:"Annulla"}),(0,gt.jsx)(nu,{className:"confirm",onClick:async()=>{b(!0);try{await qo(a,n),alert("Lega eliminata con successo!"),s("/")}catch(h){alert("Errore durante l'eliminazione: "+h.message)}finally{b(!1),x(!1)}},disabled:v||"ELIMINA"!==j,children:v?"Eliminando...":"Elimina Lega"})]})]})})]})};async function su(e,r){return ni.get(`/giocatori/${e}`,r)}async function lu(e,r){return ni.get(`/giocatori/lega/${e}`,r)}async function du(e,r){return ni.get(`/giocatori/squadra/${e}`,r)}const cu=e=>{if(!e)return[];const r=e.toUpperCase().trim();if(/[;\s,]/.test(r))return r.split(/[;\s,]+/).filter(e=>e.length>0);const t=["POR","DD","DC","DS","B","E","M","T","W","A","PC"],i=[];let n=r;for(;n.length>0;){let e=!1;for(const r of t)if(n.startsWith(r)){i.push(r),n=n.substring(r.length),e=!0;break}if(!e)for(const r of t)if(1===r.length&&n.startsWith(r)){i.push(r),n=n.substring(1),e=!0;break}e||(i.push(n[0]),n=n.substring(1))}return i.filter(e=>e.length>0)},uu=e=>{const r=e.toLowerCase();return"p"===r?"ruolo-p":"d"===r?"ruolo-d":"c"===r?"ruolo-c":"a"===r?"ruolo-a":"por"===r?"ruolo-por":"dc"===r?"ruolo-dc":"dd"===r?"ruolo-dd":"ds"===r?"ruolo-ds":"b"===r?"ruolo-b":"e"===r?"ruolo-e":"m"===r?"ruolo-m":"c"===r?"ruolo-c":"w"===r?"ruolo-w":"t"===r?"ruolo-t":"a"===r?"ruolo-a":"pc"===r?"ruolo-pc":"ruolo-default"},gu=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
`,pu=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,hu=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,mu=Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
`,fu=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 1rem;
  margin-bottom: 1rem;
`,xu=Ie.div`
  text-align: center;
  padding: 0.75rem;
  background: #f8f9fa;
  border-radius: 8px;
`,vu=Ie.div`
  font-size: 0.75rem;
  color: #86868b;
  font-weight: 500;
  margin-bottom: 0.25rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,bu=Ie.div`
  font-size: 0.9rem;
  font-weight: 600;
  color: #1d1d1f;
`,ju=Ie.span`
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 500;
  background: ${e=>e.$orphan?"#ffebee":"#e8f5e8"};
  color: ${e=>e.$orphan?"#c62828":"#2e7d32"};
`,yu=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 0.75rem;
  margin-bottom: 1.5rem;
`,wu=Ie.div`
  background: white;
  padding: 1rem;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  text-align: center;
`,ku=Ie.div`
  font-size: 0.8rem;
  color: #86868b;
  font-weight: 500;
  margin-bottom: 0.5rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,_u=Ie.div`
  font-size: 1.1rem;
  font-weight: 600;
  color: #1d1d1f;
`,Su=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Cu=Ie.h2`
  font-size: 1.1rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
`,zu=Ie.div`
  overflow-x: auto;
`,Eu=Ie.table`
  width: 100%;
  border-collapse: collapse;
  font-size: 0.85rem;
`,Au=Ie.th`
  background: #5856d6;
  color: white;
  padding: 0.75rem 0.5rem;
  text-align: center;
  font-weight: 600;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.2s;
  
  &:hover {
    background: #4a4ac7;
  }
  
  &:first-child {
    border-top-left-radius: 8px;
  }
  
  &:last-child {
    border-top-right-radius: 8px;
  }
`,Ru=Ie.td`
  padding: 0.75rem 0.5rem;
  border-bottom: 1px solid #e5e5e7;
  color: #1d1d1f;
  text-align: center;
`,Nu=(Ie.div`
  font-weight: 600;
  color: #1d1d1f;
  margin-bottom: 0.25rem;
`,Ie.span`
  .ruolo-badge {
    display: inline-block;
    padding: 2px 6px;
    margin: 1px;
    border-radius: 5px;
    font-size: 9.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: center;
    min-width: 18px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.08);
    border: 1px solid rgba(255,255,255,0.18);
    transition: all 0.2s ease;
  }
  
  .ruolo-badge:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.13);
  }
  
  .ruolo-badge:last-child {
    margin-right: 0;
  }
  
  /* Ruoli Serie A Classic */
  .ruolo-p { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  .ruolo-d { 
    background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  .ruolo-c { 
    background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-a { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #c62828;
  }
  
  /* Ruoli Euroleghe Mantra */
  /* Portieri - Arancione (come P) */
  .ruolo-por { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  /* Difensori - Palette di verdi */
  .ruolo-dc { 
    background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); 
    color: white; 
    border-color: #0d4f14;
  }
  
  .ruolo-dd { 
    background: linear-gradient(135deg, #388e3c 0%, #2e7d32 100%); 
    color: white; 
    border-color: #1b5e20;
  }
  
  .ruolo-ds { 
    background: linear-gradient(135deg, #43a047 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  /* Centrocampisti - Palette di blu */
  .ruolo-b { 
    background: linear-gradient(135deg, #1565c0 0%, #0d47a1 100%); 
    color: white; 
    border-color: #002171;
  }
  
  .ruolo-e { 
    background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); 
    color: white; 
    border-color: #0d47a1;
  }
  
  .ruolo-m { 
    background: linear-gradient(135deg, #1e88e5 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  /* Viola per W e T */
  .ruolo-t { 
    background: linear-gradient(135deg, #8e24aa 0%, #7b1fa2 100%); 
    color: white; 
    border-color: #6a0080;
  }
  
  .ruolo-w { 
    background: linear-gradient(135deg, #ab47bc 0%, #8e24aa 100%); 
    color: white; 
    border-color: #6a0080;
  }
  
  /* Attaccanti - Palette di rossi */
  .ruolo-a { 
    background: linear-gradient(135deg, #d32f2f 0%, #b71c1c 100%); 
    color: white; 
    border-color: #8e0000;
  }
  
  .ruolo-pc { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #b71c1c;
  }
  
  /* Fallback */
  .ruolo-default { 
    background: linear-gradient(135deg, #757575 0%, #616161 100%); 
    color: white; 
    border-color: #424242;
  }
`),Tu=Ie.span`
  font-weight: 600;
  color: #28a745;
  font-size: 0.8rem;
`,qu=Ie.span`
  font-weight: 600;
  color: #dc3545;
  font-size: 0.8rem;
`,Pu=Ie(lt)`
  color: #E67E22;
  font-weight: 700;
  text-decoration: none;
  cursor: pointer;
  transition: color 0.2s;
  
  &:hover {
    color: #D35400;
    text-decoration: underline;
  }
`,$u=Ie.button`
  background: #ff9500;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 500;
  font-size: 0.8rem;
  cursor: pointer;
  transition: all 0.2s;
  margin-top: 1rem;
  
  &:hover {
    background: #e6850e;
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,Iu=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #86868b;
`,Ou=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #dc3545;
`,Lu=(Ie.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ff9500 0%, #e6850e 100%);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  font-weight: 700;
  margin: 0 auto;
`,e=>{let{setCurrentLeague:t,setCurrentTeam:i}=e;const{token:n,user:o}=Si(),{id:a}=Pr(),s=qr(),[l,d]=(0,r.useState)(null),[c,u]=(0,r.useState)(null),[g,p]=(0,r.useState)(!0),[h,m]=(0,r.useState)(""),[f,x]=(0,r.useState)(!1),[v,b]=(0,r.useState)(!1),[j,y]=(0,r.useState)(""),[w,k]=(0,r.useState)({key:"ruolo",direction:"asc"}),[_,S]=(0,r.useState)([]),[C,z]=(0,r.useState)(!1),E=(0,r.useCallback)(async()=>{p(!0),m("");try{var e;const l=await Io(a,n);console.log("fetchSquadra: risposta API:",l);const c=(null===l||void 0===l||null===(e=l.data)||void 0===e?void 0:e.squadra)||(null===l||void 0===l?void 0:l.squadra);if(d(c),i&&i(c),null!==c&&void 0!==c&&c.id)try{console.log("\ud83d\udd0d [DettaglioSquadra] Inizio caricamento giocatori per squadra ID:",c.id),console.log("\ud83d\udd0d [DettaglioSquadra] Token disponibile:",!!n);const e=await du(c.id,n);console.log("\ud83d\udd0d [DettaglioSquadra] Risposta API giocatori completa:",e),console.log("\ud83d\udd0d [DettaglioSquadra] Tipo di risposta:",typeof e),console.log("\ud83d\udd0d [DettaglioSquadra] \xc8 array?",Array.isArray(e));let r=[];e&&e.ok&&e.data?(r=e.data.giocatori||e.data||[],console.log("\ud83d\udd0d [DettaglioSquadra] Estratto da giocatoriRes.data:",r)):e&&e.giocatori?(r=e.giocatori,console.log("\ud83d\udd0d [DettaglioSquadra] Estratto da giocatoriRes.giocatori:",r)):Array.isArray(e)?(r=e,console.log("\ud83d\udd0d [DettaglioSquadra] Estratto diretto (array):",r)):console.log("\ud83d\udd0d [DettaglioSquadra] Nessun dato valido trovato:",e),console.log("\ud83d\udd0d [DettaglioSquadra] Giocatori finali estratti:",r),console.log("\ud83d\udd0d [DettaglioSquadra] Numero giocatori:",r.length),d(e=>({...e,giocatori:r}))}catch(s){console.error("\u274c [DettaglioSquadra] Errore nel caricamento giocatori:",s),console.error("\u274c [DettaglioSquadra] Stack trace:",s.stack),s.message.includes("Failed to fetch")||s.message.includes("NetworkError")?m("Errore di connessione. Verifica la tua connessione e riprova."):s.message.includes("401")||s.message.includes("Token")?m("Sessione scaduta. Effettua di nuovo il login."):m(`Errore nel caricamento giocatori: ${s.message}`)}if(null!==c&&void 0!==c&&c.lega_id){var r;const e=await Ao(c.lega_id,n),i=(null===e||void 0===e||null===(r=e.data)||void 0===r?void 0:r.lega)||(null===e||void 0===e?void 0:e.lega);u(i),t&&t(i);try{var o;const e=await Lo(n),r=(null===e||void 0===e||null===(o=e.data)||void 0===o?void 0:o.squadre)||(null===e||void 0===e?void 0:e.squadre)||[];S(r);const t=null===r||void 0===r?void 0:r.some(e=>(null===e||void 0===e?void 0:e.lega_id)===(null===c||void 0===c?void 0:c.lega_id));z(t)}catch(s){console.error("Errore nel caricamento squadre utente:",s)}}}catch(s){console.error("fetchSquadra: errore:",s),m(s.message)}p(!1)},[a,n,t,i]);(0,r.useEffect)(()=>{n&&E()},[E]);const A=e=>{if(!e&&0!==e)return"FM 0";return`FM ${(parseFloat(e)||0).toLocaleString()}`},R=e=>w.key!==e?"":"asc"===w.direction?" \u25b2":" \u25bc",N=e=>{let r="asc";if(w.key===e)if("asc"===w.direction)r="desc";else if("desc"===w.direction)return void k({key:"ruolo",direction:"asc"});k({key:e,direction:r})},T=()=>l?Array.isArray(l.giocatori)?l.giocatori:l.giocatori&&Array.isArray(l.giocatori.giocatori)?l.giocatori.giocatori:l.giocatori&&l.giocatori.data&&Array.isArray(l.giocatori.data)?l.giocatori.data:l.giocatori&&l.giocatori.data&&Array.isArray(l.giocatori.data.giocatori)?l.giocatori.data.giocatori:[]:[];async function q(){if(l.is_orfana)if(v)if(j.trim()){x(!0),m(null);try{var e;await async function(e,r){let t=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};return ni.post(`/squadre/${e}/join`,t,r)}(l.id,n,{messaggio:j}),b(!1),y("");const r=await Io(a,n),t=(null===r||void 0===r||null===(e=r.data)||void 0===e?void 0:e.squadra)||(null===r||void 0===r?void 0:r.squadra);d(t)}catch(r){m(r.message)}x(!1)}else m("Inserisci un messaggio per la tua richiesta");else b(!0)}if(g)return(0,gt.jsx)(gu,{children:(0,gt.jsx)(Iu,{children:"Caricamento squadra..."})});if(h)return(0,gt.jsx)(gu,{children:(0,gt.jsxs)(Ou,{children:["Errore: ",h]})});if(!l)return(0,gt.jsx)(gu,{children:(0,gt.jsx)(Ou,{children:"Squadra non trovata"})});const P=(()=>{if(!l)return{};const e=T(),r=e.reduce((e,r)=>e+(r.quotazione_attuale||0),0)||0,t=(null===l||void 0===l?void 0:l.casse_societarie)||0,i=e.reduce((e,r)=>e+(r.costo_attuale||0),0)||0;return{valoreSquadra:r,casseSocietarie:t,ingaggioTotale:i}})();return(0,gt.jsxs)(gu,{children:[(0,gt.jsx)(pu,{onClick:()=>s(-1),children:"\u2190 Torna indietro"}),(0,gt.jsxs)(hu,{children:[(0,gt.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"1rem",marginBottom:"1rem"},children:[l.logo_url?(0,gt.jsx)("img",{src:`https://topleaguem.onrender.com/uploads/${l.logo_url}`,alt:"Logo squadra",style:{width:100,height:100,borderRadius:"50%",objectFit:"cover"}}):(0,gt.jsx)("div",{style:{width:60,height:60,borderRadius:"50%",background:"linear-gradient(135deg, #ff9500 0%, #e6850e 100%)",color:"white",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.5rem",fontWeight:"700",border:"2px solid #e5e5e7"},children:(null===l||void 0===l?void 0:l.nome)||"Nome".charAt(0).toUpperCase()}),(0,gt.jsx)(mu,{children:(null===l||void 0===l?void 0:l.nome)||"Nome"})]}),(0,gt.jsxs)(fu,{children:[(0,gt.jsxs)(xu,{children:[(0,gt.jsx)(vu,{children:"Club Level"}),(0,gt.jsx)(bu,{children:l.club_level||1})]}),(0,gt.jsxs)(xu,{children:[(0,gt.jsx)(vu,{children:"Lega"}),(0,gt.jsx)(bu,{children:(null===c||void 0===c?void 0:c.nome)||"N/A"})]}),(0,gt.jsxs)(xu,{children:[(0,gt.jsx)(vu,{children:"Torneo"}),(0,gt.jsx)(bu,{children:l.torneo||"N/A"})]}),(0,gt.jsxs)(xu,{children:[(0,gt.jsx)(vu,{children:"Giocatori"}),(0,gt.jsx)(bu,{children:P.totalPlayers})]}),(0,gt.jsxs)(xu,{children:[(0,gt.jsx)(vu,{children:"Proprietario"}),(0,gt.jsx)(bu,{children:l.proprietario_username?(0,gt.jsx)("span",{style:{color:"#28a745",fontWeight:"600"},children:l.proprietario_username}):(0,gt.jsx)("span",{style:{color:"#dc3545",fontStyle:"italic"},children:"N/A"})})]}),(0,gt.jsxs)(xu,{children:[(0,gt.jsx)(vu,{children:"Stato"}),(0,gt.jsx)(bu,{children:(0,gt.jsx)(ju,{$orphan:l.is_orfana,children:l.is_orfana?"Non Assegnata":"Assegnata"})})]})]}),l.is_orfana&&!C&&(0,gt.jsx)($u,{onClick:q,disabled:f,children:f?"Unione in corso...":"Unisciti a questa squadra"}),!!(o&&c&&l)&&(!(null===o||void 0===o||!o.ruolo)||!(null===o||void 0===o||!o.ruolo)||!(null===o||void 0===o||!o.ruolo))&&(0,gt.jsx)($u,{onClick:()=>{s(`/modifica-squadra/${l.id}`)},style:{marginLeft:"1rem"},children:"Modifica Squadra"})]}),v&&l.is_orfana&&!C&&(0,gt.jsxs)("div",{style:{background:"#f8f9fa",border:"1px solid #dee2e6",borderRadius:"8px",padding:"1.5rem",marginBottom:"2rem"},children:[(0,gt.jsx)("h3",{style:{marginTop:0,marginBottom:"1rem",color:"#495057"},children:"Richiesta di unione alla squadra"}),(0,gt.jsx)("p",{style:{marginBottom:"1rem",color:"#6c757d",fontSize:"0.9rem"},children:"Invia una richiesta all'admin della lega per unirti a questa squadra. L'admin ricever\xe0 una notifica e potr\xe0 accettare o rifiutare la tua richiesta."}),(0,gt.jsxs)("div",{style:{marginBottom:"1rem"},children:[(0,gt.jsx)("label",{style:{display:"block",marginBottom:"0.5rem",fontWeight:"500",color:"#495057"},children:"Messaggio per l'admin:"}),(0,gt.jsx)("textarea",{value:j,onChange:e=>y(e.target.value),placeholder:"Spiega perch\xe9 vuoi unirti a questa squadra...",style:{width:"100%",minHeight:"100px",padding:"0.75rem",border:"1px solid #ced4da",borderRadius:"4px",fontSize:"0.9rem",fontFamily:"inherit",resize:"vertical"}})]}),h&&(0,gt.jsx)("div",{style:{color:"#dc3545",marginBottom:"1rem",padding:"0.5rem",background:"#f8d7da",border:"1px solid #f5c6cb",borderRadius:"4px"},children:h}),(0,gt.jsxs)("div",{style:{display:"flex",gap:"1rem"},children:[(0,gt.jsx)("button",{onClick:q,disabled:f||!j.trim(),style:{background:"#007bff",color:"white",border:"none",padding:"0.75rem 1.5rem",borderRadius:"4px",cursor:f||!j.trim()?"not-allowed":"pointer",opacity:f||!j.trim()?.6:1,fontWeight:"500"},children:f?"Invio in corso...":"Invia Richiesta"}),(0,gt.jsx)("button",{onClick:()=>{b(!1),y(""),m(null)},style:{background:"#6c757d",color:"white",border:"none",padding:"0.75rem 1.5rem",borderRadius:"4px",cursor:"pointer",fontWeight:"500"},children:"Annulla"})]})]}),(0,gt.jsxs)(yu,{children:[(0,gt.jsxs)(wu,{children:[(0,gt.jsx)(ku,{children:"Valore Squadra"}),(0,gt.jsx)(_u,{children:A(P.valoreSquadra)})]}),(0,gt.jsxs)(wu,{children:[(0,gt.jsx)(ku,{children:"Casse Societarie"}),(0,gt.jsx)(_u,{children:A(P.casseSocietarie)})]}),(0,gt.jsxs)(wu,{children:[(0,gt.jsx)(ku,{children:"Ingaggio Totale"}),(0,gt.jsx)(_u,{children:A(P.ingaggioTotale)})]})]}),(0,gt.jsxs)(Su,{children:[(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1rem"},children:[(0,gt.jsx)(Cu,{children:"Giocatori della Squadra"}),(0,gt.jsx)("button",{onClick:E,style:{background:"#5856d6",color:"white",border:"none",padding:"0.5rem 1rem",borderRadius:"6px",cursor:"pointer",fontSize:"0.9rem",fontWeight:"500"},children:"\ud83d\udd04 Aggiorna Dati"})]}),T().length?(0,gt.jsx)(zu,{children:(0,gt.jsxs)(Eu,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsxs)(Au,{onClick:()=>N("nome"),children:["Giocatore",R("nome")]}),(0,gt.jsxs)(Au,{onClick:()=>N("ruolo"),children:["Ruolo",R("ruolo")]}),(0,gt.jsxs)(Au,{onClick:()=>N("r"),children:["M",R("r")]}),(0,gt.jsxs)(Au,{onClick:()=>N("fr"),children:["FaM",R("fr")]}),(0,gt.jsxs)(Au,{onClick:()=>N("squadra_reale"),children:["Squadra Reale",R("squadra_reale")]}),(0,gt.jsxs)(Au,{onClick:()=>N("cantera"),children:["Cantera",R("cantera")]}),(0,gt.jsxs)(Au,{onClick:()=>N("ingaggio"),children:["Ingaggio",R("ingaggio")]}),(0,gt.jsxs)(Au,{onClick:()=>N("qi"),children:["QI",R("qi")]}),(0,gt.jsxs)(Au,{onClick:()=>N("qa"),children:["QA",R("qa")]}),(0,gt.jsxs)(Au,{onClick:()=>N("fvmp"),children:["FVMp",R("fvmp")]}),(0,gt.jsxs)(Au,{onClick:()=>N("anni_contratto"),children:["Anni Contratto",R("anni_contratto")]}),(0,gt.jsxs)(Au,{onClick:()=>N("triggers"),children:["Triggers",R("triggers")]}),(0,gt.jsxs)(Au,{onClick:()=>N("roster"),children:["Roster",R("roster")]}),(0,gt.jsxs)(Au,{onClick:()=>N("stato_trasferimento"),children:["St.Trasf",R("stato_trasferimento")]}),(0,gt.jsxs)(Au,{onClick:()=>N("stato_prestito"),children:["St.Prest",R("stato_prestito")]})]})}),(0,gt.jsx)("tbody",{children:(()=>{const e=T();if(!e.length)return[];let r=[...e];return"ruolo"===w.key?(e=>{if(!e)return[];const r=((null===c||void 0===c?void 0:c.modalita)||"").includes("Mantra"),t=["P","Por","D","Dc","B","Dd","Ds","E","M","C","T","W","A","Pc"];return[...e].sort((e,i)=>{const n=(null===e||void 0===e?void 0:e.ruolo)||"Ruolo",o=(null===i||void 0===i?void 0:i.ruolo)||"Ruolo";let a=n,s=o;r&&(a=n.split(";")[0],s=o.split(";")[0]);const l=t.indexOf(a),d=t.indexOf(s);return-1!==l&&-1!==d?l===d?n.localeCompare(o):l-d:-1!==l?-1:-1!==d?1:n.localeCompare(o)})})(r):(r.sort((e,r)=>{let t,i;switch(w.key){case"nome":t=`${(null===e||void 0===e?void 0:e.nome)||"Nome"} ${(null===e||void 0===e?void 0:e.cognome)||""}`.toLowerCase(),i=`${(null===r||void 0===r?void 0:r.nome)||"Nome"} ${(null===r||void 0===r?void 0:r.cognome)||""}`.toLowerCase();break;case"ruolo":const n=((null===c||void 0===c?void 0:c.modalita)||"").includes("Mantra"),o=["P","Por","D","Dc","B","Dd","Ds","E","M","C","T","W","A","Pc"],a=(null===e||void 0===e?void 0:e.ruolo)||"Ruolo",s=(null===r||void 0===r?void 0:r.ruolo)||"Ruolo";let l=a,d=s;if(n){l=a.split(";")[0],d=s.split(";")[0]}const u=o.indexOf(l),g=o.indexOf(d);return-1!==u&&-1!==g?u===g?"asc"===w.direction?a.localeCompare(s):s.localeCompare(a):"asc"===w.direction?u-g:g-u:-1!==u?"asc"===w.direction?-1:1:-1!==g?"asc"===w.direction?1:-1:"asc"===w.direction?a.localeCompare(s):s.localeCompare(a);case"r":t=e.r||0,i=r.r||0;break;case"fr":t=e.fr||0,i=r.fr||0;break;case"squadra_reale":t=e.squadra_reale||"",i=r.squadra_reale||"";break;case"qi":t=e.qi||0,i=r.qi||0;break;case"ingaggio":t=e.costo_attuale||0,i=r.costo_attuale||0;break;case"qa":t=e.quotazione_attuale||0,i=r.quotazione_attuale||0;break;case"fvmp":t=e.fv_mp||0,i=r.fv_mp||0;break;case"anni_contratto":t=e.anni_contratto||0,i=r.anni_contratto||0;break;case"prestito":t=e.prestito?1:0,i=r.prestito?1:0;break;case"triggers":t=e.triggers||"",i=r.triggers||"";break;case"roster":t=e.roster||"",i=r.roster||"";break;case"stato_trasferimento":t=e.stato_trasferimento||"",i=r.stato_trasferimento||"";break;case"stato_prestito":t=e.stato_prestito||"",i=r.stato_prestito||"";break;case"cantera":t=e.cantera?"S\xec":"No",i=r.cantera?"S\xec":"No";break;default:return 0}return"string"===typeof t&&(t=t.toLowerCase(),i=i.toLowerCase()),t<i?"asc"===w.direction?-1:1:t>i?"asc"===w.direction?1:-1:0}),r)})().map(e=>(0,gt.jsxs)("tr",{style:{backgroundColor:e.squadra_prestito_id?"#fffbf0":e.valore_prestito>0||e.valore_trasferimento>0?"#faf5ff":"transparent"},children:[(0,gt.jsx)(Ru,{children:(0,gt.jsxs)(Pu,{to:`/giocatore/${e.id}`,children:[(null===e||void 0===e?void 0:e.nome)||"Nome"," ",(null===e||void 0===e?void 0:e.cognome)||""]})}),(0,gt.jsx)(Ru,{children:(0,gt.jsx)(Nu,{children:cu((null===e||void 0===e?void 0:e.ruolo)||"Ruolo").map((e,r)=>(0,gt.jsx)("span",{className:`ruolo-badge ${uu(e)}`,children:e},r))})}),(0,gt.jsx)(Ru,{children:e.r||"-"}),(0,gt.jsx)(Ru,{children:e.fr||"-"}),(0,gt.jsx)(Ru,{children:e.squadra_reale}),(0,gt.jsx)(Ru,{children:e.cantera?"\u2714":"-"}),(0,gt.jsx)(Ru,{children:(0,gt.jsx)(qu,{children:A(e.costo_attuale)})}),(0,gt.jsx)(Ru,{children:e.qi||"-"}),(0,gt.jsx)(Ru,{children:(0,gt.jsx)(Tu,{children:e.quotazione_attuale||"-"})}),(0,gt.jsx)(Ru,{children:e.fv_mp||"-"}),(0,gt.jsx)(Ru,{children:e.anni_contratto||0}),(0,gt.jsx)(Ru,{children:e.triggers||"-"}),(0,gt.jsx)(Ru,{children:(0,gt.jsx)("span",{style:{padding:"0.2rem 0.4rem",borderRadius:"4px",fontSize:"0.7rem",fontWeight:"600",backgroundColor:"A"===e.roster?"#dbeafe":"#fef3c7",color:"A"===e.roster?"#1e40af":"#92400e"},children:e.roster||"-"})}),(0,gt.jsx)(Ru,{children:e.valore_trasferimento>0?(0,gt.jsxs)("div",{style:{textAlign:"center",whiteSpace:"pre-line"},children:[(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#666",marginBottom:"2px"},children:"Costo Trasferimento"}),(0,gt.jsxs)("div",{style:{fontSize:"0.8rem",fontWeight:"600",color:"#dc3545"},children:["(",A(e.valore_trasferimento),")"]})]}):"-"}),(0,gt.jsx)(Ru,{children:e.squadra_prestito_id?(0,gt.jsxs)("div",{style:{textAlign:"center",whiteSpace:"pre-line"},children:[(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#666",marginBottom:"2px"},children:"In Prestito da"}),(0,gt.jsx)("div",{style:{fontSize:"0.8rem",fontWeight:"600",color:"#28a745"},children:e.squadra_prestito_nome||"Sconosciuta"})]}):e.valore_prestito>0?(0,gt.jsxs)("div",{style:{textAlign:"center",whiteSpace:"pre-line"},children:[(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#666",marginBottom:"2px"},children:"Costo Prestito"}),(0,gt.jsxs)("div",{style:{fontSize:"0.8rem",fontWeight:"600",color:"#28a745"},children:["(",A(e.valore_prestito),")"]})]}):"-"})]},e.id))})]})}):(0,gt.jsx)("div",{style:{textAlign:"center",padding:"2rem",color:"#86868b"},children:"Nessun giocatore in questa squadra"})]})]})}),Mu=()=>{const{token:e}=Si(),{id:t}=Pr(),i=qr(),[n,o]=(0,r.useState)(!0);return(0,r.useEffect)(()=>{o(!1)},[]),n?(0,gt.jsx)("div",{children:"Caricamento..."}):(0,gt.jsxs)("div",{style:{padding:"2rem"},children:[(0,gt.jsxs)("h1",{children:["Modifica Squadra ",t]}),(0,gt.jsx)("p",{children:"Pagina in costruzione..."}),(0,gt.jsx)("button",{onClick:()=>i(`/squadra/${t}`),children:"Torna alla squadra"})]})},Du=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
`,Fu=Ie.button`
  background: none;
  border: none;
  color: #007AFF;
  font-size: 0.9rem;
  font-weight: 500;
  cursor: pointer;
  padding: 0.5rem 0;
  margin-bottom: 1rem;
  
  &:hover {
    opacity: 0.7;
  }
`,Uu=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Bu=Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
`,Gu=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,Wu=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Hu=Ie.h2`
  font-size: 1.1rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
`,Vu=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 1rem;
`,Qu=Ie.label`
  font-size: 0.9rem;
  font-weight: 500;
  color: #1d1d1f;
`,Ku=Ie.input`
  padding: 0.75rem;
  border: 1px solid #e5e5e7;
  border-radius: 8px;
  font-size: 0.9rem;
  color: #1d1d1f;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Yu=Ie.select`
  padding: 0.75rem;
  border: 1px solid #e5e5e7;
  border-radius: 8px;
  font-size: 0.9rem;
  color: #1d1d1f;
  background: white;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Ju=(Ie.textarea`
  padding: 0.75rem;
  border: 1px solid #e5e5e7;
  border-radius: 8px;
  font-size: 0.9rem;
  color: #1d1d1f;
  min-height: 100px;
  resize: vertical;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`),Zu=Ie.label`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.9rem;
  color: #1d1d1f;
  cursor: pointer;
`,Xu=Ie.input`
  width: 16px;
  height: 16px;
`,eg=Ie.button`
  background: #ff9500;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background: #e6850e;
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,rg=Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 2rem;
`,tg=Ie.button`
  background: #e5e5e7;
  color: #1d1d1f;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background: #d1d1d6;
    transform: translateY(-1px);
  }
`,ig=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #86868b;
`,ng=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #dc3545;
`,og=Ie.div`
  background: #d4edda;
  color: #155724;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-weight: 500;
`,ag=Ie.div`
  background: #f8d7da;
  color: #721c24;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-weight: 500;
`,sg=()=>{const{token:e,user:t}=Si(),{id:i}=Pr(),n=qr(),[o,a]=(0,r.useState)(null),[s,l]=(0,r.useState)(!0),[d,c]=(0,r.useState)(!1),[u,g]=(0,r.useState)(""),[p,h]=(0,r.useState)(""),[m,f]=(0,r.useState)({nome:"",modalita:"Classic",is_pubblica:!0,password:"",max_squadre:20,min_giocatori:15,max_giocatori:25,roster_ab:!1,cantera:!1,contratti:!1,triggers:!1});(0,r.useEffect)(()=>{e&&async function(){l(!0),g("");try{const r=await Ao(i,e),t=(null===r||void 0===r?void 0:r.lega)||r||{};a(t),f({nome:(null===t||void 0===t?void 0:t.nome)||"Nome",modalita:(null===t||void 0===t?void 0:t.modalita)||"N/A",is_pubblica:(null===t||void 0===t?void 0:t.is_pubblica)||!0,password:(null===t||void 0===t?void 0:t.password)||"",max_squadre:(null===t||void 0===t?void 0:t.max_squadre)||20,min_giocatori:(null===t||void 0===t?void 0:t.min_giocatori)||15,max_giocatori:(null===t||void 0===t?void 0:t.max_giocatori)||25,roster_ab:(null===t||void 0===t?void 0:t.roster_ab)||!1,cantera:(null===t||void 0===t?void 0:t.cantera)||!1,contratti:(null===t||void 0===t?void 0:t.contratti)||!1,triggers:(null===t||void 0===t?void 0:t.triggers)||!1})}catch(r){g(r.message)}l(!1)}()},[i,e]);const x=e=>{const{name:r,value:t,type:i,checked:n}=e.target;f(e=>({...e,[r]:"checkbox"===i?n:t}))};return s?(0,gt.jsx)(Du,{children:(0,gt.jsx)(ig,{children:"Caricamento lega..."})}):u&&!o?(0,gt.jsx)(Du,{children:(0,gt.jsxs)(ng,{children:["Errore: ",u]})}):(0,gt.jsxs)(Du,{children:[(0,gt.jsx)(Fu,{onClick:()=>{t&&"admin"===(null===t||void 0===t?void 0:t.ruolo)?n("/area-admin"):n("/super-admin-dashboard")},children:"\u2190 Torna alla Dashboard"}),(0,gt.jsxs)(Uu,{children:[(0,gt.jsxs)(Bu,{children:["Modifica Lega: ",null===o||void 0===o?void 0:o.nome]}),p&&(0,gt.jsx)(og,{children:p}),u&&(0,gt.jsx)(ag,{children:u})]}),(0,gt.jsxs)(Gu,{onSubmit:async r=>{if(r.preventDefault(),console.log("\ud83d\udd0d ModificaLega: Starting handleSubmit"),console.log("\ud83d\udd0d ModificaLega: Form data:",m),console.log("\ud83d\udd0d ModificaLega: Token available:",!!e),(()=>{var e,r;return null!==m&&void 0!==m&&null!==(e=m.nome)&&void 0!==e&&e.trim()?null!==m&&void 0!==m&&m.is_pubblica||null!==m&&void 0!==m&&null!==(r=m.password)&&void 0!==r&&r.trim()?(null===m||void 0===m?void 0:m.max_squadre)<1?(g("Il numero massimo di squadre deve essere almeno 1"),!1):(null===m||void 0===m?void 0:m.min_giocatori)<1?(g("Il numero minimo di giocatori deve essere almeno 1"),!1):!((null===m||void 0===m?void 0:m.max_giocatori)<(null===m||void 0===m?void 0:m.min_giocatori))||(g("Il numero massimo di giocatori deve essere maggiore o uguale al minimo"),!1):(g("La password \xe8 obbligatoria per le leghe private"),!1):(g("Il nome della lega \xe8 obbligatorio"),!1)})()){c(!0),g(""),h("");try{console.log("\ud83d\udd0d ModificaLega: Calling updateLega with id:",i),await async function(e,r,t){const i="admin"===JSON.parse(atob(t.split(".")[1])).ruolo?`/leghe/${e}/admin`:`/leghe/${e}`;return ni.put(i,r,t)}(i,m,e),console.log("\ud83d\udd0d ModificaLega: updateLega successful"),h("Lega aggiornata con successo!"),setTimeout(()=>{t&&"admin"===(null===t||void 0===t?void 0:t.ruolo)?n("/area-admin"):n("/super-admin-dashboard")},2e3)}catch(o){console.error("\ud83d\udd0d ModificaLega: Error during update:",o),o.message&&o.message.includes("Nome lega duplicato")||o.message&&o.message.includes("Esiste gi\xe0 una lega con questo nome")?g("Esiste gi\xe0 una lega con questo nome. Scegli un nome diverso."):g(o.message||"Errore durante l'aggiornamento della lega")}finally{c(!1)}}else console.log("\ud83d\udd0d ModificaLega: Form validation failed")},children:[(0,gt.jsxs)(Wu,{children:[(0,gt.jsx)(Hu,{children:"Informazioni Generali"}),(0,gt.jsxs)(Vu,{children:[(0,gt.jsx)(Qu,{children:"Nome Lega *"}),(0,gt.jsx)(Ku,{name:"nome",value:(null===m||void 0===m?void 0:m.nome)||"Nome",onChange:x,required:!0})]}),(0,gt.jsxs)(Vu,{children:[(0,gt.jsx)(Qu,{children:"Modalit\xe0"}),(0,gt.jsxs)(Yu,{name:"modalita",value:(null===m||void 0===m?void 0:m.modalita)||"",onChange:x,children:[(0,gt.jsx)("option",{value:"Serie A Classic",children:"Serie A Classic"}),(0,gt.jsx)("option",{value:"Serie A Mantra",children:"Serie A Mantra"}),(0,gt.jsx)("option",{value:"Euroleghe Classic",children:"Euroleghe Classic"}),(0,gt.jsx)("option",{value:"Euroleghe Mantra",children:"Euroleghe Mantra"})]})]}),(0,gt.jsxs)(Vu,{children:[(0,gt.jsx)(Qu,{children:"Visibilit\xe0"}),(0,gt.jsxs)(Yu,{name:"is_pubblica",value:(null===m||void 0===m?void 0:m.is_pubblica)||(!1).toString(),onChange:x,children:[(0,gt.jsx)("option",{value:"true",children:"Pubblica"}),(0,gt.jsx)("option",{value:"false",children:"Privata"})]})]}),!(null!==m&&void 0!==m&&m.is_pubblica)&&(0,gt.jsxs)(Vu,{children:[(0,gt.jsx)(Qu,{children:"Password (obbligatoria per leghe private) *"}),(0,gt.jsx)(Ku,{name:"password",type:"password",value:(null===m||void 0===m?void 0:m.password)||"",onChange:x,placeholder:"Inserisci password per accedere",required:!(null!==m&&void 0!==m&&m.is_pubblica)})]})]}),(0,gt.jsxs)(Wu,{children:[(0,gt.jsx)(Hu,{children:"Configurazione Squadre"}),(0,gt.jsxs)(Vu,{children:[(0,gt.jsx)(Qu,{children:"Numero Massimo Squadre"}),(0,gt.jsx)(Ku,{name:"max_squadre",type:"number",value:(null===m||void 0===m?void 0:m.max_squadre)||"",onChange:x,min:"1",max:"50"})]}),(0,gt.jsxs)(Vu,{children:[(0,gt.jsx)(Qu,{children:"Numero Minimo Giocatori per Squadra"}),(0,gt.jsx)(Ku,{name:"min_giocatori",type:"number",value:(null===m||void 0===m?void 0:m.min_giocatori)||"",onChange:x,min:"1",max:"50"})]}),(0,gt.jsxs)(Vu,{children:[(0,gt.jsx)(Qu,{children:"Numero Massimo Giocatori per Squadra"}),(0,gt.jsx)(Ku,{name:"max_giocatori",type:"number",value:(null===m||void 0===m?void 0:m.max_giocatori)||"",onChange:x,min:"1",max:"50"})]})]}),(0,gt.jsxs)(Wu,{children:[(0,gt.jsx)(Hu,{children:"Funzionalit\xe0 Avanzate"}),(0,gt.jsxs)(Ju,{children:[(0,gt.jsxs)(Zu,{children:[(0,gt.jsx)(Xu,{name:"roster_ab",type:"checkbox",checked:(null===m||void 0===m?void 0:m.roster_ab)||!1,onChange:x}),"Roster A/B"]}),(0,gt.jsxs)(Zu,{children:[(0,gt.jsx)(Xu,{name:"cantera",type:"checkbox",checked:(null===m||void 0===m?void 0:m.cantera)||!1,onChange:x}),"Cantera"]}),(0,gt.jsxs)(Zu,{children:[(0,gt.jsx)(Xu,{name:"contratti",type:"checkbox",checked:(null===m||void 0===m?void 0:m.contratti)||!1,onChange:x}),"Contratti"]}),(0,gt.jsxs)(Zu,{children:[(0,gt.jsx)(Xu,{name:"triggers",type:"checkbox",checked:(null===m||void 0===m?void 0:m.triggers)||!1,onChange:x}),"Triggers"]})]})]}),(0,gt.jsxs)(Wu,{children:[(0,gt.jsx)(Hu,{children:"\ud83c\udfc6 Gestione Squadre"}),(0,gt.jsx)("p",{style:{color:"#666",marginBottom:"1rem"},children:"Gestisci le squadre di questa lega. Puoi modificare i dettagli di ogni squadra e i suoi giocatori."}),(0,gt.jsx)(eg,{type:"button",onClick:()=>n(`/gestione-squadre-lega/${i}`),style:{background:"#28a745"},children:"\ud83c\udfc3\u200d\u2642\ufe0f Gestisci Squadre"})]}),(0,gt.jsxs)(rg,{children:[(0,gt.jsx)(tg,{type:"button",onClick:()=>{t&&"admin"===(null===t||void 0===t?void 0:t.ruolo)?n("/area-admin"):n("/super-admin-dashboard")},children:"Annulla"}),(0,gt.jsx)(eg,{type:"submit",disabled:d,children:d?"Salvando...":"Salva Modifiche"})]})]})]})},lg=Ie.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 2rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
`,dg=Ie.button`
  background: none;
  border: none;
  color: #007AFF;
  font-size: 0.9rem;
  font-weight: 500;
  cursor: pointer;
  padding: 0.5rem 0;
  margin-bottom: 1rem;
  
  &:hover {
    opacity: 0.7;
  }
`,cg=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,ug=Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 0.5rem 0;
`,gg=Ie.p`
  color: #666;
  margin: 0;
`,pg=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,hg=Ie.h2`
  font-size: 1.2rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1.5rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,mg=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,fg=Ie.div`
  border: 1px solid #e5e5e7;
  border-radius: 8px;
  padding: 1rem;
  background: white;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: space-between;
  
  &:hover {
    background: #f8f9fa;
    border-color: #007AFF;
  }
`,xg=Ie.div`
  display: flex;
  align-items: center;
  gap: 2rem;
  flex: 1;
`,vg=Ie.h3`
  font-size: 1.1rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0;
  min-width: 200px;
`,bg=Ie.div`
  display: flex;
  gap: 1.5rem;
  font-size: 0.9rem;
`,jg=Ie.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 80px;
`,yg=Ie.span`
  color: #666;
  font-size: 0.8rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,wg=Ie.span`
  color: #1d1d1f;
  font-weight: 600;
  font-size: 0.9rem;
`,kg=Ie.div`
  display: flex;
  gap: 0.5rem;
`,_g=Ie.button`
  background: #ff9500;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.2s;
  margin: 0.25rem;
  
  &:hover {
    background: #e6850e;
    transform: translateY(-1px);
  }
  
  &.danger {
    background: #dc3545;
    
    &:hover {
      background: #c82333;
    }
  }
  
  &.success {
    background: #28a745;
    
    &:hover {
      background: #218838;
    }
  }
`,Sg=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #86868b;
`,Cg=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #dc3545;
`,zg=Ie.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`,Eg=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
  margin-bottom: 2rem;
`,Ag=Ie.div`
  background: #f8f9fa;
  border-radius: 8px;
  padding: 1rem;
  text-align: center;
`,Rg=Ie.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: #007AFF;
  margin-bottom: 0.25rem;
`,Ng=Ie.div`
  font-size: 0.8rem;
  color: #666;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,Tg=()=>{const{token:e,user:t}=Si(),{id:i}=Pr(),n=qr(),[o,a]=(0,r.useState)(null),[s,l]=(0,r.useState)([]),[d,c]=(0,r.useState)(!0),[u,g]=(0,r.useState)("");(0,r.useEffect)(()=>{e&&async function(){c(!0),g("");try{console.log("\ud83d\udd0d Fetching data for lega:",i),console.log("\ud83d\udd0d Token:",e?"Present":"Missing"),console.log("\ud83d\udd0d User:",t);const[r,n]=await Promise.all([Ao(i,e),Ro(i,e)]);console.log("\ud83d\udd0d Lega response:",r),console.log("\ud83d\udd0d Squadre response:",n),console.log("\ud83d\udd0d Lega details:",r.lega);const o=(null===r||void 0===r?void 0:r.data)||r,s=(null===n||void 0===n?void 0:n.data)||n;a(null===o||void 0===o?void 0:o.lega),l((null===s||void 0===s?void 0:s.squadre)||[]),console.log("\ud83d\udd0d Squadre set:",s.squadre||[])}catch(r){console.error("\u274c Error fetching data:",r),g(r.message)}c(!1)}()},[i,e]);const p=async(r,t)=>{if(window.confirm(`Sei sicuro di voler eliminare la squadra "${t}"? Questa azione non pu\xf2 essere annullata.`))try{await async function(e,r){return ni.delete(`/squadre/${e}`,r)}(r,e),l(s.filter(e=>e.id!==r)),alert("Squadra eliminata con successo!")}catch(i){alert(`Errore nell'eliminazione: ${i.message}`)}},h=()=>{n(`/super-admin/lega/${i}/squadra/nuova`)};if(d)return(0,gt.jsx)(lg,{children:(0,gt.jsx)(Sg,{children:"Caricamento squadre..."})});if(u)return(0,gt.jsx)(lg,{children:(0,gt.jsxs)(Cg,{children:["Errore: ",u]})});const m=s.reduce((e,r)=>{var t;return e+((null===(t=r.giocatori)||void 0===t?void 0:t.length)||0)},0),f=s.filter(e=>e.is_orfana).length,x=s.filter(e=>!e.is_orfana).length;return(0,gt.jsxs)(lg,{children:[(0,gt.jsx)(dg,{onClick:()=>n(`/super-admin/lega/${i}/edit`),children:"\u2190 Torna alla Modifica Lega"}),(0,gt.jsxs)(cg,{children:[(0,gt.jsxs)(ug,{children:["Gestione Squadre: ",null===o||void 0===o?void 0:o.nome]}),(0,gt.jsx)(gg,{children:"Modifica e gestisci tutte le squadre di questa lega"})]}),(0,gt.jsxs)(Eg,{children:[(0,gt.jsxs)(Ag,{children:[(0,gt.jsx)(Rg,{children:s.length}),(0,gt.jsx)(Ng,{children:"Squadre Totali"})]}),(0,gt.jsxs)(Ag,{children:[(0,gt.jsx)(Rg,{children:m}),(0,gt.jsx)(Ng,{children:"Giocatori Totali"})]}),(0,gt.jsxs)(Ag,{children:[(0,gt.jsx)(Rg,{children:x}),(0,gt.jsx)(Ng,{children:"Squadre Assegnate"})]}),(0,gt.jsxs)(Ag,{children:[(0,gt.jsx)(Rg,{children:f}),(0,gt.jsx)(Ng,{children:"Squadre Orfane"})]})]}),(0,gt.jsxs)(pg,{children:[(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1.5rem"},children:[(0,gt.jsx)(hg,{children:"Squadre della Lega"}),(0,gt.jsx)(_g,{className:"success",onClick:h,children:"\u2795 Aggiungi Squadra"})]}),0===s.length?(0,gt.jsxs)(zg,{children:[(0,gt.jsx)("h3",{children:"Nessuna squadra trovata"}),(0,gt.jsx)("p",{children:"Non ci sono ancora squadre in questa lega."}),(0,gt.jsx)(_g,{className:"success",onClick:h,children:"\u2795 Crea Prima Squadra"})]}):(0,gt.jsx)(mg,{children:s.map(e=>{var r,t;return(0,gt.jsxs)(fg,{children:[(0,gt.jsxs)(xg,{children:[(0,gt.jsx)(vg,{children:e.nome}),(0,gt.jsxs)(bg,{children:[(0,gt.jsxs)(jg,{children:[(0,gt.jsx)(yg,{children:"Proprietario"}),(0,gt.jsx)(wg,{children:e.proprietario_nome||"Orfana"})]}),(0,gt.jsxs)(jg,{children:[(0,gt.jsx)(yg,{children:"Giocatori"}),(0,gt.jsx)(wg,{children:(null===(r=e.giocatori)||void 0===r?void 0:r.length)||0})]}),(0,gt.jsxs)(jg,{children:[(0,gt.jsx)(yg,{children:"Club Level"}),(0,gt.jsx)(wg,{children:e.club_level||1})]}),(0,gt.jsxs)(jg,{children:[(0,gt.jsx)(yg,{children:"Valore"}),(0,gt.jsxs)(wg,{children:["FM ",(null===e||void 0===e||null===(t=e.valore_squadra)||void 0===t?void 0:t.toLocaleString())||0]})]})]})]}),(0,gt.jsxs)(kg,{children:[(0,gt.jsx)(_g,{onClick:()=>{return r=e.id,void n(`/modifica-squadra-completa/${r}`);var r},children:"Modifica"}),(0,gt.jsx)(_g,{className:"danger",onClick:()=>p(e.id,e.nome),children:"\ud83d\uddd1\ufe0f Elimina"})]})]},e.id)})})]})]})},qg=Ie.div`
  position: relative;
  width: 100%;
`,Pg=Ie.input`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 0.9rem;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`,$g=Ie.div`
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  background: white;
  border: 1px solid #ddd;
  border-top: none;
  border-radius: 0 0 6px 6px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  z-index: 1000;
  max-height: 200px;
  overflow-y: auto;
`,Ig=Ie.div`
  padding: 0.75rem;
  cursor: pointer;
  border-bottom: 1px solid #f0f0f0;
  font-size: 0.9rem;
  
  &:hover {
    background: #f8f9fa;
  }
  
  &:last-child {
    border-bottom: none;
  }
  
  ${e=>e.$unavailable&&"\n    opacity: 0.6;\n    cursor: not-allowed;\n    background: #f8f9fa;\n    \n    &:hover {\n      background: #f8f9fa;\n    }\n  "}
`,Og=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`,Lg=Ie.span`
  font-weight: 600;
  color: #333;
`,Mg=Ie.span`
  color: #666;
  font-size: 0.85rem;
`,Dg=Ie.span`
  background: #dc3545;
  color: white;
  padding: 0.2rem 0.5rem;
  border-radius: 12px;
  font-size: 0.7rem;
  font-weight: 600;
`,Fg=e=>{let{value:t,onChange:i,placeholder:n,token:o,legaId:a,onUserSelect:s,disabled:l=!1}=e;const[d,c]=(0,r.useState)([]),[u,g]=(0,r.useState)(!1),[p,h]=(0,r.useState)(!1),[m,f]=(0,r.useState)([]),x=(0,r.useRef)(null),v=(0,r.useRef)(null);(0,r.useEffect)(()=>{const e=e=>{x.current&&!x.current.contains(e.target)&&v.current&&!v.current.contains(e.target)&&g(!1)};return document.addEventListener("mousedown",e),()=>document.removeEventListener("mousedown",e)},[]),(0,r.useEffect)(()=>{const e=setTimeout(async()=>{if(!t||t.length<2)return c([]),void g(!1);if(!o)return console.error("Token mancante per la ricerca utenti"),void c([]);h(!0);try{console.log("Chiamata API searchUsers con:",{value:t,legaId:a,token:o?"presente":"mancante"});const e=await((e,r)=>ni.get(`/auth/search-users?q=${e}`,r))(t,a);console.log("Risposta API searchUsers:",e),c((null===e||void 0===e?void 0:e.users)||[]),g(!0)}catch(e){console.error("Errore ricerca utenti:",e),console.error("Dettagli errore:",e.message),c([])}finally{h(!1)}},300);return()=>clearTimeout(e)},[t,a,o]);return(0,gt.jsxs)(qg,{children:[(0,gt.jsx)(Pg,{ref:v,type:"text",value:t,onChange:e=>{const r=e.target.value;i(r),g(!0)},onFocus:()=>{d.length>0&&g(!0)},placeholder:n,disabled:l}),u&&(d.length>0||p)&&(0,gt.jsxs)($g,{ref:x,children:[p&&(0,gt.jsx)(Ig,{children:(0,gt.jsx)("div",{style:{textAlign:"center",color:"#666"},children:"Ricerca in corso..."})}),!p&&0===d.length&&t.length>=2&&(0,gt.jsx)(Ig,{children:(0,gt.jsx)("div",{style:{textAlign:"center",color:"#666"},children:"Nessun utente trovato"})}),!p&&d.map(e=>(0,gt.jsx)(Ig,{onClick:()=>(e=>{i(e.username),g(!1),s&&s(e)})(e),children:(0,gt.jsxs)(Og,{children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)(Lg,{children:e.username}),(0,gt.jsxs)(Mg,{children:[" - ",e.nome," ",e.cognome]})]}),e.unavailable&&(0,gt.jsx)(Dg,{children:"Non disponibile"})]})},e.id))]})]})},Ug=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
`,Bg=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,Gg=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Wg=Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 0.5rem 0;
`,Hg=Ie.p`
  color: #666;
  margin: 0;
`,Vg=Ie.form`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  margin-bottom: 1rem;
`,Qg=Ie.div`
  margin-bottom: 2rem;
`,Kg=Ie.h2`
  font-size: 1.2rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
  padding-bottom: 0.5rem;
  border-bottom: 2px solid #f0f0f0;
`,Yg=Ie.div`
  margin-bottom: 1rem;
`,Jg=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
`,Zg=Ie.input`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Xg=Ie.select`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,ep=Ie.textarea`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  min-height: 100px;
  resize: vertical;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,rp=Ie.div`
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
`,tp=Ie.button`
  padding: 12px 24px;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &.primary {
    background: #007AFF;
    color: white;
    
    &:hover {
      background: #0056b3;
    }
  }
  
  &.secondary {
    background: #6c757d;
    color: white;
    
    &:hover {
      background: #545b62;
    }
  }
  
  &.success {
    background: #28a745;
    color: white;
    
    &:hover {
      background: #218838;
    }
  }
  
  &.danger {
    background: #dc3545;
    color: white;
    
    &:hover {
      background: #c82333;
    }
  }
  
  &.warning {
    background: #ffc107;
    color: #212529;
    
    &:hover {
      background: #e0a800;
    }
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,ip=Ie.div`
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-weight: 600;
  
  &.error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
  }
  
  &.success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
  }
  
  &.warning {
    background: #fff3cd;
    color: #856404;
    border: 1px solid #ffeaa7;
  }
`,np=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #86868b;
`,op=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #dc3545;
`,ap=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,sp=(Ie.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.5rem;
  border: 1px solid #e5e5e7;
  border-radius: 6px;
  margin-bottom: 0.25rem;
  background: #f8f9fa;
  transition: all 0.2s;
  
  &:hover {
    background: #e9ecef;
    transform: translateY(-1px);
  }
  
  &:last-child {
    margin-bottom: 0;
  }
`,Ie.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  flex: 1;
`,Ie.span`
  font-weight: 600;
  color: #1d1d1f;
  min-width: 150px;
  font-size: 0.95rem;
`,Ie.span`
  color: #666;
  font-size: 0.85rem;
  min-width: 80px;
`,Ie.span`
  color: #666;
  font-size: 0.85rem;
  min-width: 120px;
`,Ie.span`
  color: #007AFF;
  font-weight: 600;
  min-width: 100px;
  font-size: 0.9rem;
`,Ie.div`
  display: flex;
  gap: 0.5rem;
`,Ie.div`
  margin-bottom: 1.5rem;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
  border: 2px dashed #dee2e6;
`,Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`),lp=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
`,dp=Ie.h2`
  font-size: 1.3rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1.5rem 0;
  text-align: center;
`,cp=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,up=Ie.div`
  display: flex;
  gap: 1rem;
  margin-top: 1.5rem;
  justify-content: flex-end;
`,gp=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,pp=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 400px;
  width: 90%;
  text-align: center;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
`,hp=Ie.h3`
  margin: 0 0 1rem 0;
  color: #28a745;
  font-size: 1.3rem;
`,mp=Ie.p`
  margin: 0 0 1.5rem 0;
  color: #666;
  line-height: 1.5;
`,fp=Ie.button`
  background: #007AFF;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
  
  &:hover {
    background: #0056b3;
  }
`,xp=(Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Ie.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
`,Ie.div`
  flex: 1;
  min-width: 200px;
`,Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
  font-size: 0.9rem;
`,Ie.input`
  width: 100%;
  padding: 8px 12px;
  border: 2px solid #e5e5e7;
  border-radius: 6px;
  font-size: 0.9rem;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Ie.select`
  width: 100%;
  padding: 8px 12px;
  border: 2px solid #e5e5e7;
  border-radius: 6px;
  font-size: 0.9rem;
  background: white;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Ie.button`
  background: ${e=>e.$active?"#007AFF":"#f8f9fa"};
  color: ${e=>e.$active?"white":"#333"};
  border: 2px solid ${e=>e.$active?"#007AFF":"#e5e5e7"};
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background: ${e=>e.$active?"#0056b3":"#e9ecef"};
  }
`,Ie.span`
  margin-left: 0.5rem;
  font-size: 0.8rem;
`,()=>{var e;const{token:t,user:i}=Si(),{id:n}=Pr(),o=qr(),[a,s]=(0,r.useState)(null),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)(!0),[g,p]=(0,r.useState)(""),[h,m]=(0,r.useState)(""),[f,x]=(0,r.useState)(!1),[v,b]=(0,r.useState)(""),[j,y]=(0,r.useState)(!1),[w,k]=(0,r.useState)(null),[_,S]=(0,r.useState)([]),[C,z]=(0,r.useState)({squadra_destinazione_id:"",costo:0,ingaggio:0,anni_contratto:1}),[E,A]=(0,r.useState)({nome:"",ruolo:"",squadra_reale:"",ingaggio_min:"",ingaggio_max:"",costo_min:"",costo_max:""}),[R,N]=(0,r.useState)({field:null,direction:"asc"}),[T,q]=(0,r.useState)(!1),[P,$]=(0,r.useState)(""),[I,O]=(0,r.useState)({nome:"",casse_societarie:0,club_level:1,is_orfana:!1,note:""});(0,r.useEffect)(()=>{t&&async function(){u(!0),p("");try{var e;const[i,o]=await Promise.all([Io(n,t),du(n,t)]),a=(null===i||void 0===i||null===(e=i.data)||void 0===e?void 0:e.squadra)||(null===i||void 0===i?void 0:i.squadra);let l=[];if(o&&o.ok&&o.data?l=o.data.giocatori||o.data||[]:o&&o.giocatori?l=o.giocatori:Array.isArray(o)?l=o:console.error("Nessun dato valido trovato per giocatori:",o),s(a),d(l),O({nome:(null===a||void 0===a?void 0:a.nome)||"Nome",casse_societarie:(null===a||void 0===a?void 0:a.casse_societarie)||0,club_level:(null===a||void 0===a?void 0:a.club_level)||1,is_orfana:(null===a||void 0===a?void 0:a.is_orfana)||!1,note:(null===a||void 0===a?void 0:a.note)||""}),null!==a&&void 0!==a&&a.lega_id)try{const e=await fetch(`https://topleaguem.onrender.com/api/squadre/lega/${a.lega_id}`,{headers:{Authorization:`Bearer ${t}`}});if(e.ok){const r=e.data;S((null===r||void 0===r?void 0:r.squadre)||[])}}catch(r){console.error("Errore nel caricamento delle squadre della lega:",r)}}catch(r){p(r.message)}u(!1)}()},[n,t]);const L=()=>{var e;return(null===a||void 0===a||null===(e=a.lega)||void 0===e?void 0:e.max_giocatori)||30},M=e=>{const{name:r,value:t,type:i,checked:n}=e.target;O(e=>({...e,[r]:"checkbox"===i?n:t}))},D=()=>{U?o(`/crea-giocatore/${n}`):p(`Impossibile aggiungere giocatori. Numero massimo raggiunto (${F})`)};if(c)return(0,gt.jsx)(Ug,{children:(0,gt.jsx)(np,{children:"Caricamento squadra..."})});if(g&&!a)return(0,gt.jsx)(Ug,{children:(0,gt.jsxs)(op,{children:["Errore: ",g]})});const F=(null===a||void 0===a||null===(e=a.lega)||void 0===e?void 0:e.max_giocatori)||30,U=(null===l||void 0===l?void 0:l.length)||0<F;return(0,gt.jsxs)(Ug,{children:[(0,gt.jsx)(Bg,{onClick:()=>o(-1),children:"\u2190 Torna indietro"}),(0,gt.jsx)(Gg,{children:(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-start"},children:[(0,gt.jsxs)("div",{children:[(0,gt.jsxs)(Wg,{children:["Modifica Squadra: ",null===a||void 0===a?void 0:a.nome]}),(0,gt.jsx)(Hg,{children:"Modifica tutti i dettagli della squadra e dei suoi giocatori"}),(0,gt.jsxs)("div",{style:{marginTop:"1rem",fontWeight:500,color:"#333"},children:["Proprietario: ",(null===a||void 0===a?void 0:a.proprietario_nome)||"Orfana"]})]}),(0,gt.jsx)(tp,{type:"button",className:"success",onClick:D,disabled:!U,style:{marginTop:"0.5rem"},children:"+ Crea Calciatore"})]})}),(0,gt.jsxs)(Vg,{onSubmit:async e=>{e.preventDefault(),p(""),m(""),x(!0);try{if(null===I||void 0===I||!I.nome||"Nome".trim())return p("Il nome della squadra \xe8 obbligatorio"),void x(!1);if(I.casse_societarie<0)return p("Le casse societarie non possono essere negative"),void x(!1);if(I.club_level<1||I.club_level>10)return p("Il club level deve essere tra 1 e 10"),void x(!1);if(I.is_orfana&&v.trim())try{if(!(await(r=v,ni.post("/auth/check-user",{username:r}))).exists)return p(`L'utente "${v}" non esiste nel database`),void x(!1)}catch(i){return p(`Errore nella verifica dell'utente: ${i.message}`),void x(!1)}await async function(e,r,t){return ni.put(`/squadre/${e}`,r,t)}(n,I,t),m("Squadra aggiornata con successo!"),s(e=>({...e,...I}))}catch(i){p(i.message)}finally{x(!1)}var r},children:[(0,gt.jsxs)(Qg,{children:[(0,gt.jsx)(Kg,{children:"Informazioni Squadra"}),(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Nome Squadra *"}),(0,gt.jsx)(Zg,{name:"nome",value:(null===I||void 0===I?void 0:I.nome)||"Nome",onChange:M,placeholder:"Inserisci il nome della squadra",required:!0})]}),(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Casse Societarie"}),(0,gt.jsx)(Zg,{name:"casse_societarie",type:"number",value:I.casse_societarie,onChange:M,placeholder:"0",min:"0"})]}),(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Club Level"}),(0,gt.jsx)(Xg,{name:"club_level",value:I.club_level,onChange:M,children:[1,2,3,4,5,6,7,8,9,10].map(e=>(0,gt.jsxs)("option",{value:e,children:["Level ",e]},e))})]}),(0,gt.jsx)(Yg,{children:(0,gt.jsxs)(Jg,{children:[(0,gt.jsx)("input",{type:"checkbox",name:"is_orfana",checked:I.is_orfana,onChange:M})," ","Aggiungi nuovo Proprietario?"]})}),I.is_orfana&&(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Username Nuovo Proprietario"}),"superadmin"===(null===i||void 0===i?void 0:i.ruolo)||"SuperAdmin"===(null===i||void 0===i?void 0:i.ruolo)?(0,gt.jsx)(Fg,{value:v,onChange:b,placeholder:"Inizia a digitare per cercare un utente...",token:t,legaId:I.lega_id,onUserSelect:e=>{console.log("Utente selezionato:",e)}}):(0,gt.jsx)(Zg,{name:"newOwnerUsername",value:v,onChange:e=>b(e.target.value),placeholder:"Inserisci username del nuovo proprietario"}),i&&(0,gt.jsxs)("small",{style:{color:"#666",marginTop:"0.25rem",display:"block"},children:["Ruolo utente: ",(null===i||void 0===i?void 0:i.ruolo)||"Ruolo"," - Token: ",t?"Presente":"Mancante"]}),(0,gt.jsx)("small",{style:{color:"#666",marginTop:"0.25rem",display:"block"},children:"superadmin"===(null===i||void 0===i?void 0:i.ruolo)||"SuperAdmin"===(null===i||void 0===i?void 0:i.ruolo)?"Digita almeno 2 caratteri per vedere i suggerimenti. Gli utenti gi\xe0 nella lega non saranno mostrati.":"L'username verr\xe0 verificato nel database prima del salvataggio"})]}),(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Note"}),(0,gt.jsx)(ep,{name:"note",value:I.note,onChange:M,placeholder:"Note aggiuntive sulla squadra..."})]})]}),g&&(0,gt.jsx)(ip,{className:"error",children:g}),h&&(0,gt.jsx)(ip,{className:"success",children:h}),(0,gt.jsxs)(rp,{children:[(0,gt.jsx)(tp,{type:"submit",className:"primary",disabled:f,children:f?"Salvataggio...":"Salva Modifiche"}),(0,gt.jsx)(tp,{type:"button",className:"secondary",onClick:()=>{o(-1)},children:"Annulla"})]})]}),(0,gt.jsxs)(ap,{children:[(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1.5rem"},children:[(0,gt.jsxs)(Kg,{children:["Giocatori (",(null===l||void 0===l?void 0:l.length)||0,"/",F,")"]}),(0,gt.jsx)(tp,{type:"button",className:"success",onClick:D,disabled:!U,children:"Aggiungi Calciatore"})]}),!U&&(0,gt.jsxs)(ip,{className:"warning",children:["Numero massimo di giocatori raggiunto (",F,"). Impossibile aggiungere nuovi calciatori."]}),(null===l||void 0===l?void 0:l.length)||!1,(null!==l&&void 0!==l&&l.length,(0,gt.jsx)("p",{style:{color:"#666",textAlign:"center",padding:"2rem"},children:"Nessun giocatore trovato in questa squadra."}))]}),j&&w&&(0,gt.jsx)(sp,{children:(0,gt.jsxs)(lp,{children:[(0,gt.jsxs)(dp,{children:["Trasferisci ",(null===w||void 0===w?void 0:w.nome)||"Nome"]}),(0,gt.jsxs)(cp,{onSubmit:async e=>{e.preventDefault(),p(""),m(""),x(!0);try{if(!C.squadra_destinazione_id)return p("Seleziona una squadra destinazione"),void x(!1);const e=_.find(e=>e.id===parseInt(C.squadra_destinazione_id)),r=L();if(e&&e.num_giocatori>=r)return p(`Numero massimo di giocatori raggiunto (${r}). Impossibile aggiungere nuovi calciatori.`),void x(!1);if(C.costo<0)return p("Il costo deve essere un numero positivo"),void x(!1);if(C.ingaggio<0)return p("L'ingaggio deve essere un numero positivo"),void x(!1);if(C.anni_contratto<1)return p("La durata del contratto deve essere almeno 1 anno"),void x(!1);await async function(e,r,t){return ni.post(`/giocatori/${e}/transfer`,r,t)}(w.id,C,t),$(`Giocatore "${(null===w||void 0===w?void 0:w.nome)||"Nome"}" trasferito con successo!`),q(!0),y(!1),k(null);const i=await du(n,t);let o=[];i&&i.ok&&i.data?o=i.data.giocatori||i.data||[]:i&&i.giocatori?o=i.giocatori:Array.isArray(i)?o=i:console.error("Nessun dato valido trovato per giocatori:",i),d(o)}catch(r){p(`Errore nel trasferimento del giocatore: ${r.message}`)}finally{x(!1)}},children:[(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Spostare in quale squadra?"}),(0,gt.jsxs)(Xg,{value:C.squadra_destinazione_id,onChange:e=>z(r=>({...r,squadra_destinazione_id:e.target.value})),required:!0,children:[(0,gt.jsx)("option",{value:"",children:"Seleziona squadra..."}),_.filter(e=>e.id!==parseInt(n)).map(e=>{var r;const t=L(),i=e.num_giocatori>=t;return(0,gt.jsxs)("option",{value:e.id,disabled:i,children:[(null===e||void 0===e?void 0:e.nome)||"Nome"," (Giocatori: ",(null===e||void 0===e?void 0:e.num_giocatori)||0,"/",t,", Casse: ",(null===e||void 0===e||null===(r=e.casse_societarie)||void 0===r?void 0:r.toLocaleString())||0," FM)",i?" - COMPLETA":""]},e.id)})]}),(0,gt.jsx)("small",{style:{color:"#666",marginTop:"0.25rem",display:"block"},children:'Le squadre con "COMPLETA" hanno raggiunto il numero massimo di giocatori'})]}),(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Costo (FM)"}),(0,gt.jsx)(Zg,{type:"number",value:C.costo,onChange:e=>z(r=>({...r,costo:parseFloat(e.target.value)||0})),placeholder:"0",min:"0",required:!0})]}),(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Ingaggio (FM)"}),(0,gt.jsx)(Zg,{type:"number",value:C.ingaggio,onChange:e=>z(r=>({...r,ingaggio:parseFloat(e.target.value)||0})),placeholder:"0",min:"0",required:!0})]}),(0,gt.jsxs)(Yg,{children:[(0,gt.jsx)(Jg,{children:"Contratto (anni)"}),(0,gt.jsx)(Zg,{type:"number",value:C.anni_contratto,onChange:e=>z(r=>({...r,anni_contratto:parseInt(e.target.value)||1})),placeholder:"1",min:"1",max:"10",required:!0})]}),g&&(0,gt.jsx)(ip,{className:"error",children:g}),h&&(0,gt.jsx)(ip,{className:"success",children:h}),(0,gt.jsxs)(up,{children:[(0,gt.jsx)(tp,{type:"button",className:"secondary",onClick:()=>{y(!1),k(null),z({squadra_destinazione_id:"",costo:0,ingaggio:0,anni_contratto:1})},children:"Annulla"}),(0,gt.jsx)(tp,{type:"submit",className:"primary",disabled:f,children:f?"Trasferimento...":"Trasferisci"})]})]})]})}),T&&(0,gt.jsx)(gp,{onClick:()=>q(!1),children:(0,gt.jsxs)(pp,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsx)(hp,{children:"Trasferimento Completato"}),(0,gt.jsx)(mp,{children:P}),(0,gt.jsx)(fp,{onClick:()=>q(!1),children:"OK"})]})})]})}),vp=Ie.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
`,bp=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,jp=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,yp=Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 0.5rem 0;
`,wp=Ie.p`
  color: #666;
  margin: 0;
`,kp=Ie.form`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  margin-bottom: 1rem;
`,_p=Ie.div`
  margin-bottom: 2rem;
`,Sp=Ie.h2`
  font-size: 1.2rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
  padding-bottom: 0.5rem;
  border-bottom: 2px solid #f0f0f0;
`,Cp=Ie.div`
  margin-bottom: 1rem;
`,zp=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
`,Ep=Ie.input`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Ap=(Ie.select`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Ie.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0.5rem;
  margin-top: 0.5rem;
`),Rp=Ie.label`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  border: 2px solid #e5e5e7;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.2s;
  background: white;
  
  &:hover {
    border-color: #007AFF;
    background: #f8f9ff;
  }
  
  input[type="checkbox"] {
    margin: 0;
    width: 16px;
    height: 16px;
    accent-color: #007AFF;
  }
  
  &.selected {
    border-color: #007AFF;
    background: #e3f2fd;
    color: #007AFF;
  }
`,Np=Ie.textarea`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  min-height: 100px;
  resize: vertical;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Tp=Ie.div`
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
`,qp=Ie.button`
  padding: 12px 24px;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &.primary {
    background: #007AFF;
    color: white;
    
    &:hover {
      background: #0056b3;
    }
  }
  
  &.secondary {
    background: #6c757d;
    color: white;
    
    &:hover {
      background: #545b62;
    }
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,Pp=Ie.div`
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-weight: 600;
  
  &.error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
  }
  
  &.success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
  }
`,$p=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #86868b;
`,Ip=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #dc3545;
`,Op=Ie.div`
  background: #f8f9fa;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
`,Lp=Ie.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.5rem;
  
  &:last-child {
    margin-bottom: 0;
  }
`,Mp=Ie.span`
  color: #666;
  font-weight: 500;
`,Dp=Ie.span`
  color: #1d1d1f;
  font-weight: 600;
`,Fp=["Por","DC","DS","DD","B","E","M","C","W","T","A","PC"],Up=()=>{const{token:e}=Si(),{id:t}=Pr(),i=qr(),[n,o]=(0,r.useState)(null),[a,s]=(0,r.useState)(!0),[l,d]=(0,r.useState)(""),[c,u]=(0,r.useState)(""),[g,p]=(0,r.useState)(!1),[h,m]=(0,r.useState)({nome:"",ruoli:[],squadra_reale:"",costo_attuale:0,valore_mercato:0,ingaggio:0,nazionalita:"",note:"",cantera:!1});(0,r.useEffect)(()=>{e&&async function(){s(!0),d("");try{var r,i,n,a,l,c,u,g,p;const s=await su(t,e);o(s.giocatore),m({nome:(null===(r=s.giocatore)||void 0===r?void 0:r.nome)||"",ruoli:null!==(i=s.giocatore)&&void 0!==i&&i.ruolo?s.giocatore.ruolo.split(";").map(e=>e.trim()).filter(Boolean):[],squadra_reale:(null===(n=s.giocatore)||void 0===n?void 0:n.squadra_reale)||"",costo_attuale:(null===(a=s.giocatore)||void 0===a?void 0:a.costo_attuale)||0,valore_mercato:(null===(l=s.giocatore)||void 0===l?void 0:l.valore_mercato)||0,ingaggio:(null===(c=s.giocatore)||void 0===c?void 0:c.costo_attuale)||0,nazionalita:(null===(u=s.giocatore)||void 0===u?void 0:u.nazionalita)||"",note:(null===(g=s.giocatore)||void 0===g?void 0:g.note)||"",cantera:(null===(p=s.giocatore)||void 0===p?void 0:p.cantera)||!1})}catch(h){d(h.message)}s(!1)}()},[t,e]);const f=e=>{const{name:r,value:t,type:i}=e.target;m(e=>({...e,[r]:"number"===i?parseFloat(t)||0:t}))};return a?(0,gt.jsx)(vp,{children:(0,gt.jsx)($p,{children:"Caricamento giocatore..."})}):l&&!n?(0,gt.jsx)(vp,{children:(0,gt.jsxs)(Ip,{children:["Errore: ",l]})}):(0,gt.jsxs)(vp,{children:[(0,gt.jsx)(bp,{onClick:()=>i(-1),children:"\u2190 Torna indietro"}),(0,gt.jsxs)(jp,{children:[(0,gt.jsxs)(yp,{children:["Modifica Giocatore: ",null===n||void 0===n?void 0:n.nome]}),(0,gt.jsx)(wp,{children:"Modifica tutti i dettagli del giocatore"})]}),(0,gt.jsxs)(kp,{onSubmit:async r=>{r.preventDefault(),d(""),u(""),p(!0);try{var i,n;if(null===h||void 0===h||null===(i=h.nome)||void 0===i||!i.trim())return d("Il nome del giocatore \xe8 obbligatorio"),void p(!1);if(!h.ruoli||0===((null===(n=h.ruoli)||void 0===n?void 0:n.length)||0))return d("Seleziona almeno un ruolo"),void p(!1);if(h.costo_attuale<0)return d("Il costo attuale non pu\xf2 essere negativo"),void p(!1);if(h.valore_mercato<0)return d("Il valore di mercato non pu\xf2 essere negativo"),void p(!1);if(h.ingaggio<0)return d("L'ingaggio non pu\xf2 essere negativo"),void p(!1);await async function(e,r,t){return ni.put(`/giocatori/${e}`,r,t)}(t,{...h,ruolo:h.ruoli.join(";")},e),u("Giocatore aggiornato con successo!"),o(e=>({...e,...h,ruolo:h.ruoli.join(";")}))}catch(a){d(a.message)}finally{p(!1)}},children:[(0,gt.jsxs)(_p,{children:[(0,gt.jsx)(Sp,{children:"Informazioni Base"}),(0,gt.jsxs)(Cp,{children:[(0,gt.jsx)(zp,{children:"Nome Completo *"}),(0,gt.jsx)(Ep,{name:"nome",value:(null===h||void 0===h?void 0:h.nome)||"Nome",onChange:f,placeholder:"Inserisci il nome completo",required:!0})]}),(0,gt.jsxs)(Cp,{children:[(0,gt.jsx)(zp,{children:"Ruoli *"}),(0,gt.jsx)(Ap,{children:null===Fp||void 0===Fp?void 0:Fp.map(e=>{var r,t;return(0,gt.jsxs)(Rp,{className:null!==(r=h.ruoli)&&void 0!==r&&r.includes(e)?"selected":"",children:[(0,gt.jsx)("input",{type:"checkbox",checked:(null===(t=h.ruoli)||void 0===t?void 0:t.includes(e))||!1,onChange:()=>(e=>{m(r=>{const t=r.ruoli||[],i=t.includes(e)?null===t||void 0===t?void 0:t.filter(r=>r!==e):[...t,e];return{...r,ruoli:i}})})(e)}),e]},e)})})]}),(0,gt.jsxs)(Cp,{children:[(0,gt.jsx)(zp,{children:"Squadra Reale"}),(0,gt.jsx)(Ep,{name:"squadra_reale",value:h.squadra_reale,onChange:f,placeholder:"Es. Juventus"})]})]}),(0,gt.jsxs)(_p,{children:[(0,gt.jsx)(Sp,{children:"Valori Economici"}),(0,gt.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem"},children:[(0,gt.jsxs)(Cp,{children:[(0,gt.jsx)(zp,{children:"Costo Attuale (FM)"}),(0,gt.jsx)(Ep,{name:"costo_attuale",type:"number",value:h.costo_attuale,onChange:f,placeholder:"0",min:"0"})]}),(0,gt.jsxs)(Cp,{children:[(0,gt.jsx)(zp,{children:"Valore di Mercato (FM)"}),(0,gt.jsx)(Ep,{name:"valore_mercato",type:"number",value:h.valore_mercato,onChange:f,placeholder:"0",min:"0"})]})]}),(0,gt.jsx)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem",marginTop:"1rem"},children:(0,gt.jsxs)(Cp,{children:[(0,gt.jsx)(zp,{children:"Ingaggio (FM)"}),(0,gt.jsx)(Ep,{name:"ingaggio",type:"number",value:h.ingaggio,onChange:f,placeholder:"0",min:"0"})]})})]}),(0,gt.jsxs)(_p,{children:[(0,gt.jsx)(Sp,{children:"Caratteristiche Fisiche"}),(0,gt.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem"},children:[(0,gt.jsxs)(Cp,{children:[(0,gt.jsx)(zp,{children:"Nazionalit\xe0"}),(0,gt.jsx)(Ep,{name:"nazionalita",value:h.nazionalita,onChange:f,placeholder:"Es. Italiana"})]}),(0,gt.jsxs)(Cp,{children:[(0,gt.jsxs)(zp,{style:{display:"flex",alignItems:"center",gap:"0.5rem"},children:[(0,gt.jsx)("input",{type:"checkbox",name:"cantera",checked:(null===h||void 0===h?void 0:h.cantera)||!1,onChange:e=>m(r=>({...r,cantera:e.target.checked}))}),"Calciatore Cantera"]}),(0,gt.jsx)("small",{style:{color:"#6c757d",fontSize:"0.8rem"},children:"I calciatori cantera hanno un ingaggio ridotto (quotazione attuale / 2)"})]})]})]}),(0,gt.jsxs)(_p,{children:[(0,gt.jsx)(Sp,{children:"Note Aggiuntive"}),(0,gt.jsxs)(Cp,{children:[(0,gt.jsx)(zp,{children:"Note"}),(0,gt.jsx)(Np,{name:"note",value:h.note,onChange:f,placeholder:"Note aggiuntive sul giocatore..."})]})]}),l&&(0,gt.jsx)(Pp,{className:"error",children:l}),c&&(0,gt.jsx)(Pp,{className:"success",children:c}),(0,gt.jsxs)(Tp,{children:[(0,gt.jsx)(qp,{type:"submit",className:"primary",disabled:g,children:g?"Salvataggio...":"Salva Modifiche"}),(0,gt.jsx)(qp,{type:"button",className:"secondary",onClick:()=>{i(-1)},children:"Annulla"})]})]}),n&&(0,gt.jsxs)(Op,{children:[(0,gt.jsx)(Sp,{children:"Informazioni Attuali"}),(0,gt.jsxs)(Lp,{children:[(0,gt.jsx)(Mp,{children:"Squadra Fantacalcio:"}),(0,gt.jsx)(Dp,{children:n.squadra_nome||"N/A"})]}),(0,gt.jsxs)(Lp,{children:[(0,gt.jsx)(Mp,{children:"Squadra Reale:"}),(0,gt.jsx)(Dp,{children:n.squadra_reale||"N/A"})]}),(0,gt.jsxs)(Lp,{children:[(0,gt.jsx)(Mp,{children:"Lega:"}),(0,gt.jsx)(Dp,{children:n.lega_nome||"N/A"})]}),(0,gt.jsxs)(Lp,{children:[(0,gt.jsx)(Mp,{children:"Proprietario:"}),(0,gt.jsx)(Dp,{children:n.proprietario_nome||"Orfano"})]})]})]})},Bp=Ie.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
`,Gp=Ie.button`
  background: none;
  border: none;
  color: #007AFF;
  font-size: 0.9rem;
  font-weight: 500;
  cursor: pointer;
  padding: 0.5rem 0;
  margin-bottom: 1rem;
  
  &:hover {
    opacity: 0.7;
  }
`,Wp=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
`,Hp=Ie.h1`
  font-size: 1.5rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 0.5rem 0;
`,Vp=Ie.p`
  color: #666;
  margin: 0;
`,Qp=Ie.form`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  margin-bottom: 1rem;
`,Kp=Ie.div`
  margin-bottom: 2rem;
`,Yp=Ie.h2`
  font-size: 1.2rem;
  font-weight: 600;
  color: #1d1d1f;
  margin: 0 0 1rem 0;
  padding-bottom: 0.5rem;
  border-bottom: 2px solid #f0f0f0;
`,Jp=Ie.div`
  margin-bottom: 1rem;
`,Zp=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
`,Xp=Ie.input`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,eh=(Ie.select`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Ie.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0.5rem;
  margin-top: 0.5rem;
`),rh=Ie.label`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  border: 2px solid #e5e5e7;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.2s;
  background: white;
  
  &:hover {
    border-color: #007AFF;
    background: #f8f9ff;
  }
  
  input[type="checkbox"] {
    margin: 0;
    width: 16px;
    height: 16px;
    accent-color: #007AFF;
  }
  
  &.selected {
    border-color: #007AFF;
    background: #e3f2fd;
    color: #007AFF;
  }
`,th=Ie.textarea`
  width: 100%;
  padding: 12px;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  min-height: 100px;
  resize: vertical;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,ih=Ie.div`
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
`,nh=Ie.button`
  padding: 12px 24px;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: all 0.2s;
  
  &.primary {
    background: #007AFF;
    color: white;
    
    &:hover {
      background: #0056b3;
    }
  }
  
  &.secondary {
    background: #6c757d;
    color: white;
    
    &:hover {
      background: #545b62;
    }
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,oh=Ie.div`
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-weight: 600;
  
  &.error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
  }
  
  &.success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
  }
`,ah=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #86868b;
`,sh=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1rem;
  color: #dc3545;
`,lh=["Por","DC","DS","DD","B","E","M","C","W","T","A","PC"],dh=()=>{const{token:e}=Si(),{id:t}=Pr(),i=qr(),[n,o]=(0,r.useState)(null),[a,s]=(0,r.useState)(!0),[l,d]=(0,r.useState)(""),[c,u]=(0,r.useState)(""),[g,p]=(0,r.useState)(!1),[h,m]=(0,r.useState)({nome:"",ruoli:[],squadra_reale:"",costo_attuale:0,valore_mercato:0,nazionalita:"",note:"",cantera:!1});(0,r.useEffect)(()=>{e&&async function(){s(!0),d("");try{var r;const i=await Io(t,e),n=(null===i||void 0===i||null===(r=i.data)||void 0===r?void 0:r.squadra)||(null===i||void 0===i?void 0:i.squadra);o(n)}catch(i){d(i.message)}s(!1)}()},[t,e]);const f=e=>{const{name:r,value:t,type:i}=e.target;m(e=>({...e,[r]:"number"===i?parseFloat(t)||0:t}))};return a?(0,gt.jsx)(Bp,{children:(0,gt.jsx)(ah,{children:"Caricamento squadra..."})}):l&&!n?(0,gt.jsx)(Bp,{children:(0,gt.jsxs)(sh,{children:["Errore: ",l]})}):(0,gt.jsxs)(Bp,{children:[(0,gt.jsx)(Gp,{onClick:()=>i(`/modifica-squadra-completa/${t}`),children:"\u2190 Torna alla squadra"}),(0,gt.jsxs)(Wp,{children:[(0,gt.jsx)(Hp,{children:"Aggiungi Nuovo Giocatore"}),(0,gt.jsxs)(Vp,{children:["Squadra: ",null===n||void 0===n?void 0:n.nome]})]}),(0,gt.jsxs)(Qp,{onSubmit:async e=>{e.preventDefault(),d(""),u(""),p(!0);try{var r;return null===h||void 0===h||!h.nome||"Nome".trim()?(d("Il nome del giocatore \xe8 obbligatorio"),void p(!1)):(!h.ruoli||null!==(r=h.ruoli)&&void 0!==r&&r.length,d("Seleziona almeno un ruolo"),void p(!1))}catch(t){d(t.message)}finally{p(!1)}},children:[(0,gt.jsxs)(Kp,{children:[(0,gt.jsx)(Yp,{children:"Informazioni Base"}),(0,gt.jsxs)(Jp,{children:[(0,gt.jsx)(Zp,{children:"Nome Completo *"}),(0,gt.jsx)(Xp,{name:"nome",value:(null===h||void 0===h?void 0:h.nome)||"Nome",onChange:f,placeholder:"Inserisci il nome completo",required:!0})]}),(0,gt.jsxs)(Jp,{children:[(0,gt.jsx)(Zp,{children:"Ruoli *"}),(0,gt.jsx)(eh,{children:null===lh||void 0===lh?void 0:lh.map(e=>{var r,t;return(0,gt.jsxs)(rh,{className:null!==(r=h.ruoli)&&void 0!==r&&r.includes(e)?"selected":"",children:[(0,gt.jsx)("input",{type:"checkbox",checked:(null===(t=h.ruoli)||void 0===t?void 0:t.includes(e))||!1,onChange:()=>(e=>{m(r=>{const t=r.ruoli||[],i=t.includes(e)?null===t||void 0===t?void 0:t.filter(r=>r!==e):[...t,e];return{...r,ruoli:i}})})(e)}),e]},e)})})]}),(0,gt.jsxs)(Jp,{children:[(0,gt.jsx)(Zp,{children:"Squadra Reale"}),(0,gt.jsx)(Xp,{name:"squadra_reale",value:h.squadra_reale,onChange:f,placeholder:"Es. Juventus"})]})]}),(0,gt.jsxs)(Kp,{children:[(0,gt.jsx)(Yp,{children:"Valori Economici"}),(0,gt.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem"},children:[(0,gt.jsxs)(Jp,{children:[(0,gt.jsx)(Zp,{children:"Costo Attuale (FM)"}),(0,gt.jsx)(Xp,{name:"costo_attuale",type:"number",value:h.costo_attuale,onChange:f,placeholder:"0",min:"0"})]}),(0,gt.jsxs)(Jp,{children:[(0,gt.jsx)(Zp,{children:"Valore di Mercato (FM)"}),(0,gt.jsx)(Xp,{name:"valore_mercato",type:"number",value:h.valore_mercato,onChange:f,placeholder:"0",min:"0"})]})]})]}),(0,gt.jsxs)(Kp,{children:[(0,gt.jsx)(Yp,{children:"Caratteristiche Fisiche"}),(0,gt.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem"},children:[(0,gt.jsxs)(Jp,{children:[(0,gt.jsx)(Zp,{children:"Nazionalit\xe0"}),(0,gt.jsx)(Xp,{name:"nazionalita",value:h.nazionalita,onChange:f,placeholder:"Es. Italiana"})]}),(0,gt.jsxs)(Jp,{children:[(0,gt.jsxs)(Zp,{style:{display:"flex",alignItems:"center",gap:"0.5rem"},children:[(0,gt.jsx)("input",{type:"checkbox",name:"cantera",checked:(null===h||void 0===h?void 0:h.cantera)||!1,onChange:e=>m(r=>({...r,cantera:e.target.checked}))}),"Calciatore Cantera"]}),(0,gt.jsx)("small",{style:{color:"#6c757d",fontSize:"0.8rem"},children:"I calciatori cantera hanno un ingaggio ridotto (quotazione attuale / 2)"})]})]})]}),(0,gt.jsxs)(Kp,{children:[(0,gt.jsx)(Yp,{children:"Note Aggiuntive"}),(0,gt.jsxs)(Jp,{children:[(0,gt.jsx)(Zp,{children:"Note"}),(0,gt.jsx)(th,{name:"note",value:h.note,onChange:f,placeholder:"Note aggiuntive sul giocatore..."})]})]}),l&&(0,gt.jsx)(oh,{className:"error",children:l}),c&&(0,gt.jsx)(oh,{className:"success",children:c}),(0,gt.jsxs)(ih,{children:[(0,gt.jsx)(nh,{type:"submit",className:"primary",disabled:g,children:g?"Creazione...":"Crea Giocatore"}),(0,gt.jsx)(nh,{type:"button",className:"secondary",onClick:()=>{i(`/modifica-squadra-completa/${t}`)},children:"Annulla"})]})]})]})},ch=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`,uh=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,gh=Ie.div`
  background: white;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 0.5rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
`,ph=Ie.h1`
  color: #333;
  margin: 0 0 0.5rem 0;
  font-size: 1.5rem;
  background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,hh=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
  gap: 0.5rem;
  margin-bottom: 0.5rem;
`,mh=Ie.div`
  background: #f8f9fa;
  border-radius: 6px;
  padding: 0.5rem;
  text-align: center;
`,fh=Ie.div`
  color: #666;
  font-size: 0.7rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 0.25rem;
`,xh=Ie.div`
  color: #333;
  font-size: 0.9rem;
  font-weight: 700;
`,vh=Ie.span`
  .ruolo-badge {
    display: inline-block;
    padding: 6px 12px;
    margin: 3px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: center;
    min-width: 28px;
    box-shadow: 0 3px 6px rgba(0,0,0,0.15);
    border: 1px solid rgba(255,255,255,0.2);
    transition: all 0.2s ease;
  }
  
  .ruolo-badge:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(0,0,0,0.2);
  }
  
  .ruolo-badge:last-child {
    margin-right: 0;
  }
  
  /* Ruoli Serie A Classic */
  .ruolo-p { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  .ruolo-d { 
    background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  .ruolo-c { 
    background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-a { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #c62828;
  }
  
  /* Ruoli Euroleghe Mantra */
  /* Portieri - Arancione (come P) */
  .ruolo-por { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  /* Difensori - Palette di verdi */
  .ruolo-dc { 
    background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); 
    color: white; 
    border-color: #0d4f14;
  }
  
  .ruolo-dd { 
    background: linear-gradient(135deg, #388e3c 0%, #2e7d32 100%); 
    color: white; 
    border-color: #1b5e20;
  }
  
  .ruolo-ds { 
    background: linear-gradient(135deg, #43a047 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  /* Centrocampisti - Palette di blu */
  .ruolo-b { 
    background: linear-gradient(135deg, #1565c0 0%, #0d47a1 100%); 
    color: white; 
    border-color: #002171;
  }
  
  .ruolo-e { 
    background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); 
    color: white; 
    border-color: #0d47a1;
  }
  
  .ruolo-m { 
    background: linear-gradient(135deg, #1e88e5 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-t { 
    background: linear-gradient(135deg, #42a5f5 0%, #1e88e5 100%); 
    color: white; 
    border-color: #1976d2;
  }
  
  .ruolo-w { 
    background: linear-gradient(135deg, #64b5f6 0%, #42a5f5 100%); 
    color: white; 
    border-color: #1e88e5;
  }
  
  /* Attaccanti - Palette di rossi */
  .ruolo-a { 
    background: linear-gradient(135deg, #d32f2f 0%, #b71c1c 100%); 
    color: white; 
    border-color: #8e0000;
  }
  
  .ruolo-pc { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #b71c1c;
  }
  
  /* Fallback */
  .ruolo-default { 
    background: linear-gradient(135deg, #757575 0%, #616161 100%); 
    color: white; 
    border-color: #424242;
  }
`,bh=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
  gap: 0.5rem;
  margin-bottom: 0.5rem;
`,jh=Ie.div`
  background: white;
  padding: 0.5rem;
  border-radius: 6px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  text-align: center;
`,yh=Ie.div`
  font-size: 0.6rem;
  color: #86868b;
  font-weight: 500;
  margin-bottom: 0.25rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,wh=Ie.div`
  font-size: 0.8rem;
  font-weight: 600;
  color: #1d1d1f;
`,kh=Ie.div`
  background: white;
  border-radius: 8px;
  padding: 0.5rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  margin-bottom: 0.5rem;
`,_h=Ie.h2`
  color: #333;
  margin: 0 0 0.5rem 0;
  font-size: 0.9rem;
  display: flex;
  align-items: center;
  gap: 0.25rem;
`,Sh=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
  gap: 0.5rem;
`,Ch=Ie.div`
  background: #f8f9fa;
  border-radius: 6px;
  padding: 0.5rem;
  text-align: center;
`,zh=Ie.div`
  color: #666;
  font-size: 0.6rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 0.25rem;
`,Eh=Ie.div`
  color: #333;
  font-size: 0.8rem;
  font-weight: 600;
`,Ah=Ie.div`
  background: white;
  border-radius: 8px;
  padding: 0.5rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
`,Rh=Ie.form`
  background: #f8f9fa;
  border-radius: 6px;
  padding: 0.5rem;
  margin-top: 0.5rem;
`,Nh=Ie.div`
  margin-bottom: 0.5rem;
`,Th=Ie.label`
  display: block;
  margin-bottom: 0.25rem;
  color: #333;
  font-weight: 600;
  font-size: 0.7rem;
`,qh=Ie.select`
  width: 100%;
  padding: 0.25rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 0.7rem;
  background: white;
`,Ph=Ie.input`
  width: 100%;
  padding: 0.25rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 0.7rem;
`,$h=Ie.button`
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  color: white;
  border: none;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-weight: 600;
  font-size: 0.7rem;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,Ih=Ie.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-weight: 600;
  font-size: 0.7rem;
  cursor: pointer;
  transition: transform 0.2s;
  margin-bottom: 0.5rem;
  
  &:hover {
    transform: translateY(-1px);
  }
`,Oh=Ie.div`
  padding: 0.5rem;
  border-radius: 4px;
  margin-top: 0.5rem;
  font-weight: 600;
  font-size: 0.7rem;
  background: ${e=>e.success?"#d4edda":"#f8d7da"};
  color: ${e=>e.success?"#155724":"#721c24"};
`,Lh=Ie.div`
  background: white;
  border-radius: 8px;
  padding: 0.5rem;
  margin-bottom: 0.5rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
`,Mh=(Ie.div`
  height: 200px;
  margin-top: 0.5rem;
`,Ie.div`
  text-align: center;
  padding: 1rem;
  color: #666;
  font-style: italic;
  font-size: 0.7rem;
`),Dh=(Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 2rem;
`,Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100px;
  font-size: 0.8rem;
  color: #dc3545;
`,Ie.div`
  background: white;
  border-radius: 8px;
  padding: 0.5rem;
  margin-bottom: 0.5rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
`),Fh=e=>{switch(e){case"trasferimento":return"#28a745";case"prestito":return"#ffc107";case"scambio":return"#17a2b8";case"rinnovo":return"#6f42c1";case"pagamento":return"#fd7e14";default:return"#6c757d"}},Uh=e=>{let{setCurrentLeague:t,setCurrentTeam:i}=e;const{token:n,user:o}=Si(),{id:a}=Pr(),s=qr(),[l,d]=(0,r.useState)(null),[c,u]=(0,r.useState)(null),[g,p]=(0,r.useState)([]),[h,m]=(0,r.useState)(!0),[f,x]=(0,r.useState)(""),[v,b]=(0,r.useState)([]),[j,y]=(0,r.useState)(!1),[w,k]=(0,r.useState)(!1),[_,S]=(0,r.useState)(!1),[C,z]=(0,r.useState)(""),[E,A]=(0,r.useState)({squadra_destinatario_id:"",tipo:"trasferimento",valore:"",richiesta_fm:"",giocatore_scambio_id:""}),[R,N]=(0,r.useState)([]),[T,q]=(0,r.useState)(!1),[P,$]=(0,r.useState)(null),[I,O]=(0,r.useState)([]);(0,r.useEffect)(()=>{n&&async function(){m(!0),x("");try{var e;console.log("\ud83d\udd0d [DettaglioGiocatore] Token presente:",!!n),console.log("\ud83d\udd0d [DettaglioGiocatore] Chiamando getGiocatoreById per ID:",a);const t=await su(a,n);console.log("\ud83d\udd0d [DettaglioGiocatore] Risposta API:",t),console.log("\ud83d\udd0d [DettaglioGiocatore] Tipo di risposta:",typeof t),console.log("\ud83d\udd0d [DettaglioGiocatore] Contenuto risposta:",JSON.stringify(t,null,2));let i=null;if(t&&t.ok&&t.data&&t.data.giocatore)i=t.data.giocatore,console.log("\ud83d\udd0d [DettaglioGiocatore] Estratto da res.data.giocatore");else if(t&&t.giocatore)i=t.giocatore,console.log("\ud83d\udd0d [DettaglioGiocatore] Estratto da res.giocatore");else{if(!t||!t.id)throw console.log("\ud83d\udd0d [DettaglioGiocatore] Nessun dato giocatore trovato"),console.log("\ud83d\udd0d [DettaglioGiocatore] Struttura res:",JSON.stringify(t,null,2)),new Error("Dati giocatore non validi");i=t,console.log("\ud83d\udd0d [DettaglioGiocatore] Usato res direttamente")}if(d(i),null!==(e=i)&&void 0!==e&&e.squadra_id){var r;console.log("\ud83d\udd0d [DettaglioGiocatore] Caricamento squadra per ID:",i.squadra_id);const e=await Io(i.squadra_id,n);console.log("\ud83d\udd0d [DettaglioGiocatore] Risposta squadra:",e);let t=null;if(e&&e.squadra?(t=e.squadra,console.log("\ud83d\udd0d [DettaglioGiocatore] Estratto da squadraRes.squadra")):e&&e.data&&e.data.squadra?(t=e.data.squadra,console.log("\ud83d\udd0d [DettaglioGiocatore] Estratto da squadraRes.data.squadra")):e&&e.id&&(t=e,console.log("\ud83d\udd0d [DettaglioGiocatore] Usato squadraRes direttamente")),u(t),null!==(r=t)&&void 0!==r&&r.lega_id){console.log("\ud83d\udd0d [DettaglioGiocatore] Caricamento squadre per lega ID:",t.lega_id);const e=await Ro(t.lega_id,n);console.log("\ud83d\udd0d [DettaglioGiocatore] Risposta squadre:",e);let r=[];Array.isArray(e)?(r=e,console.log("\ud83d\udd0d [DettaglioGiocatore] Usato squadreRes direttamente come array")):e&&e.squadre&&Array.isArray(e.squadre)?(r=e.squadre,console.log("\ud83d\udd0d [DettaglioGiocatore] Estratto da squadreRes.squadre")):e&&e.data&&Array.isArray(e.data)?(r=e.data,console.log("\ud83d\udd0d [DettaglioGiocatore] Estratto da squadreRes.data")):e&&e.data&&e.data.squadre&&Array.isArray(e.data.squadre)&&(r=e.data.squadre,console.log("\ud83d\udd0d [DettaglioGiocatore] Estratto da squadreRes.data.squadre")),p(r)}}}catch(t){console.error("Errore nel caricamento del giocatore:",t),"Giocatore non trovato"===t.message?x("Giocatore non trovato. Il giocatore potrebbe essere stato eliminato o l'ID non \xe8 corretto."):x(t.message||"Errore nel caricamento del giocatore")}m(!1)}()},[a,n]),(0,r.useEffect)(()=>{l&&n&&(L(),M(),D())},[l,n]);const L=async()=>{y(!0);try{const e=await(async(e,r)=>{try{return(await ni.get(`/giocatori/${e}/qa-history`,r)).history}catch(f){throw console.error("Errore API getQAHistory:",f),f}})(a,n),r=[];l.qi&&r.push({data:"QI Iniziale",qa_value:parseFloat(l.qi),tipo:"QI"});let t=l.qi?parseFloat(l.qi):null;if(e&&Array.isArray(e)?e.forEach(e=>{const i=parseFloat(e.qa_value);null!==t&&i===t||(r.push({data:new Date(e.data_registrazione).toLocaleDateString("it-IT"),qa_value:i,tipo:"QA"}),t=i)}):console.log("\ud83d\udd0d [DettaglioGiocatore] QA History non disponibile o non valida:",e),l.qa&&r.length>0){const e=parseFloat(l.qa);e!==r[r.length-1].qa_value&&r.push({data:"Oggi",qa_value:e,tipo:"QA Attuale"})}b(r)}catch(e){console.error("Errore nel recupero della cronologia QA:",e),b([])}y(!1)},M=async()=>{q(!0);try{const e=await(async(e,r)=>ni.get(`/contratti/log-giocatore/${e}`,r))(a,n);N(e)}catch(e){console.error("Errore nel recupero del log operazioni:",e),N([])}q(!1)},D=async()=>{try{if(null===l||void 0===l||!l.lega_id)return void console.warn("\ud83d\udd0d DettaglioGiocatore: giocatore.lega_id undefined, skipping");const e=await ni.get(`/squadre/my-team/${l.lega_id}`,n);if(e.ok){const r=e.data;$(r.squadra),O(r.giocatori||[])}else 404===e.status&&(console.log("\ud83d\udd0d DettaglioGiocatore: Utente non ha squadra in questa lega"),$(null),O([]))}catch(e){console.error("Errore nel recupero della squadra utente:",e),$(null),O([])}},F=e=>e&&"N/A"!==e?"string"===typeof e?`FM ${e}`:`FM ${e.toLocaleString()}`:"FM 0";function U(e){A(r=>({...r,[e.target.name]:e.target.value}))}const B=e=>"string"===typeof e||"number"===typeof e?e:"N/A";return h?(0,gt.jsx)(ch,{children:(0,gt.jsx)("div",{style:{display:"flex",justifyContent:"center",alignItems:"center",height:"50vh",fontSize:"1.2rem",color:"#666"},children:"Caricamento giocatore..."})}):f?(0,gt.jsxs)(ch,{children:[(0,gt.jsx)(uh,{onClick:()=>s(-1),children:"\u2190 Torna indietro"}),(0,gt.jsxs)("div",{style:{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",height:"50vh",textAlign:"center",padding:"2rem"},children:[(0,gt.jsx)("div",{style:{fontSize:"1.5rem",color:"#e74c3c",marginBottom:"1rem",fontWeight:"bold"},children:"\u26a0\ufe0f Errore"}),(0,gt.jsx)("div",{style:{fontSize:"1rem",color:"#666",marginBottom:"2rem",maxWidth:"500px"},children:f}),(0,gt.jsx)("button",{onClick:()=>s("/"),style:{padding:"0.75rem 1.5rem",backgroundColor:"#667eea",color:"white",border:"none",borderRadius:"8px",cursor:"pointer",fontSize:"1rem"},children:"Torna alla Home"})]})]}):l?(0,gt.jsxs)(ch,{children:[(0,gt.jsx)(uh,{onClick:()=>s(-1),children:"\u2190 Torna indietro"}),(0,gt.jsxs)(gh,{children:[(0,gt.jsxs)(ph,{children:[B(l.nome)," ",l.cognome?B(l.cognome):""]}),(0,gt.jsxs)(hh,{children:[(0,gt.jsxs)(mh,{children:[(0,gt.jsx)(fh,{children:"Ruolo"}),(0,gt.jsx)(xh,{children:(0,gt.jsx)(vh,{children:Array.isArray(cu(l.ruolo))&&cu(l.ruolo).length>0?cu(l.ruolo).map((e,r)=>(0,gt.jsx)("span",{className:`ruolo-badge ${uu(B(e))}`,children:B(e)},r)):"N/A"})})]}),(0,gt.jsxs)(mh,{children:[(0,gt.jsx)(fh,{children:"Squadra Reale"}),(0,gt.jsx)(xh,{children:"N/A"!==B(l.squadra_reale)&&l.squadra_id?(0,gt.jsx)("span",{style:{color:"#E67E22",fontWeight:700,cursor:"pointer",textDecoration:"none"},onClick:()=>s(`/squadra/${l.squadra_id}`),children:B(l.squadra_reale)}):"N/A"})]}),(0,gt.jsxs)(mh,{children:[(0,gt.jsx)(fh,{children:"Squadra Fantasy"}),(0,gt.jsx)(xh,{children:B(null===c||void 0===c?void 0:c.nome)})]}),(0,gt.jsxs)(mh,{children:[(0,gt.jsx)(fh,{children:"Ingaggio"}),(0,gt.jsx)(xh,{children:B(F(l.costo_attuale))})]}),(0,gt.jsxs)(mh,{children:[(0,gt.jsx)(fh,{children:"Cantera"}),(0,gt.jsx)(xh,{children:l.cantera?(0,gt.jsx)("span",{style:{color:"#28a745",fontWeight:"bold"},children:"\u2714 S\xec"}):(0,gt.jsx)("span",{style:{color:"#6c757d"},children:"\u2717 No"})})]})]})]}),(0,gt.jsxs)(bh,{children:[(0,gt.jsxs)(jh,{children:[(0,gt.jsx)(yh,{children:"Quotazione Attuale"}),(0,gt.jsx)(wh,{children:B(l.quotazione_attuale)})]}),(0,gt.jsxs)(jh,{children:[(0,gt.jsx)(yh,{children:"Ingaggio"}),(0,gt.jsx)(wh,{children:F(B(l.costo_attuale))})]}),(0,gt.jsxs)(jh,{children:[(0,gt.jsx)(yh,{children:"Costo Precedente"}),(0,gt.jsx)(wh,{children:F(B(l.costo_precedente))})]}),(0,gt.jsxs)(jh,{children:[(0,gt.jsx)(yh,{children:"QA"}),(0,gt.jsx)(wh,{children:B(l.qa)})]}),(0,gt.jsxs)(jh,{children:[(0,gt.jsx)(yh,{children:"QI"}),(0,gt.jsx)(wh,{children:B(l.qi)})]})]}),(0,gt.jsxs)(kh,{children:[(0,gt.jsx)(_h,{children:"\ud83d\udccb Dettagli Contratto"}),(0,gt.jsxs)(Sh,{children:[(0,gt.jsxs)(Ch,{children:[(0,gt.jsx)(zh,{children:"Prestito"}),(0,gt.jsx)(Eh,{children:l.prestito?"S\xec":"No"})]}),(0,gt.jsxs)(Ch,{children:[(0,gt.jsx)(zh,{children:"Anni Contratto"}),(0,gt.jsx)(Eh,{children:B(l.anni_contratto)})]}),(0,gt.jsxs)(Ch,{children:[(0,gt.jsx)(zh,{children:"Cantera"}),(0,gt.jsx)(Eh,{children:l.cantera?"S\xec":"No"})]}),(0,gt.jsxs)(Ch,{children:[(0,gt.jsx)(zh,{children:"Triggers"}),(0,gt.jsx)(Eh,{children:B(l.triggers)})]})]})]}),(0,gt.jsxs)(Lh,{children:[(0,gt.jsx)(_h,{children:"\ud83d\udcc8 Cronologia Quotazione"}),j?(0,gt.jsx)("div",{style:{textAlign:"center",padding:"1rem",fontSize:"0.8rem"},children:"Caricamento cronologia..."}):v.length>0?(0,gt.jsx)("div",{style:{marginTop:"0.5rem"},children:(0,gt.jsxs)("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:"0.7rem"},children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{style:{backgroundColor:"#f8f9fa"},children:[(0,gt.jsx)("th",{style:{padding:"0.5rem",textAlign:"left",borderBottom:"1px solid #ddd"},children:"Data"}),(0,gt.jsx)("th",{style:{padding:"0.5rem",textAlign:"center",borderBottom:"1px solid #ddd"},children:"Tipo"}),(0,gt.jsx)("th",{style:{padding:"0.5rem",textAlign:"center",borderBottom:"1px solid #ddd"},children:"Quotazione"})]})}),(0,gt.jsx)("tbody",{children:v.map((e,r)=>(0,gt.jsxs)("tr",{style:{borderBottom:"1px solid #eee"},children:[(0,gt.jsx)("td",{style:{padding:"0.5rem",textAlign:"left"},children:e.data}),(0,gt.jsx)("td",{style:{padding:"0.5rem",textAlign:"center"},children:(0,gt.jsx)("span",{style:{padding:"0.2rem 0.4rem",borderRadius:"4px",fontSize:"0.6rem",fontWeight:"bold",backgroundColor:"QI"===e.tipo?"#ffc107":"#28a745",color:"white"},children:e.tipo})}),(0,gt.jsx)("td",{style:{padding:"0.5rem",textAlign:"center",fontWeight:"bold"},children:e.qa_value})]},r))})]})}):(0,gt.jsx)(Mh,{children:"Nessun dato storico della quotazione disponibile per questo giocatore."})]}),(0,gt.jsxs)(Ah,{children:[(0,gt.jsx)(_h,{children:"\ud83d\udcb0 Proponi Offerta"}),P&&l.squadra_id!==P.id?(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(Ih,{onClick:()=>k(e=>!e),children:w?"Nascondi Form Offerta":"Mostra Form Offerta"}),w&&(0,gt.jsxs)(Rh,{onSubmit:async function(e){e.preventDefault(),z(""),S(!0);try{await(async(e,r)=>ni.post("/offerte/crea",e,r))({giocatore_id:l.id,tipo:E.tipo,valore_offerta:parseInt(E.valore)||0,richiesta_fm:parseInt(E.richiesta_fm)||0,giocatore_scambio_id:E.giocatore_scambio_id||null},n),z("Offerta inviata con successo!"),A({squadra_destinatario_id:"",tipo:"trasferimento",valore:"",richiesta_fm:"",giocatore_scambio_id:""}),k(!1)}catch(r){z(r.message)}S(!1)},children:[(0,gt.jsxs)(Nh,{children:[(0,gt.jsx)(Th,{children:"Tipo di Offerta"}),(0,gt.jsxs)(qh,{name:"tipo",value:E.tipo,onChange:U,children:[(0,gt.jsx)("option",{value:"trasferimento",children:"Trasferimento"}),(0,gt.jsx)("option",{value:"prestito",children:"Prestito"}),(0,gt.jsx)("option",{value:"scambio",children:"Scambio"})]})]}),(0,gt.jsxs)(Nh,{children:[(0,gt.jsx)(Th,{children:"Valore Offerta (FM)"}),(0,gt.jsx)(Ph,{name:"valore",type:"number",value:E.valore,onChange:U,placeholder:"Inserisci il valore dell'offerta"})]}),(0,gt.jsxs)(Nh,{children:[(0,gt.jsx)(Th,{children:"Richiesta (FM)"}),(0,gt.jsx)(Ph,{name:"richiesta_fm",type:"number",value:E.richiesta_fm,onChange:U,placeholder:"Inserisci la richiesta (opzionale)"})]}),"scambio"===E.tipo&&(0,gt.jsxs)(Nh,{children:[(0,gt.jsx)(Th,{children:"Giocatore da Scambiare"}),(0,gt.jsxs)(qh,{name:"giocatore_scambio_id",value:E.giocatore_scambio_id,onChange:U,required:!0,children:[(0,gt.jsx)("option",{value:"",children:"Seleziona giocatore da scambiare"}),I.map(e=>(0,gt.jsxs)("option",{value:e.id,children:[e.nome," ",e.cognome," (",e.ruolo,")"]},e.id))]})]}),(0,gt.jsx)($h,{type:"submit",disabled:_,children:_?"Invio in corso...":"Invia Offerta"}),C&&(0,gt.jsx)(Oh,{success:C.includes("successo"),children:C})]})]}):(0,gt.jsx)("div",{style:{textAlign:"center",padding:"1rem",color:"#666",fontStyle:"italic"},children:P&&l.squadra_id===P.id?"Questo giocatore appartiene gi\xe0 alla tua squadra":null===P?"Non hai una squadra in questa lega":"Caricamento..."})]}),(0,gt.jsxs)(Dh,{children:[(0,gt.jsx)(_h,{children:"\ud83d\udccb Log Operazioni"}),T?(0,gt.jsx)("div",{style:{textAlign:"center",padding:"1rem",fontSize:"0.8rem"},children:"Caricamento log..."}):R.length>0?(0,gt.jsx)("div",{style:{marginTop:"0.5rem"},children:(0,gt.jsxs)("table",{style:{width:"100%",borderCollapse:"collapse",fontSize:"0.7rem"},children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{style:{backgroundColor:"#f8f9fa"},children:[(0,gt.jsx)("th",{style:{padding:"0.5rem",textAlign:"left",borderBottom:"1px solid #ddd"},children:"Data"}),(0,gt.jsx)("th",{style:{padding:"0.5rem",textAlign:"center",borderBottom:"1px solid #ddd"},children:"Tipo"}),(0,gt.jsx)("th",{style:{padding:"0.5rem",textAlign:"center",borderBottom:"1px solid #ddd"},children:"Valore"}),(0,gt.jsx)("th",{style:{padding:"0.5rem",textAlign:"left",borderBottom:"1px solid #ddd"},children:"Dettagli"})]})}),(0,gt.jsx)("tbody",{children:R.map((e,r)=>(0,gt.jsxs)("tr",{style:{borderBottom:"1px solid #eee"},children:[(0,gt.jsx)("td",{style:{padding:"0.5rem",textAlign:"left"},children:new Date(e.data_operazione).toLocaleDateString("it-IT")}),(0,gt.jsx)("td",{style:{padding:"0.5rem",textAlign:"center"},children:(0,gt.jsx)("span",{style:{padding:"0.2rem 0.4rem",borderRadius:"4px",fontSize:"0.6rem",fontWeight:"bold",backgroundColor:Fh(e.tipo_operazione),color:"white"},children:e.tipo_operazione})}),(0,gt.jsx)("td",{style:{padding:"0.5rem",textAlign:"center",fontWeight:"bold"},children:e.valore?`FM ${e.valore}`:"-"}),(0,gt.jsx)("td",{style:{padding:"0.5rem",textAlign:"left",fontSize:"0.65rem"},children:e.dettagli})]},r))})]})}):(0,gt.jsx)(Mh,{children:"Nessuna operazione registrata per questo giocatore."})]})]}):(0,gt.jsxs)(ch,{children:[(0,gt.jsx)(uh,{onClick:()=>s(-1),children:"\u2190 Torna indietro"}),(0,gt.jsxs)("div",{style:{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",height:"50vh",textAlign:"center",padding:"2rem"},children:[(0,gt.jsx)("div",{style:{fontSize:"1.5rem",color:"#e74c3c",marginBottom:"1rem",fontWeight:"bold"},children:"\u274c Giocatore non trovato"}),(0,gt.jsxs)("div",{style:{fontSize:"1rem",color:"#666",marginBottom:"2rem",maxWidth:"500px"},children:["Il giocatore con ID ",a," non esiste o \xe8 stato eliminato."]}),(0,gt.jsx)("button",{onClick:()=>s("/"),style:{padding:"0.75rem 1.5rem",backgroundColor:"#667eea",color:"white",border:"none",borderRadius:"8px",cursor:"pointer",fontSize:"1rem"},children:"Torna alla Home"})]})]})},Bh=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 1.5rem;
  border: 1px solid #e2e8f0;
  min-height: 200px;
  max-width: 100%;
  overflow: hidden;
`,Gh=Ie.h3`
  color: #1e293b;
  margin: 0 0 1rem 0;
  font-size: 1.25rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Wh=Ie.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  margin-bottom: 1.5rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`,Hh=Ie.div`
  background: ${e=>"rosterA"===e.$variant?"#f0f9ff":"#fef3c7"};
  border: 1px solid ${e=>"rosterA"===e.$variant?"#0ea5e9":"#f59e0b"};
  border-radius: 8px;
  padding: 1rem;
  text-align: center;
`,Vh=Ie.div`
  font-size: 1.5rem;
  font-weight: 700;
  color: ${e=>"rosterA"===e.$variant?"#0ea5e9":"#f59e0b"};
  margin-bottom: 0.25rem;
`,Qh=Ie.div`
  font-size: 0.8rem;
  color: #64748b;
  font-weight: 500;
`,Kh=Ie.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
  font-size: 0.875rem;
  min-width: 350px;
  
  @media (max-width: 768px) {
    font-size: 0.75rem;
    min-width: 300px;
  }
`,Yh=Ie.th`
  background: #f8fafc;
  padding: 0.3rem 0.2rem;
  text-align: left;
  font-weight: 600;
  color: #475569;
  border-bottom: 1px solid #e2e8f0;
  font-size: 0.7rem;
  white-space: nowrap;
  
  &:nth-child(1) { width: 45%; } /* Giocatore */
  &:nth-child(2) { width: 20%; } /* Ruolo */
  &:nth-child(3) { width: 15%; } /* Roster */
  &:nth-child(4) { width: 20%; } /* Azioni */
  
  @media (max-width: 768px) {
    padding: 0.25rem 0.15rem;
    font-size: 0.65rem;
  }
`,Jh=Ie.td`
  padding: 0.3rem 0.2rem;
  border-bottom: 1px solid #f1f5f9;
  color: #1e293b;
  vertical-align: middle;
  font-size: 0.75rem;
  
  @media (max-width: 768px) {
    padding: 0.25rem 0.15rem;
    font-size: 0.7rem;
  }
`,Zh=Ie.tr`
  transition: background-color 0.2s ease;
  
  &:hover {
    background: #f8fafc;
  }
`,Xh=Ie.span`
  padding: 0.1rem 0.2rem;
  border-radius: 3px;
  font-size: 0.6rem;
  font-weight: 600;
  text-transform: uppercase;
  display: inline-block;
  text-align: center;
  min-width: 14px;
  
  &.rosterA {
    background: #dbeafe;
    color: #1e40af;
  }
  
  &.rosterB {
    background: #fef3c7;
    color: #92400e;
  }
  
  @media (max-width: 768px) {
    font-size: 0.55rem;
    padding: 0.08rem 0.15rem;
    min-width: 12px;
  }
`,em=Ie.button`
  background: ${e=>{switch(e.$variant){case"moveToA":return"#10b981";case"moveToB":return"#f59e0b";case"disabled":return"#6b7280";default:return"#3b82f6"}}};
  color: white;
  border: none;
  padding: 0.2rem 0.4rem;
  border-radius: 3px;
  font-weight: 500;
  cursor: ${e=>e.$disabled?"not-allowed":"pointer"};
  transition: all 0.2s ease;
  font-size: 0.6rem;
  opacity: ${e=>e.$disabled?.5:1};
  white-space: nowrap;
  
  &:hover {
    ${e=>!e.$disabled&&"filter: brightness(0.9);"}
  }
  
  @media (max-width: 768px) {
    padding: 0.15rem 0.3rem;
    font-size: 0.55rem;
  }
`,rm=Ie.div`
  text-align: center;
  font-size: 1rem;
  color: #64748b;
  margin: 2rem 0;
  padding: 1rem;
`,tm=Ie.div`
  text-align: center;
  color: #64748b;
  padding: 2rem;
  font-size: 0.9rem;
`,im=Ie.div`
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #dc2626;
  padding: 0.75rem;
  border-radius: 6px;
  margin-bottom: 1rem;
  font-size: 0.875rem;
`,nm=Ie.div`
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
  color: #16a34a;
  padding: 0.75rem;
  border-radius: 6px;
  margin-bottom: 1rem;
  font-size: 0.875rem;
`,om=e=>{var t,i;let{squadraId:n,legaId:o,userRole:a}=e;const{token:s}=Si(),[l,d]=(0,r.useState)(null),[c,u]=(0,r.useState)(!0),[g,p]=(0,r.useState)(null),[h,m]=(0,r.useState)(""),[f,x]=(0,r.useState)(null),v=(0,r.useRef)(!1),b=async()=>{if(!v.current)try{var e,r,t,i;v.current=!0,u(!0),p(null);const o=await ni.get(`/offerte/roster/${n}`,s);let a=o;o&&o.ok&&o.data?(a=o.data,console.log("\ud83d\udd0d [RosterABManager] Estratto da response.data:",a)):console.log("\ud83d\udd0d [RosterABManager] Estratto diretto:",a),console.log("\ud83d\udd0d RosterA length:",null===(e=a)||void 0===e||null===(r=e.rosterA)||void 0===r?void 0:r.length),console.log("\ud83d\udd0d RosterB length:",null===(t=a)||void 0===t||null===(i=t.rosterB)||void 0===i?void 0:i.length),d(a)}catch(a){var o;console.error("Errore fetch roster data:",a),console.error("Error details:",null===(o=a.response)||void 0===o?void 0:o.data),p("Errore nel caricamento dei dati roster")}finally{u(!1),v.current=!1}};(0,r.useEffect)(()=>{n&&s&&!v.current&&b()},[n,s]);const j=async(e,r)=>{try{x(e),p(null),m("");await ni.post("/offerte/roster/move-player",{giocatoreId:e,targetRoster:r,squadraId:n,legaId:o},s);m(`Giocatore spostato con successo in Roster ${r}`),await b()}catch(a){var t,i;p((null===(t=a.response)||void 0===t||null===(i=t.data)||void 0===i?void 0:i.error)||"Errore nello spostamento del giocatore"),console.error("Errore move player:",a)}finally{x(null)}};if(!("admin"===a||"superadmin"===a||"subadmin"===a||"Admin"===a||"SuperAdmin"===a||"SubAdmin"===a))return(0,gt.jsxs)(Bh,{children:[(0,gt.jsx)(Gh,{children:"\ud83d\udeab Accesso Negato"}),(0,gt.jsx)("p",{children:"Non hai i permessi per gestire i roster A/B."})]});if(c)return(0,gt.jsxs)(Bh,{children:[(0,gt.jsx)(Gh,{children:"\ud83d\udcca Gestione Roster A/B"}),(0,gt.jsx)(rm,{children:"Caricamento dati roster..."})]});if(g)return(0,gt.jsxs)(Bh,{children:[(0,gt.jsx)(Gh,{children:"\ud83d\udcca Gestione Roster A/B"}),(0,gt.jsx)(im,{children:g}),(0,gt.jsx)(em,{onClick:b,children:"Riprova"})]});if(!l)return(0,gt.jsxs)(Bh,{children:[(0,gt.jsx)(Gh,{children:"\ud83d\udcca Gestione Roster A/B"}),(0,gt.jsx)(tm,{children:"Nessun dato roster disponibile"})]});const y=[...(l.rosterA||[]).map(e=>({...e,currentRoster:"A"})),...(l.rosterB||[]).map(e=>({...e,currentRoster:"B"}))];return(0,gt.jsxs)(Bh,{children:[(0,gt.jsx)(Gh,{children:"\ud83d\udcca Gestione Roster A/B"}),h&&(0,gt.jsx)(nm,{children:h}),g&&(0,gt.jsx)(im,{children:g}),(0,gt.jsxs)(Wh,{children:[(0,gt.jsxs)(Hh,{$variant:"rosterA",children:[(0,gt.jsx)(Vh,{$variant:"rosterA",children:(null===(t=l.rosterA)||void 0===t?void 0:t.length)||0}),(0,gt.jsx)(Qh,{children:"Roster A (Attivi)"})]}),(0,gt.jsxs)(Hh,{$variant:"rosterB",children:[(0,gt.jsx)(Vh,{$variant:"rosterB",children:(null===(i=l.rosterB)||void 0===i?void 0:i.length)||0}),(0,gt.jsx)(Qh,{children:"Roster B (Inattivi)"})]}),(0,gt.jsxs)(Hh,{children:[(0,gt.jsx)(Vh,{children:l.total||0}),(0,gt.jsx)(Qh,{children:"Totale Giocatori"})]})]}),(0,gt.jsx)("div",{style:{overflowX:"auto"},children:(0,gt.jsxs)(Kh,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Yh,{children:"Giocatore"}),(0,gt.jsx)(Yh,{children:"Ruolo"}),(0,gt.jsx)(Yh,{children:"Roster"}),(0,gt.jsx)(Yh,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:y.length>0?y.map(e=>(0,gt.jsxs)(Zh,{children:[(0,gt.jsx)(Jh,{children:(0,gt.jsxs)("strong",{children:[e.nome," ",e.cognome||""]})}),(0,gt.jsx)(Jh,{children:e.ruolo}),(0,gt.jsx)(Jh,{children:(0,gt.jsx)(Xh,{className:`roster${e.currentRoster}`,children:e.currentRoster})}),(0,gt.jsx)(Jh,{children:"A"===e.currentRoster?(0,gt.jsx)(em,{$variant:"moveToB",$disabled:f===e.id,onClick:()=>j(e.id,"B"),children:f===e.id?"...":"\u2192 B"}):(0,gt.jsx)(em,{$variant:"moveToA",$disabled:f===e.id,onClick:()=>j(e.id,"A"),children:f===e.id?"...":"\u2192 A"})})]},e.id)):(0,gt.jsx)("tr",{children:(0,gt.jsx)("td",{colSpan:"4",style:{textAlign:"center",padding:"2rem",color:"#64748b"},children:"Nessun giocatore trovato"})})})]})}),0===y.length&&(0,gt.jsx)(tm,{children:"Nessun giocatore trovato in questa squadra"})]},`roster-manager-${n}`)},am=Ie.div`
  min-height: 100vh;
  background: #f8fafc;
  padding: 1.5rem;
`,sm=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
`,lm=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #e2e8f0;
`,dm=Ie.h1`
  color: #1e293b;
  margin: 0 0 0.5rem 0;
  font-size: 2rem;
  font-weight: 600;
`,cm=Ie.p`
  color: #64748b;
  font-size: 1rem;
  margin: 0;
`,um=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 0.75rem;
  margin-bottom: 1.5rem;
`,gm=Ie.div`
  background: white;
  border-radius: 8px;
  padding: 1rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #e2e8f0;
  text-align: center;
`,pm=Ie.div`
  font-size: 1.75rem;
  font-weight: 700;
  color: ${e=>e.$color||"#3b82f6"};
  margin-bottom: 0.25rem;
`,hm=Ie.div`
  font-size: 0.8rem;
  color: #64748b;
  font-weight: 500;
`,mm=Ie.div`
  display: grid;
  grid-template-columns: 1fr 350px;
  gap: 1rem;
  
  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
`,fm=Ie.div`
  background: white;
  border-radius: 8px;
  padding: 1rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #e2e8f0;
`,xm=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 0.75rem;
  border-bottom: 1px solid #e2e8f0;
`,vm=Ie.h3`
  color: #1e293b;
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,bm=Ie.span`
  background: ${e=>e.$color||"#3b82f6"};
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 500;
`,jm=Ie.table`
  width: 100%;
  border-collapse: collapse;
`,ym=Ie.th`
  background: #f8fafc;
  padding: 0.5rem;
  text-align: left;
  font-weight: 600;
  color: #475569;
  border-bottom: 1px solid #e2e8f0;
  font-size: 0.8rem;
`,wm=Ie.td`
  padding: 0.5rem;
  border-bottom: 1px solid #f1f5f9;
  color: #1e293b;
  vertical-align: middle;
`,km=Ie.tr`
  transition: background-color 0.2s ease;
  
  &:hover {
    background: #f8fafc;
  }
`,_m=Ie.span`
  background: ${e=>e.$public?"#10b981":"#6b7280"};
  color: white;
  padding: 0.25rem 0.5rem;
  border-radius: 6px;
  font-size: 0.75rem;
  font-weight: 500;
`,Sm=Ie.button`
  background: ${e=>{switch(e.$variant){case"primary":return"#3b82f6";case"success":return"#10b981";case"warning":return"#f59e0b";case"info":return"#06b6d4";case"danger":return"#ef4444";default:return"#6b7280"}}};
  color: white;
  border: none;
  padding: 0.4rem 0.6rem;
  border-radius: 4px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 0.7rem;
  
  &:hover {
    filter: brightness(0.9);
  }
`,Cm=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,zm=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 600px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
`,Em=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #e2e8f0;
`,Am=Ie.h2`
  color: #1e293b;
  margin: 0;
  font-size: 1.5rem;
  font-weight: 600;
`,Rm=Ie.button`
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #64748b;
  padding: 0.5rem;
  
  &:hover {
    color: #1e293b;
  }
`,Nm=Ie.div`
  background: ${e=>e.$answered?"#f8fafc":"white"};
  border: 1px solid ${e=>e.$answered?"#e2e8f0":"#d1d5db"};
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: ${e=>e.$answered?"#f1f5f9":"#f8fafc"};
  }
`,Tm=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
`,qm=Ie.h4`
  color: ${e=>e.$color||"#1e293b"};
  margin: 0;
  font-size: 1rem;
  font-weight: 600;
`,Pm=Ie.span`
  background: ${e=>e.$color};
  color: white;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 500;
`,$m=Ie.div`
  color: #64748b;
  font-size: 0.875rem;
  margin-bottom: 0.5rem;
`,Im=Ie.div`
  color: #374151;
  font-size: 0.875rem;
  margin-top: 0.5rem;
  padding: 0.5rem;
  background: #f8fafc;
  border-radius: 4px;
`,Om=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
`,Lm=Ie.button`
  background: ${e=>e.$active?"#3b82f6":"white"};
  color: ${e=>e.$active?"white":"#374151"};
  border: 1px solid ${e=>e.$active?"#3b82f6":"#d1d5db"};
  padding: 0.5rem 1rem;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 500;
  
  &:hover {
    background: ${e=>e.$active?"#2563eb":"#f8fafc"};
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,Mm=Ie.div`
  margin-top: 1rem;
`,Dm=Ie.textarea`
  width: 100%;
  min-height: 100px;
  padding: 0.75rem;
  border: 1px solid #d1d5db;
  border-radius: 4px;
  font-family: inherit;
  font-size: 0.875rem;
  resize: vertical;
  
  &:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }
`,Fm=Ie.div`
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
  justify-content: flex-end;
`,Um=(Ie.button`
  background: #3b82f6;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 6px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    background: #2563eb;
  }
`,Ie.div`
  text-align: center;
  font-size: 1rem;
  color: #64748b;
  margin: 3rem 0;
  padding: 2rem;
`),Bm=Ie.div`
  text-align: center;
  margin: 1.5rem 0;
  padding: 1.5rem;
`,Gm=Ie.div`
  font-size: 2.5rem;
  margin-bottom: 0.75rem;
  color: #cbd5e1;
`,Wm=Ie.h3`
  color: #1e293b;
  margin: 0 0 0.5rem 0;
  font-weight: 600;
  font-size: 1rem;
`,Hm=Ie.p`
  color: #64748b;
  margin: 0 0 1rem 0;
  font-size: 0.875rem;
`,Vm=Ie.button`
  background: #3b82f6;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 0.875rem;
  
  &:hover {
    background: #2563eb;
  }
`,Qm=(Ie.div`
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  padding: 0.75rem;
  margin-bottom: 0.5rem;
  transition: all 0.2s ease;
  
  &:hover {
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  }
`,Ie.div`
  background: #ecfdf5;
  color: #065f46;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  border: 1px solid #a7f3d0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,()=>{var e;const{user:t,token:i}=Si(),n=qr(),{showNotification:o}=zi(),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)({}),[g,p]=(0,r.useState)(!0),[h,m]=(0,r.useState)(!1),[f,x]=(0,r.useState)(!1),[v,b]=(0,r.useState)(null),[j,y]=(0,r.useState)(""),[w,k]=(0,r.useState)(!1),[_,S]=(0,r.useState)(1),[C]=(0,r.useState)(5),[z,E]=(0,r.useState)([]),A=(0,r.useCallback)(async()=>{try{var e,r;p(!0),console.log("\ud83d\udd0d Loading admin leghe for user:",null===t||void 0===t?void 0:t.id,null===t||void 0===t?void 0:t.username);const n=await No(i);console.log("\ud83d\udd0d Leghe data received:",n);const o=(null===n||void 0===n||null===(e=n.data)||void 0===e?void 0:e.leghe)||(null===n||void 0===n?void 0:n.leghe)||[];console.log("\ud83d\udd0d Leghe array:",o),s(o);const a=await ni.get("/leghe/richieste/admin",i);console.log("Richieste ricevute:",a),console.log("Richieste data type:",typeof a),console.log("Richieste keys:",Object.keys(a||{}));const l=(null===a||void 0===a||null===(r=a.data)||void 0===r?void 0:r.richieste)||(null===a||void 0===a?void 0:a.richieste)||[];Array.isArray(l)?(l.forEach((e,r)=>{"admin"===e.tipo_richiesta&&console.log(`Richiesta admin ${r}:`,{id:null===e||void 0===e?void 0:e.id,lega_id:null===e||void 0===e?void 0:e.lega_id,lega_nome:null===e||void 0===e?void 0:e.lega_nome,squadra_nome:null===e||void 0===e?void 0:e.squadra_nome})}),d(l)):(console.warn("Richieste non trovate o formato non valido:",a),d([]));const c={};o&&null!==o&&void 0!==o&&o.length&&await Promise.all(null===o||void 0===o?void 0:o.map(async e=>{try{const r=await Di(e.id,i);c[e.id]=(r.changes||[]).length}catch(xE){c[e.id]=0}})),u(c)}catch(n){console.error("Errore caricamento dati admin:",n)}finally{p(!1)}},[i]);(0,r.useEffect)(()=>{i&&A()},[i]),(0,r.useEffect)(()=>{E(l.slice(0,3))},[l]);const R=async(e,r)=>{try{let n;var t;if(k(!0),"unione_squadra"===e.tipo_richiesta)n=await ni.post(`/squadre/richieste-unione/${e.id}/rispondi`,{risposta:r,messaggio:j},i);else n=await ni.post(`/richieste-admin/${e.id}/gestisci`,{azione:"accetta"===r?"accepted":"rejected",note_admin:j,valore_costo:(null===(t=e.dati_richiesta)||void 0===t?void 0:t.valore_costo)||0},i);n.ok?(o?o(`Richiesta ${"accetta"===r?"accettata":"rifiutata"} con successo!`,"success"):console.log("showNotification non disponibile"),await A(),x(!1),b(null),y("")):o?o("Errore durante la gestione della richiesta","error"):console.error("showNotification non disponibile")}catch(n){console.error("Errore gestione richiesta admin:",n),o?o("Errore durante la gestione della richiesta","error"):console.error("showNotification non disponibile")}finally{k(!1)}},N=e=>{b(e),y(""),x(!0)},T=e=>"unione_squadra"===e.tipo_richiesta?"accettata"===e.stato?{text:"Richiesta Accettata",color:"#10b981"}:"rifiutata"===e.stato?{text:"Richiesta Rifiutata",color:"#ef4444"}:{text:"In Attesa",color:"#6b7280"}:"accepted"===e.stato?{text:"Richiesta Confermata",color:"#10b981"}:"rejected"===e.stato?{text:"Richiesta Rifiutata",color:"#ef4444"}:"revision"===e.stato?{text:"In Revisione",color:"#f59e0b"}:{text:"In Attesa",color:"#6b7280"},q=e=>"In Attesa"===T(e).text?"#1e293b":"#9ca3af",P=e=>e?new Date(e).toLocaleString("it-IT",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"}):"N/A",$=e=>{if(!e)return"N/A";return{club_level:"Club Level",acquisto_giocatore:"Acquisto Giocatore",vendita_giocatore:"Vendita Giocatore",scambio_giocatori:"Scambio Giocatori",trasferimento_giocatore:"Trasferimento Giocatore",modifica_roster:"Modifica Roster",richiesta_ingresso:"Richiesta Ingresso",richiesta_admin:"Richiesta Admin",admin:"Richiesta Admin",user:"Richiesta Ingresso",unione_squadra:"Richiesta Unione Squadra",ingresso:"Richiesta Ingresso"}[e]||e.replace(/_/g," ").replace(/\b\w/g,e=>e.toUpperCase())},I=e=>{if(!e)return null;try{const i="string"===typeof e?JSON.parse(e):e,n=[];if(void 0!==i.nuovo_club_level&&n.push(`Nuovo Club Level: ${i.nuovo_club_level}`),i.giocatore_nome&&n.push(`Giocatore: ${i.giocatore_nome}`),i.squadra_destinatario&&n.push(`Squadra Destinatario: ${i.squadra_destinatario}`),void 0!==i.valore_costo&&n.push(`Valore: ${i.valore_costo} FM`),i.squadra_mittente&&n.push(`Squadra Mittente: ${i.squadra_mittente}`),i.giocatore_offerto&&n.push(`Giocatore Offerto: ${i.giocatore_offerto}`),i.giocatore_richiesto&&n.push(`Giocatore Richiesto: ${i.giocatore_richiesto}`),i.motivo&&n.push(`Motivo: ${i.motivo}`),i.costi_dimezzati&&"object"===typeof i.costi_dimezzati){const e=Object.entries(i.costi_dimezzati);var r,t;if(null!==e&&void 0!==e&&e.length)if(n.push(`Giocatori Selezionati: ${i.giocatori_selezionati&&(null===(r=i.giocatori_selezionati)||void 0===r?void 0:r.length)||0}`),n.push(`Costi Dimezzati: ${(null===e||void 0===e?void 0:e.length)||0} giocatori`),i.dettagli_giocatori&&"object"===typeof i.dettagli_giocatori)Object.entries(i.dettagli_giocatori).forEach(e=>{let[r,t]=e;n.push(`  \u2022 ${(null===t||void 0===t?void 0:t.nome)||"Nome"} ${(null===t||void 0===t?void 0:t.cognome)||""} (${(null===t||void 0===t?void 0:t.ruolo)||"Ruolo"})`),n.push(`    Squadra Reale: ${t.squadra_reale}`),n.push(`    QA: ${(null===t||void 0===t?void 0:t.qa)||0}`),n.push(`    QI: ${t.qi}`),n.push(`    Ingaggio Attuale: ${t.costo_attuale} FM`),n.push(`    Ingaggio Cantera: ${t.costo_dimezzato} FM`)});else if(i.giocatori_selezionati&&Array.isArray(i.giocatori_selezionati))null===(t=i.giocatori_selezionati)||void 0===t||t.forEach((e,r)=>{const t=i.costi_dimezzati[e];void 0!==t&&n.push(`  \u2022 Giocatore ${r+1}: ${t} FM`)})}return 0===((null===n||void 0===n?void 0:n.length)||0)&&Object.entries(i).forEach(e=>{let[r,t]=e;const i=r.replace(/_/g," ").replace(/\b\w/g,e=>e.toUpperCase());"object"===typeof t&&null!==t?n.push(`${i}: ${JSON.stringify(t)}`):n.push(`${i}: ${t}`)}),n}catch(i){return console.error("Errore parsing dettagli richiesta:",i),[`Dettagli: ${e}`]}},O=(null===a||void 0===a?void 0:a.length)||0,L=null===a||void 0===a?void 0:a.reduce((e,r)=>e+(r.squadre_assegnate||0),0),M=(null===l||void 0===l?void 0:l.length)||0;return g?(0,gt.jsx)(am,{children:(0,gt.jsx)(sm,{children:(0,gt.jsx)(Um,{children:"Caricamento dashboard admin..."})})}):(0,gt.jsxs)(am,{children:[(0,gt.jsxs)(sm,{children:[(0,gt.jsxs)(lm,{children:[(0,gt.jsx)(dm,{children:"Dashboard Admin"}),(0,gt.jsx)(cm,{children:"Gestisci le tue leghe e monitora le attivit\xe0"})]}),(0,gt.jsxs)(um,{children:[(0,gt.jsxs)(gm,{children:[(0,gt.jsx)(pm,{$color:"#3b82f6",children:O}),(0,gt.jsx)(hm,{children:"Leghe Gestite"})]}),(0,gt.jsxs)(gm,{children:[(0,gt.jsx)(pm,{$color:"#10b981",children:L}),(0,gt.jsx)(hm,{children:"Squadre Assegnate"})]}),(0,gt.jsxs)(gm,{children:[(0,gt.jsx)(pm,{$color:"#f59e0b",children:null===a||void 0===a?void 0:a.reduce((e,r)=>e+(r.numero_tornei||0),0)}),(0,gt.jsx)(hm,{children:"Tornei Totali"})]}),(0,gt.jsxs)(gm,{children:[(0,gt.jsx)(pm,{$color:"#ef4444",children:M}),(0,gt.jsx)(hm,{children:"Richieste in Attesa"})]})]}),(0,gt.jsxs)(mm,{children:[(0,gt.jsxs)(fm,{children:[(0,gt.jsx)(xm,{children:(0,gt.jsxs)(vm,{children:["Le tue Leghe",(0,gt.jsx)(bm,{$color:"#3b82f6",children:O})]})}),0===((null===a||void 0===a?void 0:a.length)||0)?(0,gt.jsxs)(Bm,{children:[(0,gt.jsx)(Gm,{children:"\ud83c\udfc6"}),(0,gt.jsx)(Wm,{children:"Nessuna lega amministrata"}),(0,gt.jsx)(Hm,{children:"Non hai ancora creato o amministrato nessuna lega."}),(0,gt.jsx)(Vm,{onClick:()=>n("/crea-lega"),children:"Crea la tua prima lega"})]}):(0,gt.jsxs)(jm,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(ym,{children:"Nome Lega"}),(0,gt.jsx)(ym,{children:"Squadre"}),(0,gt.jsx)(ym,{children:"Tornei"}),(0,gt.jsx)(ym,{children:"Tipo"}),(0,gt.jsx)(ym,{children:"Data Creazione"}),(0,gt.jsx)(ym,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:null===a||void 0===a?void 0:a.map(e=>(0,gt.jsxs)(km,{children:[(0,gt.jsx)(wm,{children:(0,gt.jsx)("div",{style:{fontWeight:"700",color:"#f59e0b",fontSize:"0.875rem",cursor:"pointer",transition:"color 0.2s ease"},onClick:()=>n(`/lega/${e.id}`),onMouseEnter:e=>e.target.style.color="#d97706",onMouseLeave:e=>e.target.style.color="#f59e0b",children:(null===e||void 0===e?void 0:e.nome)||"Nome"})}),(0,gt.jsx)(wm,{children:(0,gt.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"0.25rem"},children:[(0,gt.jsx)("span",{style:{fontWeight:"600",color:"#10b981",fontSize:"0.8rem"},children:e.squadre_assegnate||0}),(0,gt.jsx)("span",{style:{color:"#64748b",fontSize:"0.8rem"},children:"/"}),(0,gt.jsx)("span",{style:{color:"#64748b",fontSize:"0.8rem"},children:e.numero_squadre_totali||0})]})}),(0,gt.jsx)(wm,{children:(0,gt.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"0.25rem"},children:[(0,gt.jsx)("span",{style:{fontWeight:"600",color:"#f59e0b",fontSize:"0.8rem"},children:e.numero_tornei||0}),(0,gt.jsx)("span",{style:{fontSize:"0.7rem",color:"#64748b"},children:1===(e.numero_tornei||0)?"torneo":"tornei"})]})}),(0,gt.jsx)(wm,{children:(0,gt.jsx)(_m,{$public:(null===e||void 0===e?void 0:e.is_pubblica)||!1,children:null!==e&&void 0!==e&&e.is_pubblica?"Pubblica":"Privata"})}),(0,gt.jsx)(wm,{children:(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#64748b"},children:e.data_creazione_formattata||"N/A"})}),(0,gt.jsx)(wm,{children:(0,gt.jsxs)("div",{style:{display:"flex",flexWrap:"wrap",gap:"0.5rem"},children:[(0,gt.jsx)(Sm,{$variant:"success",onClick:()=>{return r=e.id,void n(`/gestione-tornei/${r}`);var r},children:"Tornei"}),(0,gt.jsxs)(Sm,{$variant:"warning",onClick:()=>(async e=>{n(`/league-admin/${e}`)})(e.id),style:{position:"relative"},children:["Subadmin",c[e.id]>0&&(0,gt.jsx)("span",{style:{position:"absolute",top:"-5px",right:"-5px",background:"#ff3b30",color:"white",borderRadius:"50%",width:"16px",height:"16px",display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:"0.6rem",fontWeight:"600",border:"2px solid white"},children:c[e.id]>9?"9+":c[e.id]})]}),(0,gt.jsx)(Sm,{$variant:"info",onClick:()=>{return r=e.id,void n(`/scraping-manager/${r}`);var r},children:"Sync"}),(0,gt.jsx)(Sm,{$variant:"primary",onClick:()=>n(`/gestione-richieste-admin/${e.id}`),children:"Richieste Admin"}),(0,gt.jsx)(Sm,{$variant:"danger",onClick:()=>n(`/modifica-lega/${e.id}`),children:"Modifica"})]})})]},e.id))})]})]}),(0,gt.jsxs)(fm,{children:[(0,gt.jsx)(xm,{children:(0,gt.jsxs)(vm,{children:["\ud83d\udccb Richieste Admin",(0,gt.jsx)(bm,{$color:"#ef4444",children:M})]})}),0===((null===l||void 0===l?void 0:l.length)||0)?(0,gt.jsxs)(Bm,{children:[(0,gt.jsx)(Gm,{children:"\ud83d\udced"}),(0,gt.jsx)(Wm,{children:"Nessuna richiesta"}),(0,gt.jsx)(Hm,{children:"Non ci sono richieste admin in attesa."})]}):(0,gt.jsxs)("div",{children:[null===z||void 0===z?void 0:z.map(e=>{var r;const t=T(e),i="pending"!==e.stato;return(0,gt.jsxs)(Nm,{$answered:i,onClick:()=>N(e),children:[(0,gt.jsxs)(Tm,{children:[(0,gt.jsx)(qm,{$color:q(e),children:"admin"===e.tipo_richiesta?"Richiesta Admin":"Richiesta Ingresso"}),(0,gt.jsx)(Pm,{$color:t.color,children:t.text})]}),(0,gt.jsxs)($m,{children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Lega:"})," ",e.lega_nome]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Squadra:"})," ",e.squadra_nome]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Utente:"})," ",e.utente_nome||(e.richiedente_nome&&e.richiedente_cognome?`${e.richiedente_nome} ${e.richiedente_cognome}`.trim():e.richiedente_nome||e.richiedente_username||"N/A")]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Email:"})," ",e.utente_email||e.richiedente_email||"N/A"]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Data:"})," ",P(e.data_creazione||e.data_richiesta)]}),e.tipo_richiesta_richiesta&&(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Tipo Richiesta:"})," ",$(e.tipo_richiesta_richiesta)]})]}),e.messaggio&&(0,gt.jsxs)(Im,{children:[(0,gt.jsx)("strong",{children:"Messaggio:"})," ",e.messaggio]}),e.dati_richiesta&&(0,gt.jsxs)(Im,{children:[(0,gt.jsx)("strong",{children:"Dettagli Richiesta:"}),(0,gt.jsx)("div",{style:{marginTop:"0.5rem"},children:null===(r=I(e.dati_richiesta))||void 0===r?void 0:r.map((e,r)=>(0,gt.jsx)("div",{style:{fontSize:"0.85rem",color:"#374151",marginBottom:"0.25rem"},children:e},r))})]})]},e.id)}),(null===l||void 0===l?void 0:l.length)||!1]})]}),(0,gt.jsxs)(fm,{children:[(0,gt.jsx)(xm,{children:(0,gt.jsxs)(vm,{children:["\ud83d\udcca Gestione Roster A/B",(0,gt.jsx)(bm,{$color:"#3b82f6",children:"Admin Only"})]})}),(0,gt.jsxs)("div",{style:{marginBottom:"1rem"},children:[(0,gt.jsx)("p",{style:{fontSize:"0.9rem",color:"#64748b",marginBottom:"1rem"},children:"Seleziona una squadra per gestire i roster A/B. Solo admin, superadmin e subadmin possono modificare i roster."}),(0,gt.jsx)("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(300px, 1fr))",gap:"1rem"},children:null===a||void 0===a?void 0:a.map(e=>(0,gt.jsxs)("div",{style:{background:"#f8fafc",border:"1px solid #e2e8f0",borderRadius:"8px",padding:"1rem",cursor:"pointer",transition:"all 0.2s ease"},onClick:()=>n(`/gestione-roster-admin/${e.id}`),onMouseEnter:e=>e.target.style.background="#f1f5f9",onMouseLeave:e=>e.target.style.background="#f8fafc",children:[(0,gt.jsx)("div",{style:{fontWeight:"600",color:"#1e293b",marginBottom:"0.5rem"},children:(null===e||void 0===e?void 0:e.nome)||"Nome"}),(0,gt.jsxs)("div",{style:{fontSize:"0.8rem",color:"#64748b"},children:[e.squadre_assegnate||0," squadre \u2022 ",e.numero_tornei||0," tornei"]}),(0,gt.jsx)("div",{style:{fontSize:"0.75rem",color:"#3b82f6",marginTop:"0.5rem"},children:"\ud83d\udc46 Clicca per gestire roster"})]},e.id))})]})]})]})]}),h&&(0,gt.jsx)(Cm,{onClick:()=>m(!1),children:(0,gt.jsxs)(zm,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(Em,{children:[(0,gt.jsx)(Am,{children:"Tutte le Richieste Admin"}),(0,gt.jsx)(Rm,{onClick:()=>m(!1),children:"\u2715"})]}),(0,gt.jsxs)("div",{children:[(()=>{const e=(_-1)*C,r=e+C;return l.slice(e,r)})().map(e=>{var r;const t=T(e),i="pending"!==e.stato;return(0,gt.jsxs)(Nm,{$answered:i,onClick:()=>N(e),children:[(0,gt.jsxs)(Tm,{children:[(0,gt.jsx)(qm,{$color:q(e),children:"admin"===e.tipo_richiesta?"Richiesta Admin":"Richiesta Ingresso"}),(0,gt.jsx)(Pm,{$color:t.color,children:t.text})]}),(0,gt.jsxs)($m,{children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Lega:"})," ",e.lega_nome]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Squadra:"})," ",e.squadra_nome]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Utente:"})," ",e.utente_nome||"N/A"]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Email:"})," ",e.utente_email||"N/A"]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Data:"})," ",P(e.data_creazione||e.data_richiesta)]}),e.tipo_richiesta_richiesta&&(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Tipo Richiesta:"})," ",$(e.tipo_richiesta_richiesta)]})]}),e.messaggio&&(0,gt.jsxs)(Im,{children:[(0,gt.jsx)("strong",{children:"Messaggio:"})," ",e.messaggio]}),e.dati_richiesta&&(0,gt.jsxs)(Im,{children:[(0,gt.jsx)("strong",{children:"Dettagli Richiesta:"}),(0,gt.jsx)("div",{style:{marginTop:"0.5rem"},children:null===(r=I(e.dati_richiesta))||void 0===r?void 0:r.map((e,r)=>(0,gt.jsx)("div",{style:{fontSize:"0.85rem",color:"#374151",marginBottom:"0.25rem"},children:e},r))})]})]},e.id)}),(null===l||void 0===l?void 0:l.length)||0>C&&(0,gt.jsxs)(Om,{children:[(0,gt.jsx)(Lm,{onClick:()=>S(e=>Math.max(1,e-1)),disabled:1===_,children:"\u2190 Precedente"}),(0,gt.jsxs)("span",{style:{color:"#64748b",fontSize:"0.875rem"},children:["Pagina ",_," di ",Math.ceil((null===l||void 0===l?void 0:l.length)||0/C)]}),(0,gt.jsx)(Lm,{onClick:()=>S(e=>Math.min(Math.ceil((null===l||void 0===l?void 0:l.length)||0/C),e+1)),disabled:_===Math.ceil((null===l||void 0===l?void 0:l.length)||0/C),children:"Successiva \u2192"})]})]})]})}),f&&v&&(0,gt.jsx)(Cm,{onClick:()=>x(!1),children:(0,gt.jsxs)(zm,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(Em,{children:[(0,gt.jsx)(Am,{children:"Gestisci Richiesta Admin"}),(0,gt.jsx)(Rm,{onClick:()=>x(!1),children:"\u2715"})]}),(0,gt.jsxs)("div",{children:[(0,gt.jsxs)(Nm,{$answered:!1,children:[(0,gt.jsxs)(Tm,{children:[(0,gt.jsx)(qm,{children:"admin"===v.tipo_richiesta?"Richiesta Admin":"Richiesta Ingresso"}),(0,gt.jsx)(Pm,{$color:"#6b7280",children:"In Attesa"})]}),(0,gt.jsxs)($m,{children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Lega:"})," ",v.lega_nome]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Squadra:"})," ",v.squadra_nome]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Utente:"})," ",v.utente_nome||(v.richiedente_nome&&v.richiedente_cognome?`${v.richiedente_nome} ${v.richiedente_cognome}`.trim():v.richiedente_nome||v.richiedente_username||"N/A")]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Email:"})," ",v.utente_email||v.richiedente_email||"N/A"]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Data:"})," ",P(v.data_creazione||v.data_richiesta)]}),v.tipo_richiesta_richiesta&&(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Tipo Richiesta:"})," ",$(v.tipo_richiesta_richiesta)]})]}),v.messaggio&&(0,gt.jsxs)(Im,{children:[(0,gt.jsx)("strong",{children:"Messaggio:"})," ",v.messaggio]}),v.dati_richiesta&&(0,gt.jsxs)(Im,{children:[(0,gt.jsx)("strong",{children:"Dettagli Richiesta:"}),(0,gt.jsx)("div",{style:{marginTop:"0.5rem"},children:null===(e=I(v.dati_richiesta))||void 0===e?void 0:e.map((e,r)=>(0,gt.jsx)("div",{style:{fontSize:"0.85rem",color:"#374151",marginBottom:"0.25rem"},children:e},r))})]})]}),(0,gt.jsxs)(Mm,{children:[(0,gt.jsx)("label",{style:{display:"block",marginBottom:"0.5rem",fontWeight:"500",color:"#374151"},children:"Messaggio di risposta (opzionale):"}),(0,gt.jsx)(Dm,{value:j,onChange:e=>y(e.target.value),placeholder:"Inserisci un messaggio per l'utente..."})]}),(0,gt.jsxs)(Fm,{children:[(0,gt.jsx)(Sm,{$variant:"danger",onClick:()=>R(v,"rifiuta"),disabled:w,children:w?"Elaborazione...":"Rifiuta"}),(0,gt.jsx)(Sm,{$variant:"success",onClick:()=>R(v,"accetta"),disabled:w,children:w?"Elaborazione...":"Accetta"})]})]})]})})]})});const Km=async e=>ni.get("/notifiche",e),Ym=Ie.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 2rem;
`,Jm=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,Zm=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
`,Xm=Ie.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`,ef=Ie.h1`
  color: #333;
  margin: 0;
  font-size: 2rem;
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,rf=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border: 1px solid #f0f0f0;
`,tf=Ie.table`
  width: 100%;
  border-collapse: collapse;
`,nf=Ie.th`
  background: #5856d6;
  color: white;
  padding: 0.75rem 0.5rem;
  text-align: left;
  font-weight: 600;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  
  &:first-child {
    border-top-left-radius: 8px;
  }
  
  &:last-child {
    border-top-right-radius: 8px;
  }
`,of=Ie.td`
  padding: 1rem 0.5rem;
  border-bottom: 1px solid #dee2e6;
  color: #333;
  vertical-align: middle;
`,af=(Ie.div`
  font-weight: 600;
  color: #333;
  font-size: 1rem;
`,Ie.div`
  color: #666;
  font-size: 0.9rem;
  font-weight: 500;
`,Ie.button`
  background: linear-gradient(135deg, #007AFF 0%, #0056b3 100%);
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  font-size: 0.8rem;
  
  &:hover {
    transform: translateY(-1px);
  }
`),sf=Ie.tr`
  background: #f8f9fa;
`,lf=Ie.td`
  padding: 0;
  border-bottom: 1px solid #dee2e6;
`,df=Ie.div`
  padding: 1.5rem;
`,cf=(Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
`,Ie.div`
  text-align: center;
  padding: 1rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,Ie.div`
  color: #666;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 0.5rem;
`,Ie.div`
  color: #333;
  font-size: 1.1rem;
  font-weight: 600;
`,Ie.span`
  font-weight: 600;
  color: #28a745;
`),uf=(Ie.span`
  font-weight: 600;
  color: #dc3545;
`,Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 0.75rem;
  margin-bottom: 1.5rem;
`),gf=Ie.button`
  background: linear-gradient(135deg, #6f42c1 0%, #5a2d91 100%);
  color: white;
  border: none;
  padding: 0.75rem 0.5rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.75rem;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
`,pf=Ie.div`
  background: white;
  border-radius: 8px;
  padding: 1rem;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,hf=Ie.h4`
  color: #333;
  margin: 0 0 1rem 0;
  font-size: 1rem;
  font-weight: 600;
`,mf=Ie.div`
  padding: 0.5rem 0;
  border-bottom: 1px solid #eee;
  font-size: 0.9rem;
  color: #333;
  
  &:last-child {
    border-bottom: none;
  }
`,ff=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,xf=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,vf=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
  text-align: center;
`,bf=()=>{const{token:e,user:t}=Si(),i=qr(),[n,o]=(0,r.useState)([]),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)(!0),[g,p]=(0,r.useState)(""),[h,m]=(0,r.useState)(null);(0,r.useEffect)(()=>{e&&async function(){u(!0),p("");try{console.log("\ud83d\udd0d AreaManager: Starting fetchData"),console.log("\ud83d\udd0d AreaManager: Token available:",!!e),console.log("\ud83d\udd0d AreaManager: User ID:",null===t||void 0===t?void 0:t.id);const[r,i]=await Promise.all([bi(e,null===t||void 0===t?void 0:t.id),vi(e,null===t||void 0===t?void 0:t.id)]);console.log("\ud83d\udd0d AreaManager: Squadre response:",r),console.log("\ud83d\udd0d AreaManager: Notifiche response:",i);const n=(null===r||void 0===r?void 0:r.data)||r,a=(null===i||void 0===i?void 0:i.data)||i,l=(null===n||void 0===n?void 0:n.squadre)||[],c=(null===a||void 0===a?void 0:a.notifiche)||[];o(l),s(c),console.log("\ud83d\udd0d AreaManager: Squadre set:",(null===l||void 0===l?void 0:l.length)||0),console.log("\ud83d\udd0d AreaManager: Notifiche set:",(null===c||void 0===c?void 0:c.length)||0);const u=(null===l||void 0===l?void 0:l.map(r=>r&&null!==r&&void 0!==r&&r.lega_id?Gn(r.lega_id,e):(console.warn("\ud83d\udd0d AreaManager: Squadra o lega_id undefined, skipping"),Promise.resolve([]))))||[],g=(await Promise.all(u)).flatMap(e=>{var r;return(null===e||void 0===e||null===(r=e.data)||void 0===r?void 0:r.movimenti)||(null===e||void 0===e?void 0:e.movimenti)||[]});d(g),console.log("\ud83d\udd0d AreaManager: Movimenti loaded:",g.length)}catch(r){console.error("\u274c AreaManager: Error in fetchData:",r),p(r.message)}u(!1)}()},[e]);return c?(0,gt.jsx)(Ym,{children:(0,gt.jsx)(ff,{children:"Caricamento area manager..."})}):g?(0,gt.jsx)(Ym,{children:(0,gt.jsxs)(xf,{children:["Errore: ",g]})}):(0,gt.jsxs)(Ym,{children:[(0,gt.jsx)(Jm,{onClick:()=>i(-1),children:"\u2190 Torna indietro"}),(0,gt.jsx)(Zm,{children:(0,gt.jsx)(Xm,{children:(0,gt.jsx)(ef,{children:"\ud83d\udc51 Area Manager"})})}),0===n.length?(0,gt.jsx)(vf,{children:(0,gt.jsxs)("div",{children:[(0,gt.jsx)("h3",{children:"Nessuna squadra trovata"}),(0,gt.jsx)("p",{children:"Non hai ancora squadre assegnate. Unisciti a una lega per iniziare!"})]})}):(0,gt.jsx)(rf,{children:(0,gt.jsxs)(tf,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(nf,{children:"Squadra"}),(0,gt.jsx)(nf,{children:"Club Level"}),(0,gt.jsx)(nf,{children:"Torneo"}),(0,gt.jsx)(nf,{children:"Ingaggi"}),(0,gt.jsx)(nf,{children:"Crediti Residui"}),(0,gt.jsx)(nf,{children:"Valore Attuale"}),(0,gt.jsx)(nf,{children:"Giocatori"}),(0,gt.jsx)(nf,{children:" "})]})}),(0,gt.jsx)("tbody",{children:n.map(e=>{var t;if(!e)return console.warn("\ud83d\udd0d AreaManager: Squadra undefined, skipping"),null;const n=(o=null===e||void 0===e?void 0:e.lega_id,l.filter(e=>e.lega_id===o).sort((e,r)=>new Date(r.data)-new Date(e.data)).slice(0,5));var o;const s=(d=null===e||void 0===e?void 0:e.id,a.filter(e=>e.squadra_id===d).length);var d;const c=h===(null===e||void 0===e?void 0:e.id);let u=0,g=0,p=0;Array.isArray(null===e||void 0===e?void 0:e.giocatori)&&(null===e||void 0===e||null===(t=e.giocatori)||void 0===t?void 0:t.length)>0?(u=e.giocatori.reduce((e,r)=>e+(parseInt(null===r||void 0===r?void 0:r.quotazione_attuale)||0),0),g=e.giocatori.reduce((e,r)=>e+(parseInt(null===r||void 0===r?void 0:r.costo_attuale)||0),0),p=e.giocatori.length):"number"===typeof(null===e||void 0===e?void 0:e.numero_giocatori)&&(p=e.numero_giocatori);const f=(null===e||void 0===e?void 0:e.max_giocatori)||30,x=e.logo_url,v=e.torneo_nome||"N/A",b=(null===e||void 0===e?void 0:e.casse_societarie)||0;return(0,gt.jsxs)(r.Fragment,{children:[(0,gt.jsxs)("tr",{children:[(0,gt.jsxs)(of,{style:{display:"flex",alignItems:"center",gap:8},children:[x?(0,gt.jsx)("img",{src:`https://topleaguem.onrender.com/uploads/${x}`,alt:"logo",style:{width:32,height:32,borderRadius:"50%",objectFit:"cover",background:"#eee"}}):(0,gt.jsx)("img",{src:"data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjMyIiBoZWlnaHQ9IjMyIiByeD0iMTYiIGZpbGw9IiNGRkZGRkYiIHN0cm9rZT0iI0U1RTVFNyIgc3Ryb2tlLXdpZHRoPSIxIi8+CjxwYXRoIGQ9Ik0xNiA4QzE4LjIwOTEgOCAyMCA5Ljc5MDg2IDIwIDEyQzIwIDE0LjIwOTEgMTguMjA5MSAxNiAxNiAxNkMxMy43OTA5IDE2IDEyIDE0LjIwOTEgMTIgMTJDMTIgOS43OTA4NiAxMy43OTA5IDggMTYgOFoiIGZpbGw9IiM5OTk5OTkiLz4KPHBhdGggZD0iTTggMjRDMTAuMjA5MSAyNCAxMiAyMi4yMDkxIDEyIDIwQzEyIDE3Ljc5MDkgMTAuMjA5MSAxNiA4IDE2QzUuNzkwODYgMTYgNCAxNy43OTA5IDQgMjBDNCAyMi4yMDkxIDUuNzkwODYgMjQgOCAyNFoiIGZpbGw9IiM5OTk5OTkiLz4KPHBhdGggZD0iTTI0IDI0QzI2LjIwOTEgMjQgMjggMjIuMjA5MSAyOCAyMEMyOCAxNy43OTA5IDI2LjIwOTEgMTYgMjQgMTZDMjEuNzkwOSAxNiAyMCAxNy43OTA5IDIwIDIwQzIwIDIyLjIwOTEgMjEuNzkwOSAyNCAyNCAyNFoiIGZpbGw9IiM5OTk5OTkiLz4KPC9zdmc+",alt:"logo",style:{width:32,height:32,borderRadius:"50%",objectFit:"cover",background:"#eee"}}),(0,gt.jsx)("span",{style:{fontWeight:600,cursor:"pointer",color:"#FF8C42"},onClick:()=>i(`/gestione-squadra/${e.lega_id}`),children:e.nome})]}),(0,gt.jsx)(of,{children:e.club_level||1}),(0,gt.jsx)(of,{children:v}),(0,gt.jsxs)(of,{children:["FM ",g.toLocaleString()]}),(0,gt.jsx)(of,{children:(0,gt.jsxs)(cf,{children:[b.toLocaleString()||0," FM"]})}),(0,gt.jsxs)(of,{children:["FM ",u.toLocaleString()]}),(0,gt.jsxs)(of,{children:[p,"/",f]}),(0,gt.jsx)(of,{children:(0,gt.jsx)(af,{onClick:()=>(e=>{m(h===e?null:e)})(e.id),children:c?"Chiudi":"Gestisci"})})]}),c&&(0,gt.jsx)(sf,{children:(0,gt.jsx)(lf,{colSpan:"8",children:(0,gt.jsxs)(df,{children:[(0,gt.jsxs)(uf,{children:[(0,gt.jsx)(gf,{type:"visualizza",onClick:()=>i(`/gestione-squadra/${e.lega_id}`),children:"Visualizza"}),(0,gt.jsxs)(gf,{type:"notifiche",onClick:()=>i(`/notifiche?squadra=${e.id}`),children:["Notifiche (",s,")"]}),(0,gt.jsx)(gf,{type:"offerta",onClick:()=>i(`/proponi-offerta?squadra=${e.id}`),children:"Proponi Offerta"}),(0,gt.jsx)(gf,{type:"admin",onClick:()=>i(`/richiesta-admin?squadra=${e.id}`),children:"Richiesta Admin"}),(0,gt.jsx)(gf,{type:"log",onClick:()=>i(`/log-squadra/${e.id}`),children:"Log"})]}),(0,gt.jsxs)(pf,{children:[(0,gt.jsx)(hf,{children:"\ud83d\udce2 Ultime 5 Notifiche"}),0===a.filter(r=>r.squadra_id===e.id).slice(0,5).length?(0,gt.jsx)(mf,{children:"Nessuna notifica recente"}):a.filter(r=>r.squadra_id===e.id).slice(0,5).map((e,r)=>(0,gt.jsxs)(mf,{children:[e.titolo,": ",e.messaggio," - ",new Date(e.created_at).toLocaleDateString()]},r))]}),(0,gt.jsxs)(pf,{children:[(0,gt.jsx)(hf,{children:"\ud83d\udcc8 Ultimi 5 Movimenti di Mercato"}),0===n.length?(0,gt.jsx)(mf,{children:"Nessun movimento recente"}):n.map((e,r)=>{return(0,gt.jsxs)(mf,{children:[e.giocatore_nome," si \xe8 ","trasferimento"===e.tipo?"trasferito":"prestato"," da ",e.squadra_mittente," a ",e.squadra_destinataria," il ",new Date(e.data).toLocaleDateString()," per ",(t=e.valore,t?`FM ${t.toLocaleString()}`:"FM 0")]},r);var t})]})]})})})]},e.id)})})]})})]})},jf=Ie.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
`,yf=Ie.div`
  background: white;
  border-radius: 20px;
  padding: 40px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 400px;
  text-align: center;
`,wf=Ie.h1`
  color: #333;
  margin-bottom: 30px;
  font-size: 28px;
  font-weight: 600;
`,kf=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 20px;
`,_f=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,Sf=Ie.label`
  color: #666;
  font-size: 14px;
  font-weight: 500;
  text-align: left;
`,Cf=Ie.input`
  padding: 16px;
  border: 2px solid #e1e5e9;
  border-radius: 12px;
  font-size: 16px;
  transition: all 0.3s ease;
  background: #f8f9fa;
  
  &:focus {
    outline: none;
    border-color: #ff8c42;
    background: white;
    box-shadow: 0 0 0 3px rgba(255, 140, 66, 0.1);
  }
`,zf=Ie.button`
  background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
  color: white;
  border: none;
  padding: 16px;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 10px;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 20px rgba(255, 140, 66, 0.3);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,Ef=Ie.div`
  color: #e74c3c;
  background: #fdf2f2;
  padding: 12px;
  border-radius: 8px;
  font-size: 14px;
  margin-top: 10px;
`,Af=Ie.div`
  color: #27ae60;
  background: #f0f9f4;
  padding: 12px;
  border-radius: 8px;
  font-size: 14px;
  margin-top: 10px;
`,Rf=()=>{const[e,t]=(0,r.useState)({email:"",password:""}),[i,n]=(0,r.useState)(!1),[o,a]=(0,r.useState)(""),[s,l]=(0,r.useState)(""),d=qr(),c=r=>{t({...e,[r.target.name]:r.target.value})};return(0,gt.jsx)(jf,{children:(0,gt.jsxs)(yf,{children:[(0,gt.jsx)(wf,{children:"\ud83d\udd10 Accesso SuperAdmin"}),(0,gt.jsxs)(kf,{onSubmit:async r=>{r.preventDefault(),n(!0),a(""),l("");try{const r=await fetch("https://topleaguem.onrender.com/api/auth/superadmin-login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)}),t=r.data;r.ok?(l("Accesso effettuato con successo!"),localStorage.setItem("token",t.token),localStorage.setItem("userRole","SuperAdmin"),localStorage.setItem("userId",t.user.id),setTimeout(()=>{d("/superadmin-dashboard")},1e3)):a(t.message||"Errore durante l'accesso")}catch(t){a("Errore di connessione")}finally{n(!1)}},children:[(0,gt.jsxs)(_f,{children:[(0,gt.jsx)(Sf,{children:"Email"}),(0,gt.jsx)(Cf,{type:"email",name:"email",value:e.email,onChange:c,placeholder:"admin@topleague.com",required:!0})]}),(0,gt.jsxs)(_f,{children:[(0,gt.jsx)(Sf,{children:"Password"}),(0,gt.jsx)(Cf,{type:"password",name:"password",value:(null===e||void 0===e?void 0:e.password)||"",onChange:c,placeholder:"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",required:!0})]}),(0,gt.jsx)(zf,{type:"submit",disabled:i,children:i?"Accesso in corso...":"Accedi come SuperAdmin"})]}),o&&(0,gt.jsx)(Ef,{children:o}),s&&(0,gt.jsx)(Af,{children:s})]})})},Nf=Ie.div`
  padding: 2rem;
  max-width: 1400px;
  margin: 0 auto;
`,Tf=Ie.div`
  text-align: center;
  margin-bottom: 3rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 2rem;
  border-radius: 16px;
`,qf=Ie.h1`
  margin: 0 0 0.5rem 0;
  font-size: 2.5rem;
`,Pf=Ie.p`
  font-size: 1.1rem;
  margin: 0;
  opacity: 0.9;
`,$f=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-bottom: 3rem;
`,If=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  text-align: center;
`,Of=Ie.div`
  font-size: 2rem;
  font-weight: bold;
  color: #667eea;
  margin-bottom: 0.5rem;
`,Lf=Ie.div`
  color: #666;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,Mf=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
`,Df=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`,Ff=Ie.h2`
  color: #333;
  margin: 0 0 2rem 0;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Uf=Ie.div`
  overflow-x: auto;
`,Bf=Ie.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
`,Gf=Ie.th`
  background: #f8f9fa;
  padding: 1rem;
  text-align: left;
  font-weight: 600;
  color: #333;
  border-bottom: 2px solid #e9ecef;
`,Wf=Ie.td`
  padding: 1rem;
  border-bottom: 1px solid #e9ecef;
  vertical-align: middle;
`,Hf=Ie.tr`
  &:hover {
    background: #f8f9fa;
  }
`,Vf=Ie.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  margin: 0.25rem;
  font-size: 0.9rem;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &.danger {
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
  }
  
  &.success {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
  }
  
  &.warning {
    background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%);
    color: #212529;
  }
`,Qf=Ie.span`
  padding: 0.25rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  
  &.public {
    background: #d4edda;
    color: #155724;
  }
  
  &.private {
    background: #f8d7da;
    color: #721c24;
  }
`,Kf=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,Yf=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,Jf=Ie.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`,Zf=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,Xf=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 500px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
`,ex=Ie.h3`
  margin: 0 0 1.5rem 0;
  color: #333;
`,rx=Ie.div`
  margin-bottom: 1.5rem;
`,tx=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
`,ix=Ie.input`
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #e5e5e7;
  border-radius: 6px;
  font-size: 1rem;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`,nx=Ie.select`
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #e5e5e7;
  border-radius: 6px;
  font-size: 1rem;
  background: white;
  transition: border-color 0.3s;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`,ox=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-top: 0.5rem;
`,ax=Ie.label`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 6px;
  transition: background-color 0.2s;
  
  &:hover {
    background: #f8f9fa;
  }
  
  input[type="checkbox"] {
    width: 16px;
    height: 16px;
  }
`,sx=Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 2rem;
`,lx=(Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-top: 2rem;
`,Ie.div`
  background: #f8f9fa;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
  border-left: 4px solid #667eea;
`,Ie.span`
  background: #d4edda;
  color: #155724;
  padding: 0.2rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  margin-right: 0.5rem;
  margin-bottom: 0.5rem;
  display: inline-block;
`,()=>{const e=qr(),{token:t}=Si(),[i,n]=(0,r.useState)([]),[o,a]=(0,r.useState)([]),[s,l]=(0,r.useState)(!0),[d,c]=(0,r.useState)(""),[u,g]=(0,r.useState)(!1),[p,h]=(0,r.useState)(null),[m,f]=(0,r.useState)(""),[x,v]=(0,r.useState)(null),[b,j]=(0,r.useState)({modifica_squadre:!1,gestione_giocatori:!1,gestione_tornei:!1,modifica_impostazioni:!1,gestione_contratti:!1}),[y,w]=(0,r.useState)([]),[k,_]=(0,r.useState)(!1),[S,C]=(0,r.useState)(!1),[z,E]=(0,r.useState)(null),[A,R]=(0,r.useState)({username:"",email:"",ruolo:"Utente"});(0,r.useEffect)(()=>{t?async function(){if(l(!0),c(""),!t)return c("Token di autenticazione mancante. Effettua il login."),void l(!1);try{var e,r;console.log("\ud83d\udd0d SuperAdminDashboard: Starting fetchData"),console.log("\ud83d\udd0d SuperAdminDashboard: Token available:",!!t);const[o,s]=await Promise.all([To(t),Ii(t)]);console.log("\ud83d\udd0d SuperAdminDashboard: Leghe response:",o),console.log("\ud83d\udd0d SuperAdminDashboard: Subadmins response:",s);const l=(null===o||void 0===o||null===(e=o.data)||void 0===e?void 0:e.leghe)||(null===o||void 0===o?void 0:o.leghe)||[];n(l);const d=(null===s||void 0===s||null===(r=s.data)||void 0===r?void 0:r.subadmins)||(null===s||void 0===s?void 0:s.subadmins)||[];a(d),console.log("\ud83d\udd0d SuperAdminDashboard: Leghe set:",l.length),console.log("\ud83d\udd0d SuperAdminDashboard: Subadmins set:",d.length);try{const e=await ni.get("/auth/all-users",t),r=(null===e||void 0===e?void 0:e.users)||e||[];w(r),console.log("\ud83d\udd0d SuperAdminDashboard: Users loaded:",r.length)}catch(i){console.error("Errore caricamento utenti:",i),w([])}}catch(o){c(o.message)}l(!1)}():(l(!1),c("Effettua il login per accedere alla dashboard SuperAdmin"))},[t]);const N=e=>new Date(e).toLocaleDateString("it-IT",{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}),T=e=>{j(r=>({...r,[e]:!r[e]}))},q=e=>null===o||void 0===o?void 0:o.filter(r=>(null===r||void 0===r?void 0:r.lega_id)===e),P=async(e,r)=>{if(window.confirm(`Sei sicuro di voler eliminare l'utente "${r}"? Questa azione non pu\xf2 essere annullata.`))try{const i=await ni.delete(`/superadmin/users/${e}`,t);if(i.ok)alert(`Utente "${r}" eliminato con successo!`),await(async()=>{try{if(_(!0),!t)return console.warn("Token mancante per caricamento utenti"),void w([]);const e=await ni.get("/auth/all-users",t);e.ok?w(e.data.users||[]):401===e.status?(console.warn("Utente non autorizzato per accedere agli utenti"),w([])):403===e.status?(console.warn("Accesso negato: richiesti privilegi SuperAdmin"),w([])):(console.error("Errore nel caricamento utenti:",e.status),w([]))}catch(e){console.error("Errore nel caricamento utenti:",e),w([])}finally{_(!1)}})();else{const e=i.data;alert(`Errore nell'eliminazione: ${e.error||"Errore sconosciuto"}`)}}catch(i){console.error("Errore nell'eliminazione utente:",i),alert(`Errore nell'eliminazione: ${i.message}`)}};if(s)return(0,gt.jsx)(Nf,{children:(0,gt.jsx)(Kf,{children:"Caricamento dashboard..."})});if(d)return(0,gt.jsx)(Nf,{children:(0,gt.jsxs)(Yf,{children:["Errore: ",d]})});const $=(null===i||void 0===i?void 0:i.length)||0,I=(null===i||void 0===i?void 0:i.reduce((e,r)=>e+(r.numero_squadre||0),0))||0,O=(null===i||void 0===i?void 0:i.reduce((e,r)=>e+(r.squadre_con_proprietario||0),0))||0,L=(null===i||void 0===i?void 0:i.reduce((e,r)=>e+(r.numero_giocatori||0),0))||0,M=(null===i||void 0===i?void 0:i.filter(e=>null===e||void 0===e?void 0:e.is_pubblica).length)||0;return console.log("\ud83d\udd0d SuperAdminDashboard: Stats calculated:"),console.log("\ud83d\udd0d SuperAdminDashboard: - Total Leghe:",$),console.log("\ud83d\udd0d SuperAdminDashboard: - Total Squadre:",I),console.log("\ud83d\udd0d SuperAdminDashboard: - Total Squadre Assegnate:",O),console.log("\ud83d\udd0d SuperAdminDashboard: - Total Giocatori:",L),console.log("\ud83d\udd0d SuperAdminDashboard: - Leghe Pubbliche:",M),(0,gt.jsxs)(Nf,{children:[(0,gt.jsxs)(Tf,{children:[(0,gt.jsx)(qf,{children:"\ud83d\udc51 SuperAdmin Dashboard"}),(0,gt.jsx)(Pf,{children:"Pannello di controllo completo per la gestione del sistema"})]}),(0,gt.jsxs)($f,{children:[(0,gt.jsxs)(If,{children:[(0,gt.jsx)(Of,{children:$}),(0,gt.jsx)(Lf,{children:"Leghe Totali"})]}),(0,gt.jsxs)(If,{children:[(0,gt.jsxs)(Of,{children:[O,"/",I]}),(0,gt.jsx)(Lf,{children:"Squadre Assegnate/Totali"})]}),(0,gt.jsxs)(If,{children:[(0,gt.jsx)(Of,{children:L}),(0,gt.jsx)(Lf,{children:"Giocatori Totali"})]}),(0,gt.jsxs)(If,{children:[(0,gt.jsx)(Of,{children:M}),(0,gt.jsx)(Lf,{children:"Leghe Pubbliche"})]})]}),(0,gt.jsxs)(Mf,{children:[(0,gt.jsx)(Ff,{children:"\ud83c\udfc6 Gestione Leghe"}),i&&0!==((null===i||void 0===i?void 0:i.length)||0)?(0,gt.jsx)(Uf,{children:(0,gt.jsxs)(Bf,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Gf,{children:"Nome Lega"}),(0,gt.jsx)(Gf,{children:"Proprietario"}),(0,gt.jsx)(Gf,{children:"Modalit\xe0"}),(0,gt.jsx)(Gf,{children:"Stato"}),(0,gt.jsx)(Gf,{children:"Squadre (Assegnate/Totali)"}),(0,gt.jsx)(Gf,{children:"Giocatori"}),(0,gt.jsx)(Gf,{children:"Subadmin"}),(0,gt.jsx)(Gf,{children:"Data Creazione"}),(0,gt.jsx)(Gf,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:null===i||void 0===i?void 0:i.map(r=>(0,gt.jsxs)(Hf,{children:[(0,gt.jsx)(Wf,{children:(0,gt.jsx)("strong",{children:(null===r||void 0===r?void 0:r.nome)||"Nome"})}),(0,gt.jsx)(Wf,{children:(0,gt.jsxs)("div",{children:[(0,gt.jsx)("div",{children:(0,gt.jsx)("strong",{children:r.admin_nome||"N/A"})}),(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#666"},children:r.admin_email||"N/A"})]})}),(0,gt.jsx)(Wf,{children:(null===r||void 0===r?void 0:r.modalita)||"N/A"}),(0,gt.jsx)(Wf,{children:(0,gt.jsx)(Qf,{className:null!==r&&void 0!==r&&r.is_pubblica?"public":"private",children:null!==r&&void 0!==r&&r.is_pubblica?"Pubblica":"Privata"})}),(0,gt.jsxs)(Wf,{children:[(0,gt.jsxs)("strong",{children:[r.squadre_con_proprietario||0,"/",r.numero_squadre||0]}),r.numero_squadre>0&&(0,gt.jsxs)("div",{style:{fontSize:"0.8rem",color:"#666",marginTop:"0.25rem"},children:[Math.round((r.squadre_con_proprietario||0)/r.numero_squadre*100),"% assegnate"]})]}),(0,gt.jsx)(Wf,{children:r.numero_giocatori||0}),(0,gt.jsx)(Wf,{children:q(r.id).length>0?(0,gt.jsx)("div",{children:q(r.id).map(e=>(0,gt.jsxs)("div",{style:{marginBottom:"0.5rem"},children:[(0,gt.jsx)("strong",{children:e.username}),(0,gt.jsxs)("div",{style:{fontSize:"0.8rem",color:"#666"},children:[Object.keys(e.permessi).filter(r=>e.permessi[r]).length," permessi"]})]},e.id))}):(0,gt.jsx)("span",{style:{color:"#666",fontStyle:"italic"},children:"Nessuno"})}),(0,gt.jsx)(Wf,{children:N(r.created_at)}),(0,gt.jsxs)(Wf,{children:[(0,gt.jsx)(Vf,{className:"warning",onClick:()=>{return t=r.id,void e(`/super-admin/lega/${t}/edit`);var t},children:"\u270f\ufe0f Modifica"}),(0,gt.jsx)(Vf,{className:"success",onClick:()=>(e=>{h(e),f(""),v(null),j({modifica_squadre:!1,gestione_giocatori:!1,gestione_tornei:!1,modifica_impostazioni:!1,gestione_contratti:!1}),g(!0)})(r),children:"\ud83d\udc65 Aggiungi Subadmin"}),(0,gt.jsx)(Vf,{className:"info",onClick:()=>e(`/gestione-roster-admin/${r.id}`),children:"\ud83d\udcca Gestione Roster"}),(0,gt.jsx)(Vf,{className:"danger",onClick:()=>(async(e,r)=>{if(window.confirm(`Sei sicuro di voler eliminare la lega "${r}"? Questa azione non pu\xf2 essere annullata.`))try{console.log("\ud83d\udd0d SuperAdminDashboard: Eliminazione lega",e);const r=await qo(e,t),o=(null===r||void 0===r?void 0:r.success)||(null===r||void 0===r?void 0:r.ok)||!1,a=(null===r||void 0===r?void 0:r.message)||"Lega eliminata con successo";if(!o)throw new Error(a||"Errore nell'eliminazione della lega");n(null===i||void 0===i?void 0:i.filter(r=>r.id!==e)),alert(a),console.log("\u2705 SuperAdminDashboard: Lega eliminata con successo")}catch(o){console.error("\u274c SuperAdminDashboard: Errore eliminazione lega:",o),alert(`Errore nell'eliminazione: ${o.message||"Errore sconosciuto"}`)}})(r.id,(null===r||void 0===r?void 0:r.nome)||"Nome"),children:"\ud83d\uddd1\ufe0f Elimina"})]})]},r.id))})]})}):(0,gt.jsxs)(Jf,{children:[(0,gt.jsx)("h3",{children:"Nessuna lega trovata"}),(0,gt.jsx)("p",{children:"Non ci sono ancora leghe nel sistema."})]})]}),(0,gt.jsxs)(Df,{children:[(0,gt.jsxs)(Ff,{children:["\ud83d\udc65 Gestione Utenti",(0,gt.jsx)(Vf,{className:"success",onClick:()=>{E(null),R({username:"",email:"",ruolo:"Utente"}),C(!0)},style:{marginLeft:"1rem"},children:"\u2795 Aggiungi Utente"})]}),k?(0,gt.jsx)(Kf,{children:"Caricamento utenti..."}):y&&0!==((null===y||void 0===y?void 0:y.length)||0)?(0,gt.jsx)(Uf,{children:(0,gt.jsxs)(Bf,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Gf,{children:"Username"}),(0,gt.jsx)(Gf,{children:"Email"}),(0,gt.jsx)(Gf,{children:"Ruolo"}),(0,gt.jsx)(Gf,{children:"Data Registrazione"}),(0,gt.jsx)(Gf,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:null===y||void 0===y?void 0:y.map(e=>(0,gt.jsxs)(Hf,{children:[(0,gt.jsx)(Wf,{children:(0,gt.jsx)("strong",{children:e.username})}),(0,gt.jsx)(Wf,{children:e.email}),(0,gt.jsx)(Wf,{children:(0,gt.jsx)(Qf,{className:"SuperAdmin"===((null===e||void 0===e?void 0:e.ruolo)||"Ruolo")?"public":"private",children:(null===e||void 0===e?void 0:e.ruolo)||"Ruolo"})}),(0,gt.jsx)(Wf,{children:N(e.created_at)}),(0,gt.jsxs)(Wf,{children:[(0,gt.jsx)(Vf,{className:"warning",onClick:()=>(e=>{E(e),R({username:e.username,email:e.email,ruolo:(null===e||void 0===e?void 0:e.ruolo)||"Ruolo"}),C(!0)})(e),children:"\u270f\ufe0f Modifica"}),(0,gt.jsx)(Vf,{className:"danger",onClick:()=>P(e.id,e.username),children:"\ud83d\uddd1\ufe0f Elimina"})]})]},e.id))})]})}):(0,gt.jsxs)(Jf,{children:[(0,gt.jsx)("h3",{children:"Nessun utente trovato"}),(0,gt.jsx)("p",{children:"Non ci sono ancora utenti nel sistema."})]})]}),u&&(0,gt.jsx)(Zf,{onClick:()=>g(!1),children:(0,gt.jsxs)(Xf,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(ex,{children:["Aggiungi Subadmin - ",null===p||void 0===p?void 0:p.nome]}),(0,gt.jsxs)(rx,{children:[(0,gt.jsx)(tx,{children:"Seleziona Utente"}),(0,gt.jsx)(Fg,{value:m,onChange:f,placeholder:"Cerca utente per username...",token:t,onUserSelect:e=>{f(e.username),v(e.id)}})]}),(0,gt.jsxs)(rx,{children:[(0,gt.jsx)(tx,{children:"Permessi"}),(0,gt.jsxs)(ox,{children:[(0,gt.jsxs)(ax,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:b.modifica_squadre,onChange:()=>T("modifica_squadre")}),"Modifica Squadre"]}),(0,gt.jsxs)(ax,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:b.gestione_giocatori,onChange:()=>T("gestione_giocatori")}),"Gestione Giocatori"]}),(0,gt.jsxs)(ax,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:b.gestione_tornei,onChange:()=>T("gestione_tornei")}),"Gestione Tornei"]}),(0,gt.jsxs)(ax,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:b.modifica_impostazioni,onChange:()=>T("modifica_impostazioni")}),"Modifica Impostazioni"]}),(0,gt.jsxs)(ax,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:b.gestione_contratti,onChange:()=>T("gestione_contratti")}),"Gestione Contratti"]})]})]}),(0,gt.jsxs)(sx,{children:[(0,gt.jsx)(Vf,{className:"secondary",onClick:()=>g(!1),children:"Annulla"}),(0,gt.jsx)(Vf,{className:"success",onClick:async()=>{if(x&&p)try{var e;await Li(p.id,x,b,t),alert("Subadmin aggiunto con successo!"),g(!1);const r=await Ii(t);a((null===r||void 0===r||null===(e=r.data)||void 0===e?void 0:e.subadmins)||[])}catch(r){alert(`Errore nell'aggiunta del subadmin: ${r.message}`)}else alert("Seleziona un utente e una lega")},children:"Aggiungi Subadmin"})]})]})}),S&&(0,gt.jsx)(Zf,{onClick:()=>C(!1),children:(0,gt.jsxs)(Xf,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsx)(ex,{children:z?"Modifica Utente":"Nuovo Utente"}),(0,gt.jsxs)(rx,{children:[(0,gt.jsx)(tx,{children:"Username"}),(0,gt.jsx)(ix,{type:"text",value:A.username,onChange:e=>R(r=>({...r,username:e.target.value})),placeholder:"Inserisci username"})]}),(0,gt.jsxs)(rx,{children:[(0,gt.jsx)(tx,{children:"Email"}),(0,gt.jsx)(ix,{type:"email",value:A.email,onChange:e=>R(r=>({...r,email:e.target.value})),placeholder:"Inserisci email"})]}),(0,gt.jsxs)(rx,{children:[(0,gt.jsx)(tx,{children:"Ruolo"}),(0,gt.jsxs)(nx,{value:(null===A||void 0===A?void 0:A.ruolo)||"Ruolo",onChange:e=>R(r=>({...r,ruolo:e.target.value})),children:[(0,gt.jsx)("option",{value:"Utente",children:"Utente"}),(0,gt.jsx)("option",{value:"Admin",children:"Admin"}),(0,gt.jsx)("option",{value:"SuperAdmin",children:"SuperAdmin"})]})]}),(0,gt.jsxs)(sx,{children:[(0,gt.jsx)(Vf,{className:"secondary",onClick:()=>C(!1),children:"Annulla"}),(0,gt.jsxs)(Vf,{className:"success",onClick:async()=>{try{return!A.username||!A.email||null===A||void 0===A||A.ruolo,void alert("Compila tutti i campi obbligatori")}catch(e){console.error("Errore nel salvataggio utente:",e),alert(`Errore nel salvataggio: ${e.message}`)}},children:[z?"Aggiorna":"Crea"," Utente"]})]})]})})]})}),dx=async(e,r)=>bc("GET",`/finanze/squadra/${e}`,null,r),cx=async(e,r,t)=>{const i=new URLSearchParams(r).toString();return bc("GET",`/finanze/squadra/${e}/transazioni?${i}`,null,t)},ux=async(e,r,t)=>{const i=new URLSearchParams(r).toString();return bc("GET",`/finanze/squadra/${e}/report?${i}`,null,t)},gx=Ie.div`
  padding: 2rem;
  max-width: 1400px;
  margin: 0 auto;
`,px=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 2px solid #f0f0f0;
`,hx=Ie.h1`
  color: #333;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,mx=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  margin-bottom: 2rem;
`,fx=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border: 1px solid #f0f0f0;
`,xx=Ie.h3`
  color: #333;
  margin: 0 0 1rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,vx=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  background: ${e=>e.highlight?"#f8f9fa":"transparent"};
  border-radius: 8px;
  margin-bottom: 0.5rem;
`,bx=Ie.span`
  font-weight: 600;
  color: #333;
`,jx=Ie.span`
  font-size: 1.2rem;
  font-weight: 700;
  color: ${e=>e.positive?"#28a745":e.negative?"#dc3545":"#333"};
`,yx=Ie.div`
  width: 100%;
  height: 8px;
  background: #e9ecef;
  border-radius: 4px;
  overflow: hidden;
  margin-top: 0.5rem;
`,wx=Ie.div`
  height: 100%;
  background: linear-gradient(90deg, #FFA94D 0%, #FF8C42 100%);
  width: ${e=>e.percentage}%;
  transition: width 0.3s ease;
`,kx=Ie.div`
  height: 200px;
  background: #f8f9fa;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #6c757d;
  font-style: italic;
`,_x=Ie.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
`,Sx=Ie.th`
  background: #f8f9fa;
  padding: 0.75rem;
  text-align: left;
  font-weight: 600;
  color: #333;
  border-bottom: 2px solid #dee2e6;
`,Cx=Ie.td`
  padding: 0.75rem;
  border-bottom: 1px solid #dee2e6;
  color: #333;
`,zx=Ie.span`
  background: ${e=>{switch(e.$status){case"attivo":return"#28a745";case"infortunato":return"#ffc107";case"squalificato":return"#dc3545";default:return"#6c757d"}}};
  color: white;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 600;
`,Ex=Ie.button`
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
`,Ax=Ie.div`
  padding: 1rem;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  margin-bottom: 0.5rem;
  background: ${e=>e.read?"#f8f9fa":"white"};
  cursor: pointer;
  
  &:hover {
    background: #f8f9fa;
  }
`,Rx=()=>{const{squadraId:e}=Pr(),t=qr(),{token:i}=Si(),[n,o]=(0,r.useState)(null),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)(null),[c,u]=(0,r.useState)([]),[g,p]=(0,r.useState)(null),[h,m]=(0,r.useState)([]),[f,x]=(0,r.useState)(!0);(0,r.useEffect)(()=>{v()},[e]);const v=async()=>{try{var r,t,n,a,l;const[c,g,h,f,x,v]=await Promise.all([Io(e,i),Mo(e,i),dx(e,i),cx(e,i),ux(e,i),Km(i)]);o((null===c||void 0===c||null===(r=c.data)||void 0===r?void 0:r.squadra)||(null===c||void 0===c?void 0:c.squadra)),s(null!==g&&void 0!==g&&null!==(t=g.data)&&void 0!==t&&t.giocatori||null!==g&&void 0!==g&&g.giocatori||Array.isArray(g)?g:[]),d((null===h||void 0===h||null===(n=h.data)||void 0===n?void 0:n.bilancio)||(null===h||void 0===h?void 0:h.bilancio)),u((null===f||void 0===f||null===(a=f.data)||void 0===a?void 0:a.transazioni)||(null===f||void 0===f?void 0:f.transazioni)),p((null===x||void 0===x?void 0:x.data)||x),m((null===v||void 0===v||null===(l=v.data)||void 0===l?void 0:l.notifiche)||(null===v||void 0===v?void 0:v.notifiche))}catch(c){console.error("Errore caricamento dashboard:",c)}finally{x(!1)}},b=e=>new Intl.NumberFormat("it-IT",{style:"currency",currency:"EUR"}).format(e);if(f)return(0,gt.jsx)(gx,{children:"Caricamento dashboard..."});const j=(()=>{if(null===a||void 0===a||!a.length)return{};const e={totale_valore:null===a||void 0===a?void 0:a.reduce((e,r)=>e+(r.valore_mercato||0),0),attaccanti:null===a||void 0===a?void 0:a.filter(e=>"A"===((null===e||void 0===e?void 0:e.ruolo)||"Ruolo")).length,centrocampisti:null===a||void 0===a?void 0:a.filter(e=>"C"===((null===e||void 0===e?void 0:e.ruolo)||"Ruolo")).length,difensori:null===a||void 0===a?void 0:a.filter(e=>"D"===((null===e||void 0===e?void 0:e.ruolo)||"Ruolo")).length,portieri:null===a||void 0===a?void 0:a.filter(e=>"P"===((null===e||void 0===e?void 0:e.ruolo)||"Ruolo")).length,infortunati:null===a||void 0===a?void 0:a.filter(e=>"infortunato"===e.stato).length,squalificati:null===a||void 0===a?void 0:a.filter(e=>"squalificato"===e.stato).length};return e})();return(0,gt.jsxs)(gx,{children:[(0,gt.jsxs)(px,{children:[(0,gt.jsxs)(hx,{children:["\ud83d\udcca Dashboard - ",null===n||void 0===n?void 0:n.nome]}),(0,gt.jsx)(Ex,{onClick:()=>t(`/squadra/${e}/gestione`),children:"Gestione Squadra"})]}),(0,gt.jsxs)(mx,{children:[(0,gt.jsxs)(fx,{children:[(0,gt.jsx)(xx,{children:"\ud83d\udcb0 Bilancio"}),(0,gt.jsxs)(vx,{highlight:!0,children:[(0,gt.jsx)(bx,{children:"Budget Iniziale"}),(0,gt.jsx)(jx,{children:b((null===l||void 0===l?void 0:l.budget_iniziale)||0)})]}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Entrate Totali"}),(0,gt.jsx)(jx,{positive:!0,children:b((null===l||void 0===l?void 0:l.entrate_totali)||0)})]}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Uscite Totali"}),(0,gt.jsx)(jx,{negative:!0,children:b((null===l||void 0===l?void 0:l.uscite_totali)||0)})]}),(0,gt.jsxs)(vx,{highlight:!0,children:[(0,gt.jsx)(bx,{children:"Bilancio Attuale"}),(0,gt.jsx)(jx,{positive:(null===l||void 0===l?void 0:l.bilancio_attuale)>=0,negative:(null===l||void 0===l?void 0:l.bilancio_attuale)<0,children:b((null===l||void 0===l?void 0:l.bilancio_attuale)||0)})]}),l&&(0,gt.jsx)(yx,{children:(0,gt.jsx)(wx,{percentage:Math.min(100,l.bilancio_attuale/l.budget_iniziale*100)})})]}),(0,gt.jsxs)(fx,{children:[(0,gt.jsx)(xx,{children:"\u26bd Statistiche Squadra"}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Giocatori Totali"}),(0,gt.jsx)(jx,{children:(null===a||void 0===a?void 0:a.length)||0})]}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Valore Mercato"}),(0,gt.jsx)(jx,{children:b(j.totale_valore)})]}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Infortunati"}),(0,gt.jsx)(jx,{negative:j.infortunati>0,children:j.infortunati})]})]}),(0,gt.jsxs)(fx,{children:[(0,gt.jsx)(xx,{children:"\ud83d\udc65 Distribuzione Ruoli"}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Portieri"}),(0,gt.jsx)(jx,{children:j.portieri})]}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Difensori"}),(0,gt.jsx)(jx,{children:j.difensori})]}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Centrocampisti"}),(0,gt.jsx)(jx,{children:j.centrocampisti})]}),(0,gt.jsxs)(vx,{children:[(0,gt.jsx)(bx,{children:"Attaccanti"}),(0,gt.jsx)(jx,{children:j.attaccanti})]})]}),(0,gt.jsxs)(fx,{children:[(0,gt.jsx)(xx,{children:"\ud83d\udcb3 Ultime Transazioni"}),c.slice(0,5).map(e=>(0,gt.jsxs)(vx,{children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)("div",{style:{fontWeight:600},children:e.descrizione}),(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#6c757d"},children:new Date(e.data_transazione).toLocaleDateString("it-IT")})]}),(0,gt.jsxs)(jx,{positive:"entrata"===e.tipo,negative:"uscita"===e.tipo,children:["entrata"===e.tipo?"+":"-",b(e.importo)]})]},e.id))]})]}),(0,gt.jsxs)(mx,{children:[(0,gt.jsxs)(fx,{children:[(0,gt.jsx)(xx,{children:"\ud83d\udcc8 Andamento Finanziario"}),(0,gt.jsx)(kx,{children:"Grafico andamento entrate/uscite (implementare con libreria grafici)"})]}),(0,gt.jsxs)(fx,{children:[(0,gt.jsx)(xx,{children:"\ud83d\udcca Spese per Categoria"}),(0,gt.jsx)(kx,{children:"Grafico a torta spese per categoria (implementare con libreria grafici)"})]})]}),(0,gt.jsxs)(fx,{children:[(0,gt.jsx)(xx,{children:"\ud83d\udc64 Rosa Squadra"}),(0,gt.jsxs)(_x,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Sx,{children:"Nome"}),(0,gt.jsx)(Sx,{children:"Ruolo"}),(0,gt.jsx)(Sx,{children:"Valore"}),(0,gt.jsx)(Sx,{children:"Stato"}),(0,gt.jsx)(Sx,{children:"Contratto"})]})}),(0,gt.jsx)("tbody",{children:null===a||void 0===a?void 0:a.map(e=>(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Cx,{children:(null===e||void 0===e?void 0:e.nome)||"Nome"}),(0,gt.jsx)(Cx,{children:(null===e||void 0===e?void 0:e.ruolo)||"Ruolo"}),(0,gt.jsx)(Cx,{children:b(e.valore_mercato)}),(0,gt.jsx)(Cx,{children:(0,gt.jsx)(zx,{$status:e.stato,children:e.stato})}),(0,gt.jsx)(Cx,{children:e.scadenza_contratto})]},e.id))})]})]}),(0,gt.jsxs)(fx,{children:[(0,gt.jsx)(xx,{children:"\ud83d\udd14 Notifiche Recenti"}),h.slice(0,5).map(e=>(0,gt.jsxs)(Ax,{read:e.letta,children:[(0,gt.jsx)("div",{style:{fontWeight:600},children:e.titolo}),(0,gt.jsx)("div",{style:{fontSize:"0.9rem",color:"#6c757d"},children:e.messaggio}),(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#999",marginTop:"0.5rem"},children:new Date(e.data_creazione).toLocaleDateString("it-IT")})]},e.id))]})]})},Nx=Ie.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 2rem;
`,Tx=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,qx=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
`,Px=Ie.h1`
  color: #333;
  margin: 0 0 1rem 0;
  font-size: 2.5rem;
  background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,$x=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
`,Ix=Ie.h2`
  color: #333;
  margin: 0 0 2rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Ox=Ie.div`
  overflow-x: auto;
`,Lx=Ie.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
`,Mx=Ie.th`
  background: #5856d6;
  color: white;
  padding: 0.5rem 0.25rem;
  text-align: center;
  font-weight: 600;
  font-size: 0.7rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  
  &:first-child {
    border-top-left-radius: 8px;
  }
  
  &:last-child {
    border-top-right-radius: 8px;
  }
`,Dx=Ie.td`
  padding: 0.5rem 0.25rem;
  border-bottom: 1px solid #e5e5e7;
  color: #1d1d1f;
  text-align: center;
  cursor: pointer;
  transition: background-color 0.2s ease;
  font-size: 0.85rem;
  
  &:hover {
    background-color: ${e=>e.isLoan?"#fff3cd":"#f8f9fa"};
  }
`,Fx=Ie.div`
  font-weight: 600;
  color: #333;
  font-size: 1rem;
`,Ux=(Ie.span`
  display: inline-block;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: uppercase;
  
  &.available {
    background: #28a745;
    color: white;
  }
  
  &.unavailable {
    background: #dc3545;
    color: white;
  }
  
  &.loan {
    background: #ffc107;
    color: #212529;
  }
`,Ie.span`
  display: inline-block;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.7rem;
  font-weight: 600;
  text-transform: uppercase;
  margin: 1px;
  
  &.available {
    background: #28a745;
    color: white;
  }
  
  &.unavailable {
    background: #6c757d;
    color: white;
  }
`),Bx=(Ie.div`
  display: flex;
  justify-content: space-between;
  font-size: 0.9rem;
  color: #666;
`,Ie.div`
  text-align: center;
  
  .value {
    font-weight: 700;
    color: #333;
    font-size: 1rem;
  }
  
  .label {
    font-size: 0.75rem;
    color: #666;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
`,Ie.button`
  width: 100%;
  padding: 0.5rem;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 0.8rem;
  
  background: ${e=>{if(e.disabled)return"linear-gradient(135deg, #6c757d 0%, #545b62 100%)";switch(e.type){case"contatta":return"linear-gradient(135deg, #007bff 0%, #0056b3 100%)";case"trasferimento":return"linear-gradient(135deg, #28a745 0%, #1e7e34 100%)";case"prestito":return"linear-gradient(135deg, #ffc107 0%, #e0a800 100%)";default:return"linear-gradient(135deg, #6c757d 0%, #545b62 100%)"}}};
  color: white;
  
  &:hover {
    transform: ${e=>e.disabled?"none":"translateY(-1px)"};
    box-shadow: ${e=>e.disabled?"none":"0 4px 12px rgba(0,0,0,0.2)"};
  }
  
  &:active {
    transform: translateY(0);
  }
  
  &:disabled {
    cursor: not-allowed;
    opacity: 0.6;
  }
`),Gx=(Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  margin-top: 1rem;
`,Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`),Wx=Ie.h3`
  color: #333;
  margin: 0;
  font-size: 1.2rem;
`,Hx=(Ie.button`
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 0.5rem 1rem;
  cursor: pointer;
  font-weight: 600;
  
  &:hover {
    background: #c82333;
  }
`,Ie.div`
  overflow-x: auto;
`),Vx=Ie.button`
  position: fixed;
  left: 2rem;
  top: 50%;
  transform: translateY(-50%);
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  cursor: pointer;
  font-weight: 600;
  font-size: 1.2rem;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  z-index: 100;
  transition: all 0.3s ease;
  
  &:hover {
    background: #c82333;
    transform: translateY(-50%) scale(1.1);
    box-shadow: 0 6px 16px rgba(0,0,0,0.4);
  }
`,Qx=Ie.tr`
  background: #f8f9fa;
`,Kx=Ie.td`
  padding: 0 !important;
  border: none !important;
`,Yx=Ie.div`
  padding: 1rem;
  background: white;
  margin: 0.5rem;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
`,Jx=(Ie.div`
  font-weight: 600;
  color: #333;
  margin-bottom: 0.25rem;
`,Ie.span`
  .ruolo-badge {
    display: inline-block;
    padding: 4px 8px;
    margin: 2px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: center;
    min-width: 24px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    transition: all 0.2s ease;
  }
  
  .ruolo-badge:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
  }
  
  .ruolo-badge:last-child {
    margin-right: 0;
  }
  
  /* Ruoli Serie A Classic */
  .ruolo-p { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  .ruolo-d { 
    background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  .ruolo-c { 
    background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-a { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #c62828;
  }
  
  /* Ruoli Euroleghe Mantra */
  /* Portieri - Arancione (come P) */
  .ruolo-por { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  /* Difensori - Palette di verdi */
  .ruolo-dc { 
    background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); 
    color: white; 
    border-color: #0d4f14;
  }
  
  .ruolo-dd { 
    background: linear-gradient(135deg, #388e3c 0%, #2e7d32 100%); 
    color: white; 
    border-color: #1b5e20;
  }
  
  .ruolo-ds { 
    background: linear-gradient(135deg, #43a047 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  /* Centrocampisti - Palette di blu */
  .ruolo-b { 
    background: linear-gradient(135deg, #1565c0 0%, #0d47a1 100%); 
    color: white; 
    border-color: #0a3d91;
  }
  
  .ruolo-c { 
    background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); 
    color: white; 
    border-color: #0d47a1;
  }
  
  .ruolo-m { 
    background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-w { 
    background: linear-gradient(135deg, #42a5f5 0%, #2196f3 100%); 
    color: white; 
    border-color: #1976d2;
  }
  
  /* Attaccanti - Palette di rossi */
  .ruolo-a { 
    background: linear-gradient(135deg, #d32f2f 0%, #b71c1c 100%); 
    color: white; 
    border-color: #a41515;
  }
  
  .ruolo-pc { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #b71c1c;
  }
  
  .ruolo-t { 
    background: linear-gradient(135deg, #ef5350 0%, #f44336 100%); 
    color: white; 
    border-color: #d32f2f;
  }
`),Zx=Ie.span`
  font-weight: 700;
  color: #28a745;
`,Xx=Ie.div`
  display: flex;
  gap: 0.25rem;
  justify-content: center;
  flex-direction: column;
`,ev=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,rv=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,tv=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,iv=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  max-width: 500px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
`,nv=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
`,ov=Ie.h3`
  color: #333;
  margin: 0;
  font-size: 1.5rem;
`,av=Ie.button`
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 0.5rem 1rem;
  cursor: pointer;
  font-weight: 600;
  
  &:hover {
    background: #c82333;
  }
`,sv=Ie.div`
  margin-bottom: 1.5rem;
`,lv=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
  font-weight: 600;
`,dv=Ie.input`
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #28a745;
  }
`,cv=(Ie.textarea`
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #e5e5e7;
  border-radius: 8px;
  font-size: 1rem;
  min-height: 100px;
  resize: vertical;
  
  &:focus {
    outline: none;
    border-color: #28a745;
  }
`,Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 2rem;
`),uv=Ie.button`
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  
  background: ${e=>"trasferimento"===e.type?"linear-gradient(135deg, #28a745 0%, #1e7e34 100%)":"linear-gradient(135deg, #ffc107 0%, #e0a800 100%)"};
  color: white;
  
  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  }
`,gv=Ie.button`
  padding: 0.75rem 1.5rem;
  border: 2px solid #6c757d;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  background: white;
  color: #6c757d;
  
  &:hover {
    background: #6c757d;
    color: white;
  }
`,pv=()=>{const{token:e}=Si(),t=qr(),[i]=ut(),n=i.get("squadra"),[o,a]=(0,r.useState)([]),[s,l]=(0,r.useState)([]),[d,c]=(0,r.useState)(!0),[u,g]=(0,r.useState)(""),[p,h]=(0,r.useState)(null),[m,f]=(0,r.useState)(!1),[x,v]=(0,r.useState)(null),[b,j]=(0,r.useState)(""),[y,w]=(0,r.useState)(""),[k,_]=(0,r.useState)(""),[S,C]=(0,r.useState)(!1),[z,E]=(0,r.useState)(null),[A,R]=(0,r.useState)(!1),[N,T]=(0,r.useState)(!1),[q,P]=(0,r.useState)(""),[$,I]=(0,r.useState)(""),[O,L]=(0,r.useState)(""),[M,D]=(0,r.useState)(null),[F,U]=(0,r.useState)("tutti"),[B,G]=(0,r.useState)([]);(0,r.useEffect)(()=>{e&&n&&async function(){c(!0),g("");try{var r,t;const i=await fetch(`${ni.baseUrl}/squadre/${n}`,{headers:{Authorization:`Bearer ${e}`}}),o=i.data;if(!i.ok)throw new Error(o.error||"Errore caricamento squadra");const s=null===o||void 0===o||null===(r=o.squadra)||void 0===r?void 0:r.lega_id;if(!s)throw new Error("Lega ID non trovato per questa squadra");E(s),D(null===o||void 0===o?void 0:o.squadra);const[d,c]=await Promise.all([Ro(s,e),lu(s,e)]),u=(null===d||void 0===d||null===(t=d.data)||void 0===t?void 0:t.squadre)||(null===d||void 0===d?void 0:d.squadre)||[],g=(null===u||void 0===u?void 0:u.filter(e=>(null===e||void 0===e?void 0:e.id)!==parseInt(n)))||[];a(g);let p=[];c&&c.ok&&c.data?p=c.data.giocatori||c.data||[]:c&&c.giocatori?p=c.giocatori:Array.isArray(c)?p=c:console.error("Nessun dato valido trovato per giocatori:",c),l(p);const h=[...new Set(g.map(e=>e.torneo||"N/A"))];G(h)}catch(i){g(i.message)}c(!1)}()},[e,n]);const W=e=>e?`FM ${e.toLocaleString()}`:"FM 0",H=()=>{f(!1),v(null),j(""),w(""),_("")},V=()=>{T(!1),v(null),P(""),I(""),L("")},Q=e=>{h(e)},K=()=>{h(null)},Y=e=>e.valore_trasferimento>0?"available":"unavailable",J=e=>e.valore_prestito>0?"available":"unavailable",Z=()=>"tutti"===F?o:o.filter(e=>(e.torneo||"N/A")===F);return d?(0,gt.jsx)(Nx,{children:(0,gt.jsx)(ev,{children:"Caricamento squadre e giocatori..."})}):u?(0,gt.jsx)(Nx,{children:(0,gt.jsxs)(rv,{children:["Errore: ",u]})}):(0,gt.jsxs)(Nx,{children:[(0,gt.jsx)(Tx,{onClick:()=>t(-1),children:"\u2190 Torna indietro"}),(0,gt.jsx)(qx,{children:(0,gt.jsx)(Px,{children:"\ud83d\udcb0 Proponi Offerta"})}),(0,gt.jsxs)($x,{children:[(0,gt.jsx)(Ix,{children:"\ud83c\udfc6 Squadre della Lega"}),B.length>1&&(0,gt.jsxs)("div",{style:{marginBottom:"1rem",display:"flex",alignItems:"center",gap:"1rem"},children:[(0,gt.jsx)("label",{style:{fontWeight:"600",color:"#333"},children:"Filtra per Torneo:"}),(0,gt.jsxs)("select",{value:F,onChange:e=>U(e.target.value),style:{padding:"0.5rem",borderRadius:"6px",border:"1px solid #ddd",backgroundColor:"white",fontSize:"0.9rem"},children:[(0,gt.jsx)("option",{value:"tutti",children:"Tutti i Tornei"}),B.map(e=>(0,gt.jsx)("option",{value:e,children:e},e))]})]}),0===Z().length?(0,gt.jsx)("div",{style:{textAlign:"center",padding:"2rem",color:"#666"},children:"Nessuna squadra disponibile in questa lega"}):(0,gt.jsx)(Ox,{children:(0,gt.jsxs)(Lx,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Mx,{children:"Squadra"}),(0,gt.jsx)(Mx,{children:"Proprietario"}),(0,gt.jsx)(Mx,{children:"Giocatori"}),(0,gt.jsx)(Mx,{children:"Valore"}),(0,gt.jsx)(Mx,{children:"Ingaggi"}),(0,gt.jsx)(Mx,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:Z().map(e=>{const i=(e=>{const r=s.filter(r=>r.squadra_id===e.id),t=r.reduce((e,r)=>e+(r.costo_attuale||0),0),i=r.reduce((e,r)=>e+(r.salario||0),0);return{giocatori:r.length,valore:t,salari:i}})(e),n=p&&p.id===e.id;return(0,gt.jsxs)(r.Fragment,{children:[(0,gt.jsxs)("tr",{onClick:()=>Q(e),children:[(0,gt.jsx)(Dx,{children:(0,gt.jsx)(Fx,{children:e.nome})}),(0,gt.jsx)(Dx,{children:(0,gt.jsx)("div",{className:"value",children:e.proprietario_nome&&e.proprietario_cognome?`${e.proprietario_nome} ${e.proprietario_cognome}`:e.proprietario_nome||e.proprietario_cognome||"Non assegnato"})}),(0,gt.jsx)(Dx,{children:(0,gt.jsx)("div",{className:"value",children:i.giocatori})}),(0,gt.jsx)(Dx,{children:(0,gt.jsx)(Zx,{children:W(i.valore)})}),(0,gt.jsx)(Dx,{children:(0,gt.jsx)(Zx,{children:W(i.salari)})}),(0,gt.jsx)(Dx,{children:(0,gt.jsx)(Bx,{type:"contatta",onClick:r=>{r.stopPropagation(),n?K():Q(e)},children:n?"Chiudi":"Visualizza Giocatori"})})]}),n&&(0,gt.jsx)(Qx,{children:(0,gt.jsx)(Kx,{colSpan:"15",children:(0,gt.jsxs)(Yx,{children:[(0,gt.jsx)(Gx,{children:(0,gt.jsxs)(Wx,{children:["\ud83d\udc65 Giocatori di ",e.nome]})}),(0,gt.jsx)(Hx,{children:(0,gt.jsxs)(Lx,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Mx,{children:"Giocatore"}),(0,gt.jsx)(Mx,{children:"Ruolo"}),(0,gt.jsx)(Mx,{children:"Squadra Reale"}),(0,gt.jsx)(Mx,{children:"Cantera"}),(0,gt.jsx)(Mx,{children:"QA"}),(0,gt.jsx)(Mx,{children:"Ingaggio"}),(0,gt.jsx)(Mx,{children:"Valore Mercato"}),(0,gt.jsx)(Mx,{children:"St.Pres"}),(0,gt.jsx)(Mx,{children:"St.Tra"}),(0,gt.jsx)(Mx,{children:"Roster"}),(0,gt.jsx)(Mx,{children:"Prestito"}),(0,gt.jsx)(Mx,{children:"Valore Prestito"}),(0,gt.jsx)(Mx,{children:"Trasferimento"}),(0,gt.jsx)(Mx,{children:"Valore Trasferimento"}),(0,gt.jsx)(Mx,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:s.filter(r=>r.squadra_id===e.id).sort((e,r)=>{const t={P:1,Por:2,D:3,Dc:4,B:5,Dd:6,Ds:7,E:8,M:9,C:10,T:11,W:12,A:13,Pc:14},i=cu(e.ruolo),n=cu(r.ruolo),o=i[0]||"",a=n[0]||"",s=t[o]||15,l=t[a]||15;return s!==l?s-l:(e.nome+" "+(e.cognome||"")).localeCompare(r.nome+" "+(r.cognome||""))}).map(e=>(0,gt.jsxs)("tr",{style:{backgroundColor:e.prestito?"#fff3cd":"transparent"},children:[(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsxs)("span",{style:{color:"#E67E22",fontWeight:700,cursor:"pointer",textDecoration:"none"},onClick:()=>t(`/giocatore/${e.id}`),children:[e.nome," ",e.cognome||""]})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsx)(Jx,{children:cu(e.ruolo).map((e,r)=>(0,gt.jsx)("span",{className:`ruolo-badge ${uu(e)}`,children:e},r))})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:e.squadra_reale}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:e.cantera?"\u2714":"-"}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:e.qa_scraping||e.quotazione_attuale||"-"}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsx)(Zx,{children:W(e.salario)})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsx)(Zx,{children:W(e.costo_attuale)})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:e.prestito?(0,gt.jsxs)("div",{style:{textAlign:"center",whiteSpace:"pre-line"},children:[(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#666",marginBottom:"2px"},children:"In Prestito da"}),(0,gt.jsx)(Ux,{className:"loan",children:e.squadra_prestito_nome||"Sconosciuta"})]}):"-"}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:e.trasferimento?(0,gt.jsx)(Ux,{className:"unavailable",children:"Trasferimento"}):"-"}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsx)("span",{style:{color:"B"===e.roster?"#ffc107":"#28a745",fontWeight:"bold"},children:"B"===e.roster?"B":"A"})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsx)(Ux,{className:J(e),children:"available"===J(e)?"S\xec":"No"})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsx)(Zx,{children:e.valore_prestito>0?W(e.valore_prestito):"-"})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsx)(Ux,{className:Y(e),children:"available"===Y(e)?"S\xec":"No"})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsx)(Zx,{children:e.valore_trasferimento>0?W(e.valore_trasferimento):"-"})}),(0,gt.jsx)(Dx,{isLoan:e.prestito,children:(0,gt.jsxs)(Xx,{children:[(0,gt.jsx)(Bx,{type:"trasferimento",onClick:()=>(e=>{v(e),j("trasferimento"),w(""),_(""),f(!0)})(e),children:"Trasferimento"}),(0,gt.jsx)(Bx,{type:"prestito",onClick:()=>(e=>{v(e),j("prestito"),w(""),_(""),f(!0)})(e),children:"Prestito"}),(0,gt.jsx)(Bx,{type:"scambio",onClick:()=>(e=>{v(e),P(""),I(""),L(""),T(!0)})(e),children:"Scambio"})]})})]},e.id))})]})})]})})})]},e.id)})})]})})]}),p&&(0,gt.jsx)(Vx,{onClick:K,children:"\u2715"}),m&&(0,gt.jsx)(tv,{children:(0,gt.jsxs)(iv,{children:[(0,gt.jsxs)(nv,{children:[(0,gt.jsxs)(ov,{children:["Proponi ","trasferimento"===b?"Trasferimento":"Prestito"," - ",null===x||void 0===x?void 0:x.nome," ",null===x||void 0===x?void 0:x.cognome]}),(0,gt.jsx)(av,{onClick:H,children:"\u2715"})]}),(0,gt.jsxs)(sv,{children:[(0,gt.jsx)(lv,{children:"Valore Offerta (FM)"}),(0,gt.jsx)(dv,{type:"number",value:y,onChange:e=>w(e.target.value),placeholder:"Inserisci il valore dell'offerta",min:"0",step:"1"})]}),(0,gt.jsxs)(sv,{children:[(0,gt.jsxs)(lv,{style:{display:"flex",alignItems:"center",gap:"0.5rem"},children:[(0,gt.jsx)("input",{type:"checkbox",checked:A,onChange:e=>R(e.target.checked)}),"Calciatore Cantera"]}),(0,gt.jsx)("small",{style:{color:"#6c757d",fontSize:"0.8rem"},children:"I calciatori cantera hanno un ingaggio ridotto (quotazione attuale / 2)"})]}),(0,gt.jsxs)(cv,{children:[(0,gt.jsx)(gv,{onClick:H,children:"Annulla"}),(0,gt.jsx)(uv,{type:b,onClick:async()=>{if(!y)return void alert("Inserisci il valore dell'offerta");const r=parseFloat(y);if(r>(null===M||void 0===M?void 0:M.casse_societarie))alert("Non hai abbastanza fondi nelle casse societarie per questa offerta");else{if("trasferimento"===b){const e=s.filter(e=>e.squadra_id===(null===M||void 0===M?void 0:M.id)).length;if(e+1>25)return void alert("La tua squadra supererebbe il limite massimo di giocatori")}C(!0);try{const t=await fetch(`${ni.baseUrl}/offerte/crea`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e}`},body:JSON.stringify({giocatore_id:null===x||void 0===x?void 0:x.id,tipo:b,valore_offerta:r,richiesta_fm:0,cantera:A})});if(t.ok)alert("Offerta inviata con successo!"),H();else{const e=t.data;alert("Errore nell'invio dell'offerta: "+(e.error||"Errore sconosciuto"))}}catch(u){alert("Errore nell'invio dell'offerta: "+u.message)}finally{C(!1)}}},disabled:S,children:S?"Invio...":"Proponi "+("trasferimento"===b?"Trasferimento":"Prestito")})]})]})}),N&&(0,gt.jsx)(tv,{children:(0,gt.jsxs)(iv,{children:[(0,gt.jsxs)(nv,{children:[(0,gt.jsxs)(ov,{children:["Proponi Scambio - ",null===x||void 0===x?void 0:x.nome," ",null===x||void 0===x?void 0:x.cognome]}),(0,gt.jsx)(av,{onClick:V,children:"\u2715"})]}),(0,gt.jsxs)(sv,{children:[(0,gt.jsx)(lv,{children:"Giocatore che offri (dalla tua squadra)"}),(0,gt.jsxs)("select",{value:q,onChange:e=>P(e.target.value),style:{width:"100%",padding:"0.5rem",borderRadius:"4px",border:"1px solid #ddd"},children:[(0,gt.jsx)("option",{value:"",children:"Seleziona un giocatore"}),s.filter(e=>e.squadra_id===(null===M||void 0===M?void 0:M.id)).map(e=>(0,gt.jsxs)("option",{value:e.id,children:[e.nome," ",e.cognome," (",e.ruolo,")"]},e.id))]})]}),(0,gt.jsxs)(sv,{children:[(0,gt.jsxs)(lv,{children:["Giocatore che ricevi (dalla squadra ",null===p||void 0===p?void 0:p.nome,")"]}),(0,gt.jsxs)("div",{style:{padding:"0.5rem",borderRadius:"4px",border:"1px solid #ddd",backgroundColor:"#f8f9fa",color:"#333",fontWeight:"600"},children:[null===x||void 0===x?void 0:x.nome," ",null===x||void 0===x?void 0:x.cognome," (",null===x||void 0===x?void 0:x.ruolo,")"]})]}),(0,gt.jsxs)(sv,{children:[(0,gt.jsxs)(lv,{children:["Offro (FM) - Verr\xe0 aggiunto alle casse societarie di ",null===p||void 0===p?void 0:p.nome]}),(0,gt.jsx)(dv,{type:"number",value:$,onChange:e=>I(e.target.value),placeholder:"Inserisci il valore da offrire",min:"0",step:"1"})]}),(0,gt.jsxs)(sv,{children:[(0,gt.jsx)(lv,{children:"Ricevo (FM) - Verr\xe0 aggiunto alle tue casse societarie"}),(0,gt.jsx)(dv,{type:"number",value:O,onChange:e=>L(e.target.value),placeholder:"Inserisci il valore da ricevere",min:"0",step:"1"})]}),(0,gt.jsxs)(cv,{children:[(0,gt.jsx)(gv,{onClick:V,children:"Annulla"}),(0,gt.jsx)(uv,{type:"scambio",onClick:async()=>{if(!q)return void alert("Seleziona un giocatore da offrire");const r=parseFloat($)||0,t=parseFloat(O)||0;if(r>0&&r>(null===M||void 0===M?void 0:M.casse_societarie))alert("Non hai abbastanza fondi nelle casse societarie per questa offerta");else if(t>0&&t>(null===p||void 0===p?void 0:p.casse_societarie))alert("La squadra destinataria non ha abbastanza fondi per questa offerta");else{C(!0);try{const i=await fetch(`${ni.baseUrl}/offerte/crea`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e}`},body:JSON.stringify({giocatore_id:null===x||void 0===x?void 0:x.id,tipo:"scambio",valore_offerta:r,richiesta_fm:t,giocatore_scambio_id:q})});if(i.ok)alert("Offerta di scambio inviata con successo!"),V();else{const e=i.data;alert("Errore nell'invio dell'offerta: "+(e.error||"Errore sconosciuto"))}}catch(u){alert("Errore nell'invio dell'offerta: "+u.message)}finally{C(!1)}}},disabled:S,children:S?"Invio...":"Proponi Scambio"})]})]})})]})},hv=async function(e,r,t,i,n,o){return bc("POST","/scraping/playwright",{leagueUrl:r,scrapingUrls:t,username:i,password:n,lega_id:e,tournament:arguments.length>6&&void 0!==arguments[6]?arguments[6]:null},o)},mv=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`,fv=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  text-align: center;
`,xv=Ie.h1`
  color: #333;
  margin: 0 0 1rem 0;
  font-size: 2.5rem;
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,vv=Ie.p`
  color: #666;
  font-size: 1.1rem;
  margin: 0;
`,bv=Ie.button`
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,jv=(Ie.span`
  .ruolo-badge {
  display: inline-block;
    padding: 4px 8px;
    margin: 2px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: center;
    min-width: 24px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    transition: all 0.2s ease;
  }
  
  .ruolo-badge:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
  }
  
  .ruolo-badge:last-child {
    margin-right: 0;
  }
  
  /* Ruoli Serie A Classic */
  .ruolo-p { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  .ruolo-d { 
    background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  .ruolo-c { 
    background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-a { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #c62828;
  }
  
  /* Ruoli Euroleghe Mantra */
  /* Portieri - Arancione (come P) */
  .ruolo-por { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  /* Difensori - Palette di verdi */
  .ruolo-dc { 
    background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); 
    color: white; 
    border-color: #0d4f14;
  }
  
  .ruolo-dd { 
    background: linear-gradient(135deg, #388e3c 0%, #2e7d32 100%); 
    color: white; 
    border-color: #1b5e20;
  }
  
  .ruolo-ds { 
    background: linear-gradient(135deg, #43a047 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  /* Centrocampisti - Palette di blu */
  .ruolo-b { 
    background: linear-gradient(135deg, #1565c0 0%, #0d47a1 100%); 
    color: white; 
    border-color: #002171;
  }
  
  .ruolo-e { 
    background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); 
    color: white; 
    border-color: #0d47a1;
  }
  
  .ruolo-m { 
    background: linear-gradient(135deg, #1e88e5 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-t { 
    background: linear-gradient(135deg, #9c27b0 0%, #7b1fa2 100%); 
    color: white; 
    border-color: #4a148c;
  }
  
  .ruolo-w { 
    background: linear-gradient(135deg, #ba68c8 0%, #9c27b0 100%); 
    color: white; 
    border-color: #7b1fa2;
  }
  
  /* Attaccanti - Palette di rossi */
  .ruolo-a { 
    background: linear-gradient(135deg, #d32f2f 0%, #b71c1c 100%); 
    color: white; 
    border-color: #8e0000;
  }
  
  .ruolo-pc { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #b71c1c;
  }
  
  /* Fallback */
  .ruolo-default { 
    background: linear-gradient(135deg, #757575 0%, #616161 100%); 
    color: white; 
    border-color: #424242;
  }
`,document.createElement("style"));jv.innerText="\n  .tournament-buttons {\n    display: flex;\n    flex-wrap: wrap;\n    gap: 10px;\n    margin: 15px 0;\n  }\n  \n  .tournament-btn {\n    min-width: 120px;\n    text-align: center;\n    font-size: 0.9em;\n    padding: 8px 12px;\n  }\n  \n  .tournament-btn.active {\n    background-color: #007bff;\n    color: white;\n    border-color: #007bff;\n  }\n  \n  .tournament-actions {\n    display: flex;\n    gap: 10px;\n    margin: 15px 0;\n  }\n  \n  .selected-tournaments {\n    margin-top: 15px;\n    padding: 10px;\n    background-color: #f8f9fa;\n    border-radius: 5px;\n    border: 1px solid #dee2e6;\n  }\n\n  .preferiti-controls {\n    display: flex;\n    align-items: center;\n    gap: 10px;\n    margin: 10px 0;\n  }\n\n  .preferiti-section {\n    margin-top: 15px;\n    padding: 15px;\n    background-color: #f8f9fa;\n    border-radius: 8px;\n    border: 1px solid #dee2e6;\n  }\n\n  .preferiti-list h5 {\n    margin-bottom: 15px;\n    color: #333;\n    font-weight: 600;\n  }\n\n  .preferiti-buttons {\n    display: flex;\n    flex-wrap: wrap;\n    gap: 8px;\n    margin-bottom: 15px;\n  }\n\n  .preferito-item {\n    display: flex;\n    align-items: center;\n  }\n\n  .preferito-btn {\n    transition: all 0.2s ease;\n  }\n\n  .preferito-btn:hover {\n    transform: translateY(-1px);\n    box-shadow: 0 2px 4px rgba(0,0,0,0.1);\n  }\n\n  .remove-btn {\n    transition: all 0.2s ease;\n  }\n\n  .remove-btn:hover {\n    background-color: #dc3545 !important;\n    color: white !important;\n    transform: scale(1.1);\n  }\n\n  .preferiti-info {\n    margin-top: 10px;\n    padding: 8px;\n    background-color: #e9ecef;\n    border-radius: 4px;\n  }\n\n  .no-preferiti {\n    text-align: center;\n    padding: 20px;\n  }\n",document.head.appendChild(jv);const yv=()=>{var e,t,i;const{token:n}=Si(),{showSuccessModal:o,showErrorModal:a}=zi(),s=qr(),{legaId:l}=Pr(),[d,c]=(0,r.useState)(""),[u,g]=(0,r.useState)([]),[p,h]=(0,r.useState)(""),[m,f]=(0,r.useState)({rose:"",classifica:"",formazioni:""}),[x,v]=(0,r.useState)(""),[b,j]=(0,r.useState)({username:"",password:""}),[y,w]=(0,r.useState)([]),[k,_]=(0,r.useState)(!1),[S,C]=(0,r.useState)(null),[z,E]=(0,r.useState)(null),[A,R]=(0,r.useState)(null),[N,T]=(0,r.useState)("carica-files"),[q,P]=(0,r.useState)({rose:!1,classifica:!1,formazioni:!1}),[$,I]=(0,r.useState)({}),[O,L]=(0,r.useState)("default"),[M,D]=(0,r.useState)("desc"),[F,U]=(0,r.useState)(!1),[B,G]=(0,r.useState)(0),[W,H]=(0,r.useState)(""),[V,Q]=(0,r.useState)([]),[K,Y]=(0,r.useState)({}),[J,Z]=(0,r.useState)([]),[X,ee]=(0,r.useState)(!1),[re,te]=(0,r.useState)(!1),[ie,ne]=(0,r.useState)(0),[oe,ae]=(0,r.useState)(null),[se,le]=(0,r.useState)([]),[de,ce]=(0,r.useState)(null),[ue,ge]=(0,r.useState)(!1),[pe,he]=(0,r.useState)(null),[me,fe]=(0,r.useState)(!1),[xe,ve]=(0,r.useState)(null),[be,je]=(0,r.useState)(null),[ye,we]=(0,r.useState)(!1),[ke,_e]=(0,r.useState)([]),[Se,Ce]=(0,r.useState)([]);(0,r.useEffect)(()=>{const e=localStorage.getItem("scraping_credentials");if(e)try{const r=JSON.parse(e);j(e=>({...e,username:r.username||"",password:(null===r||void 0===r?void 0:r.password)||""}))}catch(r){console.error("Errore nel caricamento delle credenziali salvate:",r)}},[]),(0,r.useEffect)(()=>{const e=localStorage.getItem("quotazioni_backup"),r=localStorage.getItem("statistiche_backup");if(e)try{ce(JSON.parse(e))}catch(t){console.error("Errore nel caricamento del backup quotazioni:",t)}if(r)try{je(JSON.parse(r))}catch(t){console.error("Errore nel caricamento del backup statistiche:",t)}},[]);(0,r.useEffect)(()=>{(b.username||null!==b&&void 0!==b&&b.password)&&localStorage.setItem("scraping_credentials",JSON.stringify({username:b.username,password:(null===b||void 0===b?void 0:b.password)||""}))},[b.username,(null===b||void 0===b?void 0:b.password)||""]),(0,r.useEffect)(()=>{(async()=>{try{var e;const i=await No(n),o=(null===i||void 0===i||null===(e=i.data)||void 0===e?void 0:e.leghe)||(null===i||void 0===i?void 0:i.leghe)||[];if(g(o),l){const e=null===o||void 0===o?void 0:o.find(e=>{var r;return(null===e||void 0===e||null===(r=e.id)||void 0===r?void 0:r.toString())===l});if(e){var r;if(c(null===e||void 0===e||null===(r=e.id)||void 0===r?void 0:r.toString()),null!==e&&void 0!==e&&e.fantacalcio_url){var t;h(null===e||void 0===e?void 0:e.fantacalcio_url);const r=null===e||void 0===e||null===(t=e.fantacalcio_url)||void 0===t?void 0:t.replace(/\/$/,"");f({rose:`${r}/rose`,classifica:`${r}/classifica`,formazioni:`${r}/formazioni`})}if(null!==e&&void 0!==e&&e.fantacalcio_username&&null!==e&&void 0!==e&&e.fantacalcio_password){localStorage.getItem("scraping_credentials")||j({username:null===e||void 0===e?void 0:e.fantacalcio_username,password:null===e||void 0===e?void 0:e.fantacalcio_password})}}else a("Lega Non Trovata",`La lega con ID ${l} non \xe8 stata trovata o non hai i permessi per accedervi.`)}}catch(i){console.error("Errore caricamento leghe:",i),a("Errore di Caricamento","Impossibile caricare le leghe. Verifica la connessione e riprova.")}})()},[n,l,a]),(0,r.useEffect)(()=>{d&&(async()=>{if(d)try{const e=await jc.get(`/quotazioni/logs/${d}`,{headers:{Authorization:`Bearer ${n}`}});_e(e.data.logs||[]);const r=await jc.get(`/quotazioni/logs-stats/${d}`,{headers:{Authorization:`Bearer ${n}`}});Ce(r.data.logs||[])}catch(e){console.error("Errore caricamento log:",e)}})()},[d,n]);const ze=(e,r)=>{if("base"===e){h(r);const e=r.replace(/\/$/,"");f({rose:`${e}/rose`,classifica:`${e}/classifica`,formazioni:`${e}/formazioni`})}else f(t=>({...t,[e]:r}))},Ee=(e,r)=>{j(t=>({...t,[e]:r}))},Ae=async()=>{if(d)try{const e=await(async(e,r)=>bc("GET",`/scraping/preferiti/${e}`,{},r))(d,n);e.success?(Z(e.tornei||[]),console.log("\ud83d\udcc2 Tornei preferiti caricati:",e.tornei)):(console.error("Errore caricamento tornei preferiti:",e.message),Z([]))}catch(e){console.error("Errore caricamento tornei preferiti:",e),Z([])}},Re=async e=>{if(d)try{const r=await(async(e,r,t)=>bc("DELETE",`/scraping/preferiti/${e}/${r}`,{},t))(d,e,n);r.success?(o("\u2705 Torneo Rimosso","Torneo rimosso dai preferiti con successo."),await Ae()):a("\u274c Errore",r.message||"Errore durante la rimozione del torneo.")}catch(r){console.error("Errore rimozione torneo preferito:",r),a("\u274c Errore","Errore durante la rimozione del torneo.")}};(0,r.useEffect)(()=>{d&&Ae()},[d]);const Ne=async()=>{if(d)try{const r=await(async(e,r)=>bc("GET",`/scraping/dati-scraping/${e}`,{},r))(d,n);var e;if(console.log("DEBUG: Risposta API dati scraping:",r),r.success&&r.dati_scraping)E({lega_nome:(null===(e=r.lega)||void 0===e?void 0:e.nome)||"Lega",rose:r.dati_scraping.rose||[],classifica:r.dati_scraping.classifica||[],voti:r.dati_scraping.voti||[],formazioni:r.dati_scraping.formazioni||[],mercato:r.dati_scraping.mercato||[]});else E(null);L("default"),D("desc")}catch(r){console.error("Errore caricamento dati scraping:",r),E(null)}},Te=async()=>{if(d)try{const e=await(async(e,r)=>bc("GET",`/scraping/confronto/${e}`,{},r))(d,n);R(e)}catch(e){console.error("Errore caricamento confronto dati:",e)}};(0,r.useEffect)(()=>{d&&(Ne(),Te())},[d]);const qe=()=>{if(!F)return null;const e=W.toLowerCase().includes("scraping"),r=W.toLowerCase().includes("tornei")||W.toLowerCase().includes("recupero");return(0,gt.jsx)("div",{className:"progress-modal-overlay",children:(0,gt.jsxs)("div",{className:"progress-modal",children:[(0,gt.jsx)("h3",{children:e?"\ud83d\udd77\ufe0f Scraping in corso...":r?"\ud83d\udd0d Recupero tornei...":"\u23f3 Operazione in corso..."}),(0,gt.jsx)("div",{className:"progress-bar-container",children:(0,gt.jsx)("div",{className:"progress-bar",style:{width:`${B}%`}})}),(0,gt.jsx)("p",{className:"progress-text",children:W}),(0,gt.jsxs)("p",{className:"progress-percentage",children:[B,"%"]}),(0,gt.jsxs)("div",{className:"progress-info",children:[(0,gt.jsx)("small",{children:e?"\u23f1\ufe0f Tempo stimato: 30-60 secondi":r?"\u23f1\ufe0f Tempo stimato: 10-20 secondi":"\u23f1\ufe0f Operazione in corso..."}),(0,gt.jsx)("br",{}),(0,gt.jsx)("small",{children:"\ud83d\udd04 Non chiudere questa finestra durante l'operazione"})]})]})})};return(0,gt.jsxs)(mv,{children:[(0,gt.jsxs)(fv,{children:[(0,gt.jsx)(xv,{children:"Sync"}),(0,gt.jsx)(vv,{children:"Importa dati da siti esterni"}),(0,gt.jsx)(bv,{onClick:()=>s("/area-admin"),style:{marginTop:"1rem",background:"#6c757d"},children:"\u2190 Torna all'Area Admin"})]}),(0,gt.jsxs)("div",{className:"tabs",children:[(0,gt.jsx)("button",{className:"carica-files"===N?"active":"",onClick:()=>T("carica-files"),children:"Carica Files"}),(0,gt.jsx)("button",{className:"scraping"===N?"active":"",onClick:()=>T("scraping"),children:"Scraping"}),(0,gt.jsx)("button",{className:"dati-scraping"===N?"active":"",onClick:()=>T("dati-scraping"),children:"Dati Scraping"}),(0,gt.jsx)("button",{className:"confronto"===N?"active":"",onClick:()=>T("confronto"),children:"Confronto Dati"})]}),"carica-files"===N&&(0,gt.jsxs)("div",{className:"carica-files-section",children:[(0,gt.jsxs)("div",{className:"form-section",children:[(0,gt.jsx)("h3",{children:"Carica Files"}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Seleziona Lega:"}),(0,gt.jsxs)("select",{value:d,onChange:e=>c(e.target.value),children:[(0,gt.jsx)("option",{value:"",children:"Seleziona una lega"}),null===u||void 0===u?void 0:u.map(e=>(0,gt.jsx)("option",{value:e.id,children:(null===e||void 0===e?void 0:e.nome)||"Nome"},e.id))]})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Carica quotazioni aggiornate:"}),(0,gt.jsx)("input",{type:"file",accept:".xlsx,.xls",onChange:async e=>{const r=e.target.files[0];if(r&&d){te(!0),ne(0),ae(null),le([]);try{const e=new FormData;e.append("file",r),e.append("legaId",d);const t=await jc.post("/quotazioni/upload",e,{headers:{"Content-Type":"multipart/form-data",Authorization:`Bearer ${n}`},onUploadProgress:e=>{e.total&&ne(Math.round(100*e.loaded/e.total))}});ae(t.data),le(t.data.errors||[]),ce(t.data.backup||null),t.data.backup&&localStorage.setItem("quotazioni_backup",JSON.stringify(t.data.backup)),o("Quotazioni caricate",t.data.message)}catch(c){var t,i,s,l;ae(null),le([{motivo:(null===(t=c.response)||void 0===t||null===(i=t.data)||void 0===i?void 0:i.error)||c.message}]),a("Errore upload",(null===(s=c.response)||void 0===s||null===(l=s.data)||void 0===l?void 0:l.error)||c.message)}finally{te(!1),ne(0)}}else a("Errore","Seleziona una lega e un file Excel")},disabled:re||!d}),(0,gt.jsx)(bv,{style:{marginTop:10},disabled:re||!d,children:re?"Caricamento...":"Carica Quotazioni Aggiornate"}),(0,gt.jsx)("div",{style:{fontSize:"0.95em",color:"#666",marginTop:8},children:"Carica le quotazioni aggiornate dal sito. Queste aggiorneranno tutte le quotazioni dei calciatori nel sistema."}),re&&(0,gt.jsxs)("div",{style:{marginTop:10},children:[(0,gt.jsx)("div",{style:{width:"100%",background:"#eee",borderRadius:6,height:10,marginBottom:4},children:(0,gt.jsx)("div",{style:{width:ie+"%",background:"#007bff",height:10,borderRadius:6}})}),(0,gt.jsxs)("div",{style:{fontSize:"0.9em",color:"#007bff"},children:[ie,"%"]})]})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)(bv,{onClick:async()=>{if(d&&de){ge(!0);try{const e=await jc.post("/quotazioni/restore-backup",{legaId:d,backupData:de},{headers:{Authorization:`Bearer ${n}`}});o("Backup ripristinato",e.data.message)}catch(t){var e,r;a("Errore ripristino",(null===(e=t.response)||void 0===e||null===(r=e.data)||void 0===r?void 0:r.error)||t.message)}finally{ge(!1)}}},disabled:!de||ue,style:{background:"#ffc107",color:"#333"},children:ue?"Ripristino...":"Backup"}),(0,gt.jsxs)("div",{style:{fontSize:"0.95em",color:"#666",marginTop:8},children:["Clicca in caso vuoi riassumere l'aggiornamento prima del data che \xe8 stato fatto",de&&de.timestamp&&(0,gt.jsxs)("span",{children:[" (Backup: ",new Date(de.timestamp).toLocaleString(),")"]})]})]}),oe&&(0,gt.jsxs)("div",{style:{marginTop:20},children:[(0,gt.jsx)("div",{style:{fontWeight:600,color:oe.success?"#28a745":"#dc3545"},children:oe.message}),(0,gt.jsxs)("div",{style:{fontSize:"0.95em",color:"#666",marginTop:8},children:["Giocatori aggiornati: ",(null===(e=oe.stats)||void 0===e?void 0:e.updated)||0," / ",(null===(t=oe.stats)||void 0===t?void 0:t.totalRows)||0]})]}),se&&(null===se||void 0===se?void 0:se.length)||!1]}),(0,gt.jsxs)("div",{className:"form-section",style:{marginTop:"2rem",padding:"2rem",background:"#f8f9fa",borderRadius:"12px",border:"1px solid #dee2e6"},children:[(0,gt.jsx)("h3",{style:{color:"#495057",marginBottom:"1.5rem",borderBottom:"2px solid #007bff",paddingBottom:"0.5rem"},children:"\ud83d\udcca Carica Statistiche Aggiornate"}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{style:{fontWeight:"600",color:"#495057",marginBottom:"0.5rem"},children:"File Excel con statistiche:"}),(0,gt.jsx)("input",{type:"file",accept:".xlsx,.xls",onChange:async e=>{const r=e?e.target.files[0]:pe;if(r&&d){fe(!0),ve(null);try{const e=new FormData;e.append("file",r),e.append("legaId",d);const t=await jc.post("/quotazioni/upload-stats",e,{headers:{"Content-Type":"multipart/form-data",Authorization:`Bearer ${n}`},onUploadProgress:e=>{if(e.total){const r=Math.round(100*e.loaded/e.total);console.log("Progresso upload statistiche:",r)}}});ve(t.data),je(t.data.backup),t.data.backup&&localStorage.setItem("statistiche_backup",JSON.stringify(t.data.backup)),he(null),o("Statistiche caricate",t.data.message);const i=document.querySelector('input[type="file"]');i&&(i.value="")}catch(s){var t,i;console.error("Errore caricamento statistiche:",s),ve(null),a("Errore",(null===(t=s.response)||void 0===t||null===(i=t.data)||void 0===i?void 0:i.error)||"Errore durante il caricamento delle statistiche")}finally{fe(!1)}}else a("Errore","Seleziona una lega e un file Excel")},style:{width:"100%",padding:"0.5rem",border:"1px solid #ced4da",borderRadius:"6px",fontSize:"1rem",marginBottom:"1rem"},disabled:me||!d}),(0,gt.jsx)("div",{style:{fontSize:"0.95em",color:"#666",marginTop:8},children:"Carica le statistiche aggiornate dal sito. Queste aggiorneranno tutte le statistiche dei calciatori nel sistema."}),me&&(0,gt.jsxs)("div",{style:{marginTop:10},children:[(0,gt.jsx)("div",{style:{width:"100%",background:"#eee",borderRadius:6,height:10,marginBottom:4},children:(0,gt.jsx)("div",{style:{width:"50%",background:"#28a745",height:10,borderRadius:6}})}),(0,gt.jsx)("div",{style:{fontSize:"0.9em",color:"#28a745"},children:"Caricamento in corso..."})]})]}),xe&&(0,gt.jsxs)("div",{style:{marginTop:"1.5rem",padding:"1rem",background:"#d4edda",border:"1px solid #c3e6cb",borderRadius:"6px"},children:[(0,gt.jsx)("h4",{style:{color:"#155724",marginBottom:"1rem"},children:"\u2705 Risultato Caricamento:"}),(0,gt.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(200px, 1fr))",gap:"1rem",marginBottom:"1rem"},children:[(0,gt.jsxs)("div",{style:{textAlign:"center",padding:"0.5rem",background:"#fff",borderRadius:"4px"},children:[(0,gt.jsx)("div",{style:{fontSize:"1.5rem",fontWeight:"bold",color:"#28a745"},children:xe.stats.totalRows}),(0,gt.jsx)("div",{style:{fontSize:"0.9rem",color:"#6c757d"},children:"Righe processate"})]}),(0,gt.jsxs)("div",{style:{textAlign:"center",padding:"0.5rem",background:"#fff",borderRadius:"4px"},children:[(0,gt.jsx)("div",{style:{fontSize:"1.5rem",fontWeight:"bold",color:"#007bff"},children:xe.stats.updated}),(0,gt.jsx)("div",{style:{fontSize:"0.9rem",color:"#6c757d"},children:"Giocatori aggiornati"})]}),(0,gt.jsxs)("div",{style:{textAlign:"center",padding:"0.5rem",background:"#fff",borderRadius:"4px"},children:[(0,gt.jsx)("div",{style:{fontSize:"1.5rem",fontWeight:"bold",color:"#dc3545"},children:xe.stats.errors}),(0,gt.jsx)("div",{style:{fontSize:"0.9rem",color:"#6c757d"},children:"Errori"})]})]}),(0,gt.jsxs)("div",{style:{fontSize:"0.9rem",color:"#155724"},children:[(0,gt.jsx)("strong",{children:"Backup creato:"})," ",new Date(xe.backup.timestamp).toLocaleString()]}),(0,gt.jsxs)("div",{style:{marginTop:"1rem"},children:[(0,gt.jsx)(bv,{onClick:async()=>{if(be&&d){we(!0);try{const e=await jc.post("/quotazioni/restore-backup",{legaId:d,backupData:be},{headers:{Authorization:`Bearer ${n}`}});o("Backup ripristinato",e.data.message),ve(null),je(null)}catch(t){var e,r;console.error("Errore ripristino backup statistiche:",t),a("Errore",(null===(e=t.response)||void 0===e||null===(r=e.data)||void 0===r?void 0:r.error)||"Errore durante il ripristino del backup")}finally{we(!1)}}else a("Errore","Nessun backup disponibile per le statistiche")},disabled:!be||ye,style:{background:"#ffc107",color:"#333",marginRight:"1rem"},children:ye?"Ripristino...":"Backup Statistiche"}),(0,gt.jsx)("div",{style:{fontSize:"0.9em",color:"#666",marginTop:"0.5rem"},children:"Clicca per ripristinare le statistiche precedenti al caricamento"})]}),xe.errors&&(null===(i=xe.errors)||void 0===i?void 0:i.length)||!1]})]}),(0,gt.jsxs)("div",{className:"form-section",style:{marginTop:"2rem",padding:"2rem",background:"#f8f9fa",borderRadius:"12px",border:"1px solid #dee2e6"},children:[(0,gt.jsx)("h3",{style:{color:"#495057",marginBottom:"1.5rem",borderBottom:"2px solid #007bff",paddingBottom:"0.5rem"},children:"\ud83d\udccb Log Caricamenti"}),(0,gt.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"2rem"},children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)("h4",{style:{color:"#007bff",marginBottom:"1rem"},children:"\ud83d\udcc8 Log Quotazioni"}),(0,gt.jsx)("div",{style:{maxHeight:"300px",overflowY:"auto",background:"#fff",border:"1px solid #dee2e6",borderRadius:"6px",padding:"1rem"},children:null!==ke&&void 0!==ke&&ke.length?null===ke||void 0===ke?void 0:ke.map((e,r)=>(0,gt.jsxs)("div",{style:{padding:"0.75rem",borderBottom:(null===ke||void 0===ke||ke.length,"1px solid #eee"),fontSize:"0.9rem"},children:[(0,gt.jsx)("div",{style:{fontWeight:"600",color:"#495057"},children:e.utente_nome}),(0,gt.jsx)("div",{style:{color:"#6c757d",fontSize:"0.8rem"},children:e.file_nome}),(0,gt.jsxs)("div",{style:{color:"#28a745",fontSize:"0.8rem"},children:["\u2705 ",e.giocatori_aggiornati," aggiornati, \u274c ",e.errori," errori"]}),(0,gt.jsx)("div",{style:{color:"#6c757d",fontSize:"0.75rem",fontStyle:"italic"},children:new Date(e.data_caricamento).toLocaleString()})]},r)):(0,gt.jsx)("div",{style:{color:"#6c757d",fontStyle:"italic",textAlign:"center",padding:"2rem"},children:"Nessun log disponibile"})})]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("h4",{style:{color:"#28a745",marginBottom:"1rem"},children:"\ud83d\udcca Log Statistiche"}),(0,gt.jsx)("div",{style:{maxHeight:"300px",overflowY:"auto",background:"#fff",border:"1px solid #dee2e6",borderRadius:"6px",padding:"1rem"},children:null!==Se&&void 0!==Se&&Se.length?null===Se||void 0===Se?void 0:Se.map((e,r)=>(0,gt.jsxs)("div",{style:{padding:"0.75rem",borderBottom:(null===Se||void 0===Se||Se.length,"1px solid #eee"),fontSize:"0.9rem"},children:[(0,gt.jsx)("div",{style:{fontWeight:"600",color:"#495057"},children:e.utente_nome}),(0,gt.jsx)("div",{style:{color:"#6c757d",fontSize:"0.8rem"},children:e.file_nome}),(0,gt.jsxs)("div",{style:{color:"#28a745",fontSize:"0.8rem"},children:["\u2705 ",e.giocatori_aggiornati," aggiornati, \u274c ",e.errori," errori"]}),(0,gt.jsx)("div",{style:{color:"#6c757d",fontSize:"0.75rem",fontStyle:"italic"},children:new Date(e.data_caricamento).toLocaleString()})]},r)):(0,gt.jsx)("div",{style:{color:"#6c757d",fontStyle:"italic",textAlign:"center",padding:"2rem"},children:"Nessun log disponibile"})})]})]})]})]}),"scraping"===N&&(0,gt.jsxs)("div",{className:"scraping-section",children:[(0,gt.jsxs)("div",{className:"form-section",children:[(0,gt.jsx)("h3",{children:"Configurazione Scraping"}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Seleziona Lega:"}),(0,gt.jsxs)("select",{value:d,onChange:e=>c(e.target.value),children:[(0,gt.jsx)("option",{value:"",children:"Seleziona una lega"}),null===u||void 0===u?void 0:u.map(e=>(0,gt.jsx)("option",{value:e.id,children:(null===e||void 0===e?void 0:e.nome)||"Nome"},e.id))]})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"URL Base Lega Fantacalcio:"}),(0,gt.jsx)("input",{type:"text",value:p,onChange:e=>ze("base",e.target.value),placeholder:"https://esempio-url-piattaforma"}),(0,gt.jsx)("small",{children:"Inserisci l'URL base della lega. Gli altri URL verranno generati automaticamente."})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"URL Rose:"}),(0,gt.jsx)("input",{type:"text",value:m.rose,onChange:e=>ze("rose",e.target.value),placeholder:"https://esempio-url-piattaforma/rose"})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"URL Classifica:"}),(0,gt.jsx)("input",{type:"text",value:m.classifica,onChange:e=>ze("classifica",e.target.value),placeholder:"https://esempio-url-piattaforma/classifica"})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"URL Formazioni:"}),(0,gt.jsx)("input",{type:"text",value:m.formazioni,onChange:e=>ze("formazioni",e.target.value),placeholder:"https://esempio-url-piattaforma/formazioni"})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Giornata Formazioni (opzionale):"}),(0,gt.jsx)("input",{type:"number",value:x,onChange:e=>v(e.target.value),placeholder:"1",min:"1",max:"38"}),(0,gt.jsx)("small",{children:"Inserisci il numero della giornata per le formazioni. Se lasciato vuoto, verr\xe0 usata la giornata corrente."})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Username Fantacalcio:"}),(0,gt.jsx)("input",{type:"text",value:b.username,onChange:e=>Ee("username",e.target.value),placeholder:"Inserisci username"})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Password Fantacalcio:"}),(0,gt.jsx)("input",{type:"password",value:(null===b||void 0===b?void 0:b.password)||"",onChange:e=>Ee("password",e.target.value),placeholder:"Inserisci password"})]}),b.username||(null===b||void 0===b?void 0:b.password)?(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("button",{type:"button",className:"btn btn-outline-danger",onClick:()=>{j({username:"",password:""}),localStorage.removeItem("scrapingCredentials"),o("Credenziali Rimosse","Le credenziali sono state rimosse dal browser.")},style:{fontSize:"0.9em",padding:"8px 16px"},children:"\ud83d\uddd1\ufe0f Rimuovi Credenziali Salvate"}),(0,gt.jsx)("small",{style:{display:"block",marginTop:"5px",color:"#666"},children:"Rimuove le credenziali salvate dal browser. Dovrai reinserirle alla prossima sessione."})]}):"",(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Gestione Tornei:"}),(0,gt.jsxs)("div",{className:"tournament-controls",children:[(0,gt.jsx)("button",{type:"button",className:"btn btn-warning",onClick:async()=>{if(!d||!p||!b.username||null===b||void 0===b||!b.password)return void a("Dati Mancanti","Inserisci tutti i dati richiesti per recuperare i tornei.");_(!0),U(!0),G(0),H("Recupero tornei disponibili...");const e=setInterval(()=>{G(e=>e<85?Math.floor(e+4*Math.random()+2):e)},1500);try{console.log("Recupero tornei disponibili...");const i=await(async(e,r,t,i,n)=>bc("POST","/scraping/tournaments",{lega_id:e,leagueUrl:r,username:t,password:i},n))(d,p,b.username,(null===b||void 0===b?void 0:b.password)||"",n);var r,t;if(clearInterval(e),i.success)G(100),H("Tornei recuperati con successo!"),w(i.tournaments||[]),console.log("\ud83d\udd0d DEBUG FRONTEND - Tornei ricevuti dal backend:",i.tournaments),console.log("\ud83d\udd0d DEBUG FRONTEND - Numero tornei:",(null===(r=i.tournaments)||void 0===r?void 0:r.length)||0),o("Tornei Recuperati",`Trovati ${(null===(t=i.tournaments)||void 0===t?void 0:t.length)||0} tornei disponibili.`);else G(100),H("Errore nel recupero tornei"),a("Errore Recupero Tornei",i.message||"Errore durante il recupero dei tornei")}catch(i){console.error("Errore recupero tornei:",i),clearInterval(e),G(100),H("Errore nel recupero tornei"),a("Errore Recupero Tornei",i.message)}finally{_(!1),U(!1),G(0),H("")}},disabled:k,style:{backgroundColor:"#ebb13d",borderColor:"#ebb13d",color:"white",fontWeight:"600",padding:"12px 24px",borderRadius:"8px",transition:"all 0.3s ease",minWidth:"150px"},children:k?"Recuperando...":"Recupera Tornei Disponibili"}),(null===y||void 0===y?void 0:y.length)||!1]})]}),(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"\ud83c\udfaf Tornei Preferiti:"}),(0,gt.jsxs)("div",{className:"preferiti-controls",children:[(0,gt.jsxs)("button",{type:"button",className:"btn btn-info",onClick:()=>ee(!X),style:{backgroundColor:"#17a2b8",borderColor:"#17a2b8",color:"white",fontWeight:"600",padding:"8px 16px",borderRadius:"6px",marginRight:"10px"},children:[X?"\ud83d\udd3d Nascondi":"\ud83d\udd3c Mostra"," Preferiti (",(null===J||void 0===J?void 0:J.length)||0,")"]}),(null===V||void 0===V?void 0:V.length)||!1]}),X&&(0,gt.jsx)("div",{className:"preferiti-section",children:null!==J&&void 0!==J&&J.length?(0,gt.jsxs)("div",{className:"preferiti-list",children:[(0,gt.jsx)("h5",{children:"I tuoi tornei preferiti:"}),(0,gt.jsx)("div",{className:"preferiti-buttons",children:null===J||void 0===J?void 0:J.map((e,r)=>(0,gt.jsxs)("div",{className:"preferito-item",children:[(0,gt.jsxs)("button",{type:"button",className:"btn btn-outline-primary preferito-btn",onClick:()=>{return r=e.id,console.log("\ud83d\udd0d DEBUG - toggleTournament chiamato con id:",r),console.log("\ud83d\udd0d DEBUG - selectedTournaments prima:",V),V.includes(r)?Q(null===V||void 0===V?void 0:V.filter(e=>e!==r)):Q([...V,r]),void console.log("\ud83d\udd0d DEBUG - selectedTournaments dopo:",V);var r},style:{backgroundColor:V.includes(e.id)?"#007bff":"transparent",color:V.includes(e.id)?"white":"#007bff",border:"1px solid #007bff",borderRadius:"6px",padding:"6px 12px",margin:"2px",fontSize:"0.9em",cursor:"pointer",transition:"all 0.2s ease"},children:[e.name," (ID: ",e.id,")"]}),(0,gt.jsx)("button",{type:"button",className:"btn btn-outline-danger remove-btn",onClick:()=>Re(e.id),style:{backgroundColor:"transparent",color:"#dc3545",border:"1px solid #dc3545",borderRadius:"4px",padding:"4px 8px",marginLeft:"5px",fontSize:"0.8em",cursor:"pointer"},title:"Rimuovi dai preferiti",children:"\u274c"})]},r))}),(0,gt.jsx)("div",{className:"preferiti-info",children:(0,gt.jsx)("small",{style:{color:"#666",fontStyle:"italic"},children:"\ud83d\udca1 Clicca su un torneo preferito per selezionarlo automaticamente. I tornei preferiti vengono salvati per ogni lega."})})]}):(0,gt.jsx)("div",{className:"no-preferiti",children:(0,gt.jsx)("p",{style:{color:"#666",fontStyle:"italic",margin:"10px 0"},children:'\ud83d\udcdd Nessun torneo preferito salvato. Seleziona dei tornei e clicca "Salva Selezionati come Preferiti" per salvarli.'})})})]}),(0,gt.jsxs)("div",{className:"actions",children:[(0,gt.jsx)("button",{onClick:async()=>{if(d&&b.username&&null!==b&&void 0!==b&&b.password){_(!0);try{const e=await(async(e,r,t,i)=>bc("POST","/scraping/update-credentials",{lega_id:e,username:r,password:t},i))(d,b.username,(null===b||void 0===b?void 0:b.password)||"",n);e.success?o("\u2705 Credenziali Aggiornate","Le credenziali sono state salvate nel database!"):a("\u274c Errore",e.error||"Errore durante l'aggiornamento delle credenziali.")}catch(e){console.error("Errore aggiornamento credenziali:",e),a("\u274c Errore","Errore durante l'aggiornamento delle credenziali.")}finally{_(!1)}}else a("Dati Mancanti","Seleziona una lega e inserisci username e password.")},disabled:k,children:k?"Aggiornando...":"Aggiorna Credenziali"}),(0,gt.jsx)("button",{onClick:async()=>{if(d&&p&&b.username&&null!==b&&void 0!==b&&b.password){_(!0),U(!0),G(0),H("Inizializzazione scraping...");try{if(console.log("Avvio scraping con Playwright..."),console.log("Lega:",d),console.log("URL:",p),console.log("Tornei selezionati:",V),null!==V&&void 0!==V&&V.length)if(H(`Scraping di ${(null===V||void 0===V?void 0:V.length)||0} tornei...`),null!==V&&void 0!==V&&V.length){console.log("Usando metodo batch per pi\xf9 tornei..."),G(10),H("Inizializzazione scraping batch...");const e=setInterval(()=>{G(e=>e<90?Math.floor(e+3*Math.random()+1):e)},2e3),r=await(async(e,r,t,i,n,o,a)=>bc("POST","/scraping/playwright-batch",{leagueUrl:r,scrapingUrls:t,username:i,password:n,lega_id:e,tournamentIds:o},a))(d,p,m,b.username,(null===b||void 0===b?void 0:b.password)||"",V,n);clearInterval(e),C(r),G(100),H("Scraping batch completato!"),r.success?(o("Scraping Batch Completato",r.message),await Ne(),await Te()):a("Errore Scraping Batch",r.error||"Errore durante lo scraping batch")}else{const e=V[0],r=y.find(r=>r.id===e);G(15),H(`Scraping torneo: ${(null===r||void 0===r?void 0:r.name)||e}...`);const t=setInterval(()=>{G(e=>e<85?Math.floor(e+4*Math.random()+2):e)},1500),i=await hv(d,p,m,b.username,(null===b||void 0===b?void 0:b.password)||"",n,e);clearInterval(t),C(i),G(100),H("Scraping completato!"),i.success?(o("Scraping Completato",i.message),await Ne(),await Te()):a("Errore Scraping",i.error||"Errore durante lo scraping")}else{G(20),H("Scraping senza selezione torneo...");const e=setInterval(()=>{G(e=>e<80?Math.floor(e+3*Math.random()+1):e)},1800),r=await hv(d,p,m,b.username,(null===b||void 0===b?void 0:b.password)||"",n,null);clearInterval(e),C(r),G(100),H("Scraping completato!"),r.success?(o("Scraping Completato",r.message),await Ne(),await Te()):a("Errore Scraping",r.error||"Errore durante lo scraping")}}catch(e){console.error("Errore scraping:",e),C({success:!1,error:e.message,message:"Errore durante lo scraping"}),a("Errore Scraping",e.message)}finally{_(!1),U(!1),G(0),H("")}}else a("Dati Mancanti","Seleziona una lega, inserisci l'URL e le credenziali.")},disabled:k,className:"primary",children:k?"Scraping...":"Avvia Scraping Rose"}),(0,gt.jsx)("button",{onClick:async()=>{if(d&&p&&b.username&&null!==b&&void 0!==b&&b.password){_(!0),U(!0),G(0),H("Inizializzazione scraping classifica...");try{console.log("Avvio scraping classifica con Playwright..."),console.log("Lega:",d),console.log("URL:",p),console.log("Torneo selezionato:",V[0]||"nessuno");const e=null!==V&&void 0!==V&&V.length?V[0]:null;G(20),H("Scraping classifica in corso...");const r=setInterval(()=>{G(e=>e<80?Math.floor(e+3*Math.random()+1):e)},1500),t=await(async(e,r,t,i,n,o)=>bc("POST","/scraping/playwright-classifica",{lega_id:e,leagueUrl:r,username:t,password:i,tournamentId:n},o))(d,p,b.username,(null===b||void 0===b?void 0:b.password)||"",e,n);clearInterval(r),C(t),G(100),H("Scraping classifica completato!"),t.success?(o("Classifica Scrapata",`Trovate ${t.posizioni_trovate} posizioni nella classifica`),await Ne()):a("Errore Scraping Classifica",t.message||"Errore durante lo scraping della classifica")}catch(e){console.error("Errore scraping classifica:",e),C({success:!1,error:e.message,message:"Errore durante lo scraping della classifica"}),a("Errore Scraping Classifica",e.message)}finally{_(!1),U(!1),G(0),H("")}}else a("Dati Mancanti","Seleziona una lega, inserisci l'URL e le credenziali.")},disabled:k,className:"primary",children:k?"Scraping...":"Scraping Classifica"}),(0,gt.jsx)("button",{onClick:async()=>{if(!d||!p||!b.username||null===b||void 0===b||!b.password)return void a("Dati Mancanti","Seleziona una lega, inserisci l'URL e le credenziali.");const e=prompt("Inserisci il numero della giornata (es. 1, 2, 3...):");if(e&&!isNaN(parseInt(e))){_(!0),U(!0),G(0),H("Inizializzazione scraping formazioni...");try{console.log("Avvio scraping formazioni con Playwright..."),console.log("Lega:",d),console.log("URL:",p),console.log("Giornata:",e),console.log("Torneo selezionato:",V[0]||"nessuno");const r=null!==V&&void 0!==V&&V.length?V[0]:null;G(20),H(`Scraping formazioni giornata ${e}...`);const t=setInterval(()=>{G(e=>e<80?Math.floor(e+3*Math.random()+1):e)},1500),i=await(async(e,r,t,i,n,o,a)=>bc("POST","/scraping/playwright-formazioni",{lega_id:e,leagueUrl:r,username:t,password:i,tournamentId:n,giornata:o},a))(d,p,b.username,(null===b||void 0===b?void 0:b.password)||"",r,parseInt(e),n);clearInterval(t),C(i),G(100),H("Scraping formazioni completato!"),i.success?(o("Formazioni Scrapate",`Trovate ${i.formazioni_trovate} formazioni per la giornata ${e}`),await Ne()):a("Errore Scraping Formazioni",i.message||"Errore durante lo scraping delle formazioni")}catch(r){console.error("Errore scraping formazioni:",r),C({success:!1,error:r.message,message:"Errore durante lo scraping delle formazioni"}),a("Errore Scraping Formazioni",r.message)}finally{_(!1),U(!1),G(0),H("")}}else a("Giornata Non Valida","Inserisci un numero valido per la giornata.")},disabled:k,className:"primary",children:k?"Scraping...":"Scraping Formazioni"}),(0,gt.jsx)("button",{onClick:async()=>{if(!d||!p||!b.username||null===b||void 0===b||!b.password)return void a("Dati Mancanti","Seleziona una lega, inserisci l'URL e le credenziali.");const e=prompt("Inserisci il numero della giornata per le formazioni (es. 1, 2, 3...) o premi OK per saltare:"),r=e&&!isNaN(parseInt(e))?parseInt(e):null;_(!0),U(!0),G(0),H("Inizializzazione scraping completo...");try{console.log("Avvio scraping completo con Playwright..."),console.log("Lega:",d),console.log("URL:",p),console.log("Giornata:",r||"non specificata"),console.log("Torneo selezionato:",V[0]||"nessuno");const e=null!==V&&void 0!==V&&V.length?V[0]:null;G(10),H("Scraping rose, classifica e formazioni...");const i=setInterval(()=>{G(e=>e<85?Math.floor(e+2*Math.random()+1):e)},2e3),s=await(async(e,r,t,i,n,o,a)=>bc("POST","/scraping/playwright-completo",{lega_id:e,leagueUrl:r,username:t,password:i,tournamentId:n,giornata:o},a))(d,p,b.username,(null===b||void 0===b?void 0:b.password)||"",e,r,n);if(clearInterval(i),C(s),G(100),H("Scraping completo terminato!"),s.success){var t;const e=(null===(t=s.results)||void 0===t?void 0:t.summary)||{};o("Scraping Completo",`Completato con successo!\n\u2022 Squadre: ${e.squadre_trovate||0}\n\u2022 Giocatori: ${e.giocatori_totali||0}\n\u2022 Posizioni classifica: ${e.posizioni_classifica||0}\n\u2022 Formazioni: ${e.formazioni_trovate||0}`),await Ne(),await Te()}else a("Errore Scraping Completo",s.message||"Errore durante lo scraping completo")}catch(i){console.error("Errore scraping completo:",i),C({success:!1,error:i.message,message:"Errore durante lo scraping completo"}),a("Errore Scraping Completo",i.message)}finally{_(!1),U(!1),G(0),H("")}},disabled:k,className:"primary",children:k?"Scraping...":"Scraping Completo"})]})]}),S?(0,gt.jsxs)("div",{className:"results "+(S.success?"success":"error"),children:[(0,gt.jsx)("h3",{children:"credentials"===S.type?"Test Credenziali":"url"===S.type?"Test URL":"scraping"===S.type?"Scraping Completato":"Aggiornamento Credenziali"}),(0,gt.jsx)("p",{children:S.message}),S.details&&(0,gt.jsx)("pre",{children:JSON.stringify(S.details,null,2)})]}):null]}),"dati-scraping"===N&&(0,gt.jsxs)("div",{className:"dati-scraping-section",children:[(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Seleziona Lega per visualizzare i dati di scraping:"}),(0,gt.jsxs)("select",{value:d,onChange:e=>c(e.target.value),children:[(0,gt.jsx)("option",{value:"",children:"Seleziona una lega"}),null===u||void 0===u?void 0:u.map(e=>(0,gt.jsx)("option",{value:e.id,children:(null===e||void 0===e?void 0:e.nome)||"Nome"},e.id))]})]}),(()=>{var e,r,t,i,n,o,a;if(console.log("DEBUG renderDatiScraping:",z),console.log("DEBUG sortField:",O),console.log("DEBUG sortDirection:",M),!z)return(0,gt.jsx)("p",{children:"Nessun dato di scraping disponibile per questa lega"});var s,l;(console.log("DEBUG rose disponibili:",z.rose),z.rose&&null!==(e=z.rose)&&void 0!==e&&e.length)&&(console.log("DEBUG prima squadra:",z.rose[0]),console.log("DEBUG giocatori prima squadra:",z.rose[0].giocatori),z.rose[0].giocatori&&null!==(s=z.rose[0].giocatori)&&void 0!==s&&s.length&&(console.log("DEBUG primo giocatore:",z.rose[0].giocatori[0]),console.log("DEBUG giocatori ordinati:",(!(l=z.rose[0].giocatori)||null!==l&&void 0!==l&&l.length,l))));return(0,gt.jsxs)("div",{className:"dati-scraping-container",children:[(0,gt.jsxs)("div",{className:"dati-scraping-header",children:[(0,gt.jsxs)("h3",{children:["Dati di Scraping - ",z.lega_nome]}),(0,gt.jsx)("button",{className:"refresh-button",onClick:async()=>{console.log("\ud83d\udd04 Refresh manuale dati scraping..."),await Ne(),await Te(),console.log("\u2705 Dati aggiornati manualmente")},disabled:k,children:"\ud83d\udd04 Aggiorna Dati"})]}),(0,gt.jsx)("p",{className:"info-text",children:"Dati estratti tramite scraping automatico. Questi dati sono separati dai dati ufficiali della lega."}),z.rose&&(null===(r=z.rose)||void 0===r?void 0:r.length)||!1,z.classifica&&(null===(t=z.classifica)||void 0===t?void 0:t.length)||!1,z.formazioni&&(null===(i=z.formazioni)||void 0===i?void 0:i.length)||!1,(!z.rose||null===(n=z.rose)||void 0===n||n.length,!z.classifica||null===(o=z.classifica)||void 0===o||o.length,!z.formazioni||null===(a=z.formazioni)||void 0===a||a.length,(0,gt.jsxs)("div",{className:"no-data-message",children:[(0,gt.jsx)("p",{children:"\ud83d\udced Nessun dato di scraping disponibile per questa lega"}),(0,gt.jsx)("p",{children:"Esegui lo scraping per iniziare a raccogliere dati"})]}))]})})()]}),"confronto"===N&&(0,gt.jsxs)("div",{className:"confronto-section",children:[(0,gt.jsxs)("div",{className:"form-group",children:[(0,gt.jsx)("label",{children:"Seleziona Lega per confrontare i dati:"}),(0,gt.jsxs)("select",{value:d,onChange:e=>c(e.target.value),children:[(0,gt.jsx)("option",{value:"",children:"Seleziona una lega"}),null===u||void 0===u?void 0:u.map(e=>(0,gt.jsx)("option",{value:e.id,children:(null===e||void 0===e?void 0:e.nome)||"Nome"},e.id))]})]}),A?(0,gt.jsxs)("div",{className:"confronto-dati",children:[(0,gt.jsx)("h3",{children:"Confronto: Dati Ufficiali vs Dati Scraping"}),(0,gt.jsxs)("div",{className:"confronto-stats",children:[(0,gt.jsxs)("div",{className:"stat-card",children:[(0,gt.jsx)("h4",{children:"Dati Ufficiali (Excel)"}),(0,gt.jsxs)("p",{children:["Squadre: ",A.confronto.squadre_ufficiali]}),(0,gt.jsxs)("p",{children:["Giocatori: ",A.confronto.giocatori_ufficiali]})]}),(0,gt.jsxs)("div",{className:"stat-card",children:[(0,gt.jsx)("h4",{children:"Dati Scraping"}),(0,gt.jsxs)("p",{children:["Squadre: ",A.confronto.squadre_scraping]}),(0,gt.jsxs)("p",{children:["Giocatori: ",A.confronto.giocatori_scraping]})]}),(0,gt.jsxs)("div",{className:"stat-card",children:[(0,gt.jsx)("h4",{children:"Corrispondenze"}),(0,gt.jsxs)("p",{children:["Squadre comuni: ",A.confronto.squadre_comuni]}),(0,gt.jsxs)("p",{children:["Giocatori comuni: ",A.confronto.giocatori_comuni]})]})]}),(0,gt.jsxs)("div",{className:"differenze",children:[(0,gt.jsx)("h4",{children:"Differenze Principali:"}),(0,gt.jsxs)("ul",{children:[(0,gt.jsxs)("li",{children:[(0,gt.jsx)("strong",{children:"Dati Ufficiali:"})," Caricati tramite file Excel durante la creazione della lega"]}),(0,gt.jsxs)("li",{children:[(0,gt.jsx)("strong",{children:"Dati Scraping:"})," Ottenuti tramite scraping automatico, salvati separatamente"]}),(0,gt.jsxs)("li",{children:[(0,gt.jsx)("strong",{children:"Separazione:"})," I due set di dati non si sovrascrivono mai"]}),(0,gt.jsxs)("li",{children:[(0,gt.jsx)("strong",{children:"Scopo:"})," I dati di scraping sono utilizzati per altri scopi (aggiornamenti, confronti, ecc.)"]})]})]})]}):(0,gt.jsx)("p",{children:"Nessun dato di confronto disponibile"})]}),(0,gt.jsx)(qe,{}),Object.entries(K).map(e=>{let[r,t]=e;return(0,gt.jsxs)("div",{style:{margin:"2rem 0"},children:[(0,gt.jsxs)("h3",{children:["Classifica ",r]}),(0,gt.jsxs)("table",{className:"table table-striped",children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)("th",{children:"Pos"}),(0,gt.jsx)("th",{children:"Squadra"}),(0,gt.jsx)("th",{children:"Partite"}),(0,gt.jsx)("th",{children:"V"}),(0,gt.jsx)("th",{children:"N"}),(0,gt.jsx)("th",{children:"P"}),(0,gt.jsx)("th",{children:"GF"}),(0,gt.jsx)("th",{children:"GS"}),(0,gt.jsx)("th",{children:"DR"}),(0,gt.jsx)("th",{children:"Punti"}),(0,gt.jsx)("th",{children:"Punti Totali"})]})}),(0,gt.jsx)("tbody",{children:Array.isArray(t)&&(null===t||void 0===t?void 0:t.map((e,r)=>(0,gt.jsxs)("tr",{children:[(0,gt.jsx)("td",{children:e.posizione}),(0,gt.jsx)("td",{children:e.squadra}),(0,gt.jsx)("td",{children:e.partite}),(0,gt.jsx)("td",{children:e.vittorie}),(0,gt.jsx)("td",{children:e.pareggi}),(0,gt.jsx)("td",{children:e.sconfitte}),(0,gt.jsx)("td",{children:e.golFatti}),(0,gt.jsx)("td",{children:e.golSubiti}),(0,gt.jsx)("td",{children:e.differenzaReti}),(0,gt.jsx)("td",{children:e.punti}),(0,gt.jsx)("td",{children:e.puntiTotali})]},r)))})]})]},r)})]})},wv=Ie.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
`,kv=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  text-align: center;
`,_v=Ie.h1`
  color: #333;
  margin: 0 0 1rem 0;
  font-size: 2.5rem;
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,Sv=Ie.p`
  color: #666;
  font-size: 1.1rem;
  margin: 0;
`,Cv=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
`,zv=Ie.h2`
  color: #333;
  margin: 0 0 1.5rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Ev=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,Av=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,Rv=Ie.label`
  font-weight: 600;
  color: #333;
`,Nv=Ie.input`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #FFA94D;
  }
`,Tv=Ie.button`
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,qv=Ie.div`
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #FFA94D;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`,Pv=Ie.div`
  padding: 1rem;
  border-radius: 8px;
  margin-top: 1rem;
  background: ${e=>e.$success?"#d4edda":"#f8d7da"};
  border: 1px solid ${e=>e.$success?"#c3e6cb":"#f5c6cb"};
  color: ${e=>e.$success?"#155724":"#721c24"};
`,$v=()=>{const{token:e}=Si(),{showErrorModal:t,showSuccessModal:i}=zi(),{legaId:n}=Pr(),o=qr(),[a,s]=(0,r.useState)(null),[l,d]=(0,r.useState)({username:"",password:""}),[c,u]=(0,r.useState)(!1),[g,p]=(0,r.useState)(null);(0,r.useEffect)(()=>{n&&(async()=>{try{var r;const i=await No(e),a=(null===i||void 0===i||null===(r=i.data)||void 0===r?void 0:r.leghe)||(null===i||void 0===i?void 0:i.leghe)||[],l=null===a||void 0===a?void 0:a.find(e=>{var r;return(null===e||void 0===e||null===(r=e.id)||void 0===r?void 0:r.toString())===n});l?(s(l),d({username:(null===l||void 0===l?void 0:l.fantacalcio_username)||"",password:(null===l||void 0===l?void 0:l.fantacalcio_password)||""})):(t("Lega Non Trovata","La lega richiesta non \xe8 stata trovata."),o("/scraping-manager"))}catch(i){console.error("Errore caricamento lega:",i),t("Errore di Caricamento","Impossibile caricare i dati della lega.")}})()},[n,e,t,o]);return a?(0,gt.jsxs)(wv,{children:[(0,gt.jsxs)(kv,{children:[(0,gt.jsx)(_v,{children:"\ud83d\udd10 Gestione Credenziali Scraping"}),(0,gt.jsxs)(Sv,{children:["Configura le credenziali per ",(null===a||void 0===a?void 0:a.nome)||"Nome"]}),(0,gt.jsx)(Tv,{onClick:()=>o("/scraping-manager"),style:{marginTop:"1rem",background:"#6c757d"},children:"\u2190 Torna alla Gestione Scraping"})]}),(0,gt.jsxs)(Cv,{children:[(0,gt.jsx)(zv,{children:"\u2699\ufe0f Credenziali piattaforma esterna"}),(0,gt.jsxs)(Ev,{onSubmit:async r=>{if(r.preventDefault(),l.username&&null!==l&&void 0!==l&&l.password){u(!0);try{const r=await ni.put(`/leghe/${n}/scraping-credentials`,l,e);if(r.ok){var o;i("\u2705 Credenziali Aggiornate","Le credenziali sono state aggiornate con successo! Ora puoi testarle.");const r=await No(e),t=(null===r||void 0===r||null===(o=r.data)||void 0===o?void 0:o.leghe)||(null===r||void 0===r?void 0:r.leghe)||[],a=null===t||void 0===t?void 0:t.find(e=>{var r;return(null===e||void 0===e||null===(r=e.id)||void 0===r?void 0:r.toString())===n});a&&(s(a),p(null))}else{const e=r.data;t("\u274c Errore Aggiornamento",e.error||"Errore durante l'aggiornamento delle credenziali")}}catch(a){t("\u274c Errore di Connessione",`Errore: ${a.message}`)}finally{u(!1)}}else t("Campi Mancanti","Inserisci sia username che password.")},children:[(0,gt.jsxs)(Av,{children:[(0,gt.jsx)(Rv,{children:"Username"}),(0,gt.jsx)(Nv,{type:"text",value:l.username,onChange:e=>d(r=>({...r,username:e.target.value})),placeholder:"Inserisci username piattaforma esterna",required:!0})]}),(0,gt.jsxs)(Av,{children:[(0,gt.jsx)(Rv,{children:"Password"}),(0,gt.jsx)(Nv,{type:"password",value:(null===l||void 0===l?void 0:l.password)||"",onChange:e=>d(r=>({...r,password:e.target.value})),placeholder:"Inserisci password piattaforma esterna",required:!0})]}),(0,gt.jsxs)("div",{style:{display:"flex",gap:"1rem",flexWrap:"wrap"},children:[(0,gt.jsx)(Tv,{type:"submit",disabled:c,children:c?(0,gt.jsx)(qv,{}):"\ud83d\udcbe Salva Credenziali"}),(0,gt.jsx)(Tv,{type:"button",onClick:async()=>{if(a&&a.fantacalcio_url){u(!0),p(null);try{var r;const t=await No(e),a=(null===t||void 0===t||null===(r=t.data)||void 0===r?void 0:r.leghe)||(null===t||void 0===t?void 0:t.leghe)||[],c=null===a||void 0===a?void 0:a.find(e=>{var r;return(null===e||void 0===e||null===(r=e.id)||void 0===r?void 0:r.toString())===n});if(!c)throw new Error("Impossibile caricare i dati aggiornati della lega");const u={leagueUrl:c.fantacalcio_url,username:c.fantacalcio_username,password:c.fantacalcio_password,lega_id:n},g=await ni.post("/scraping/puppeteer/league",u,e);if(g.ok){var i,o,s,l,d;const e=g.data;let r=`\u2705 Credenziali valide! Connessione riuscita. Trovate ${(null===(i=e.data)||void 0===i||null===(o=i.summary)||void 0===o?void 0:o.squadre_trovate)||0} squadre con ${(null===(s=e.data)||void 0===s||null===(l=s.summary)||void 0===l?void 0:l.giocatori_totali)||0} giocatori totali.`;null!==(d=e.data)&&void 0!==d&&d.database&&(r+=`\n\n\ud83d\udcbe Salvataggio nel database:\n\u2022 ${e.data.database.squadre_salvate} squadre salvate\n\u2022 ${e.data.database.giocatori_salvati} giocatori salvati`),p({success:!0,message:r})}else{const e=g.data;p({success:!1,message:`\u274c Test fallito: ${e.error||"Errore sconosciuto"}`})}}catch(c){p({success:!1,message:`\u274c Errore di connessione: ${c.message}`})}finally{u(!1)}}else t("Configurazione Mancante","Questa lega non ha configurato l'URL di scraping.")},disabled:c||!a.fantacalcio_url,style:{background:"#28a745"},children:c?(0,gt.jsx)(qv,{}):"\ud83e\uddea Testa Credenziali"})]})]}),g&&(0,gt.jsx)(Pv,{$success:g.success,children:g.message})]}),(0,gt.jsxs)(Cv,{children:[(0,gt.jsx)(zv,{children:"\u2139\ufe0f Informazioni"}),(0,gt.jsxs)("div",{style:{lineHeight:"1.6"},children:[(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"URL Lega:"})," ",a.fantacalcio_url||"Non configurato"]}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Username attuale:"})," ",a.fantacalcio_username||"Non configurato"]}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Password:"})," ",a.fantacalcio_password?"***":"Non configurata"]})]})]})]}):(0,gt.jsx)(wv,{children:(0,gt.jsxs)("div",{style:{textAlign:"center",padding:"2rem"},children:[(0,gt.jsx)(qv,{}),(0,gt.jsx)("p",{children:"Caricamento..."})]})})},Iv=Ie.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`,Ov=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 2px solid #f0f0f0;
`,Lv=Ie.h1`
  color: #333;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Mv=Ie.button`
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,Dv=Ie.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`,Fv=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border: 1px solid #f0f0f0;
`,Uv=Ie.h3`
  color: #333;
  margin: 0 0 1rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Bv=Ie.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
`,Gv=Ie.th`
  background: #f8f9fa;
  padding: 0.75rem;
  text-align: left;
  font-weight: 600;
  color: #333;
  border-bottom: 2px solid #dee2e6;
`,Wv=Ie.td`
  padding: 0.75rem;
  border-bottom: 1px solid #dee2e6;
  color: #333;
`,Hv=Ie.tr`
  &:hover {
    background: #f8f9fa;
  }
`,Vv=Ie.span`
  background: ${e=>{switch(e.$status){case"giocata":return"#28a745";case"programmata":return"#ffc107";case"in_corso":return"#17a2b8";default:return"#6c757d"}}};
  color: white;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-size: 0.75rem;
  font-weight: 600;
`,Qv=Ie.form`
  display: flex;
  gap: 1rem;
  align-items: center;
  margin-bottom: 1rem;
`,Kv=Ie.input`
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
`,Yv=(Ie.select`
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
`,()=>{const{legaId:e}=Pr(),t=qr(),{token:i}=Si(),[n,o]=(0,r.useState)([]),[a,s]=(0,r.useState)(null),[l,d]=(0,r.useState)(!0),[c,u]=(0,r.useState)(1);(0,r.useEffect)(()=>{g()},[e]);const g=async()=>{try{const r=await wc(e,i);o(r.tornei)}catch(r){console.error("Errore caricamento tornei:",r)}finally{d(!1)}},p=async e=>{try{const r=await kc(e,i);s(r)}catch(r){console.error("Errore caricamento dettaglio torneo:",r)}};return l?(0,gt.jsx)(Iv,{children:"Caricamento tornei..."}):(0,gt.jsxs)(Iv,{children:[(0,gt.jsxs)(Ov,{children:[(0,gt.jsx)(Lv,{children:"\ud83c\udfc6 Gestione Tornei"}),(0,gt.jsx)(Mv,{onClick:()=>{t(`/lega/${e}/nuovo-torneo`)},children:"Nuovo Torneo"})]}),(0,gt.jsxs)(Dv,{children:[(0,gt.jsxs)(Fv,{children:[(0,gt.jsx)(Uv,{children:"\ud83d\udccb Lista Tornei"}),0===n.length?(0,gt.jsx)("p",{children:"Nessun torneo creato"}):(0,gt.jsx)("div",{children:n.map(e=>(0,gt.jsxs)("div",{style:{padding:"1rem",border:"1px solid #ddd",borderRadius:"8px",marginBottom:"1rem",cursor:"pointer",backgroundColor:(null===a||void 0===a?void 0:a.torneo.id)===e.id?"#f8f9fa":"white"},onClick:()=>p(e.id),children:[(0,gt.jsx)("h4",{children:e.nome}),(0,gt.jsxs)("p",{children:["Tipo: ",e.tipo]}),(0,gt.jsxs)("p",{children:["Stato: ",(0,gt.jsx)(Vv,{$status:e.stato,children:e.stato})]}),(0,gt.jsxs)("p",{children:["Giornate: ",e.partite_giocate||0,"/",e.partite_totali||0]})]},e.id))})]}),a&&(0,gt.jsxs)(Fv,{children:[(0,gt.jsxs)(Uv,{children:["\ud83d\udcca ",a.torneo.nome]}),(0,gt.jsxs)("div",{style:{marginBottom:"1rem"},children:[(0,gt.jsxs)(Qv,{children:[(0,gt.jsx)("label",{children:"Giornata:"}),(0,gt.jsx)(Kv,{type:"number",min:"1",value:c,onChange:e=>u(parseInt(e.target.value))}),(0,gt.jsx)(Mv,{type:"button",onClick:async()=>{if(a)try{await(async(e,r,t)=>bc("POST",`/tornei/${e}/calcola-giornata`,{giornata:r},t))(a.torneo.id,c,i),await p(a.torneo.id),alert(`Giornata ${c} calcolata con successo!`)}catch(e){alert("Errore nel calcolo della giornata")}},children:"Calcola Giornata"})]}),(0,gt.jsx)(Mv,{onClick:async()=>{if(a)try{await(async(e,r)=>bc("POST",`/tornei/${e}/aggiorna-classifica`,{},r))(a.torneo.id,i),await p(a.torneo.id),alert("Classifica aggiornata con successo!")}catch(e){alert("Errore nell'aggiornamento della classifica")}},style:{marginRight:"1rem"},children:"Aggiorna Classifica"})]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("h4",{children:"\ud83c\udfc6 Classifica"}),(0,gt.jsxs)(Bv,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Gv,{children:"Pos"}),(0,gt.jsx)(Gv,{children:"Squadra"}),(0,gt.jsx)(Gv,{children:"Punti"}),(0,gt.jsx)(Gv,{children:"GF"}),(0,gt.jsx)(Gv,{children:"GS"}),(0,gt.jsx)(Gv,{children:"DR"})]})}),(0,gt.jsx)("tbody",{children:a.classifica.map((e,r)=>(0,gt.jsxs)(Hv,{children:[(0,gt.jsx)(Wv,{children:r+1}),(0,gt.jsx)(Wv,{children:e.nome}),(0,gt.jsx)(Wv,{children:e.punti_campionato}),(0,gt.jsx)(Wv,{children:e.gol_fatti}),(0,gt.jsx)(Wv,{children:e.gol_subiti}),(0,gt.jsx)(Wv,{children:e.differenza_reti})]},e.id))})]})]}),(0,gt.jsxs)("div",{style:{marginTop:"2rem"},children:[(0,gt.jsx)("h4",{children:"\ud83d\udcc5 Calendario"}),(0,gt.jsxs)(Bv,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Gv,{children:"Giornata"}),(0,gt.jsx)(Gv,{children:"Casa"}),(0,gt.jsx)(Gv,{children:"Risultato"}),(0,gt.jsx)(Gv,{children:"Trasferta"}),(0,gt.jsx)(Gv,{children:"Stato"})]})}),(0,gt.jsx)("tbody",{children:a.calendario.map(e=>(0,gt.jsxs)(Hv,{children:[(0,gt.jsx)(Wv,{children:e.giornata}),(0,gt.jsx)(Wv,{children:e.squadra_casa_nome}),(0,gt.jsx)(Wv,{children:"giocata"===e.stato?`${e.gol_casa} - ${e.gol_trasferta}`:"-"}),(0,gt.jsx)(Wv,{children:e.squadra_trasferta_nome}),(0,gt.jsx)(Wv,{children:(0,gt.jsx)(Vv,{$status:e.stato,children:e.stato})})]},e.id))})]})]})]})]})]})}),Jv=$e`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`,Zv=$e`
  from { transform: translateX(-100%); }
  to { transform: translateX(0); }
`,Xv=$e`
  0% { transform: scale(1); }
  50% { transform: scale(1.05); }
  100% { transform: scale(1); }
`,eb=Ie.div`
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 2rem;
`,rb=Ie.div`
  max-width: 1400px;
  margin: 0 auto;
  animation: ${Jv} 0.6s ease-out;
`,tb=Ie.div`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  display: flex;
  justify-content: space-between;
  align-items: center;
`,ib=Ie.h1`
  color: #2d3748;
  margin: 0;
  font-size: 2.5rem;
  font-weight: 700;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,nb=Ie.div`
  display: flex;
  gap: 1.5rem;
`,ob=Ie.div`
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  padding: 1rem 1.5rem;
  border-radius: 12px;
  text-align: center;
  min-width: 120px;
`,ab=Ie.div`
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 0.25rem;
`,sb=Ie.div`
  font-size: 0.9rem;
  opacity: 0.9;
`,lb=Ie.button`
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 10px;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
  margin-bottom: 1rem;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
  }
`,db=Ie.button`
  background: linear-gradient(135deg, #48bb78, #38a169);
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 12px;
  font-weight: 600;
  font-size: 1.1rem;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3);
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(72, 187, 120, 0.4);
  }
  
  &:disabled {
    background: #cbd5e0;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`,cb=Ie.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  
  @media (max-width: 1200px) {
    grid-template-columns: 1fr;
  }
`,ub=Ie.div`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  animation: ${Jv} 0.6s ease-out;
`,gb=Ie.div`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  animation: ${Zv} 0.4s ease-out;
`,pb=Ie.h3`
  color: #2d3748;
  margin: 0 0 1.5rem 0;
  font-size: 1.5rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,hb=Ie.div`
  display: grid;
  gap: 1rem;
  max-height: 600px;
  overflow-y: auto;
  padding-right: 0.5rem;
  
  &::-webkit-scrollbar {
    width: 6px;
  }
  
  &::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 3px;
  }
  
  &::-webkit-scrollbar-thumb {
    background: #c1c1c1;
    border-radius: 3px;
  }
  
  &::-webkit-scrollbar-thumb:hover {
    background: #a8a8a8;
  }
`,mb=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  border: 1px solid #e2e8f0;
  transition: all 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    border-color: #667eea;
  }
`,fb=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
`,xb=Ie.h4`
  color: #2d3748;
  margin: 0;
  font-size: 1.2rem;
  font-weight: 600;
`,vb=Ie.span`
  background: ${e=>{switch(e.$status){case"in_corso":return"linear-gradient(135deg, #48bb78, #38a169)";case"programmato":return"linear-gradient(135deg, #ed8936, #dd6b20)";default:return"linear-gradient(135deg, #718096, #4a5568)"}}};
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,bb=Ie.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 1rem;
`,jb=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
`,yb=Ie.span`
  font-size: 0.8rem;
  color: #718096;
  font-weight: 500;
`,wb=Ie.span`
  font-size: 0.9rem;
  color: #2d3748;
  font-weight: 600;
`,kb=Ie.div`
  display: flex;
  gap: 0.5rem;
  justify-content: flex-end;
  flex-wrap: wrap;
  min-width: 200px;
`,_b=Ie.button`
  background: ${e=>"danger"===e.$variant?"linear-gradient(135deg, #f56565, #e53e3e)":"primary"===e.$variant?"linear-gradient(135deg, #667eea, #764ba2)":"linear-gradient(135deg, #718096, #4a5568)"};
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 0.8rem;
  white-space: nowrap;
  min-width: 80px;
  
  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  }
`,Sb=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`,Cb=Ie.div`
  background: #f7fafc;
  border-radius: 12px;
  padding: 1.5rem;
  border: 1px solid #e2e8f0;
`,zb=Ie.h4`
  color: #2d3748;
  margin: 0 0 1rem 0;
  font-size: 1.1rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Eb=Ie.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`,Ab=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`,Rb=Ie.label`
  font-weight: 600;
  color: #2d3748;
  font-size: 0.9rem;
  display: flex;
  align-items: center;
  gap: 0.25rem;
  
  &::after {
    content: ${e=>e.required?'"*"':'""'};
    color: #e53e3e;
    margin-left: 0.25rem;
  }
`,Nb=Ie.input`
  padding: 0.75rem;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  font-size: 1rem;
  transition: all 0.2s ease;
  background: white;
  
  &:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  &.error {
    border-color: #e53e3e;
    box-shadow: 0 0 0 3px rgba(229, 62, 62, 0.1);
  }
`,Tb=Ie.select`
  padding: 0.75rem;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  font-size: 1rem;
  transition: all 0.2s ease;
  background: white;
  cursor: pointer;
  
  &:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  &.error {
    border-color: #e53e3e;
    box-shadow: 0 0 0 3px rgba(229, 62, 62, 0.1);
  }
`,qb=Ie.textarea`
  padding: 0.75rem;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  font-size: 1rem;
  min-height: 100px;
  resize: vertical;
  transition: all 0.2s ease;
  background: white;
  
  &:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
`,Pb=Ie.div`
  max-height: 300px;
  overflow-y: auto;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  padding: 1rem;
  background: white;
  
  &::-webkit-scrollbar {
    width: 6px;
  }
  
  &::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 3px;
  }
`,$b=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 0.5rem;
  border-bottom: 2px solid #e2e8f0;
`,Ib=Ie.span`
  font-size: 0.9rem;
  color: #667eea;
  font-weight: 600;
  background: #edf2f7;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
`,Ob=Ie.div`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin: 0.75rem 0;
  padding: 0.75rem;
  border-radius: 8px;
  transition: all 0.2s ease;
  
  &:hover {
    background: #f7fafc;
  }
`,Lb=Ie.input`
  width: 20px;
  height: 20px;
  cursor: pointer;
  accent-color: #667eea;
`,Mb=Ie.label`
  cursor: pointer;
  font-size: 0.95rem;
  color: #2d3748;
  font-weight: 500;
  flex: 1;
`,Db=Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 1rem;
`,Fb=Ie.button`
  background: linear-gradient(135deg, #48bb78, #38a169);
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3);
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(72, 187, 120, 0.4);
  }
  
  &:disabled {
    background: #cbd5e0;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`,Ub=Ie.button`
  background: linear-gradient(135deg, #718096, #4a5568);
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(113, 128, 150, 0.4);
  }
`,Bb=Ie.div`
  padding: 1rem 1.5rem;
  border-radius: 12px;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-weight: 500;
  animation: ${Jv} 0.3s ease-out;
`,Gb=Ie(Bb)`
  background: linear-gradient(135deg, #fed7d7, #feb2b2);
  color: #c53030;
  border: 1px solid #feb2b2;
`,Wb=Ie(Bb)`
  background: linear-gradient(135deg, #c6f6d5, #9ae6b4);
  color: #22543d;
  border: 1px solid #9ae6b4;
`,Hb=Ie(Bb)`
  background: linear-gradient(135deg, #fef5e7, #fbd38d);
  color: #744210;
  border: 1px solid #fbd38d;
`,Vb=Ie.div`
  text-align: center;
  font-size: 1.2rem;
  color: white;
  margin: 3rem 0;
  animation: ${Xv} 2s infinite;
`,Qb=Ie.div`
  text-align: center;
  margin: 3rem 0;
  color: #718096;
  
  h3 {
    color: #2d3748;
    margin-bottom: 0.5rem;
  }
`,Kb=()=>{var e,t;const{legaId:i}=Pr(),n=qr(),{token:o}=Si(),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)(!0),[g,p]=(0,r.useState)(!1),[h,m]=(0,r.useState)(null),[f,x]=(0,r.useState)({}),[v,b]=(0,r.useState)(""),[j,y]=(0,r.useState)(""),[w,k]=(0,r.useState)(""),[_,S]=(0,r.useState)({nome:"",tipo:"campionato",formato:"girone_unico",giornate_totali:1,descrizione:"",squadre_partecipanti:[],informazioni_utente:""}),C=(0,r.useCallback)(async()=>{try{var e,r;u(!0),y("");const[t,n]=await Promise.all([wc(i,o),Oo(i,o)]);s((null===t||void 0===t||null===(e=t.data)||void 0===e?void 0:e.tornei)||(null===t||void 0===t?void 0:t.tornei)||[]),d((null===n||void 0===n||null===(r=n.data)||void 0===r?void 0:r.squadre)||(null===n||void 0===n?void 0:n.squadre)||[])}catch(t){console.error("Errore caricamento dati:",t),y("Errore nel caricamento dei dati. Riprova pi\xf9 tardi.")}finally{u(!1)}},[i,o]);(0,r.useEffect)(()=>{C()},[C]),(0,r.useEffect)(()=>{var e;const r=window.location;if(null!==(e=r.state)&&void 0!==e&&e.editingTorneo){var t;const e=r.state.editingTorneo;m(e),S({nome:(null===e||void 0===e?void 0:e.nome)||"Nome",tipo:e.tipo||"campionato",formato:e.formato||"girone_unico",giornate_totali:e.giornate_totali||1,descrizione:e.descrizione||"",squadre_partecipanti:(null===(t=e.squadre_partecipanti)||void 0===t?void 0:t.map(e=>e.id))||[],informazioni_utente:e.informazioni_utente||""}),p(!0),x({})}},[]);const z=()=>{S({nome:"",tipo:"campionato",formato:"girone_unico",giornate_totali:1,descrizione:"",squadre_partecipanti:[],informazioni_utente:""}),x({})},E=()=>{0!==((null===l||void 0===l?void 0:l.length)||0)?(p(!0),m(null),z()):k("Non ci sono squadre disponibili in questa lega. Crea prima delle squadre.")};return c?(0,gt.jsx)(eb,{children:(0,gt.jsx)(Vb,{children:"Caricamento tornei..."})}):(0,gt.jsx)(eb,{children:(0,gt.jsxs)(rb,{children:[(0,gt.jsx)(lb,{onClick:()=>n(-1),children:"\u2190 Torna Indietro"}),(0,gt.jsxs)(tb,{children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)(ib,{children:"Gestione Tornei"}),(0,gt.jsx)("p",{style:{color:"#718096",margin:"0.5rem 0 0 0"},children:"Crea e gestisci i tornei della tua lega"})]}),(0,gt.jsxs)(nb,{children:[(0,gt.jsxs)(ob,{children:[(0,gt.jsx)(ab,{children:(null===a||void 0===a?void 0:a.length)||0}),(0,gt.jsx)(sb,{children:"Tornei"})]}),(0,gt.jsxs)(ob,{children:[(0,gt.jsx)(ab,{children:(null===l||void 0===l?void 0:l.length)||0}),(0,gt.jsx)(sb,{children:"Squadre"})]})]})]}),j&&(0,gt.jsxs)(Gb,{children:[(0,gt.jsx)("span",{children:"\u26a0\ufe0f"}),j]}),v&&(0,gt.jsxs)(Wb,{children:[(0,gt.jsx)("span",{children:"\u2705"}),v]}),w&&(0,gt.jsxs)(Hb,{children:[(0,gt.jsx)("span",{children:"\u26a0\ufe0f"}),w]}),(0,gt.jsxs)(cb,{children:[(0,gt.jsxs)(ub,{children:[(0,gt.jsx)(pb,{children:"Tornei Esistenti"}),0===(null===a||void 0===a?void 0:a.length)?(0,gt.jsxs)(Qb,{children:[(0,gt.jsx)("h3",{children:"Nessun torneo creato"}),(0,gt.jsx)("p",{children:"Crea il tuo primo torneo per iniziare a competere!"}),(0,gt.jsx)(db,{onClick:E,disabled:0===(null===l||void 0===l?void 0:l.length),children:"Crea Primo Torneo"})]}):(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1rem"},children:[(0,gt.jsxs)("span",{style:{color:"#718096",fontSize:"0.9rem"},children:[(null===a||void 0===a?void 0:a.length)||0," torneo",1!==(null===a||void 0===a?void 0:a.length)?"i":""," trovato",1!==(null===a||void 0===a?void 0:a.length)?"i":""]}),(0,gt.jsx)(db,{onClick:E,disabled:0===(null===l||void 0===l?void 0:l.length),children:"+ Nuovo Torneo"})]}),(0,gt.jsx)(hb,{children:null===a||void 0===a?void 0:a.map(e=>{var r;return(0,gt.jsxs)(mb,{children:[(0,gt.jsxs)(fb,{children:[(0,gt.jsx)(xb,{children:(null===e||void 0===e?void 0:e.nome)||"Nome"}),(0,gt.jsxs)(vb,{$status:e.stato,children:["in_corso"===e.stato&&"In Corso","programmato"===e.stato&&"Programmato","completato"===e.stato&&"Completato"]})]}),e.descrizione&&(0,gt.jsx)("p",{style:{color:"#718096",fontSize:"0.9rem",margin:"0 0 1rem 0"},children:e.descrizione}),(0,gt.jsxs)(bb,{children:[(0,gt.jsxs)(jb,{children:[(0,gt.jsx)(yb,{children:"Tipo"}),(0,gt.jsx)(wb,{children:e.tipo})]}),(0,gt.jsxs)(jb,{children:[(0,gt.jsx)(yb,{children:"Formato"}),(0,gt.jsx)(wb,{children:e.formato})]}),(0,gt.jsxs)(jb,{children:[(0,gt.jsx)(yb,{children:"Giornate"}),(0,gt.jsx)(wb,{children:e.giornate_totali})]}),(0,gt.jsxs)(jb,{children:[(0,gt.jsx)(yb,{children:"Squadre"}),(0,gt.jsx)(wb,{children:(null===(r=e.squadre_partecipanti)||void 0===r?void 0:r.length)||0})]})]}),(0,gt.jsxs)(kb,{children:[(0,gt.jsx)(_b,{onClick:()=>n(`/torneo/${e.id}`),children:"Visualizza"}),(0,gt.jsx)(_b,{$variant:"primary",onClick:()=>(e=>{var r;m(e),S({nome:(null===e||void 0===e?void 0:e.nome)||"Nome",tipo:e.tipo||"campionato",formato:e.formato||"girone_unico",giornate_totali:e.giornate_totali||1,descrizione:e.descrizione||"",squadre_partecipanti:(null===(r=e.squadre_partecipanti)||void 0===r?void 0:r.map(e=>e.id))||[],informazioni_utente:e.informazioni_utente||""}),p(!0),x({})})(e),children:"Modifica"}),(0,gt.jsx)(_b,{$variant:"danger",onClick:()=>(async e=>{if(window.confirm("Sei sicuro di voler eliminare questo torneo? Questa azione non pu\xf2 essere annullata."))try{await yc(e,o),b("Torneo eliminato con successo!"),await C(),setTimeout(()=>b(""),3e3)}catch(r){console.error("Errore eliminazione torneo:",r),y("Errore nell'eliminazione del torneo. Riprova pi\xf9 tardi.")}})(e.id),children:"Elimina"})]})]},e.id)})})]})]}),g&&(0,gt.jsxs)(gb,{children:[(0,gt.jsx)(pb,{children:h?"Modifica Torneo":"Nuovo Torneo"}),(0,gt.jsxs)(Sb,{onSubmit:async e=>{if(e.preventDefault(),y(""),b(""),k(""),(()=>{var e,r;const t={};return null!==_&&void 0!==_&&null!==(e=_.nome)&&void 0!==e&&e.trim()||(t.nome="Il nome del torneo \xe8 obbligatorio"),_.giornate_totali<1&&(t.giornate_totali="Le giornate totali devono essere almeno 1"),((null===(r=_.squadre_partecipanti)||void 0===r?void 0:r.length)||0)<2&&(t.squadre_partecipanti="Seleziona almeno 2 squadre per il torneo"),x(t),0===Object.keys(t).length})())try{const e={..._,lega_id:i,squadre_partecipanti:_.squadre_partecipanti};h?(await(async(e,r,t)=>bc("PUT",`/tornei/${e}`,r,t))(h.id,e,o),b("Torneo aggiornato con successo!")):(await(async(e,r)=>bc("POST","/tornei",e,r))(e,o),b("Torneo creato con successo!")),p(!1),m(null),z(),await C(),setTimeout(()=>b(""),3e3)}catch(r){console.error("Errore salvataggio torneo:",r),y("Errore nel salvataggio del torneo. Riprova pi\xf9 tardi.")}else y("Correggi gli errori nel form prima di procedere.")},children:[(0,gt.jsxs)(Cb,{children:[(0,gt.jsx)(zb,{children:"Informazioni Base"}),(0,gt.jsx)(Eb,{children:(0,gt.jsxs)(Ab,{children:[(0,gt.jsx)(Rb,{required:!0,children:"Nome Torneo"}),(0,gt.jsx)(Nb,{type:"text",value:(null===_||void 0===_?void 0:_.nome)||"Nome",onChange:e=>S(r=>({...r,nome:e.target.value})),className:null!==f&&void 0!==f&&f.nome?"error":"",placeholder:"Es: Campionato 2024"}),(null===f||void 0===f?void 0:f.nome)&&(0,gt.jsx)("div",{style:{color:"#e53e3e",fontSize:"0.8rem"},children:null===f||void 0===f?void 0:f.nome})]})}),(0,gt.jsxs)(Ab,{children:[(0,gt.jsx)(Rb,{children:"Descrizione"}),(0,gt.jsx)(qb,{value:_.descrizione,onChange:e=>S(r=>({...r,descrizione:e.target.value})),placeholder:"Descrizione del torneo..."})]})]}),(0,gt.jsxs)(Cb,{children:[(0,gt.jsx)(zb,{children:"Configurazione"}),(0,gt.jsxs)(Eb,{children:[(0,gt.jsxs)(Ab,{children:[(0,gt.jsx)(Rb,{children:"Tipo Torneo"}),(0,gt.jsxs)(Tb,{value:_.tipo,onChange:e=>S(r=>({...r,tipo:e.target.value})),children:[(0,gt.jsx)("option",{value:"campionato",children:"Campionato"}),(0,gt.jsx)("option",{value:"coppa",children:"Coppa"}),(0,gt.jsx)("option",{value:"amichevole",children:"Amichevole"}),(0,gt.jsx)("option",{value:"playoff",children:"Playoff"})]})]}),(0,gt.jsxs)(Ab,{children:[(0,gt.jsx)(Rb,{children:"Formato"}),(0,gt.jsxs)(Tb,{value:_.formato,onChange:e=>S(r=>({...r,formato:e.target.value})),children:[(0,gt.jsx)("option",{value:"girone_unico",children:"Girone Unico"}),(0,gt.jsx)("option",{value:"andata_ritorno",children:"Andata e Ritorno"}),(0,gt.jsx)("option",{value:"eliminazione",children:"Eliminazione Diretta"}),(0,gt.jsx)("option",{value:"misto",children:"Misto"})]})]}),(0,gt.jsxs)(Ab,{children:[(0,gt.jsx)(Rb,{required:!0,children:"Giornate Totali"}),(0,gt.jsx)(Nb,{type:"number",min:"1",value:_.giornate_totali,onChange:e=>S(r=>({...r,giornate_totali:parseInt(e.target.value)})),className:f.giornate_totali?"error":""}),f.giornate_totali&&(0,gt.jsx)("div",{style:{color:"#e53e3e",fontSize:"0.8rem"},children:f.giornate_totali})]})]})]}),(0,gt.jsxs)(Cb,{children:[(0,gt.jsx)(zb,{children:"Squadre Partecipanti"}),(0,gt.jsxs)(Pb,{children:[(0,gt.jsxs)($b,{children:[(0,gt.jsx)("span",{children:"Squadre disponibili"}),(0,gt.jsxs)(Ib,{children:[(null===(e=_.squadre_partecipanti)||void 0===e?void 0:e.length)||0," selezionate di ",(null===l||void 0===l?void 0:l.length)||0]})]}),null===l||void 0===l?void 0:l.map(e=>(0,gt.jsxs)(Ob,{children:[(0,gt.jsx)(Lb,{type:"checkbox",id:`squadra-${e.id}`,checked:_.squadre_partecipanti.includes(e.id),onChange:()=>(e=>{var r;S(r=>{var t;return{...r,squadre_partecipanti:r.squadre_partecipanti.includes(e)?null===(t=r.squadre_partecipanti)||void 0===t?void 0:t.filter(r=>r!==e):[...r.squadre_partecipanti,e]}}),((null===(r=_.squadre_partecipanti)||void 0===r?void 0:r.length)||0)>=1&&x(e=>({...e,squadre_partecipanti:void 0}))})(e.id)}),(0,gt.jsxs)(Mb,{htmlFor:`squadra-${e.id}`,children:[(null===e||void 0===e?void 0:e.nome)||"Nome",e.proprietario_username&&(0,gt.jsxs)("span",{style:{color:"#718096",fontSize:"0.8rem"},children:[" ","(",e.proprietario_username,")"]})]})]},e.id))]}),f.squadre_partecipanti&&(0,gt.jsx)("div",{style:{color:"#e53e3e",fontSize:"0.8rem"},children:f.squadre_partecipanti})]}),(0,gt.jsxs)(Cb,{children:[(0,gt.jsx)(zb,{children:"Informazioni Utenti"}),(0,gt.jsxs)(Ab,{children:[(0,gt.jsx)(Rb,{children:"Informazioni per gli Utenti"}),(0,gt.jsx)(qb,{value:_.informazioni_utente,onChange:e=>S(r=>({...r,informazioni_utente:e.target.value})),placeholder:"Informazioni che verranno mostrate agli utenti quando visualizzano il torneo..."})]})]}),(0,gt.jsxs)(Db,{children:[(0,gt.jsx)(Ub,{type:"button",onClick:()=>{p(!1),m(null),z(),y(""),b(""),k("")},children:"Annulla"}),(0,gt.jsx)(Fb,{type:"submit",disabled:((null===(t=_.squadre_partecipanti)||void 0===t?void 0:t.length)||0)<2,children:h?"Aggiorna Torneo":"Crea Torneo"})]})]})]})]})]})})},Yb=Ie.div`
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 2rem;
`,Jb=Ie.div`
  max-width: 1400px;
  margin: 0 auto;
`,Zb=Ie.div`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
`,Xb=Ie.h1`
  color: #2d3748;
  margin: 0 0 0.5rem 0;
  font-size: 2.5rem;
  font-weight: 700;
  background: linear-gradient(135deg, #667eea, #764ba2);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,ej=Ie.p`
  color: #718096;
  margin: 0;
  font-size: 1.1rem;
`,rj=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-top: 1.5rem;
`,tj=Ie.div`
  background: #f7fafc;
  padding: 1rem;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
`,ij=Ie.div`
  font-size: 0.8rem;
  color: #718096;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 0.25rem;
`,nj=Ie.div`
  font-size: 1.1rem;
  color: #2d3748;
  font-weight: 600;
`,oj=Ie.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  
  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
`,aj=Ie.div`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
`,sj=Ie.h3`
  color: #2d3748;
  margin: 0 0 1.5rem 0;
  font-size: 1.5rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,lj=Ie.div`
  display: grid;
  gap: 1rem;
`,dj=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  border: 1px solid #e2e8f0;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    border-color: #667eea;
  }
`,cj=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`,uj=Ie.h4`
  color: #2d3748;
  margin: 0;
  font-size: 1.2rem;
  font-weight: 600;
`,gj=Ie.span`
  background: #edf2f7;
  color: #4a5568;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 500;
`,pj=Ie.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
`,hj=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
`,mj=Ie.span`
  font-size: 0.8rem;
  color: #718096;
  font-weight: 500;
`,fj=Ie.span`
  font-size: 0.9rem;
  color: #2d3748;
  font-weight: 600;
`,xj=Ie.table`
  width: 100%;
  border-collapse: collapse;
`,vj=Ie.th`
  background: #f8f9fa;
  padding: 1rem;
  text-align: left;
  font-weight: 600;
  color: #495057;
  border-bottom: 2px solid #dee2e6;
  font-size: 0.9rem;
`,bj=Ie.td`
  padding: 1rem;
  border-bottom: 1px solid #f1f3f4;
  color: #2d3748;
  vertical-align: middle;
`,jj=Ie.tr`
  transition: all 0.2s ease;
  
  &:hover {
    background: #f8f9fa;
  }
`,yj=Ie.span`
  background: ${e=>1===e.$pos?"linear-gradient(135deg, #ffd700, #ffed4e)":2===e.$pos?"linear-gradient(135deg, #c0c0c0, #e2e8f0)":3===e.$pos?"linear-gradient(135deg, #cd7f32, #d69e2e)":"#f7fafc"};
  color: ${e=>e.$pos<=3?"#2d3748":"#718096"};
  padding: 0.25rem 0.5rem;
  border-radius: 6px;
  font-size: 0.8rem;
  font-weight: 600;
  min-width: 30px;
  text-align: center;
  display: inline-block;
`,wj=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,kj=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  border: 1px solid #e2e8f0;
`,_j=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
`,Sj=Ie.span`
  background: #667eea;
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
`,Cj=Ie.span`
  font-size: 0.8rem;
  color: #718096;
`,zj=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
`,Ej=Ie.div`
  flex: 1;
  text-align: ${e=>e.$align||"left"};
  font-weight: 600;
  color: #2d3748;
`,Aj=Ie.div`
  background: #f7fafc;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  font-weight: 700;
  color: #2d3748;
  min-width: 60px;
  text-align: center;
`,Rj=Ie.div`
  font-weight: 700;
  color: #718096;
`,Nj=Ie.div`
  text-align: center;
  font-size: 1.2rem;
  color: white;
  margin: 3rem 0;
`,Tj=Ie.div`
  text-align: center;
  margin: 3rem 0;
  color: #718096;
  
  h3 {
    color: #2d3748;
    margin-bottom: 0.5rem;
  }
`,qj=Ie.button`
  background: linear-gradient(135deg, #718096, #4a5568);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-bottom: 1rem;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(113, 128, 150, 0.4);
  }
`,Pj=Ie.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 1rem;
`,$j=Ie.button`
  background: ${e=>"primary"===e.$variant?"linear-gradient(135deg, #667eea, #764ba2)":"danger"===e.$variant?"linear-gradient(135deg, #e53e3e, #c53030)":"linear-gradient(135deg, #718096, #4a5568)"};
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
  }
`,Ij=()=>{var e,t,i,n;const{torneoId:o}=Pr(),a=qr(),{token:s,user:l}=Si(),[d,c]=(0,r.useState)(null),[u,g]=(0,r.useState)(!0),[p,h]=(0,r.useState)(""),[m,f]=(0,r.useState)(!1);(0,r.useEffect)(()=>{x()},[o]);const x=async()=>{try{g(!0),h("");const e=await kc(o,s);c(e.torneo),e.torneo&&l&&f("admin"===(null===l||void 0===l?void 0:l.ruolo)||"superadmin"===(null===l||void 0===l?void 0:l.ruolo))}catch(p){console.error("Errore caricamento torneo:",p),h("Errore nel caricamento del torneo. Riprova pi\xf9 tardi.")}finally{g(!1)}};if(u)return(0,gt.jsx)(Yb,{children:(0,gt.jsx)(Nj,{children:"Caricamento torneo..."})});if(p)return(0,gt.jsx)(Yb,{children:(0,gt.jsx)(Jb,{children:(0,gt.jsx)("div",{style:{background:"rgba(255, 255, 255, 0.95)",padding:"2rem",borderRadius:"20px",textAlign:"center",color:"#e53e3e"},children:p})})});if(!d)return(0,gt.jsx)(Yb,{children:(0,gt.jsx)(Jb,{children:(0,gt.jsxs)(Tj,{children:[(0,gt.jsx)("h3",{children:"Torneo non trovato"}),(0,gt.jsx)("p",{children:"Il torneo richiesto non esiste o non \xe8 accessibile."})]})})});const v=(null===(e=d.squadre_partecipanti)||void 0===e?void 0:e.map((e,r)=>({posizione:r+1,squadra:e.nome,proprietario:e.proprietario_username||"N/A",punti:Math.floor(50*Math.random())+10,partite_giocate:Math.floor(20*Math.random())+5,vittorie:Math.floor(10*Math.random())+2,pareggi:Math.floor(5*Math.random())+1,sconfitte:Math.floor(5*Math.random())+1,gol_fatti:Math.floor(30*Math.random())+10,gol_subiti:Math.floor(25*Math.random())+8})).sort((e,r)=>r.punti-e.punti))||[],b=[{giornata:1,data:"15/01/2024",casa:"Squadra A",trasferta:"Squadra B",gol_casa:2,gol_trasferta:1},{giornata:1,data:"15/01/2024",casa:"Squadra C",trasferta:"Squadra D",gol_casa:0,gol_trasferta:0},{giornata:2,data:"22/01/2024",casa:"Squadra B",trasferta:"Squadra C",gol_casa:1,gol_trasferta:3}];return(0,gt.jsx)(Yb,{children:(0,gt.jsxs)(Jb,{children:[(0,gt.jsx)(qj,{onClick:()=>a(-1),children:"\u2190 Torna indietro"}),m&&(0,gt.jsxs)(Pj,{children:[(0,gt.jsx)($j,{onClick:()=>{a(`/gestione-tornei/${d.lega_id}`,{state:{editingTorneo:d}})},children:"\u270f\ufe0f Modifica Torneo"}),(0,gt.jsx)($j,{$variant:"danger",onClick:async()=>{if(window.confirm("Sei sicuro di voler eliminare questo torneo? Questa azione non pu\xf2 essere annullata."))try{await yc(o,s),alert("Torneo eliminato con successo!"),a(-1)}catch(p){console.error("Errore eliminazione torneo:",p),alert("Errore nell'eliminazione del torneo. Riprova pi\xf9 tardi.")}},children:"\ud83d\uddd1\ufe0f Elimina Torneo"})]}),(0,gt.jsxs)(Zb,{children:[(0,gt.jsx)(Xb,{children:d.nome}),(0,gt.jsx)(ej,{children:d.descrizione||"Nessuna descrizione disponibile"}),(0,gt.jsxs)(rj,{children:[(0,gt.jsxs)(tj,{children:[(0,gt.jsx)(ij,{children:"Tipo"}),(0,gt.jsx)(nj,{children:d.tipo})]}),(0,gt.jsxs)(tj,{children:[(0,gt.jsx)(ij,{children:"Formato"}),(0,gt.jsx)(nj,{children:d.formato})]}),(0,gt.jsxs)(tj,{children:[(0,gt.jsx)(ij,{children:"Stato"}),(0,gt.jsxs)(nj,{children:["in_corso"===d.stato&&"In Corso","programmato"===d.stato&&"Programmato","completato"===d.stato&&"Completato"]})]}),(0,gt.jsxs)(tj,{children:[(0,gt.jsx)(ij,{children:"Squadre"}),(0,gt.jsx)(nj,{children:(null===(t=d.squadre_partecipanti)||void 0===t?void 0:t.length)||0})]}),(0,gt.jsxs)(tj,{children:[(0,gt.jsx)(ij,{children:"Giornate"}),(0,gt.jsx)(nj,{children:d.giornate_totali})]}),(0,gt.jsxs)(tj,{children:[(0,gt.jsx)(ij,{children:"Data Inizio"}),(0,gt.jsx)(nj,{children:d.data_inizio?new Date(d.data_inizio).toLocaleDateString("it-IT"):"N/A"})]})]})]}),(0,gt.jsxs)(oj,{children:[(0,gt.jsxs)(aj,{children:[(0,gt.jsx)(sj,{children:"Classifica"}),0===v.length?(0,gt.jsxs)(Tj,{children:[(0,gt.jsx)("h3",{children:"Nessuna squadra"}),(0,gt.jsx)("p",{children:"Non ci sono squadre iscritte a questo torneo."})]}):(0,gt.jsxs)(xj,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(vj,{children:"Pos"}),(0,gt.jsx)(vj,{children:"Squadra"}),(0,gt.jsx)(vj,{children:"P"}),(0,gt.jsx)(vj,{children:"PG"}),(0,gt.jsx)(vj,{children:"V"}),(0,gt.jsx)(vj,{children:"P"}),(0,gt.jsx)(vj,{children:"S"}),(0,gt.jsx)(vj,{children:"GF"}),(0,gt.jsx)(vj,{children:"GS"})]})}),(0,gt.jsx)("tbody",{children:v.map((e,r)=>(0,gt.jsxs)(jj,{children:[(0,gt.jsx)(bj,{children:(0,gt.jsx)(yj,{$pos:e.posizione,children:e.posizione})}),(0,gt.jsx)(bj,{children:(0,gt.jsxs)("div",{children:[(0,gt.jsx)("div",{style:{fontWeight:"600",color:"#2d3748"},children:e.squadra}),(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#718096"},children:e.proprietario})]})}),(0,gt.jsx)(bj,{style:{fontWeight:"700",color:"#2d3748"},children:e.punti}),(0,gt.jsx)(bj,{children:e.partite_giocate}),(0,gt.jsx)(bj,{style:{color:"#28a745"},children:e.vittorie}),(0,gt.jsx)(bj,{style:{color:"#ffc107"},children:e.pareggi}),(0,gt.jsx)(bj,{style:{color:"#dc3545"},children:e.sconfitte}),(0,gt.jsx)(bj,{children:e.gol_fatti}),(0,gt.jsx)(bj,{children:e.gol_subiti})]},r))})]})]}),(0,gt.jsxs)(aj,{children:[(0,gt.jsx)(sj,{children:"Ultimi Risultati"}),0===b.length?(0,gt.jsxs)(Tj,{children:[(0,gt.jsx)("h3",{children:"Nessun risultato"}),(0,gt.jsx)("p",{children:"Non ci sono ancora risultati disponibili."})]}):(0,gt.jsx)(wj,{children:b.map((e,r)=>(0,gt.jsxs)(kj,{children:[(0,gt.jsxs)(_j,{children:[(0,gt.jsxs)(Sj,{children:["Giornata ",e.giornata]}),(0,gt.jsx)(Cj,{children:e.data})]}),(0,gt.jsxs)(zj,{children:[(0,gt.jsx)(Ej,{children:e.casa}),(0,gt.jsx)(Aj,{children:e.gol_casa}),(0,gt.jsx)(Rj,{children:"-"}),(0,gt.jsx)(Aj,{children:e.gol_trasferta}),(0,gt.jsx)(Ej,{$align:"right",children:e.trasferta})]})]},r))})]})]}),(0,gt.jsxs)(aj,{style:{marginTop:"2rem"},children:[(0,gt.jsx)(sj,{children:"Squadre Partecipanti"}),0===(null===(i=d.squadre_partecipanti)||void 0===i?void 0:i.length)?(0,gt.jsxs)(Tj,{children:[(0,gt.jsx)("h3",{children:"Nessuna squadra"}),(0,gt.jsx)("p",{children:"Non ci sono squadre iscritte a questo torneo."})]}):(0,gt.jsx)(lj,{children:null===(n=d.squadre_partecipanti)||void 0===n?void 0:n.map((e,r)=>{var t,i;return(0,gt.jsxs)(dj,{children:[(0,gt.jsxs)(cj,{children:[(0,gt.jsx)(uj,{children:null===e||void 0===e?void 0:e.nome}),(0,gt.jsx)(gj,{children:(null===e||void 0===e?void 0:e.proprietario_username)||"Non assegnata"})]}),(0,gt.jsxs)(pj,{children:[(0,gt.jsxs)(hj,{children:[(0,gt.jsx)(mj,{children:"Valore Squadra"}),(0,gt.jsxs)(fj,{children:["FM ",(null===e||void 0===e||null===(t=e.valore_squadra)||void 0===t?void 0:t.toLocaleString())||"0"]})]}),(0,gt.jsxs)(hj,{children:[(0,gt.jsx)(mj,{children:"Casse Societarie"}),(0,gt.jsxs)(fj,{children:["FM ",(null===e||void 0===e||null===(i=e.casse_societarie)||void 0===i?void 0:i.toLocaleString())||"0"]})]}),(0,gt.jsxs)(hj,{children:[(0,gt.jsx)(mj,{children:"Giocatori"}),(0,gt.jsx)(fj,{children:(null===e||void 0===e?void 0:e.numero_giocatori)||"N/A"})]}),(0,gt.jsxs)(hj,{children:[(0,gt.jsx)(mj,{children:"Stato"}),(0,gt.jsx)(fj,{children:null!==e&&void 0!==e&&e.is_orfana?"Disponibile":"Assegnata"})]})]})]},(null===e||void 0===e?void 0:e.id)||r)})})]})]})})},Oj=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`,Lj=Ie.button`
  background: none;
  border: none;
  color: #666;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 2rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    color: #FFA94D;
  }
`,Mj=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
`,Dj=Ie.h1`
  color: #333;
  margin: 0 0 1rem 0;
  font-size: 2.5rem;
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
`,Fj=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
`,Uj=Ie.form`
  display: flex;
  gap: 1rem;
  align-items: end;
`,Bj=Ie.div`
  flex: 1;
`,Gj=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  color: #333;
  font-weight: 600;
`,Wj=Ie.select`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  background: white;
`,Hj=(Ie.button`
  background: linear-gradient(135deg, #FFA94D 0%, #FF8C42 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-1px);
  }
`,Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  margin-bottom: 2rem;
`),Vj=Ie.h2`
  color: #333;
  margin: 0 0 2rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Qj=Ie.div`
  overflow-x: auto;
`,Kj=Ie.table`
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
`,Yj=Ie.th`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 1rem;
  text-align: left;
  font-weight: 600;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,Jj=Ie.td`
  padding: 1rem;
  border-bottom: 1px solid #eee;
  color: #333;
  
  .ruolo-badge {
    display: inline-block;
    padding: 4px 8px;
    margin: 2px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: center;
    min-width: 24px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    transition: all 0.2s ease;
  }
  
  .ruolo-badge:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
  }
  
  .ruolo-badge:last-child {
    margin-right: 0;
  }
  
  /* Ruoli Serie A Classic */
  .ruolo-p { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  .ruolo-d { 
    background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  .ruolo-c { 
    background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-a { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #c62828;
  }
  
  /* Ruoli Euroleghe Mantra */
  /* Portieri - Arancione (come P) */
  .ruolo-por { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  /* Difensori - Palette di verdi */
  .ruolo-dc { 
    background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); 
    color: white; 
    border-color: #0d4f14;
  }
  
  .ruolo-dd { 
    background: linear-gradient(135deg, #388e3c 0%, #2e7d32 100%); 
    color: white; 
    border-color: #1b5e20;
  }
  
  .ruolo-ds { 
    background: linear-gradient(135deg, #43a047 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  /* Centrocampisti - Palette di blu */
  .ruolo-b { 
    background: linear-gradient(135deg, #1565c0 0%, #0d47a1 100%); 
    color: white; 
    border-color: #002171;
  }
  
  .ruolo-e { 
    background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); 
    color: white; 
    border-color: #0d47a1;
  }
  
  .ruolo-m { 
    background: linear-gradient(135deg, #1e88e5 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-t { 
    background: linear-gradient(135deg, #42a5f5 0%, #1e88e5 100%); 
    color: white; 
    border-color: #1976d2;
  }
  
  .ruolo-w { 
    background: linear-gradient(135deg, #64b5f6 0%, #42a5f5 100%); 
    color: white; 
    border-color: #1e88e5;
  }
  
  /* Attaccanti - Palette di rossi */
  .ruolo-a { 
    background: linear-gradient(135deg, #d32f2f 0%, #b71c1c 100%); 
    color: white; 
    border-color: #8e0000;
  }
  
  .ruolo-pc { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #b71c1c;
  }
  
  /* Fallback */
  .ruolo-default { 
    background: linear-gradient(135deg, #757575 0%, #616161 100%); 
    color: white; 
    border-color: #424242;
  }
`,Zj=(Ie.div`
  font-weight: 600;
  color: #333;
  margin-bottom: 0.25rem;
`,Ie.span`
  font-weight: 600;
  color: #28a745;
`),Xj=(Ie.span`
  font-weight: 600;
  color: #dc3545;
`,Ie.span`
  padding: 0.25rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 500;
  background: ${e=>e.$active?"#d4edda":"#f8d7da"};
  color: ${e=>e.$active?"#155724":"#721c24"};
`),ey=Ie.button`
  background: ${e=>e.pay?"linear-gradient(135deg, #28a745 0%, #20c997 100%)":"linear-gradient(135deg, #ffc107 0%, #fd7e14 100%)"};
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.9rem;
  cursor: pointer;
  transition: transform 0.2s;
  margin-right: 0.5rem;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,ry=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,ty=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,iy=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`,ny=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  border-left: 4px solid ${e=>e.color||"#667eea"};
`,oy=Ie.h3`
  margin: 0 0 0.5rem 0;
  color: #666;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`,ay=Ie.div`
  font-size: 2rem;
  font-weight: 700;
  color: #333;
`,sy=()=>{const{token:e}=Si(),t=qr(),[i,n]=(0,r.useState)([]),[o,a]=(0,r.useState)(""),[s,l]=(0,r.useState)([]),[d,c]=(0,r.useState)(""),[u,g]=(0,r.useState)([]),[p,h]=(0,r.useState)(!0),[m,f]=(0,r.useState)(""),[x,v]=(0,r.useState)("");(0,r.useEffect)(()=>{e&&async function(){h(!0),f("");try{var r,t;const s=await Eo(e);n((null===s||void 0===s||null===(r=s.data)||void 0===r?void 0:r.leghe)||(null===s||void 0===s?void 0:s.leghe)||[]);const l=(null===s||void 0===s||null===(t=s.data)||void 0===t?void 0:t.leghe)||(null===s||void 0===s?void 0:s.leghe)||[];var i,o;if(((null===l||void 0===l?void 0:l.length)||0)>0)a(null===(i=l[0])||void 0===i?void 0:i.id),await b(null===(o=l[0])||void 0===o?void 0:o.id)}catch(s){f(s.message)}h(!1)}()},[e]);const b=async r=>{try{var t,i;const a=await Ro(r,e);l((null===a||void 0===a||null===(t=a.data)||void 0===t?void 0:t.squadre)||(null===a||void 0===a?void 0:a.squadre)||[]);const s=(null===a||void 0===a||null===(i=a.data)||void 0===i?void 0:i.squadre)||(null===a||void 0===a?void 0:a.squadre)||[];var n,o;if(((null===s||void 0===s?void 0:s.length)||0)>0)c(null===(n=s[0])||void 0===n?void 0:n.id),await j(null===(o=s[0])||void 0===o?void 0:o.id)}catch(a){f(a.message)}},j=async r=>{try{const t=await du(r,e);let i=[];t&&t.ok&&t.data?i=t.data.giocatori||t.data||[]:t&&t.giocatori?i=t.giocatori:Array.isArray(t)?i=t:console.error("Nessun dato valido trovato per giocatori:",t),g(i)}catch(t){f(t.message)}},y=e=>e?`FM ${e.toLocaleString()}`:"FM 0";if(p)return(0,gt.jsx)(Oj,{children:(0,gt.jsx)(ry,{children:"Caricamento contratti..."})});if(m)return(0,gt.jsx)(Oj,{children:(0,gt.jsxs)(ty,{children:["Errore: ",m]})});const w=(()=>{const e=(null===u||void 0===u?void 0:u.filter(e=>(null===e||void 0===e?void 0:e.contratto_scadenza)&&new Date(e.contratto_scadenza)<new Date).length)||0,r=(null===u||void 0===u?void 0:u.filter(e=>{if(null===e||void 0===e||!e.contratto_scadenza)return!1;const r=new Date(e.contratto_scadenza)-new Date,t=Math.ceil(r/864e5);return t<=30&&t>0}).length)||0,t=(null===u||void 0===u?void 0:u.reduce((e,r)=>e+((null===r||void 0===r?void 0:r.salario)||0),0))||0,i=(null===u||void 0===u?void 0:u.filter(e=>null===e||void 0===e?void 0:e.trigger_attivo).length)||0;return{contrattiScaduti:e,contrattiInScadenza:r,costoContratti:t,triggerAttivi:i}})();return(0,gt.jsxs)(Oj,{children:[(0,gt.jsx)(Lj,{onClick:()=>t(-1),children:"\u2190 Torna indietro"}),(0,gt.jsx)(Mj,{children:(0,gt.jsx)(Dj,{children:"\ud83d\udcb0 Gestione Contratti e Trigger"})}),(0,gt.jsxs)(iy,{children:[(0,gt.jsxs)(ny,{color:"#dc3545",children:[(0,gt.jsx)(oy,{children:"Contratti Scaduti"}),(0,gt.jsx)(ay,{children:w.contrattiScaduti})]}),(0,gt.jsxs)(ny,{color:"#ffc107",children:[(0,gt.jsx)(oy,{children:"In Scadenza (30gg)"}),(0,gt.jsx)(ay,{children:w.contrattiInScadenza})]}),(0,gt.jsxs)(ny,{color:"#28a745",children:[(0,gt.jsx)(oy,{children:"Costo Contratti"}),(0,gt.jsx)(ay,{children:y(w.costoContratti)})]}),(0,gt.jsxs)(ny,{color:"#667eea",children:[(0,gt.jsx)(oy,{children:"Trigger Attivi"}),(0,gt.jsx)(ay,{children:w.triggerAttivi})]})]}),(0,gt.jsx)(Fj,{children:(0,gt.jsxs)(Uj,{onSubmit:e=>e.preventDefault(),children:[(0,gt.jsxs)(Bj,{children:[(0,gt.jsx)(Gj,{children:"Lega"}),(0,gt.jsxs)(Wj,{value:o,onChange:e=>(async e=>{a(e),await b(e)})(e.target.value),children:[(0,gt.jsx)("option",{value:"",children:"Seleziona una lega"}),null===i||void 0===i?void 0:i.map(e=>(0,gt.jsx)("option",{value:e.id,children:(null===e||void 0===e?void 0:e.nome)||"Nome"},e.id))]})]}),(0,gt.jsxs)(Bj,{children:[(0,gt.jsx)(Gj,{children:"Squadra"}),(0,gt.jsxs)(Wj,{value:d,onChange:e=>(async e=>{c(e),await j(e)})(e.target.value),children:[(0,gt.jsx)("option",{value:"",children:"Seleziona una squadra"}),null===s||void 0===s?void 0:s.map(e=>(0,gt.jsx)("option",{value:e.id,children:(null===e||void 0===e?void 0:e.nome)||"Nome"},e.id))]})]})]})}),x&&(0,gt.jsx)("div",{style:{padding:"1rem",borderRadius:"8px",marginBottom:"1rem",textAlign:"center",fontWeight:"600",backgroundColor:x.includes("successo")?"#d4edda":"#f8d7da",color:x.includes("successo")?"#155724":"#721c24",border:"1px solid "+(x.includes("successo")?"#c3e6cb":"#f5c6cb")},children:x}),(0,gt.jsxs)(Hj,{children:[(0,gt.jsx)(Vj,{children:"\ud83d\udccb Contratti e Trigger"}),0===((null===u||void 0===u?void 0:u.length)||0)?(0,gt.jsxs)("div",{style:{textAlign:"center",padding:"2rem",color:"#666"},children:[(0,gt.jsx)("h3",{children:"Nessun giocatore trovato"}),(0,gt.jsx)("p",{children:"Seleziona una squadra per visualizzare i contratti."})]}):(0,gt.jsx)(Qj,{children:(0,gt.jsxs)(Kj,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Yj,{children:"Giocatore"}),(0,gt.jsx)(Yj,{children:"Ruolo"}),(0,gt.jsx)(Yj,{children:"Salario"}),(0,gt.jsx)(Yj,{children:"Scadenza Contratto"}),(0,gt.jsx)(Yj,{children:"Trigger"}),(0,gt.jsx)(Yj,{children:"Stato"}),(0,gt.jsx)(Yj,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:null===u||void 0===u?void 0:u.map(e=>{const r=e.contratto_scadenza&&new Date(e.contratto_scadenza)<new Date,i=e.contratto_scadenza&&!r&&(new Date(e.contratto_scadenza)-new Date)/864e5<=30;return(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(Jj,{children:(0,gt.jsxs)("span",{style:{color:"#E67E22",fontWeight:700,cursor:"pointer",textDecoration:"none"},onClick:()=>t(`/giocatore/${e.id}`),children:[(null===e||void 0===e?void 0:e.nome)||"Nome"," ",(null===e||void 0===e?void 0:e.cognome)||""]})}),(0,gt.jsx)(Jj,{children:cu((null===e||void 0===e?void 0:e.ruolo)||"Ruolo").map((e,r)=>(0,gt.jsx)("span",{className:`ruolo-badge ${uu(e)}`,children:e},r))}),(0,gt.jsx)(Jj,{children:(0,gt.jsx)(Zj,{children:y(e.salario)})}),(0,gt.jsx)(Jj,{children:e.contratto_scadenza?new Date(e.contratto_scadenza).toLocaleDateString():"N/A"}),(0,gt.jsx)(Jj,{children:e.trigger_attivo&&(0,gt.jsx)(Xj,{$active:!0,children:"Attivo"})}),(0,gt.jsx)(Jj,{children:r?(0,gt.jsx)("span",{style:{color:"#dc3545",fontWeight:"600"},children:"Scaduto"}):i?(0,gt.jsx)("span",{style:{color:"#ffc107",fontWeight:"600"},children:"In Scadenza"}):(0,gt.jsx)("span",{style:{color:"#28a745",fontWeight:"600"},children:"Valido"})}),(0,gt.jsxs)(Jj,{children:[(0,gt.jsx)(ey,{pay:!0,onClick:()=>(async()=>{v("");try{v("Contratto pagato con successo per il giocatore!")}catch(e){f(e.message)}})(e.id),disabled:!r&&!i,children:"Paga"}),e.trigger_attivo&&(0,gt.jsx)(ey,{onClick:()=>(async(e,r)=>{v("");try{v(`Trigger ${r} attivato con successo!`)}catch(t){f(t.message)}})(e.id,"rinnegoziazione"),children:"Trigger"})]})]},e.id)})})]})})]})]})},ly=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f8f9fa;
  min-height: 100vh;
  
  @media (max-width: 768px) {
    padding: 0.5rem;
  }
`,dy=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  
  @media (max-width: 768px) {
    padding: 1rem;
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
`,cy=Ie.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
    gap: 0.5rem;
  }
`,uy=Ie.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  
  @media (max-width: 768px) {
    justify-content: center;
  }
`,gy=Ie.h1`
  color: #1d1d1f;
  margin: 0;
  font-size: 1.5rem;
  font-weight: 600;
  
  @media (max-width: 768px) {
    font-size: 1.3rem;
  }
  
  @media (max-width: 480px) {
    font-size: 1.1rem;
  }
`,py=Ie.button`
  background: none;
  border: none;
  color: #5856d6;
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  border-radius: 6px;
  transition: background-color 0.2s;
  
  &:hover {
    background-color: #f8f9fa;
  }
  
  @media (max-width: 768px) {
    font-size: 0.8rem;
    padding: 0.4rem;
  }
`,hy=Ie.button`
  background: #5856d6;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
  
  &:hover {
    background: #4a4a9e;
  }
  
  @media (max-width: 768px) {
    padding: 0.4rem 0.8rem;
    font-size: 0.9rem;
  }
`,my=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  align-items: center;
  
  @media (max-width: 768px) {
    padding: 1rem;
    flex-direction: column;
    align-items: stretch;
  }
`,fy=Ie.select`
  padding: 0.5rem;
  border: 1px solid #e5e5e7;
  border-radius: 6px;
  font-size: 0.9rem;
  background: white;
  min-width: 150px;
  
  @media (max-width: 768px) {
    min-width: auto;
    width: 100%;
  }
`,xy=(Ie.div`
  display: flex;
  gap: 0.5rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
  }
`,Ie.button`
  background: #28a745;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
  
  &:hover {
    background: #218838;
  }
  
  @media (max-width: 768px) {
    padding: 0.4rem 0.8rem;
    font-size: 0.9rem;
  }
`),vy=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  border-left: 4px solid ${e=>"unread"===e.$type?"#5856d6":"#e5e5e7"};
  transition: transform 0.2s;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  }
  
  @media (max-width: 768px) {
    padding: 1rem;
  }
`,by=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 0.5rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
    gap: 0.5rem;
  }
`,jy=Ie.h3`
  color: #1d1d1f;
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
  
  @media (max-width: 768px) {
    font-size: 1rem;
  }
`,yy=Ie.span`
  color: #86868b;
  font-size: 0.8rem;
  
  @media (max-width: 768px) {
    font-size: 0.75rem;
  }
`,wy=Ie.p`
  color: #666;
  margin: 0.5rem 0;
  line-height: 1.5;
  
  @media (max-width: 768px) {
    font-size: 0.9rem;
  }
`,ky=Ie.div`
  display: flex;
  gap: 0.5rem;
  margin-top: 1rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
  }
`,_y=Ie.button`
  background: ${e=>"danger"===e.$variant?"#ff3b30":"#5856d6"};
  color: white;
  border: none;
  padding: 0.4rem 0.8rem;
  border-radius: 6px;
  font-size: 0.8rem;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
  
  &:hover {
    background: ${e=>"danger"===e.$variant?"#d70015":"#4a4a9e"};
  }
  
  @media (max-width: 768px) {
    padding: 0.3rem 0.6rem;
    font-size: 0.75rem;
  }
`,Sy=Ie.div`
  text-align: center;
  padding: 3rem 1rem;
  color: #86868b;
  
  @media (max-width: 768px) {
    padding: 2rem 1rem;
  }
`,Cy=Ie.div`
  font-size: 3rem;
  margin-bottom: 1rem;
  
  @media (max-width: 768px) {
    font-size: 2.5rem;
  }
`,zy=Ie.h3`
  color: #1d1d1f;
  margin-bottom: 0.5rem;
  
  @media (max-width: 768px) {
    font-size: 1.1rem;
  }
`,Ey=Ie.p`
  color: #86868b;
  margin: 0;
  
  @media (max-width: 768px) {
    font-size: 0.9rem;
  }
`,Ay=(Ie.button`
  background: #5856d6;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 6px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
  width: 100%;
  margin-top: 1rem;
  
  &:hover {
    background: #4a4a9e;
  }
  
  @media (max-width: 768px) {
    padding: 0.6rem 1.2rem;
    font-size: 0.9rem;
  }
`,Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  cursor: pointer;
`),Ry=Ie.div`
  background: white;
  border-radius: 12px;
  max-width: 500px;
  width: 90%;
  max-height: 70vh;
  overflow-y: auto;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  cursor: default;
`,Ny=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  border-bottom: 1px solid #eee;
`,Ty=Ie.h2`
  margin: 0;
  color: #333;
  font-size: 16px;
  font-weight: 600;
`,qy=Ie.button`
  background: none;
  border: none;
  font-size: 18px;
  cursor: pointer;
  color: #666;
  padding: 0;
  width: 25px;
  height: 25px;
  display: flex;
  align-items: center;
  justify-content: center;
  
  &:hover {
    color: #333;
  }
`,Py=Ie.div`
  padding: 10px 20px;
`,$y=Ie.div`
  margin-bottom: 10px;
`,Iy=Ie.h3`
  margin: 0 0 6px 0;
  color: #333;
  font-size: 13px;
  font-weight: 600;
  border-bottom: 2px solid #ffc107;
  padding-bottom: 2px;
`,Oy=Ie.div`
  display: grid;
  gap: 6px;
`,Ly=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 4px 8px;
  background: #f8f9fa;
  border-radius: 4px;
`,My=Ie.span`
  font-weight: 600;
  color: #555;
  font-size: 11px;
`,Dy=Ie.span`
  color: #333;
  font-size: 11px;
`,Fy=Ie.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
`,Uy=Ie.div`
  padding: 6px 8px;
  background: #fff3cd;
  border-radius: 6px;
  border: 1px solid #ffeaa7;
`,By=Ie.div`
  font-weight: 600;
  color: #856404;
  margin-bottom: 3px;
  font-size: 11px;
`,Gy=Ie.div`
  color: #856404;
  font-size: 10px;
  margin-bottom: 1px;
`,Wy=Ie.div`
  color: #856404;
  font-size: 10px;
  font-weight: 600;
`,Hy=Ie.div`
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  padding: 12px 20px;
  border-top: 1px solid #eee;
`,Vy=Ie.button`
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 12px;
  
  background: ${e=>e.disabled?"#6c757d":"danger"===e.$variant?"#dc3545":"#28a745"};
  color: white;
  
  &:hover {
    background: ${e=>e.disabled?"#6c757d":"danger"===e.$variant?"#c82333":"#218838"};
  }
  
  &:disabled {
    cursor: not-allowed;
  }
`,Qy=()=>{var e,t,i,n,o,a,s,l,d,c,u,g,p,h,m,f,x,v,b,j,y,w,k,_,S,C,z,E,A,R,N,T,q,P,$,I,O,L,M;const{user:D,token:F}=Si(),U=qr(),{showNotification:B}=zi(),[G,W]=(0,r.useState)([]),[H,V]=(0,r.useState)(!0),[Q,K]=(0,r.useState)(null),[Y,J]=(0,r.useState)("tutte"),[Z,X]=(0,r.useState)(1),[ee,re]=(0,r.useState)(""),[te,ie]=(0,r.useState)(""),[ne,oe]=(0,r.useState)(""),[ae,se]=(0,r.useState)([]),[le]=(0,r.useState)(6),[de,ce]=(0,r.useState)([]),[ue,ge]=(0,r.useState)(null),[pe,he]=(0,r.useState)(!1),[me,fe]=(0,r.useState)(!1),[xe,ve]=(0,r.useState)(!1),[be,je]=(0,r.useState)(!1),[ye,we]=(0,r.useState)(!1),[ke,_e]=(0,r.useState)(!1),[Se,Ce]=(0,r.useState)(null),[ze,Ee]=(0,r.useState)(""),[Ae,Re]=(0,r.useState)(!1);(0,r.useEffect)(()=>{D&&F?(qe(),Pe(),Ne()):U("/login")},[D,F]);const Ne=async()=>{try{const e=G.filter(e=>!e.letta);e.length>0&&(await Promise.all(e.map(e=>$e(e.id))),console.log("\u2705 Tutte le notifiche marcate come lette"))}catch(Q){console.error("\u274c Errore nel marcare le notifiche come lette:",Q)}},Te=async(e,r)=>{try{var t;Re(!0);(await ni.post(`/richieste-admin/${e.id}/gestisci`,{azione:"accetta"===r?"accepted":"rejected",note_admin:ze,valore_costo:(null===(t=e.dati_richiesta)||void 0===t?void 0:t.valore_costo)||0},F)).ok?(B(`Richiesta ${"accetta"===r?"accettata":"rifiutata"} con successo!`,"success"),await qe(),_e(!1),Ce(null),Ee("")):B("Errore durante la gestione della richiesta","error")}catch(Q){console.error("Errore gestione richiesta admin:",Q),B("Errore durante la gestione della richiesta","error")}finally{Re(!1)}},qe=async()=>{try{V(!0),K(null),console.log("\ud83d\udd04 Loading notifications...");const r=await ni.get("/notifiche",F);if(console.log("\ud83d\udcca Notification response:",r),r&&(r.ok||r.notifiche)){var e;const t=(null===r||void 0===r||null===(e=r.data)||void 0===e?void 0:e.notifiche)||(null===r||void 0===r?void 0:r.notifiche)||[];if(Array.isArray(t)){const e=t.map(e=>{const r=e.dati_aggiuntivi?"string"===typeof e.dati_aggiuntivi?JSON.parse(e.dati_aggiuntivi):e.dati_aggiuntivi:{};return{...e,letta:e.letta||1===e.letto,dati_aggiuntivi:r}});W(e),ce(e.slice(0,le)),X(1),console.log("\u2705 Notifications loaded successfully")}else console.error("\u274c Invalid notifications data format:",t),K("Formato dati notifiche non valido")}else console.error("\u274c Notification API error:",r),K("Errore nel caricamento delle notifiche: "+((null===r||void 0===r?void 0:r.error)||"Errore sconosciuto"))}catch(Q){console.error("\u274c Notification loading error:",Q),K("Errore di connessione: "+Q.message)}finally{V(!1)}},Pe=async()=>{try{const r=await ni.get("/leghe/user-leagues",F);var e;if(r.ok)se((null===r||void 0===r||null===(e=r.data)||void 0===e?void 0:e.leghe)||[]);else console.error("Errore nel caricamento delle leghe:",r)}catch(Q){console.error("Errore di connessione per leghe:",Q)}},$e=async e=>{try{await ni.put(`/notifiche/${e}/letta`,{},F),W(r=>null===r||void 0===r?void 0:r.map(r=>r.id===e?{...r,letta:!0,letto:1}:r)),ce(r=>null===r||void 0===r?void 0:r.map(r=>r.id===e?{...r,letta:!0,letto:1}:r))}catch(Q){console.error("Errore marcatura notifica come letta:",Q)}},Ie=e=>{if($e(e.id),(e=>["trasferimento","prestito","scambio","offerta_inviata","offerta_ricevuta"].includes(e.tipo))(e)){if(e.dati_aggiuntivi&&"string"===typeof e.dati_aggiuntivi)try{e.dati_aggiuntivi=JSON.parse(e.dati_aggiuntivi)}catch(Q){console.error("Errore parsing dati aggiuntivi:",Q)}return ge(e),void he(!0)}switch(e.tipo){case"richiesta_ingresso":U("/gestione-richieste");break;case"richiesta_admin":Ce(e),Ee(""),_e(!0);break;case"richiesta_unione_squadra":case"risposta_richiesta_admin":case"risposta_richiesta_unione":U("/area-admin");break;default:console.log("Notifica cliccata:",e)}},Oe=e=>{switch(e){case"trasferimento":return"\ud83d\udd04 Trasferimento";case"offerta":return"\ud83d\udcb0 Offerta";case"offerta_inviata":return"\ud83d\udce4 Offerta Inviata";case"offerta_ricevuta":return"\ud83d\udce5 Offerta Ricevuta";case"sistema":return"\u2699\ufe0f Sistema";case"richiesta_ingresso":return"\ud83d\udd10 Richiesta Ingresso";case"risposta_richiesta":return"\u2705 Risposta Richiesta";case"richiesta_admin":return"\ud83d\udccb Richiesta Admin";case"risposta_richiesta_admin":return"\ud83d\udccb Risposta Richiesta Admin";case"richiesta_admin_gestita":return"\ud83d\udccb Richiesta Admin Gestita";case"richiesta_admin_annullata":return"\u274c Richiesta Admin Annullata";case"richiesta_unione_squadra":return"\ud83d\udc65 Richiesta Unione Squadra";case"risposta_richiesta_unione":return"\ud83c\udfaf Risposta Richiesta Unione";case"prestito":return"\ud83d\udce4 Prestito";case"pagamento":return"\ud83d\udcb3 Pagamento";default:return"\ud83d\udce2 Notifica"}},Le=e=>new Date(e).toLocaleString("it-IT",{day:"2-digit",month:"2-digit",year:"2-digit",hour:"2-digit",minute:"2-digit"}),Me=e=>{if(!e.dati_aggiuntivi)return null;try{let t;if(t="object"===typeof e.dati_aggiuntivi?e.dati_aggiuntivi:JSON.parse(e.dati_aggiuntivi),"offerta_ricevuta"===e.tipo||"offerta_inviata"===e.tipo){let e=[];if(t.giocatore_nome){const r=`${t.giocatore_nome}${t.giocatore_cognome?` ${t.giocatore_cognome}`:""}`;e.push(r)}if(t.giocatore_scambio_nome){const r=`${t.giocatore_scambio_nome}${t.giocatore_scambio_cognome?` ${t.giocatore_scambio_cognome}`:""}`;e.push(`\u2194\ufe0f ${r}`)}return t.valore&&t.valore>0&&e.push(`\ud83d\udcb0 ${t.valore} FM`),t.richiesta_fm&&t.richiesta_fm>0&&e.push(`\ud83d\udcb8 Richiesta: ${t.richiesta_fm} FM`),e.join(" \u2022 ")}if("richiesta_admin"===e.tipo&&"cantera"===t.tipo_richiesta){let e=[];if(t.costi_dimezzati&&"object"===typeof t.costi_dimezzati){const i=Object.entries(t.costi_dimezzati);var r;if(null!==i&&void 0!==i&&i.length)e.push(`Giocatori Selezionati: ${t.giocatori_selezionati&&(null===(r=t.giocatori_selezionati)||void 0===r?void 0:r.length)||0}`),e.push(`Costi Dimezzati: ${(null===i||void 0===i?void 0:i.length)||0} giocatori`),t.dettagli_giocatori&&"object"===typeof t.dettagli_giocatori?Object.entries(t.dettagli_giocatori).forEach(r=>{let[t,i]=r;e.push(`  \u2022 ${(null===i||void 0===i?void 0:i.nome)||"Nome"} ${(null===i||void 0===i?void 0:i.cognome)||""} (${(null===i||void 0===i?void 0:i.ruolo)||"Ruolo"})`),e.push(`    Squadra Reale: ${i.squadra_reale}`),e.push(`    QA: ${(null===i||void 0===i?void 0:i.qa)||0}`),e.push(`    QI: ${i.qi}`),e.push(`    Ingaggio Attuale: ${i.costo_attuale} FM`),e.push(`    Ingaggio Cantera: ${i.costo_dimezzato} FM`)}):t.giocatori_selezionati&&Array.isArray(t.giocatori_selezionati)&&t.giocatori_selezionati.forEach((r,i)=>{const n=t.costi_dimezzati[r];void 0!==n&&e.push(`  \u2022 Giocatore ${i+1}: ${n} FM`)})}return e.join("\n")}let i=[];return t.giocatore_nome&&t.giocatore_cognome&&i.push(`Giocatore: ${t.giocatore_nome} ${t.giocatore_cognome}`),t.giocatore_scambio_nome&&t.giocatore_scambio_cognome&&i.push(`In scambio: ${t.giocatore_scambio_nome} ${t.giocatore_scambio_cognome}`),t.squadra_mittente&&i.push(`Da: ${t.squadra_mittente}`),t.squadra_destinatario&&i.push(`A: ${t.squadra_destinatario}`),t.valore_offerta&&i.push(`Valore: ${t.valore_offerta} FM`),t.richiesta_fm&&i.push(`Richiesta: ${t.richiesta_fm} FM`),i.join(" \u2022 ")}catch(Q){return console.error("Errore parsing dati notifica:",Q),null}},De=e=>{if(!e.dati_aggiuntivi)return!1;if(e.messaggio&&(e.messaggio.includes(" - ACCETTATA")||e.messaggio.includes(" - RIFIUTATA")||e.messaggio.includes("Hai accettato l'offerta")||e.messaggio.includes("Hai rifiutato l'offerta")||e.messaggio.includes("La tua offerta \xe8 stata accettata")||e.messaggio.includes("La tua offerta \xe8 stata rifiutata")))return!1;try{let r;return r="object"===typeof e.dati_aggiuntivi?e.dati_aggiuntivi:JSON.parse(e.dati_aggiuntivi),r.offerta_id&&["trasferimento","prestito","scambio","offerta_ricevuta","offerta_inviata"].includes(e.tipo)}catch(Q){return!1}},Fe=(0,r.useMemo)(()=>null===G||void 0===G?void 0:G.filter(e=>{var r,t,i;if("tutte"===Y);else{if("non_lette"===Y&&e.letta)return!1;if("lette"===Y&&!e.letta)return!1;if(!("richieste"!==Y||null!==e&&void 0!==e&&null!==(r=e.tipo)&&void 0!==r&&r.includes("richiesta")))return!1;if("trasferimenti"===Y&&!["trasferimento","prestito","scambio"].includes(e.tipo))return!1;if(!("pagamenti"!==Y||null!==e&&void 0!==e&&null!==(t=e.tipo)&&void 0!==t&&t.includes("pagamento")))return!1;if(!("offerte"!==Y||null!==e&&void 0!==e&&null!==(i=e.tipo)&&void 0!==i&&i.includes("offerta")))return!1;if("admin"===Y&&"richiesta_admin"!==e.tipo)return!1;if("tutte"!==Y)return!1}if(ne&&(null===e||void 0===e?void 0:e.lega_id)!==parseInt(ne))return!1;if(ee||te){const r=new Date(e.data_creazione),t=r.getMonth()+1,i=r.getFullYear();if(ee&&t!==parseInt(ee))return!1;if(te&&i!==parseInt(te))return!1}return!0}),[G,Y,ee,te,ne]);(0,r.useEffect)(()=>{const e=Fe.slice(0,le);ce(e),X(1)},[Fe,le]);const Ue=null===G||void 0===G?void 0:G.filter(e=>!e.letta).length,Be=(null===G||void 0===G||G.filter(e=>e.letta).length,(()=>{const e=new Set;G.forEach(r=>{const t=new Date(r.data_creazione);e.add(t.getMonth()+1)});const r=[{value:"",label:"Tutti i mesi"}];for(let t=1;t<=12;t++)if(e.has(t)){const e=["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"];r.push({value:t.toString(),label:e[t-1]})}return r})()),Ge=((()=>{const e=new Set;G.forEach(r=>{const t=new Date(r.data_creazione);e.add(t.getFullYear())});const r=[{value:"",label:"Tutti gli anni"}];Array.from(e).sort((e,r)=>r-e).forEach(e=>{r.push({value:e.toString(),label:e.toString()})})})(),async e=>{var r;if(!ue)return;const t=null===(r=ue.dati_aggiuntivi)||void 0===r?void 0:r.offerta_id;if(t){fe(!0);try{const r=await ni.post(`/offerte/${e}/${t}`,{headers:{"Content-Type":"application/json",Authorization:`Bearer ${F}`}});if(r.ok){r.data;alert(`Offerta ${"accetta"===e?"accettata":"rifiutata"} con successo!`),ve(!0),W(r=>null===r||void 0===r?void 0:r.map(r=>r.id===ue.id?{...r,messaggio:r.messaggio+` - ${e.toUpperCase()}`}:r)),setTimeout(()=>{he(!1),ge(null),ve(!1),fe(!1),qe()},1500)}else{const e=r.data;alert(`Errore: ${e.error||"Errore sconosciuto"}`),fe(!1)}}catch(Q){console.error("Errore azione mercato:",Q),alert("Errore durante l'elaborazione della richiesta"),fe(!1)}}else alert("Errore: ID offerta non trovato")}),We=()=>{he(!1),ge(null),ve(!1),fe(!1)};return H?(0,gt.jsx)(ly,{children:(0,gt.jsx)("div",{style:{textAlign:"center",padding:"40px 20px"},children:"Caricamento notifiche..."})}):Q?(0,gt.jsx)(ly,{children:(0,gt.jsxs)("div",{style:{textAlign:"center",padding:"40px 20px",maxWidth:"600px",margin:"0 auto"},children:[(0,gt.jsxs)("div",{style:{background:"#fff3cd",border:"1px solid #ffeaa7",borderRadius:"8px",padding:"20px",marginBottom:"20px"},children:[(0,gt.jsx)("div",{style:{fontSize:"2rem",marginBottom:"10px"},children:"\u26a0\ufe0f"}),(0,gt.jsx)("h3",{style:{color:"#856404",marginBottom:"10px"},children:"Errore nel caricamento delle notifiche"}),(0,gt.jsx)("p",{style:{color:"#856404",marginBottom:"20px"},children:Q}),(0,gt.jsx)("button",{onClick:qe,style:{background:"#007bff",color:"white",border:"none",padding:"10px 20px",borderRadius:"6px",cursor:"pointer",fontSize:"0.9rem",fontWeight:"500"},children:"\ud83d\udd04 Riprova"})]}),(0,gt.jsx)("button",{onClick:()=>U(-1),style:{background:"none",border:"1px solid #6c757d",color:"#6c757d",padding:"8px 16px",borderRadius:"6px",cursor:"pointer",fontSize:"0.9rem"},children:"\u2b05\ufe0f Torna indietro"})]})}):(0,gt.jsxs)(ly,{children:[(0,gt.jsxs)(dy,{children:[(0,gt.jsxs)(cy,{children:[(0,gt.jsx)(py,{onClick:()=>U(-1),children:"\u2b05\ufe0f Torna indietro"}),(0,gt.jsx)(gy,{children:"\ud83d\udd14 Notifiche"})]}),(0,gt.jsx)(uy,{children:(0,gt.jsx)(hy,{onClick:()=>je(!0),children:"\ud83d\udce6 Archivia"})})]}),(0,gt.jsxs)(my,{children:[(0,gt.jsxs)(fy,{value:Y,onChange:e=>J(e.target.value),children:[(0,gt.jsx)("option",{value:"tutte",children:"Tutte le notifiche"}),(0,gt.jsx)("option",{value:"non_lette",children:"Non lette"}),(0,gt.jsx)("option",{value:"lette",children:"Lette"}),(0,gt.jsx)("option",{value:"richieste",children:"Richieste"}),(0,gt.jsx)("option",{value:"trasferimenti",children:"Trasferimenti & Prestiti"}),(0,gt.jsx)("option",{value:"pagamenti",children:"Pagamenti"}),(0,gt.jsx)("option",{value:"offerte",children:"Offerte"}),(0,gt.jsx)("option",{value:"admin",children:"Richieste Admin"})]}),(null===ae||void 0===ae?void 0:ae.length)||!1,(null===Be||void 0===Be?void 0:Be.length)||!1,Ue>0&&(0,gt.jsx)(xy,{onClick:async()=>{try{await ni.put("/notifiche/tutte-lette",{},F),W(e=>null===e||void 0===e?void 0:e.map(e=>({...e,letta:!0,letto:1}))),ce(e=>null===e||void 0===e?void 0:e.map(e=>({...e,letta:!0,letto:1})))}catch(Q){console.error("Errore marcatura tutte notifiche come lette:",Q)}},children:"Segna tutte come lette"}),(0,gt.jsx)(xy,{onClick:qe,children:"\ud83d\udd04 Aggiorna"})]}),0===((null===Fe||void 0===Fe?void 0:Fe.length)||0)?(0,gt.jsxs)(Sy,{children:[(0,gt.jsx)(Cy,{children:"\ud83d\udced"}),(0,gt.jsx)(zy,{children:"Nessuna notifica trovata"}),(0,gt.jsx)(Ey,{children:"Non ci sono notifiche che corrispondono ai tuoi filtri."})]}):(0,gt.jsxs)(gt.Fragment,{children:[null===de||void 0===de?void 0:de.map(e=>(0,gt.jsxs)(vy,{$type:e.letta?"read":"unread",onClick:()=>Ie(e),children:[(0,gt.jsxs)(by,{children:[(0,gt.jsx)(jy,{children:Oe(e.tipo)}),(0,gt.jsx)(yy,{children:Le(e.data_creazione)})]}),(0,gt.jsx)(wy,{children:e.messaggio}),Me(e)&&(0,gt.jsxs)("div",{style:{marginTop:"0.75rem"},children:[(0,gt.jsx)("div",{style:{background:"#f8f9fa",border:"1px solid #e9ecef",borderRadius:"6px",padding:"0.75rem",fontSize:"0.85rem",color:"#495057",whiteSpace:"pre-line",fontFamily:"monospace"},children:Me(e)}),(0,gt.jsxs)(ky,{children:[(0,gt.jsx)(_y,{$variant:De(e)?"warning":"success",onClick:r=>{r.stopPropagation(),De(e)&&Ge(De(e)?"rifiuta":"accetta")},disabled:me,children:De(e)?"Rispondi":"Segna come letta"}),e.letta&&!De(e)&&(0,gt.jsx)(_y,{$variant:"success",children:"\u2705 Letta"}),De(e)&&(0,gt.jsx)(_y,{$variant:"warning",children:"\u23f3 In attesa di risposta"})]})]})]},e.id)),(null===de||void 0===de?void 0:de.length)||0<(null===Fe||void 0===Fe?void 0:Fe.length)||0]}),pe&&ue&&(0,gt.jsx)(Ay,{onClick:We,children:(0,gt.jsxs)(Ry,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(Ny,{children:[(0,gt.jsxs)(Ty,{children:[Oe(ue.tipo)," - Dettagli Offerta"]}),(0,gt.jsx)(qy,{onClick:We,children:"\u2715"})]}),(0,gt.jsxs)(Py,{children:[(0,gt.jsxs)($y,{children:[(0,gt.jsx)(Iy,{children:"\ud83d\udccb Dettagli Offerta"}),(0,gt.jsxs)(Oy,{children:[(0,gt.jsxs)(Ly,{children:[(0,gt.jsxs)(My,{children:["Proprietario del calciatore (",(null===ue||void 0===ue||null===(e=ue.dati_aggiuntivi)||void 0===e?void 0:e.giocatore_nome)||"N/A"," ",(null===ue||void 0===ue||null===(t=ue.dati_aggiuntivi)||void 0===t?void 0:t.giocatore_cognome)||"","):"]}),(0,gt.jsxs)(Dy,{children:[(null===ue||void 0===ue||null===(i=ue.dati_aggiuntivi)||void 0===i?void 0:i.proprietario_destinatario)||"N/A"," della squadra ",(null===ue||void 0===ue||null===(n=ue.dati_aggiuntivi)||void 0===n?void 0:n.squadra_destinatario)||"N/A"]})]}),(null===ue||void 0===ue||null===(o=ue.dati_aggiuntivi)||void 0===o?void 0:o.giocatore_scambio_nome)&&(0,gt.jsxs)(Ly,{children:[(0,gt.jsxs)(My,{children:["Proprietario del calciatore (",null===ue||void 0===ue||null===(a=ue.dati_aggiuntivi)||void 0===a?void 0:a.giocatore_scambio_nome," ",(null===ue||void 0===ue||null===(s=ue.dati_aggiuntivi)||void 0===s?void 0:s.giocatore_scambio_cognome)||"","):"]}),(0,gt.jsxs)(Dy,{children:[(null===ue||void 0===ue||null===(l=ue.dati_aggiuntivi)||void 0===l?void 0:l.proprietario_mittente)||"N/A"," della squadra ",(null===ue||void 0===ue||null===(d=ue.dati_aggiuntivi)||void 0===d?void 0:d.squadra_mittente)||"N/A"]})]}),(0,gt.jsxs)(Ly,{children:[(0,gt.jsx)(My,{children:"Offerta fatta da:"}),(0,gt.jsxs)(Dy,{children:[(null===ue||void 0===ue||null===(c=ue.dati_aggiuntivi)||void 0===c?void 0:c.proprietario_mittente)||"N/A"," della squadra ",(null===ue||void 0===ue||null===(u=ue.dati_aggiuntivi)||void 0===u?void 0:u.squadra_mittente)||"N/A"]})]}),(0,gt.jsxs)(Ly,{children:[(0,gt.jsx)(My,{children:"Ricevuta da:"}),(0,gt.jsxs)(Dy,{children:[(null===ue||void 0===ue||null===(g=ue.dati_aggiuntivi)||void 0===g?void 0:g.proprietario_destinatario)||"N/A"," della squadra ",(null===ue||void 0===ue||null===(p=ue.dati_aggiuntivi)||void 0===p?void 0:p.squadra_destinatario)||"N/A"]})]})]})]}),(0,gt.jsxs)($y,{children:[(0,gt.jsx)(Iy,{children:"\ud83d\udcb0 Valori"}),(0,gt.jsxs)(Oy,{children:[(0,gt.jsxs)(Ly,{children:[(0,gt.jsx)(My,{children:"Tipo di Offerta:"}),(0,gt.jsx)(Dy,{children:"trasferimento"===(null===ue||void 0===ue||null===(h=ue.dati_aggiuntivi)||void 0===h?void 0:h.tipo_offerta)?"\ud83d\udd04 Trasferimento":"prestito"===(null===ue||void 0===ue||null===(m=ue.dati_aggiuntivi)||void 0===m?void 0:m.tipo_offerta)?"\ud83d\udce4 Prestito":"scambio"===(null===ue||void 0===ue||null===(f=ue.dati_aggiuntivi)||void 0===f?void 0:f.tipo_offerta)?"\ud83d\udd04 Scambio":(null===ue||void 0===ue||null===(x=ue.dati_aggiuntivi)||void 0===x?void 0:x.tipo_offerta)||"N/A"})]}),(0,gt.jsxs)(Ly,{children:[(0,gt.jsxs)(My,{children:["Valore Offerto da (",(null===ue||void 0===ue||null===(v=ue.dati_aggiuntivi)||void 0===v?void 0:v.squadra_mittente)||"N/A","):"]}),(0,gt.jsxs)(Dy,{children:["FM ",null!==(b=null===ue||void 0===ue||null===(j=ue.dati_aggiuntivi)||void 0===j?void 0:j.valore)&&void 0!==b?b:0]})]}),(0,gt.jsxs)(Ly,{children:[(0,gt.jsxs)(My,{children:["Valore Richiesto da (",(null===ue||void 0===ue||null===(y=ue.dati_aggiuntivi)||void 0===y?void 0:y.squadra_destinatario)||"N/A","):"]}),(0,gt.jsxs)(Dy,{children:["FM ",null!==(w=null===ue||void 0===ue||null===(k=ue.dati_aggiuntivi)||void 0===k?void 0:k.richiesta_fm)&&void 0!==w?w:0]})]})]})]}),(0,gt.jsxs)($y,{children:[(0,gt.jsx)(Iy,{children:"\ud83c\udfe6 Impatto Casse Societarie"}),(0,gt.jsxs)(Fy,{children:[(0,gt.jsxs)(Uy,{children:[(0,gt.jsx)(By,{children:"Squadra Mittente:"}),(0,gt.jsxs)(Gy,{children:["Prima: FM ",null!==(_=null===ue||void 0===ue||null===(S=ue.dati_aggiuntivi)||void 0===S?void 0:S.casse_mittente_prima)&&void 0!==_?_:"N/A"]}),(0,gt.jsxs)(Wy,{children:["Dopo: FM ",null!==(C=null===ue||void 0===ue||null===(z=ue.dati_aggiuntivi)||void 0===z?void 0:z.casse_mittente_dopo)&&void 0!==C?C:"N/A"]})]}),(0,gt.jsxs)(Uy,{children:[(0,gt.jsx)(By,{children:"Squadra Destinataria:"}),(0,gt.jsxs)(Gy,{children:["Prima: FM ",null!==(E=null===ue||void 0===ue||null===(A=ue.dati_aggiuntivi)||void 0===A?void 0:A.casse_destinatario_prima)&&void 0!==E?E:"N/A"]}),(0,gt.jsxs)(Wy,{children:["Dopo: FM ",null!==(R=null===ue||void 0===ue||null===(N=ue.dati_aggiuntivi)||void 0===N?void 0:N.casse_destinatario_dopo)&&void 0!==R?R:"N/A"]})]})]})]})]}),(0,gt.jsx)(Hy,{children:!xe&&De(ue)&&"offerta_ricevuta"===ue.tipo?(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(Vy,{$variant:"danger",onClick:()=>Ge("rifiuta"),disabled:me,children:me?"Elaborazione...":"Rifiuta Offerta"}),(0,gt.jsx)(Vy,{$variant:"success",onClick:()=>Ge("accetta"),disabled:me,children:me?"Elaborazione...":"Accetta Offerta"})]}):xe?(0,gt.jsx)("div",{style:{textAlign:"center",width:"100%",color:"#28a745",fontWeight:"600",fontSize:"14px"},children:"\u2705 Offerta processata con successo!"}):"offerta_inviata"===ue.tipo?(0,gt.jsx)("div",{style:{textAlign:"center",width:"100%",color:"#17a2b8",fontWeight:"600",fontSize:"14px"},children:"\ud83d\udce4 Offerta inviata - In attesa di risposta"}):(0,gt.jsx)("div",{style:{textAlign:"center",width:"100%",color:"#6c757d",fontWeight:"600",fontSize:"14px"},children:null!==ue&&void 0!==ue&&null!==(T=ue.messaggio)&&void 0!==T&&T.includes(" - ACCETTATA")||null!==ue&&void 0!==ue&&null!==(q=ue.messaggio)&&void 0!==q&&q.includes("Hai accettato l'offerta")||null!==ue&&void 0!==ue&&null!==(P=ue.messaggio)&&void 0!==P&&P.includes("La tua offerta \xe8 stata accettata")||null!==ue&&void 0!==ue&&null!==($=ue.messaggio)&&void 0!==$&&$.includes("\xe8 stata accettata")?"\u2705 Offerta gi\xe0 accettata":"\u274c Offerta gi\xe0 rifiutata"})})]})}),be&&(0,gt.jsx)(Ay,{onClick:()=>je(!1),children:(0,gt.jsxs)(Ry,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsx)(Ny,{children:(0,gt.jsx)(Ty,{children:"\ud83d\udce6 Archivia Notifiche"})}),(0,gt.jsxs)(Py,{children:[(0,gt.jsx)("p",{children:"Sei sicuro di voler archiviare queste notifiche?"}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Attenzione:"})," Questa azione non pu\xf2 essere annullata."]}),(0,gt.jsxs)("p",{children:["Verranno archiviate ",(0,gt.jsx)("strong",{children:(null===Fe||void 0===Fe?void 0:Fe.length)||0})," notifiche."]})]}),(0,gt.jsxs)(Hy,{children:[(0,gt.jsx)(Vy,{$variant:"danger",onClick:()=>je(!1),disabled:ye,children:"Annulla"}),(0,gt.jsx)(Vy,{$variant:"success",onClick:async()=>{if(F){we(!0);try{const e=null===Fe||void 0===Fe?void 0:Fe.map(e=>e.id);if(0===((null===e||void 0===e?void 0:e.length)||0))return void alert("Nessuna notifica da archiviare");const r=await ni.put("/notifiche/archivia",{headers:{"Content-Type":"application/json",Authorization:`Bearer ${F}`},data:{notifica_ids:e}});if(r.ok){const e=r.data;alert(`Archiviate ${e.archiviate} notifiche con successo!`),je(!1),qe()}else{const e=r.data;alert(`Errore: ${e.error}`)}}catch(e){alert("Errore di connessione")}finally{we(!1)}}},disabled:ye,children:ye?"Archiviazione...":"Conferma Archiviazione"})]})]})}),ke&&Se&&(0,gt.jsx)(Ay,{onClick:()=>_e(!1),children:(0,gt.jsxs)(Ry,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(Ny,{children:[(0,gt.jsx)(Ty,{children:"\ud83d\udccb Gestione Richiesta Admin"}),(0,gt.jsx)(qy,{onClick:()=>_e(!1),children:"\u2715"})]}),(0,gt.jsxs)(Py,{children:[(0,gt.jsxs)("div",{style:{marginBottom:"1rem"},children:[(0,gt.jsxs)("h3",{style:{margin:"0 0 0.5rem 0",color:"#1e293b"},children:["Richiesta di: ",(null===(I=Se.dati_aggiuntivi)||void 0===I?void 0:I.utente_nome)||"Utente"]}),(0,gt.jsxs)("p",{style:{margin:"0 0 0.5rem 0",color:"#64748b"},children:[(0,gt.jsx)("strong",{children:"Tipo:"})," ",(null===(O=Se.dati_aggiuntivi)||void 0===O?void 0:O.tipo_richiesta)||"N/A"]}),(0,gt.jsxs)("p",{style:{margin:"0 0 0.5rem 0",color:"#64748b"},children:[(0,gt.jsx)("strong",{children:"Data:"})," ",Le(Se.created_at)]}),(null===(L=Se.dati_aggiuntivi)||void 0===L?void 0:L.descrizione)&&(0,gt.jsxs)("p",{style:{margin:"0 0 0.5rem 0",color:"#64748b"},children:[(0,gt.jsx)("strong",{children:"Descrizione:"})," ",Se.dati_aggiuntivi.descrizione]}),(null===(M=Se.dati_aggiuntivi)||void 0===M?void 0:M.dettagli)&&(0,gt.jsxs)("div",{style:{margin:"0 0 0.5rem 0"},children:[(0,gt.jsx)("strong",{style:{color:"#64748b"},children:"Dettagli:"}),(0,gt.jsx)("pre",{style:{background:"#f8f9fa",padding:"0.5rem",borderRadius:"4px",fontSize:"0.9rem",color:"#495057",whiteSpace:"pre-wrap",margin:"0.5rem 0 0 0"},children:JSON.stringify(Se.dati_aggiuntivi.dettagli,null,2)})]})]}),(0,gt.jsxs)("div",{style:{marginBottom:"1rem"},children:[(0,gt.jsx)("label",{style:{display:"block",marginBottom:"0.5rem",fontWeight:"600",color:"#1e293b"},children:"Note (opzionale):"}),(0,gt.jsx)("textarea",{value:ze,onChange:e=>Ee(e.target.value),placeholder:"Inserisci una nota per la risposta...",style:{width:"100%",minHeight:"80px",padding:"0.5rem",border:"1px solid #d1d5db",borderRadius:"4px",fontSize:"0.9rem",fontFamily:"inherit"}})]})]}),(0,gt.jsxs)(Hy,{children:[(0,gt.jsx)(Vy,{$variant:"danger",onClick:()=>Te(Se,"rifiuta"),disabled:Ae,children:Ae?"Elaborazione...":"Rifiuta Richiesta"}),(0,gt.jsx)(Vy,{$variant:"success",onClick:()=>Te(Se,"accetta"),disabled:Ae,children:Ae?"Elaborazione...":"Accetta Richiesta"})]})]})})]})},Ky=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`,Yy=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 16px;
  border-bottom: 1px solid #eee;
`,Jy=Ie.h1`
  color: #333;
  font-size: 24px;
  font-weight: 600;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 12px;
`,Zy=Ie.button`
  padding: 8px 16px;
  background: #6c757d;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  
  &:hover {
    background: #5a6268;
  }
`,Xy=Ie.div`
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
  align-items: center;
  flex-wrap: wrap;
`,ew=Ie.select`
  padding: 6px 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  background: white;
  font-size: 13px;
  min-width: 120px;
`,rw=Ie.input`
  padding: 6px 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 13px;
`,tw=Ie.button`
  padding: 6px 12px;
  border: none;
  border-radius: 6px;
  background: #007bff;
  color: white;
  font-size: 13px;
  cursor: pointer;
  transition: all 0.2s;
  
  &:hover {
    background: #0056b3;
  }
`,iw=Ie.div`
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
`,nw=Ie.div`
  display: grid;
  grid-template-columns: 1fr 120px 100px 150px 200px;
  gap: 12px;
  padding: 12px 16px;
  background: #f8f9fa;
  border-bottom: 1px solid #dee2e6;
  font-weight: 600;
  font-size: 13px;
  color: #495057;
`,ow=Ie.div`
  display: grid;
  grid-template-columns: 1fr 120px 100px 150px 200px;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid #f1f3f4;
  font-size: 13px;
  
  &:hover {
    background: #f8f9fa;
  }
  
  &:last-child {
    border-bottom: none;
  }
`,aw=Ie.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
`,sw=Ie.div`
  font-weight: 600;
  color: #333;
`,lw=Ie.div`
  color: #666;
  font-size: 12px;
`,dw=Ie.div`
  color: #888;
  font-size: 11px;
  font-style: italic;
`,cw=Ie.span`
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  
  background: ${e=>{switch(e.categoria){case"trasferimento":return"#e3f2fd";case"contratto":return"#f3e5f5";case"offerta":return"#fff3e0";case"richiesta_admin":return"#e8f5e8";case"pagamento":return"#fce4ec";case"rinnovo":return"#e0f2f1";case"sistema":default:return"#f5f5f5";case"torneo":return"#fff8e1";case"finanza":return"#f1f8e9"}}};
  
  color: ${e=>{switch(e.categoria){case"trasferimento":return"#1565c0";case"contratto":return"#7b1fa2";case"offerta":return"#e65100";case"richiesta_admin":return"#2e7d32";case"pagamento":return"#c2185b";case"rinnovo":return"#00695c";case"sistema":default:return"#666";case"torneo":return"#f57c00";case"finanza":return"#33691e"}}};
`,uw=Ie.span`
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  
  background: ${e=>{switch(e.tipo){case"giocatore_acquistato":case"offerta_accettata":case"richiesta_admin_approvata":return"#e8f5e8";case"giocatore_venduto":case"offerta_rifiutata":case"richiesta_admin_rifiutata":return"#ffebee";case"offerta_ricevuta":return"#fff3e0";case"offerta_inviata":return"#e3f2fd";case"contratto_firmato":return"#f3e5f5";case"pagamento_effettuato":return"#e0f2f1";case"richiesta_admin_inviata":return"#fff8e1";default:return"#f5f5f5"}}};
  
  color: ${e=>{switch(e.tipo){case"giocatore_acquistato":case"offerta_accettata":case"richiesta_admin_approvata":return"#2e7d32";case"giocatore_venduto":case"offerta_rifiutata":case"richiesta_admin_rifiutata":return"#c62828";case"offerta_ricevuta":return"#e65100";case"offerta_inviata":return"#1565c0";case"contratto_firmato":return"#7b1fa2";case"pagamento_effettuato":return"#00695c";case"richiesta_admin_inviata":return"#f57c00";default:return"#666"}}};
`,gw=Ie.div`
  color: #666;
  font-size: 12px;
`,pw=Ie.div`
  color: #666;
  font-size: 12px;
`,hw=Ie.div`
  text-align: center;
  padding: 60px 20px;
  color: #666;
`,mw=Ie.div`
  text-align: center;
  padding: 40px 20px;
  color: #666;
`,fw=Ie.div`
  text-align: center;
  padding: 40px 20px;
  color: #dc3545;
`,xw=()=>{const{user:e,token:t}=Si(),i=qr(),{squadraId:n}=Pr(),[o,a]=(0,r.useState)([]),[s,l]=(0,r.useState)(!0),[d,c]=(0,r.useState)(null),[u,g]=(0,r.useState)({categoria:"",tipo_evento:"",data_inizio:"",data_fine:""});(0,r.useEffect)(()=>{e&&t&&n?p():i("/login")},[e,t,n,u]);const p=async()=>{try{l(!0);const e=new URLSearchParams;u.categoria&&e.append("categoria",u.categoria),u.tipo_evento&&e.append("tipo_evento",u.tipo_evento),u.data_inizio&&e.append("data_inizio",u.data_inizio),u.data_fine&&e.append("data_fine",u.data_fine);const r=await fetch(`https://topleaguem.onrender.com/api/log-squadra/${n}?${e}`,{headers:{Authorization:`Bearer ${t}`}});if(r.ok){const e=r.data;a(e.logs||[])}else{const e=r.data;c(e.error||"Errore nel caricamento dei log")}}catch(e){c("Errore di connessione")}finally{l(!1)}};return s?(0,gt.jsx)(Ky,{children:(0,gt.jsx)(mw,{children:"Caricamento log squadra..."})}):d?(0,gt.jsx)(Ky,{children:(0,gt.jsxs)(fw,{children:["Errore: ",d]})}):(0,gt.jsxs)(Ky,{children:[(0,gt.jsx)(Zy,{onClick:()=>i(-1),children:"\u2190 Torna indietro"}),(0,gt.jsx)(Yy,{children:(0,gt.jsx)(Jy,{children:"\ud83d\udccb Log Squadra"})}),(0,gt.jsxs)(Xy,{children:[(0,gt.jsxs)(ew,{value:u.categoria,onChange:e=>g(r=>({...r,categoria:e.target.value})),children:[(0,gt.jsx)("option",{value:"",children:"Tutte le categorie"}),(0,gt.jsx)("option",{value:"trasferimento",children:"Trasferimenti"}),(0,gt.jsx)("option",{value:"contratto",children:"Contratti"}),(0,gt.jsx)("option",{value:"offerta",children:"Offerte"}),(0,gt.jsx)("option",{value:"richiesta_admin",children:"Richieste Admin"}),(0,gt.jsx)("option",{value:"pagamento",children:"Pagamenti"}),(0,gt.jsx)("option",{value:"rinnovo",children:"Rinnovi"}),(0,gt.jsx)("option",{value:"sistema",children:"Sistema"}),(0,gt.jsx)("option",{value:"torneo",children:"Tornei"}),(0,gt.jsx)("option",{value:"finanza",children:"Finanza"})]}),(0,gt.jsxs)(ew,{value:u.tipo_evento,onChange:e=>g(r=>({...r,tipo_evento:e.target.value})),children:[(0,gt.jsx)("option",{value:"",children:"Tutti i tipi"}),(0,gt.jsx)("option",{value:"giocatore_acquistato",children:"Giocatore Acquistato"}),(0,gt.jsx)("option",{value:"giocatore_venduto",children:"Giocatore Venduto"}),(0,gt.jsx)("option",{value:"offerta_ricevuta",children:"Offerta Ricevuta"}),(0,gt.jsx)("option",{value:"offerta_inviata",children:"Offerta Inviata"}),(0,gt.jsx)("option",{value:"offerta_accettata",children:"Offerta Accettata"}),(0,gt.jsx)("option",{value:"offerta_rifiutata",children:"Offerta Rifiutata"}),(0,gt.jsx)("option",{value:"contratto_firmato",children:"Contratto Firmato"}),(0,gt.jsx)("option",{value:"pagamento_effettuato",children:"Pagamento Effettuato"}),(0,gt.jsx)("option",{value:"richiesta_admin_inviata",children:"Richiesta Admin Inviata"}),(0,gt.jsx)("option",{value:"richiesta_admin_approvata",children:"Richiesta Admin Approvata"}),(0,gt.jsx)("option",{value:"richiesta_admin_rifiutata",children:"Richiesta Admin Rifiutata"})]}),(0,gt.jsx)(rw,{type:"date",value:u.data_inizio,onChange:e=>g(r=>({...r,data_inizio:e.target.value})),placeholder:"Data inizio"}),(0,gt.jsx)(rw,{type:"date",value:u.data_fine,onChange:e=>g(r=>({...r,data_fine:e.target.value})),placeholder:"Data fine"}),(0,gt.jsx)(tw,{onClick:p,children:"\ud83d\udd04 Aggiorna"})]}),0===o.length?(0,gt.jsxs)(hw,{children:[(0,gt.jsx)("div",{style:{fontSize:"36px",marginBottom:"12px"},children:"\ud83d\udccb"}),(0,gt.jsx)("div",{children:"Nessun log trovato"})]}):(0,gt.jsxs)(iw,{children:[(0,gt.jsxs)(nw,{children:[(0,gt.jsx)("div",{children:"Evento"}),(0,gt.jsx)("div",{children:"Categoria"}),(0,gt.jsx)("div",{children:"Tipo"}),(0,gt.jsx)("div",{children:"Data"}),(0,gt.jsx)("div",{children:"Utente"})]}),o.map(e=>{return(0,gt.jsxs)(ow,{children:[(0,gt.jsxs)(aw,{children:[(0,gt.jsx)(sw,{children:e.titolo}),(0,gt.jsx)(lw,{children:e.descrizione}),e.dati_aggiuntivi&&(0,gt.jsx)(dw,{children:Object.entries(e.dati_aggiuntivi).filter(e=>{let[r,t]=e;return t&&"offerta_id"!==r}).map(e=>{let[r,t]=e;return`${r}: ${t}`}).join(" \u2022 ")})]}),(0,gt.jsx)(aw,{children:(0,gt.jsx)(cw,{categoria:e.categoria,children:(i=e.categoria,{trasferimento:"Trasferimento",contratto:"Contratto",offerta:"Offerta",richiesta_admin:"Richiesta Admin",pagamento:"Pagamento",rinnovo:"Rinnovo",sistema:"Sistema",torneo:"Torneo",finanza:"Finanza"}[i]||i)})}),(0,gt.jsx)(aw,{children:(0,gt.jsx)(uw,{tipo:e.tipo_evento,children:(t=e.tipo_evento,{giocatore_acquistato:"Giocatore Acquistato",giocatore_venduto:"Giocatore Venduto",giocatore_prestato:"Giocatore Prestato",giocatore_restituito:"Giocatore Restituito",offerta_ricevuta:"Offerta Ricevuta",offerta_inviata:"Offerta Inviata",offerta_accettata:"Offerta Accettata",offerta_rifiutata:"Offerta Rifiutata",contratto_firmato:"Contratto Firmato",contratto_rinnovato:"Contratto Rinnovato",contratto_scaduto:"Contratto Scaduto",pagamento_effettuato:"Pagamento Effettuato",pagamento_ricevuto:"Pagamento Ricevuto",richiesta_admin_inviata:"Richiesta Admin Inviata",richiesta_admin_approvata:"Richiesta Admin Approvata",richiesta_admin_rifiutata:"Richiesta Admin Rifiutata",squadra_creata:"Squadra Creata",squadra_modificata:"Squadra Modificata",iscrizione_torneo:"Iscrizione Torneo",vittoria_partita:"Vittoria Partita",sconfitta_partita:"Sconfitta Partita",pareggio_partita:"Pareggio Partita",casse_aggiornate:"Casse Aggiornate",bonus_ricevuto:"Bonus Ricevuto",penale_pagata:"Penale Pagata"}[t]||t)})}),(0,gt.jsx)(aw,{children:(0,gt.jsx)(gw,{children:(r=e.data_evento,new Date(r).toLocaleString("it-IT",{day:"2-digit",month:"2-digit",year:"2-digit",hour:"2-digit",minute:"2-digit"}))})}),(0,gt.jsx)(aw,{children:(0,gt.jsxs)(pw,{children:[e.utente_nome," ",e.utente_cognome]})})]},e.id);var r,t,i})]})]})},vw=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`,bw=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
`,jw=Ie.h1`
  color: #333;
  margin: 0;
`,yw=Ie.button`
  background: #6c757d;
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  
  &:hover {
    background: #5a6268;
  }
`,ww=Ie.div`
  display: grid;
  gap: 1.5rem;
`,kw=Ie.div`
  background: white;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`,_w=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
`,Sw=Ie.div`
  flex: 1;
`,Cw=Ie.h3`
  margin: 0 0 0.5rem 0;
  color: #333;
`,zw=Ie.div`
  color: #6c757d;
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
`,Ew=Ie.span`
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 500;
  ${e=>{switch(e.stato){case"in_attesa":return"background: #fff3cd; color: #856404;";case"accettata":return"background: #d4edda; color: #155724;";case"rifiutata":return"background: #f8d7da; color: #721c24;";default:return"background: #e2e3e5; color: #383d41;"}}}
`,Aw=Ie.div`
  background: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 6px;
  padding: 1rem;
  margin: 1rem 0;
  font-style: italic;
  color: #495057;
`,Rw=Ie.div`
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
`,Nw=Ie.button`
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 500;
  font-size: 0.9rem;
  
  ${e=>"accept"===e.$variant?"\n        background: #28a745;\n        color: white;\n        &:hover { background: #218838; }\n      ":"reject"===e.$variant?"\n        background: #dc3545;\n        color: white;\n        &:hover { background: #c82333; }\n      ":"\n        background: #6c757d;\n        color: white;\n        &:hover { background: #5a6268; }\n      "}
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,Tw=Ie.div`
  text-align: center;
  padding: 2rem;
  color: #6c757d;
`,qw=Ie.div`
  background: #f8d7da;
  color: #721c24;
  padding: 1rem;
  border-radius: 6px;
  margin-bottom: 1rem;
`,Pw=Ie.div`
  text-align: center;
  padding: 3rem;
  color: #6c757d;
`,$w=()=>{const{legaId:e}=Pr(),t=qr(),{token:i}=Si(),[n,o]=(0,r.useState)([]),[a,s]=(0,r.useState)(!0),[l,d]=(0,r.useState)(null),[c,u]=(0,r.useState)(null);(0,r.useEffect)(()=>{g()},[e]);const g=async()=>{try{var r;s(!0);const t=await async function(e,r){return ni.get(`/squadre/richieste-unione/${e}`,r)}(e,i),n=(null===t||void 0===t||null===(r=t.data)||void 0===r?void 0:r.richieste)||(null===t||void 0===t?void 0:t.richieste)||[];o(n)}catch(t){d(t.message)}finally{s(!1)}},p=async(e,r)=>{try{u(e),await async function(e,r,t,i){return ni.post(`/squadre/richieste-unione/${e}/rispondi`,{risposta:r,messaggio:t},i)}(e,r,"",i),await g()}catch(t){d(t.message)}finally{u(null)}};return a?(0,gt.jsx)(vw,{children:(0,gt.jsx)(Tw,{children:"Caricamento richieste..."})}):(0,gt.jsxs)(vw,{children:[(0,gt.jsxs)(bw,{children:[(0,gt.jsx)(jw,{children:"Richieste di Unione Squadra"}),(0,gt.jsx)(yw,{onClick:()=>t(-1),children:"\u2190 Torna indietro"})]}),l&&(0,gt.jsxs)(qw,{children:["Errore: ",l]}),0===n.length?(0,gt.jsxs)(Pw,{children:[(0,gt.jsx)("h3",{children:"Nessuna richiesta di unione squadra"}),(0,gt.jsx)("p",{children:"Non ci sono richieste in attesa di risposta."})]}):(0,gt.jsx)(ww,{children:n.map(e=>{return(0,gt.jsxs)(kw,{children:[(0,gt.jsx)(_w,{children:(0,gt.jsxs)(Sw,{children:[(0,gt.jsxs)(Cw,{children:["Richiesta di ",e.utente_username||e.utente_nome]}),(0,gt.jsxs)(zw,{children:[(0,gt.jsx)("strong",{children:"Squadra:"})," ",e.squadra_nome," |",(0,gt.jsx)("strong",{children:" Lega:"})," ",e.lega_nome," |",(0,gt.jsx)("strong",{children:" Data:"})," ",(r=e.data_richiesta,new Date(r).toLocaleString("it-IT"))]}),(0,gt.jsxs)(Ew,{stato:e.stato,children:["in_attesa"===e.stato&&"In attesa","accettata"===e.stato&&"Accettata","rifiutata"===e.stato&&"Rifiutata"]})]})}),e.messaggio_richiesta&&(0,gt.jsxs)(Aw,{children:[(0,gt.jsx)("strong",{children:"Messaggio:"})," ",e.messaggio_richiesta]}),e.messaggio_risposta&&(0,gt.jsxs)(Aw,{children:[(0,gt.jsx)("strong",{children:"Risposta:"})," ",e.messaggio_risposta]}),"in_attesa"===e.stato&&(0,gt.jsxs)(Rw,{children:[(0,gt.jsx)(Nw,{$variant:"accept",onClick:()=>p(e.id,"accetta"),disabled:c===e.id,children:c===e.id?"Accettazione...":"Accetta"}),(0,gt.jsx)(Nw,{$variant:"reject",onClick:()=>p(e.id,"rifiuta"),disabled:c===e.id,children:c===e.id?"Rifiuto...":"Rifiuta"})]})]},e.id);var r})})]})},Iw=Ie.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`,Ow=Ie.div`
  text-align: center;
  margin-bottom: 3rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 2rem;
  border-radius: 16px;
`,Lw=Ie.h1`
  margin: 0 0 0.5rem 0;
  font-size: 2.5rem;
`,Mw=Ie.p`
  font-size: 1.1rem;
  margin: 0;
  opacity: 0.9;
`,Dw=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
`,Fw=Ie.h2`
  color: #333;
  margin: 0 0 2rem 0;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Uw=Ie.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s;
  margin: 0.25rem;
  
  &:hover {
    transform: translateY(-1px);
  }
  
  &.danger {
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
  }
  
  &.success {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
  }
  
  &.warning {
    background: linear-gradient(135deg, #ffc107 0%, #e0a800 100%);
    color: #212529;
  }
`,Bw=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,Gw=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 500px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
`,Ww=Ie.h3`
  margin: 0 0 1.5rem 0;
  color: #333;
`,Hw=Ie.div`
  margin-bottom: 1.5rem;
`,Vw=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
`,Qw=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
  margin-top: 0.5rem;
`,Kw=Ie.label`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 6px;
  transition: background-color 0.2s;
  
  &:hover {
    background: #f8f9fa;
  }
  
  input[type="checkbox"] {
    width: 16px;
    height: 16px;
  }
`,Yw=Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 2rem;
`,Jw=Ie.div`
  background: #f8f9fa;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
  border-left: 4px solid #667eea;
`,Zw=Ie.span`
  background: #d4edda;
  color: #155724;
  padding: 0.2rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  margin-right: 0.5rem;
  margin-bottom: 0.5rem;
  display: inline-block;
`,Xw=Ie.div`
  background: #fff3cd;
  border: 1px solid #ffeaa7;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
`,ek=Ie.div`
  display: flex;
  justify-content: between;
  align-items: center;
  margin-bottom: 1rem;
`,rk=Ie.span`
  background: #007bff;
  color: white;
  padding: 0.2rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
`,tk=Ie.span`
  color: #667eea;
  cursor: pointer;
  text-decoration: underline;
  font-weight: 600;
  
  &:hover {
    color: #5a6fd8;
  }
`,ik=Ie.div`
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
`,nk=Ie.span`
  color: #666;
  font-size: 0.9rem;
`,ok=Ie.div`
  margin-bottom: 1rem;
  line-height: 1.5;
`,ak=Ie.div`
  display: flex;
  gap: 0.5rem;
`,sk=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,lk=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,dk=Ie.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`,ck=()=>{const{legaId:e}=Pr(),t=qr(),{token:i}=Si(),[n,o]=(0,r.useState)(null),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)([]),[g,p]=(0,r.useState)(!0),[h,m]=(0,r.useState)(""),[f,x]=(0,r.useState)(!1),[v,b]=(0,r.useState)(!1),[j,y]=(0,r.useState)(""),[w,k]=(0,r.useState)(null),[_,S]=(0,r.useState)(null),[C,z]=(0,r.useState)({modifica_squadre:!1,gestione_giocatori:!1,gestione_tornei:!1,modifica_impostazioni:!1,gestione_contratti:!1,gestione_richieste:!1}),[E,A]=(0,r.useState)({modifica_squadre:!1,gestione_giocatori:!1,gestione_tornei:!1,modifica_impostazioni:!1,gestione_contratti:!1,gestione_richieste:!1});(0,r.useEffect)(()=>{i&&e&&async function(){p(!0),m("");try{var r,t,n,a,l,c;const[g,p,h,m]=await Promise.all([Ao(e,i),Oi(e,i),Di(e,i),Ui(e,i)]);o((null===g||void 0===g||null===(r=g.data)||void 0===r?void 0:r.lega)||(null===g||void 0===g?void 0:g.lega)),s((null===p||void 0===p||null===(t=p.data)||void 0===t?void 0:t.subadmins)||(null===p||void 0===p?void 0:p.subadmins)||[]),d((null===h||void 0===h||null===(n=h.data)||void 0===n?void 0:n.changes)||(null===h||void 0===h?void 0:h.changes)||[]),u((null===m||void 0===m||null===(a=m.data)||void 0===a?void 0:a.changes)||(null===m||void 0===m?void 0:m.changes)||[]);const f=(null===h||void 0===h||null===(l=h.data)||void 0===l?void 0:l.changes)||(null===h||void 0===h?void 0:h.changes)||[],x=(null===m||void 0===m||null===(c=m.data)||void 0===c?void 0:c.changes)||(null===m||void 0===m?void 0:m.changes)||[],v=new Set;[...f,...x].forEach(e=>{var r,t;null!==e&&void 0!==e&&e.action_data&&null!==e&&void 0!==e&&null!==(r=e.action_data)&&void 0!==r&&r.squadreModifiche&&Object.keys(null===e||void 0===e||null===(t=e.action_data)||void 0===t?void 0:t.squadreModifiche).forEach(e=>{v.add(parseInt(e))})}),v.size>0&&await O(Array.from(v))}catch(g){m(g.message)}p(!1)}()},[i,e]);const R=e=>{z(r=>({...r,[e]:!r[e]}))},N=e=>{A(r=>({...r,[e]:!r[e]}))},T=async e=>{const r=prompt("Inserisci un commento (opzionale):");try{await(async(e,r,t)=>ni.post(`/subadmin/approve/${e}`,{adminResponse:r},t))(e,r||"",i);const t=l.find(r=>r.id===e);if(t){d(r=>null===r||void 0===r?void 0:r.filter(r=>r.id!==e));const i={...t,status:"approved",admin_response:r||"",reviewed_at:(new Date).toISOString()};u(e=>[i,...e])}alert("Modifica approvata con successo!")}catch(t){alert(`Errore nell'approvazione: ${t.message}`)}},q=async e=>{const r=prompt("Inserisci un commento per il rifiuto:");if(r)try{await(async(e,r,t)=>ni.post(`/subadmin/reject/${e}`,{adminResponse:r},t))(e,r,i);const t=l.find(r=>r.id===e);if(t){d(r=>null===r||void 0===r?void 0:r.filter(r=>r.id!==e));const i={...t,status:"rejected",admin_response:r,reviewed_at:(new Date).toISOString()};u(e=>[i,...e])}alert("Modifica rifiutata con successo!")}catch(t){alert(`Errore nel rifiuto: ${t.message}`)}else alert("\xc8 necessario inserire un commento per il rifiuto")},P=e=>new Date(e).toLocaleDateString("it-IT",{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}),[$,I]=(0,r.useState)({}),O=async e=>{try{const r=await fetch("https://topleaguem.onrender.com/api/squadre/original-data",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${i}`},body:JSON.stringify({squadraIds:e})});if(r.ok){const e=r.data;I(r=>({...r,...e.squadre}))}else console.error("Errore risposta API:",r.status,r.statusText)}catch(h){console.error("Errore recupero dati originali squadre:",h)}},L=e=>{try{if("string"===typeof e)return e;const d=e=>null===e||void 0===e||"null"===e?"N/A":e;if("object"===typeof e&&null!==e){if(e.squadreModifiche){const r=Object.entries(e.squadreModifiche),t=e.addedPlayers?Object.values(e.addedPlayers).flat().length:0,i=e.removedPlayers?Object.values(e.removedPlayers).flat().length:0;let n=[];return null!==r&&void 0!==r&&r.length&&(n.push(`\ud83d\udcdd Modifiche a ${(null===r||void 0===r?void 0:r.length)||0} squadra${null!==r&&void 0!==r&&r.length?"e":""}`),r.forEach(e=>{let[r,t]=e;if(t&&"object"===typeof t){const e=Object.entries(t).map(e=>{let[t,i]=e;const n={nome:"Nome",immagine:"Immagine",casse_societarie:"Casse Societarie",club_level:"Club Level",proprietario:"Proprietario",note:"Note"},o=$[r];if(o){const e=o[t];return`${n[t]||t}: ${e} \u2192 ${i}`}return`${n[t]||t}: ${i}`});null!==e&&void 0!==e&&e.length&&n.push(`  \u2022 Squadra ${r}: ${e.join(", ")}`)}})),t>0&&n.push(`\u2795 ${t} giocatore${t>1?"i":""} aggiunto${t>1?"i":""}`),i>0&&n.push(`\u2796 ${i} giocatore${i>1?"i":""} rimosso${i>1?"i":""}`),n.join("\n")}if(e.modifiche&&e.modifiche.giocatoreId&&e.modifiche.modifiche){var r,t,i,n;const l={nome:"Nome",cognome:"Cognome",ruolo:"Ruolo",media_voto:"Media Voto",fantamedia_voto:"Fantamedia Voto",squadra_reale:"Squadra Reale",quotazione_iniziale:"Quotazione Iniziale",costo_attuale:"Ingaggio",quotazione_attuale:"Quotazione Attuale",fanta_valore_mercato:"Fanta Valore di Mercato",anni_contratto:"Anni Contratto",prestito:"Prestito",triggers:"Triggers"},c=Object.entries(e.modifiche.modifiche).map(r=>{var t;let[i,n]=r;const o=d(null===(t=e.modifiche.valoriOriginali)||void 0===t?void 0:t[i])||"N/A";return`${l[i]||i}: ${o} \u2192 ${d(n)}`}),u=d(e.modifiche.giocatore)||d(null===(r=e.modifiche)||void 0===r?void 0:r.nome)||`ID ${e.modifiche.giocatoreId}`||"Giocatore sconosciuto";let g="N/A";var o;if(null!==(t=e.modifiche.valoriOriginali)&&void 0!==t&&t.ruolo)g=d((null===(o=e.modifiche.valoriOriginali)||void 0===o?void 0:o.ruolo)||"Ruolo");else if(null!==(i=e.modifiche.modifiche)&&void 0!==i&&i.ruolo){var a;g=d((null===(a=e.modifiche.modifiche)||void 0===a?void 0:a.ruolo)||"Ruolo")}else{var s;null!==(n=e.modifiche)&&void 0!==n&&n.ruolo,g=d((null===(s=e.modifiche)||void 0===s?void 0:s.ruolo)||"Ruolo")}return console.log("Debug formatActionData - nested structure:",{actionData:e,giocatoreNome:u,ruolo:g,valoriOriginali:e.modifiche.valoriOriginali,modifiche:e.modifiche.modifiche,modificheList:c}),`\ud83d\udc64 ${u} (${g}):\n  \u2022 ${c.join("\n  \u2022 ")}`}if(e.giocatoreId&&e.modifiche){var l;const r={nome:"Nome",cognome:"Cognome",ruolo:"Ruolo",media_voto:"Media Voto",fantamedia_voto:"Fantamedia Voto",squadra_reale:"Squadra Reale",quotazione_iniziale:"Quotazione Iniziale",costo_attuale:"Ingaggio",quotazione_attuale:"Quotazione Attuale",fanta_valore_mercato:"Fanta Valore di Mercato",anni_contratto:"Anni Contratto",prestito:"Prestito",triggers:"Triggers"},t=Object.entries(e.modifiche).map(t=>{var i;let[n,o]=t;const a=d(null===(i=e.valoriOriginali)||void 0===i?void 0:i[n])||"N/A";return`${r[n]||n}: ${a} \u2192 ${d(o)}`}),i=d(e.giocatore)||d(null===e||void 0===e?void 0:e.nome)||`ID ${e.giocatoreId}`||"Giocatore sconosciuto";return`\ud83d\udc64 ${i} (${d(null===(l=e.valoriOriginali)||void 0===l?void 0:l.ruolo)||"N/A"}):\n  \u2022 ${t.join("\n  \u2022 ")}`}return JSON.stringify(e,null,2)}return String(e||"")}catch(xE){return console.error("Error formatting action data:",xE),"string"===typeof e?e:JSON.stringify(e)}};return g?(0,gt.jsx)(Iw,{children:(0,gt.jsx)(sk,{children:"Caricamento..."})}):h?(0,gt.jsx)(Iw,{children:(0,gt.jsxs)(lk,{children:["Errore: ",h]})}):n?(0,gt.jsxs)(Iw,{children:[(0,gt.jsxs)(Ow,{children:[(0,gt.jsxs)(Lw,{children:["Area Admin - ",(null===n||void 0===n?void 0:n.nome)||"Nome"]}),(0,gt.jsx)(Mw,{children:"Gestione subadmin e approvazione modifiche"})]}),(0,gt.jsxs)(Dw,{children:[(0,gt.jsxs)(Fw,{children:["\ud83d\udc65 Gestione Subadmin",(0,gt.jsx)(Uw,{onClick:()=>{y(""),k(null),A({modifica_squadre:!1,gestione_giocatori:!1,gestione_tornei:!1,modifica_impostazioni:!1,gestione_contratti:!1,gestione_richieste:!1}),x(!0)},children:"Aggiungi Subadmin"})]}),null!==a&&void 0!==a&&a.length?null===a||void 0===a?void 0:a.map(r=>(0,gt.jsx)(Jw,{children:(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"flex-start"},children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)("h4",{children:r.username}),(0,gt.jsxs)("p",{style:{color:"#666",margin:"0.5rem 0"},children:["Aggiunto il: ",P(r.data_nomina)]}),(0,gt.jsx)("div",{children:Object.entries(r.permessi).map(e=>{let[r,t]=e;if(!t)return null;return(0,gt.jsx)(Zw,{children:{modifica_squadre:"Modifica Squadre",gestione_giocatori:"Gestione Calciatori",gestione_tornei:"Gestione Tornei",modifica_impostazioni:"Modifica Impostazioni",gestione_contratti:"Gestione Contratti",gestione_richieste:"Gestione Richieste"}[r]||r.replace("_"," ")},r)})})]}),(0,gt.jsxs)("div",{style:{display:"flex",gap:"0.5rem"},children:[(0,gt.jsx)(Uw,{className:"warning",onClick:()=>{return S(e=r),z(e.permessi),void b(!0);var e},children:"Modifica Permessi"}),(0,gt.jsx)(Uw,{className:"danger",onClick:()=>(async()=>{if(window.confirm("Sei sicuro di voler rimuovere questo subadmin?"))try{var r;await Mi(0,0,i),alert("Subadmin rimosso con successo!");const t=await Oi(e,i);s((null===t||void 0===t||null===(r=t.data)||void 0===r?void 0:r.subadmins)||(null===t||void 0===t?void 0:t.subadmins)||[])}catch(t){alert(`Errore nella rimozione del subadmin: ${t.message}`)}})(r.utente_id),children:"Rimuovi"})]})]})},r.id)):(0,gt.jsx)(dk,{children:"Nessun subadmin assegnato a questa lega"})]}),(0,gt.jsxs)(Dw,{children:[(0,gt.jsxs)(Fw,{children:["\u23f3 Modifiche in Attesa (",(null===l||void 0===l?void 0:l.length)||0,")"]}),null!==l&&void 0!==l&&l.length?null===l||void 0===l?void 0:l.map(e=>(0,gt.jsxs)(Xw,{children:[(0,gt.jsxs)(ek,{children:[(0,gt.jsx)(rk,{children:"gestione_giocatori"===e.action_type?"Gestione Calciatori":e.action_type}),(0,gt.jsx)(nk,{children:P(e.created_at)})]}),(0,gt.jsxs)(ok,{children:[(0,gt.jsxs)(ik,{children:["Subadmin: ",e.username]}),(0,gt.jsx)("strong",{children:"Lega:"})," ",(0,gt.jsx)(tk,{onClick:()=>t(`/lega/${null===e||void 0===e?void 0:e.lega_id}`),children:null===e||void 0===e?void 0:e.lega_nome}),(0,gt.jsx)("br",{}),(0,gt.jsx)("strong",{children:"Descrizione:"}),(0,gt.jsx)("br",{}),(0,gt.jsx)("pre",{style:{background:"#f8f9fa",padding:"0.5rem",borderRadius:"4px",fontSize:"0.9rem",whiteSpace:"pre-wrap",margin:"0.5rem 0",fontFamily:"inherit"},children:L(e.action_data)})]}),(0,gt.jsxs)(ak,{children:[(0,gt.jsx)(Uw,{className:"success",onClick:()=>T(e.id),children:"Approva"}),(0,gt.jsx)(Uw,{className:"danger",onClick:()=>q(e.id),children:"Rifiuta"})]})]},e.id)):(0,gt.jsx)(dk,{children:"Nessuna modifica in attesa di approvazione"})]}),(0,gt.jsxs)(Dw,{children:[(0,gt.jsx)(Fw,{children:"\ud83d\udccb Storico Modifiche"}),null!==c&&void 0!==c&&c.length?null===c||void 0===c?void 0:c.map(e=>(0,gt.jsxs)(Xw,{style:{background:"approved"===e.status?"#d4edda":"#f8d7da",borderColor:"approved"===e.status?"#c3e6cb":"#f5c6cb"},children:[(0,gt.jsxs)(ek,{children:[(0,gt.jsxs)(rk,{style:{background:"approved"===e.status?"#28a745":"#dc3545"},children:["gestione_giocatori"===e.action_type?"Gestione Calciatori":e.action_type," - ",e.status]}),(0,gt.jsx)(nk,{children:P(e.created_at)})]}),(0,gt.jsxs)(ok,{children:[(0,gt.jsxs)(ik,{children:["Subadmin: ",e.username]}),(0,gt.jsx)("strong",{children:"Lega:"})," ",(0,gt.jsx)(tk,{onClick:()=>t(`/lega/${e.lega_id}`),children:e.lega_nome}),(0,gt.jsx)("br",{}),(0,gt.jsx)("strong",{children:"Descrizione:"}),(0,gt.jsx)("br",{}),(0,gt.jsx)("pre",{style:{background:"#f8f9fa",padding:"0.5rem",borderRadius:"4px",fontSize:"0.9rem",whiteSpace:"pre-wrap",margin:"0.5rem 0",fontFamily:"inherit"},children:L(e.action_data)}),e.admin_response&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)("strong",{children:"Risposta Admin:"})," ",e.admin_response,(0,gt.jsx)("br",{})]}),e.reviewed_at&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)("strong",{children:"Risolto il:"})," ",P(e.reviewed_at),(0,gt.jsx)("br",{})]})]})]},e.id)):(0,gt.jsx)(dk,{children:"Nessuna modifica nello storico"})]}),f&&(0,gt.jsx)(Bw,{onClick:()=>x(!1),children:(0,gt.jsxs)(Gw,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(Ww,{children:["Aggiungi Subadmin - ",(null===n||void 0===n?void 0:n.nome)||"Nome"]}),(0,gt.jsxs)(Hw,{children:[(0,gt.jsx)(Vw,{children:"Seleziona Utente"}),(0,gt.jsx)(Fg,{value:j,onChange:y,placeholder:"Cerca utente per username...",token:i,onUserSelect:e=>{y(e.username),k(e.id)}})]}),(0,gt.jsxs)(Hw,{children:[(0,gt.jsx)(Vw,{children:"Permessi"}),(0,gt.jsxs)(Qw,{children:[(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:E.modifica_squadre,onChange:()=>N("modifica_squadre")}),"Modifica Squadre"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:E.gestione_giocatori,onChange:()=>N("gestione_giocatori")}),"Gestione Calciatori"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:E.gestione_tornei,onChange:()=>N("gestione_tornei")}),"Gestione Tornei"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:E.modifica_impostazioni,onChange:()=>N("modifica_impostazioni")}),"Modifica Impostazioni"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:E.gestione_contratti,onChange:()=>N("gestione_contratti")}),"Gestione Contratti"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:E.gestione_richieste,onChange:()=>N("gestione_richieste")}),"Gestione Richieste"]})]})]}),(0,gt.jsxs)(Yw,{children:[(0,gt.jsx)(Uw,{onClick:()=>x(!1),children:"Annulla"}),(0,gt.jsx)(Uw,{className:"success",onClick:async()=>{if(w)try{var r;console.log("Aggiungendo subadmin:",{legaId:e,selectedUserId:w,permissions:E});const t=await Li(e,w,E,i);console.log("Risultato aggiunta subadmin:",t),alert("Subadmin aggiunto con successo!"),x(!1),console.log("Ricarico lista subadmin...");const n=await Oi(e,i);console.log("Nuova lista subadmin:",n),s((null===n||void 0===n||null===(r=n.data)||void 0===r?void 0:r.subadmins)||(null===n||void 0===n?void 0:n.subadmins)||[])}catch(t){console.error("Errore nell'aggiunta del subadmin:",t),alert(`Errore nell'aggiunta del subadmin: ${t.message}`)}else alert("Seleziona un utente")},children:"Aggiungi Subadmin"})]})]})}),v&&_&&(0,gt.jsx)(Bw,{onClick:()=>b(!1),children:(0,gt.jsxs)(Gw,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(Ww,{children:["Modifica Permessi - ",_.username]}),(0,gt.jsxs)(Hw,{children:[(0,gt.jsx)(Vw,{children:"Permessi"}),(0,gt.jsxs)(Qw,{children:[(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:C.modifica_squadre,onChange:()=>R("modifica_squadre")}),"Modifica Squadre"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:C.gestione_giocatori,onChange:()=>R("gestione_giocatori")}),"Gestione Calciatori"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:C.gestione_tornei,onChange:()=>R("gestione_tornei")}),"Gestione Tornei"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:C.modifica_impostazioni,onChange:()=>R("modifica_impostazioni")}),"Modifica Impostazioni"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:C.gestione_contratti,onChange:()=>R("gestione_contratti")}),"Gestione Contratti"]}),(0,gt.jsxs)(Kw,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:C.gestione_richieste,onChange:()=>R("gestione_richieste")}),"Gestione Richieste"]})]})]}),(0,gt.jsxs)(Yw,{children:[(0,gt.jsx)(Uw,{onClick:()=>b(!1),children:"Annulla"}),(0,gt.jsx)(Uw,{className:"success",onClick:async()=>{try{await(async(e,r,t,i)=>ni.put("/subadmin/update-permissions",{legaId:e,userId:r,permissions:t},i))(e,_.utente_id,C,i),alert("Permessi aggiornati con successo!"),b(!1);const r=await Oi(e,i);s(r.subadmins||[])}catch(r){alert(`Errore nell'aggiornamento dei permessi: ${r.message}`)}},children:"Salva Permessi"})]})]})})]}):(0,gt.jsx)(Iw,{children:(0,gt.jsx)(lk,{children:"Lega non trovata"})})},uk=Ie.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`,gk=Ie.div`
  text-align: center;
  margin-bottom: 3rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 2rem;
  border-radius: 16px;
`,pk=Ie.h1`
  margin: 0 0 0.5rem 0;
  font-size: 2.5rem;
`,hk=Ie.p`
  font-size: 1.1rem;
  margin: 0;
  opacity: 0.9;
`,mk=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
`,fk=Ie.h2`
  color: #333;
  margin: 0 0 2rem 0;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,xk=Ie.div`
  background: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  transition: all 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    border-color: #667eea;
  }
`,vk=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`,bk=Ie.h3`
  margin: 0;
  color: #333;
  font-size: 1.3rem;
`,jk=(Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 1rem;
  margin-bottom: 1rem;
`,Ie.div`
  text-align: center;
  padding: 0.5rem;
  background: white;
  border-radius: 8px;
  border: 1px solid #e9ecef;
`,Ie.div`
  font-size: 1.5rem;
  font-weight: bold;
  color: #667eea;
`,Ie.div`
  font-size: 0.8rem;
  color: #666;
  text-transform: uppercase;
`,Ie.div`
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-top: 1rem;
`),yk=Ie.span`
  background: ${e=>e.$active?"#d4edda":"#f8d7da"};
  color: ${e=>e.$active?"#155724":"#721c24"};
  padding: 0.3rem 0.6rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
`,wk=Ie.button`
  background: ${e=>"success"===e.className?"#28a745":"danger"===e.className?"#dc3545":"secondary"===e.className?"#6c757d":"#667eea"};
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s;
  
  &:hover {
    opacity: 0.9;
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
  }
`,kk=Ie.div`
  background: #fff3cd;
  border: 1px solid #ffeaa7;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
`,_k=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`,Sk=Ie.span`
  background: #007bff;
  color: white;
  padding: 0.2rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
`,Ck=Ie.span`
  color: #666;
  font-size: 0.9rem;
`,zk=Ie.div`
  margin-bottom: 1rem;
  line-height: 1.5;
`,Ek=Ie.span`
  padding: 0.2rem 0.5rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  
  &.pending {
    background: #fff3cd;
    color: #856404;
  }
  
  &.approved {
    background: #d4edda;
    color: #155724;
  }
  
  &.rejected {
    background: #f8d7da;
    color: #721c24;
  }
`,Ak=Ie.span`
  color: #667eea;
  cursor: pointer;
  text-decoration: underline;
  font-weight: 600;
  
  &:hover {
    color: #5a6fd8;
  }
`,Rk=(Ie.div`
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #333;
`,Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`),Nk=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,Tk=Ie.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`,qk=Ie.div`
  background: #e3f2fd;
  border: 1px solid #bbdefb;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 2rem;
`,Pk=Ie.div`
  display: flex;
  margin-bottom: 2rem;
  border-bottom: 2px solid #e9ecef;
`,$k=Ie.button`
  background: none;
  border: none;
  padding: 1rem 2rem;
  cursor: pointer;
  font-size: 1rem;
  font-weight: 600;
  color: ${e=>e.$active?"#667eea":"#666"};
  border-bottom: 2px solid ${e=>e.$active?"#667eea":"transparent"};
  transition: all 0.2s;
  
  &:hover {
    color: #667eea;
  }
`,Ik=()=>{const e=qr(),{token:t,user:i}=Si(),[n,o]=(0,r.useState)("leagues"),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)([]),[c,u]=(0,r.useState)([]),[g,p]=(0,r.useState)(!0),[h,m]=(0,r.useState)(""),f=async()=>{p(!0),m("");try{const[e,r,i]=await Promise.all([Bi(t),Fi(t),Ui(null,t)]);s(e.leagues||[]),d(r.changes||[]),u(i.changes||[])}catch(e){m(e.message)}p(!1)};(0,r.useEffect)(()=>{t&&f()},[t]);const x=r=>{e(`/league-subadmin/${r}`)},v=async e=>{if(window.confirm("Sei sicuro di voler annullare questa modifica? Questa azione non pu\xf2 essere annullata."))try{await(async(e,r)=>ni.delete(`/subadmin/cancel/${e}`,r))(e,t),alert("Modifica annullata con successo!"),f()}catch(h){console.error("Errore nell'annullamento della modifica:",h),alert(`Errore nell'annullamento: ${h.message}`)}},b=e=>new Date(e).toLocaleDateString("it-IT",{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}),j=e=>({modifica_squadre:"Modifica Squadre",gestione_giocatori:"Gestione Calciatori",gestione_tornei:"Gestione Tornei",modifica_impostazioni:"Modifica Impostazioni",gestione_contratti:"Gestione Contratti",gestione_richieste:"Gestione Richieste"}[e]||e),y=e=>({modifica_squadre:"\ud83c\udfc6 Modifica Squadre",gestione_giocatori:"\ud83d\udc65 Gestione Calciatori",gestione_tornei:"\ud83c\udfc5 Gestione Tornei",modifica_impostazioni:"\u2699\ufe0f Modifica Impostazioni",gestione_contratti:"\ud83d\udcc4 Gestione Contratti"}[e]||e),w=e=>{try{const o="string"===typeof e?JSON.parse(e):e,a=e=>null===e||void 0===e||"null"===e?"N/A":e;if(o&&"object"===typeof o&&o.squadreModifiche){const e=Object.entries(o.squadreModifiche),r=o.addedPlayers?Object.values(o.addedPlayers).flat().length:0,t=o.removedPlayers?Object.values(o.removedPlayers).flat().length:0;let i=[];return e.length>0&&(i.push(`\ud83d\udcdd Modifiche a ${e.length} squadra${e.length>1?"e":""}`),e.forEach(e=>{let[r,t]=e;if(t&&"object"===typeof t){const e=Object.entries(t).map(e=>{let[r,t]=e;return`${{nome:"Nome",immagine:"Immagine",casse_societarie:"Casse Societarie",club_level:"Club Level",proprietario:"Proprietario",note:"Note"}[r]||r}: ${t}`});i.push(`  \u2022 Squadra ${r}: ${e.join(", ")}`)}})),r>0&&i.push(`\u2795 ${r} giocatore${r>1?"i":""} aggiunto${r>1?"i":""}`),t>0&&i.push(`\u2796 ${t} giocatore${t>1?"i":""} rimosso${t>1?"i":""}`),i.join("\n")}if(o&&"object"===typeof o&&o.modifiche&&o.modifiche.giocatoreId&&o.modifiche.modifiche){var r,t;const e={nome:"Nome",cognome:"Cognome",ruolo:"Ruolo",media_voto:"Media Voto",fantamedia_voto:"Fantamedia Voto",squadra_reale:"Squadra Reale",eta:"Et\xe0",quotazione_iniziale:"Quotazione Iniziale",costo_attuale:"Ingaggio",quotazione_attuale:"Quotazione Attuale",fanta_valore_mercato:"Fanta Valore di Mercato",anni_contratto:"Anni Contratto",prestito:"Prestito",triggers:"Triggers"},i=Object.entries(o.modifiche.modifiche).map(r=>{var t;let[i,n]=r;const s=a(null===(t=o.modifiche.valoriOriginali)||void 0===t?void 0:t[i])||"N/A";return`${e[i]||i}: ${s} \u2192 ${a(n)}`}),n=a(o.modifiche.giocatore)||`ID ${o.modifiche.giocatoreId}`||"Giocatore sconosciuto",s=a(null===(r=o.modifiche.valoriOriginali)||void 0===r?void 0:r.ruolo)||a(null===(t=o.modifiche.modifiche)||void 0===t?void 0:t.ruolo)||"N/A",l=a(o.modifiche.squadra)||"N/A";return console.log("Debug SubadminArea formatActionData - nested structure:",{data:o,giocatoreNome:n,ruolo:s,squadraFantasy:l,modificheList:i}),`\ud83d\udc64 ${n} (${s}) - ${l}:\n  \u2022 ${i.join("\n  \u2022 ")}`}if(o&&"object"===typeof o&&o.giocatoreId&&o.modifiche){var i,n;const e={nome:"Nome",cognome:"Cognome",ruolo:"Ruolo",media_voto:"Media Voto",fantamedia_voto:"Fantamedia Voto",squadra_reale:"Squadra Reale",eta:"Et\xe0",quotazione_iniziale:"Quotazione Iniziale",costo_attuale:"Ingaggio",quotazione_attuale:"Quotazione Attuale",fanta_valore_mercato:"Fanta Valore di Mercato",anni_contratto:"Anni Contratto",prestito:"Prestito",triggers:"Triggers"},r=Object.entries(o.modifiche).map(r=>{var t;let[i,n]=r;const s=a(null===(t=o.valoriOriginali)||void 0===t?void 0:t[i])||"N/A";return`${e[i]||i}: ${s} \u2192 ${a(n)}`}),t=a(o.giocatore)||`ID ${o.giocatoreId}`||"Giocatore sconosciuto",s=a(null===(i=o.valoriOriginali)||void 0===i?void 0:i.ruolo)||a(null===(n=o.modifiche)||void 0===n?void 0:n.ruolo)||"N/A";return`\ud83d\udc64 ${t} (${s}) - ${a(o.squadra)||"N/A"}:\n  \u2022 ${r.join("\n  \u2022 ")}`}return"object"===typeof o?JSON.stringify(o,null,2):String(o||e||"")}catch(xE){return console.error("Error formatting action data:",xE),"string"===typeof e?e:JSON.stringify(e)}};return g?(0,gt.jsx)(uk,{children:(0,gt.jsx)(Rk,{children:"Caricamento area subadmin..."})}):h?(0,gt.jsx)(uk,{children:(0,gt.jsxs)(Nk,{children:["Errore: ",h]})}):(0,gt.jsxs)(uk,{children:[(0,gt.jsxs)(gk,{children:[(0,gt.jsx)(pk,{children:"Area Subadmin"}),(0,gt.jsx)(hk,{children:"Gestione delle tue leghe e richieste di modifica"})]}),(0,gt.jsxs)(qk,{children:[(0,gt.jsx)("h3",{children:"Come funziona il sistema Subadmin"}),(0,gt.jsx)("p",{children:'Come subadmin, hai accesso limitato alle leghe che ti sono state assegnate. Puoi richiedere modifiche che verranno esaminate dall\'amministratore della lega. Le tue richieste appariranno nella sezione "Modifiche in Attesa" e "Storico Modifiche".'})]}),(0,gt.jsxs)(Pk,{children:[(0,gt.jsxs)($k,{$active:"leagues"===n,onClick:()=>o("leagues"),children:["\ud83c\udfc6 Le Mie Leghe (",a.length,")"]}),(0,gt.jsxs)($k,{$active:"pending"===n,onClick:()=>o("pending"),children:["\u23f3 Modifiche in Attesa (",l.length,")"]}),(0,gt.jsxs)($k,{$active:"history"===n,onClick:()=>o("history"),children:["\ud83d\udccb Storico Modifiche (",c.length,")"]}),(0,gt.jsx)($k,{$active:"requests"===n,onClick:()=>o("requests"),children:"\ud83d\udcdd Gestione Richieste"}),(0,gt.jsx)($k,{$active:"roster"===n,onClick:()=>o("roster"),children:"\ud83d\udcca Gestione Roster A/B"})]}),"leagues"===n&&(0,gt.jsxs)(mk,{children:[(0,gt.jsx)(fk,{children:"\ud83c\udfc6 Le Mie Leghe"}),a.length>0?a.map(e=>(0,gt.jsxs)(xk,{onClick:()=>x(e.id),children:[(0,gt.jsxs)(vk,{children:[(0,gt.jsx)(bk,{children:e.nome}),(0,gt.jsx)(wk,{children:"Gestisci Lega"})]}),(0,gt.jsx)(jk,{children:Object.entries(e.permessi).map(e=>{let[r,t]=e;return(0,gt.jsx)(yk,{$active:t,children:j(r)},r)})})]},e.id)):(0,gt.jsxs)(Tk,{children:[(0,gt.jsx)("h3",{children:"Nessuna lega assegnata"}),(0,gt.jsx)("p",{children:"Non sei ancora stato assegnato come subadmin a nessuna lega."})]})]}),"pending"===n&&(0,gt.jsxs)(mk,{children:[(0,gt.jsx)(fk,{children:"\u23f3 Modifiche in Attesa"}),l.length>0?l.map(e=>(0,gt.jsxs)(kk,{children:[(0,gt.jsxs)(_k,{children:[(0,gt.jsx)(Sk,{children:y(e.action_type)}),(0,gt.jsx)(Ck,{children:b(e.created_at)})]}),(0,gt.jsxs)(zk,{children:[(0,gt.jsx)("strong",{children:"Lega:"})," ",(0,gt.jsx)(Ak,{onClick:()=>x(null===e||void 0===e?void 0:e.lega_id),children:null===e||void 0===e?void 0:e.lega_nome}),(0,gt.jsx)("br",{}),(0,gt.jsx)("strong",{children:"Modifiche:"}),(0,gt.jsx)("br",{}),(0,gt.jsx)("pre",{style:{background:"#f8f9fa",padding:"0.5rem",borderRadius:"4px",fontSize:"0.9rem",whiteSpace:"pre-wrap",margin:"0.5rem 0"},children:w(e.action_data)})]}),(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:"1rem"},children:[(0,gt.jsx)(Ek,{className:"pending",children:"In Attesa"}),(0,gt.jsx)(wk,{className:"danger",onClick:r=>{r.stopPropagation(),v(e.id)},children:"\u274c Annulla"})]})]},e.id)):(0,gt.jsxs)(Tk,{children:[(0,gt.jsx)("h3",{children:"Nessuna modifica in attesa"}),(0,gt.jsx)("p",{children:"Non hai modifiche in attesa di approvazione."})]})]}),"history"===n&&(0,gt.jsxs)(mk,{children:[(0,gt.jsx)(fk,{children:"\ud83d\udccb Storico Modifiche"}),c.length>0?c.map(e=>(0,gt.jsxs)(kk,{style:{background:"approved"===e.status?"#d4edda":"#f8d7da",borderColor:"approved"===e.status?"#c3e6cb":"#f5c6cb"},children:[(0,gt.jsxs)(_k,{children:[(0,gt.jsx)(Sk,{style:{background:"approved"===e.status?"#28a745":"#dc3545"},children:y(e.action_type)}),(0,gt.jsx)(Ck,{children:b(e.created_at)})]}),(0,gt.jsxs)(zk,{children:[(0,gt.jsx)("strong",{children:"Lega:"})," ",(0,gt.jsx)(Ak,{onClick:()=>x(e.lega_id),children:e.lega_nome}),(0,gt.jsx)("br",{}),(0,gt.jsx)("strong",{children:"Modifiche:"}),(0,gt.jsx)("br",{}),(0,gt.jsx)("pre",{style:{background:"#f8f9fa",padding:"0.5rem",borderRadius:"4px",fontSize:"0.9rem",whiteSpace:"pre-wrap",margin:"0.5rem 0"},children:w(e.action_data)}),e.admin_response&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)("strong",{children:"Risposta Admin:"})," ",e.admin_response,(0,gt.jsx)("br",{})]}),e.reviewed_at&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)("strong",{children:"Risolto il:"})," ",b(e.reviewed_at),(0,gt.jsx)("br",{})]})]}),(0,gt.jsx)(Ek,{className:e.status,children:"approved"===e.status?"Approvato":"Rifiutato"})]},e.id)):(0,gt.jsxs)(Tk,{children:[(0,gt.jsx)("h3",{children:"Nessuna modifica nello storico"}),(0,gt.jsx)("p",{children:"Non hai ancora fatto modifiche alle leghe."})]})]}),"requests"===n&&(0,gt.jsxs)(mk,{children:[(0,gt.jsx)(fk,{children:"\ud83d\udcdd Gestione Richieste"}),(0,gt.jsx)("p",{style:{marginBottom:"1rem",color:"#666"},children:"Gestisci le richieste di ingresso nelle tue leghe. Clicca il pulsante qui sotto per accedere alla pagina di gestione."}),(0,gt.jsx)(wk,{onClick:()=>e("/subadmin-requests"),style:{marginTop:"1rem"},children:"\ud83d\udccb Vai alla Gestione Richieste"})]}),"roster"===n&&(0,gt.jsxs)(mk,{children:[(0,gt.jsx)(fk,{children:"\ud83d\udcca Gestione Roster A/B"}),(0,gt.jsx)("p",{style:{marginBottom:"1rem",color:"#666"},children:"Gestisci i roster A/B per le squadre delle tue leghe. Seleziona una lega per iniziare."}),a.length>0?(0,gt.jsx)("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit, minmax(300px, 1fr))",gap:"1rem"},children:a.map(r=>(0,gt.jsxs)(xk,{onClick:()=>e(`/gestione-roster-admin/${r.id}`),children:[(0,gt.jsxs)(vk,{children:[(0,gt.jsx)(bk,{children:r.nome}),(0,gt.jsx)(wk,{children:"Gestisci Roster"})]}),(0,gt.jsx)(jk,{children:Object.entries(r.permessi).map(e=>{let[r,t]=e;return(0,gt.jsx)(yk,{$active:t,children:j(r)},r)})})]},r.id))}):(0,gt.jsxs)(Tk,{children:[(0,gt.jsx)("h3",{children:"Nessuna lega disponibile"}),(0,gt.jsx)("p",{children:"Non hai accesso a nessuna lega per gestire i roster."})]})]})]})},Ok=Ie.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`,Lk=Ie.div`
  text-align: center;
  margin-bottom: 3rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 2rem;
  border-radius: 16px;
`,Mk=Ie.h1`
  margin: 0 0 0.5rem 0;
  font-size: 2.5rem;
`,Dk=Ie.p`
  font-size: 1.1rem;
  margin: 0;
  opacity: 0.9;
`,Fk=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
`,Uk=Ie.h2`
  color: #333;
  margin: 0 0 2rem 0;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,Bk=Ie.div`
  background: #fff3cd;
  border: 1px solid #ffeaa7;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 2rem;
  color: #856404;
`,Gk=Ie.button`
  background: ${e=>"success"===e.className?"#28a745":"danger"===e.className?"#dc3545":"secondary"===e.className?"#6c757d":"#667eea"};
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s;
  margin-right: 1rem;
  margin-bottom: 1rem;
  
  &:hover {
    opacity: 0.9;
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
  }
`,Wk=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,Hk=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #dc3545;
`,Vk=Ie.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`,Qk=Ie.span`
  background: ${e=>e.$active?"#d4edda":"#f8d7da"};
  color: ${e=>e.$active?"#155724":"#721c24"};
  padding: 0.3rem 0.6rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
  margin-right: 0.5rem;
  margin-bottom: 0.5rem;
  display: inline-block;
`,Kk=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
`,Yk=Ie.div`
  background: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 12px;
  padding: 1.5rem;
  text-align: center;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  }
`,Jk=Ie.div`
  font-size: 2rem;
  font-weight: bold;
  color: #667eea;
  margin-bottom: 0.5rem;
`,Zk=Ie.div`
  font-size: 0.9rem;
  color: #666;
  text-transform: uppercase;
  font-weight: 600;
`,Xk=Ie.div`
  background: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  }
`,e_=Ie.h3`
  margin: 0 0 1rem 0;
  color: #333;
  font-size: 1.2rem;
`,r_=Ie.p`
  color: #666;
  margin-bottom: 1rem;
  line-height: 1.5;
`,t_=()=>{const{legaId:e}=Pr(),t=qr(),{token:i,user:n}=Si(),[o,a]=(0,r.useState)(null),[s,l]=(0,r.useState)([]),[d,c]=(0,r.useState)([]),[u,g]=(0,r.useState)({}),[p,h]=(0,r.useState)(!0),[m,f]=(0,r.useState)("");(0,r.useEffect)(()=>{i&&e&&async function(){h(!0),f("");try{var r,t;const n=await(async(e,r)=>ni.get(`/subadmin/check/${e}`,r))(e,i);if(!n.isSubadmin)return f("Accesso negato: non sei subadmin di questa lega"),void h(!1);g(n.permissions||{});const[o,s,d]=await Promise.all([Ao(e,i),Oo(e,i),wc(e,i)]);a((null===o||void 0===o||null===(r=o.data)||void 0===r?void 0:r.lega)||(null===o||void 0===o?void 0:o.lega)),l((null===s||void 0===s||null===(t=s.data)||void 0===t?void 0:t.squadre)||(null===s||void 0===s?void 0:s.squadre)||[]),c((null===d||void 0===d?void 0:d.data)||d||[])}catch(n){f(n.message)}h(!1)}()},[i,e]);const x=r=>{switch(r){case"squadre":t(`/request-squadre-modification/${e}`);break;case"giocatori":t(`/request-giocatori-modification/${e}`);break;case"tornei":t(`/request-tornei-modification/${e}`);break;case"contratti":t(`/request-contratti-modification/${e}`);break;case"impostazioni":t(`/request-impostazioni-modification/${e}`);break;default:alert(`Funzionalit\xe0 di richiesta modifica per ${r} sar\xe0 implementata presto!`)}};return p?(0,gt.jsx)(Ok,{children:(0,gt.jsx)(Wk,{children:"Caricamento lega..."})}):m?(0,gt.jsx)(Ok,{children:(0,gt.jsxs)(Hk,{children:["Errore: ",m]})}):o?(0,gt.jsxs)(Ok,{children:[(0,gt.jsxs)(Lk,{children:[(0,gt.jsxs)(Mk,{children:["Area Subadmin - ",(null===o||void 0===o?void 0:o.nome)||"Nome"]}),(0,gt.jsx)(Dk,{children:"Richiedi modifiche alla lega (non modificare direttamente)"})]}),(0,gt.jsxs)(Bk,{children:[(0,gt.jsx)("strong",{children:"\u26a0\ufe0f Attenzione:"})," Come subadmin, non puoi modificare direttamente la lega. Puoi solo richiedere modifiche che verranno esaminate dall'amministratore della lega."]}),(0,gt.jsxs)(Fk,{children:[(0,gt.jsx)(Uk,{children:"\ud83d\udd10 I Tuoi Permessi"}),(0,gt.jsx)("div",{children:Object.entries(u).map(e=>{let[r,t]=e;return(0,gt.jsxs)(Qk,{$active:t,children:[(i=r,{modifica_squadre:"Modifica Squadre",gestione_giocatori:"Gestione Calciatori",gestione_tornei:"Gestione Tornei",modifica_impostazioni:"Modifica Impostazioni",gestione_contratti:"Gestione Contratti"}[i]||i),": ",t?"\u2705 Attivo":"\u274c Non attivo"]},r);var i})})]}),(0,gt.jsxs)(Fk,{children:[(0,gt.jsx)(Uk,{children:"\ud83d\udcca Statistiche Lega"}),(0,gt.jsxs)(Kk,{children:[(0,gt.jsxs)(Yk,{children:[(0,gt.jsx)(Jk,{children:(null===s||void 0===s?void 0:s.length)||0}),(0,gt.jsx)(Zk,{children:"Squadre"})]}),(0,gt.jsxs)(Yk,{children:[(0,gt.jsx)(Jk,{children:(null===d||void 0===d?void 0:d.length)||0}),(0,gt.jsx)(Zk,{children:"Tornei"})]}),(0,gt.jsxs)(Yk,{children:[(0,gt.jsx)(Jk,{children:o.numero_giocatori||0}),(0,gt.jsx)(Zk,{children:"Giocatori"})]}),(0,gt.jsxs)(Yk,{children:[(0,gt.jsx)(Jk,{children:o.budget||0}),(0,gt.jsx)(Zk,{children:"Budget"})]})]})]}),(0,gt.jsxs)(Fk,{children:[(0,gt.jsx)(Uk,{children:"\ud83d\udcdd Richieste di Modifica"}),(0,gt.jsxs)("div",{children:[(0,gt.jsxs)(Xk,{children:[(0,gt.jsx)(e_,{children:"\ud83c\udfc6 Gestione Squadre"}),(0,gt.jsx)(r_,{children:"Richiedi modifiche alle squadre della lega (aggiunta/rimozione giocatori, cambio formazione, ecc.)"}),(0,gt.jsx)(Gk,{onClick:()=>x("squadre"),disabled:!u.modifica_squadre,children:"Richiedi Modifica Squadre"})]}),(0,gt.jsxs)(Xk,{children:[(0,gt.jsx)(e_,{children:"\ud83d\udc65 Gestione Calciatori"}),(0,gt.jsx)(r_,{children:"Richiedi modifiche ai giocatori (aggiunta nuovi giocatori, modifica statistiche, ecc.)"}),(0,gt.jsx)(Gk,{onClick:()=>x("giocatori"),disabled:!u.gestione_giocatori,children:"Richiedi Modifica Giocatori"})]}),(0,gt.jsxs)(Xk,{children:[(0,gt.jsx)(e_,{children:"\ud83c\udfc5 Gestione Tornei"}),(0,gt.jsx)(r_,{children:"Richiedi modifiche ai tornei (creazione nuovo torneo, modifica calendario, ecc.)"}),(0,gt.jsx)(Gk,{onClick:()=>x("tornei"),disabled:!u.gestione_tornei,children:"Richiedi Modifica Tornei"})]}),(0,gt.jsxs)(Xk,{children:[(0,gt.jsx)(e_,{children:"\ud83d\udccb Gestione Contratti"}),(0,gt.jsx)(r_,{children:"Richiedi modifiche ai contratti (nuovi contratti, rinnovi, rescissioni, ecc.)"}),(0,gt.jsx)(Gk,{onClick:()=>x("contratti"),disabled:!u.gestione_contratti,children:"Richiedi Modifica Contratti"})]}),(0,gt.jsxs)(Xk,{children:[(0,gt.jsx)(e_,{children:"\u2699\ufe0f Modifica Impostazioni"}),(0,gt.jsx)(r_,{children:"Richiedi modifiche alle impostazioni della lega (budget, regolamento, numero giocatori, ecc.)"}),(0,gt.jsx)(Gk,{onClick:()=>x("impostazioni"),disabled:!u.modifica_impostazioni,children:"Richiedi Modifica Impostazioni"})]})]}),Object.values(u).every(e=>!e)&&(0,gt.jsxs)(Vk,{children:[(0,gt.jsx)("h3",{children:"Nessun permesso attivo"}),(0,gt.jsx)("p",{children:"Non hai ancora permessi attivi per questa lega. Contatta l'amministratore della lega."})]})]}),(0,gt.jsxs)(Fk,{children:[(0,gt.jsx)(Uk,{children:"\u2139\ufe0f Informazioni Lega"}),(0,gt.jsxs)("div",{children:[(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Nome:"})," ",(null===o||void 0===o?void 0:o.nome)||"Nome"]}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Descrizione:"})," ",o.descrizione||"Nessuna descrizione"]}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Regolamento:"})," ",o.regolamento||"Nessun regolamento specificato"]}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Budget:"})," FM ",o.budget||0]}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Numero Giocatori:"})," ",o.numero_giocatori||0]}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Data Creazione:"})," ",new Date(o.created_at).toLocaleDateString("it-IT")]})]})]})]}):(0,gt.jsx)(Ok,{children:(0,gt.jsx)(Hk,{children:"Lega non trovata"})})},i_=Ie.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`,n_=Ie.div`
  text-align: center;
  margin-bottom: 3rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 2rem;
  border-radius: 16px;
`,o_=Ie.h1`
  margin: 0 0 0.5rem 0;
  font-size: 2.5rem;
`,a_=Ie.p`
  font-size: 1.1rem;
  margin: 0;
  opacity: 0.9;
`,s_=Ie.div`
  background: #fff3cd;
  border: 1px solid #ffeaa7;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 2rem;
  color: #856404;
  text-align: center;
  font-weight: 600;
`,l_=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
`,d_=Ie.h2`
  color: #333;
  margin: 0 0 2rem 0;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,c_=Ie.div`
  background: #f8f9fa;
  border: 1px solid #e9ecef;
  border-radius: 12px;
  margin-bottom: 1rem;
  transition: all 0.3s ease;
  overflow: hidden;
  
  ${e=>e.$isModified&&"\n    border-color: #28a745;\n    background: #d4edda;\n  "}
`,u_=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  cursor: pointer;
  background: ${e=>e.$isOpen?"#e3f2fd":"#f8f9fa"};
  transition: all 0.3s ease;
  
  &:hover {
    background: ${e=>e.$isOpen?"#e3f2fd":"#e9ecef"};
  }
`,g_=Ie.h3`
  margin: 0;
  color: #333;
  font-size: 1.3rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,p_=Ie.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`,h_=Ie.div`
  font-size: 0.9rem;
  color: #666;
`,m_=Ie.span`
  font-size: 1.2rem;
  transition: transform 0.3s ease;
  transform: ${e=>e.$isOpen?"rotate(180deg)":"rotate(0deg)"};
`,f_=Ie.div`
  padding: 0;
  max-height: ${e=>e.$isOpen?"2000px":"0"};
  overflow: hidden;
  transition: all 0.3s ease;
  opacity: ${e=>e.$isOpen?"1":"0"};
`,x_=Ie.div`
  padding: 1.5rem;
  background: white;
  border-top: 1px solid #e9ecef;
`,v_=Ie.span`
  background: #28a745;
  color: white;
  padding: 0.3rem 0.6rem;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
`,b_=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 1.5rem;
`,j_=Ie.div`
  display: flex;
  flex-direction: column;
`,y_=Ie.label`
  font-weight: 600;
  color: #333;
  margin-bottom: 0.5rem;
  font-size: 0.9rem;
`,w_=Ie.input`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 0.9rem;
  
  &:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
  }
`,k_=Ie.textarea`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 0.9rem;
  min-height: 100px;
  resize: vertical;
  
  &:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
  }
`,__=Ie.select`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 0.9rem;
  
  &:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.1);
  }
`,S_=Ie.button`
  background: ${e=>"success"===e.className?"#28a745":"danger"===e.className?"#dc3545":"secondary"===e.className?"#6c757d":"#667eea"};
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.8rem;
  margin-right: 0.5rem;
  margin-bottom: 0.5rem;
  
  &:hover {
    opacity: 0.9;
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,C_=Ie.button`
  background: #28a745;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  font-size: 1.1rem;
  margin-top: 2rem;
  
  &:hover {
    background: #218838;
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,z_=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,E_=Ie.div`
  margin-top: 2rem;
  padding-top: 2rem;
  border-top: 1px solid #e9ecef;
`,A_=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
`,R_=Ie.div`
  background: white;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 1rem;
  position: relative;
  
  ${e=>e.$isModified&&"\n    border-color: #28a745;\n    background: #d4edda;\n  "}
  
  ${e=>e.$isRemoved&&"\n    border-color: #dc3545;\n    background: #f8d7da;\n    opacity: 0.6;\n  "}
`,N_=Ie.div`
  font-weight: 600;
  color: #333;
  margin-bottom: 0.5rem;
`,T_=Ie.div`
  font-size: 0.9rem;
  color: #666;
  margin-bottom: 0.25rem;
`,q_=()=>{const{legaId:e}=Pr(),t=qr(),{token:i,user:n}=Si(),[o,a]=(0,r.useState)(null),[s,l]=(0,r.useState)([]),[d,c]=(0,r.useState)([]),[u,g]=(0,r.useState)({}),[p,h]=(0,r.useState)(!0),[m,f]=(0,r.useState)(""),[x,v]=(0,r.useState)({squadreModifiche:{},addedPlayers:{},removedPlayers:{}}),[b,j]=(0,r.useState)(null);(0,r.useEffect)(()=>{i&&e&&async function(){try{var r,t,n;const o=(await ni.get(`/subadmin/check/${e}`,i)).data;if(!o.isSubadmin)return f("Non hai i permessi per modificare questa lega"),void h(!1);g(o.permissions||{});const[s,d,u]=await Promise.all([Ao(e,i),Oo(e,i),lu(e,i)]);a((null===s||void 0===s||null===(r=s.data)||void 0===r?void 0:r.lega)||(null===s||void 0===s?void 0:s.lega)),l((null===d||void 0===d||null===(t=d.data)||void 0===t?void 0:t.squadre)||(null===d||void 0===d?void 0:d.squadre)||[]),c((null===u||void 0===u||null===(n=u.data)||void 0===n?void 0:n.giocatori)||(null===u||void 0===u?void 0:u.giocatori)||[])}catch(o){f(o.message)}h(!1)}()},[i,e]);const y=(e,r,t)=>{v(i=>({...i,squadreModifiche:{...i.squadreModifiche,[e]:{...i.squadreModifiche[e],[r]:t}}}))},w=e=>x.squadreModifiche[e]&&Object.keys(x.squadreModifiche[e]).length>0,k=(e,r)=>{const t=x.addedPlayers[e]||[],i=x.removedPlayers[e]||[];return t.includes(r)||i.includes(r)},_=(e,r)=>(x.removedPlayers[e]||[]).includes(r),S=(e,r,t)=>{var i;return void 0!==(null===(i=x.squadreModifiche[e])||void 0===i?void 0:i[r])?x.squadreModifiche[e][r]:t},C=e=>{const r=s.find(r=>r.id===e),t=(null===r||void 0===r?void 0:r.giocatori)||[],i=x.addedPlayers[e]||[],n=x.removedPlayers[e]||[];return null===d||void 0===d?void 0:d.filter(e=>!t.some(r=>r.id===e.id)&&!i.includes(e.id)&&!n.includes(e.id))},z=()=>Object.keys(x.squadreModifiche).length>0||Object.keys(x.addedPlayers).length>0||Object.keys(x.removedPlayers).length>0;return p?(0,gt.jsx)(i_,{children:(0,gt.jsx)(z_,{children:"Caricamento dati squadre..."})}):m?(0,gt.jsx)(i_,{children:(0,gt.jsxs)("div",{style:{color:"#dc3545",textAlign:"center",padding:"2rem"},children:["Errore: ",m]})}):(0,gt.jsxs)(i_,{children:[(0,gt.jsxs)(n_,{children:[(0,gt.jsx)(o_,{children:"Richiesta Modifica Squadre"}),(0,gt.jsxs)(a_,{children:["Lega: ",null===o||void 0===o?void 0:o.nome]})]}),(0,gt.jsx)(s_,{children:"\ud83d\udd04 Modalit\xe0 Richiesta - Le modifiche verranno inviate all'amministratore della lega per approvazione"}),(0,gt.jsxs)(l_,{children:[(0,gt.jsx)(d_,{children:"\ud83c\udfc6 Gestione Squadre"}),null===s||void 0===s?void 0:s.map(e=>{var r,t;const i=b===e.id,n=(null===(r=e.giocatori)||void 0===r?void 0:r.length)||0;return(0,gt.jsxs)(c_,{$isModified:w(e.id),children:[(0,gt.jsxs)(u_,{$isOpen:i,onClick:()=>{return r=e.id,void j(b===r?null:r);var r},children:[(0,gt.jsxs)(g_,{children:[w(e.id)&&(0,gt.jsx)("span",{style:{color:"#28a745"},children:"\u25cf"}),(null===e||void 0===e?void 0:e.nome)||"Nome"]}),(0,gt.jsxs)(p_,{children:[(0,gt.jsxs)(h_,{children:[n," giocatori \u2022 Level ",e.club_level||1]}),w(e.id)&&(0,gt.jsx)(v_,{children:"Modificata"}),(0,gt.jsx)(m_,{$isOpen:i,children:"\u25bc"})]})]}),(0,gt.jsx)(f_,{$isOpen:i,children:(0,gt.jsxs)(x_,{children:[(0,gt.jsxs)(b_,{children:[(0,gt.jsxs)(j_,{children:[(0,gt.jsx)(y_,{children:"Nome Squadra"}),(0,gt.jsx)(w_,{type:"text",value:S(e.id,"nome",(null===e||void 0===e?void 0:e.nome)||"Nome"),onChange:r=>y(e.id,"nome",r.target.value)})]}),(0,gt.jsxs)(j_,{children:[(0,gt.jsx)(y_,{children:"Immagine URL"}),(0,gt.jsx)(w_,{type:"text",value:S(e.id,"immagine",e.immagine||""),onChange:r=>y(e.id,"immagine",r.target.value),placeholder:"https://esempio.com/immagine.jpg"})]}),(0,gt.jsxs)(j_,{children:[(0,gt.jsx)(y_,{children:"Casse Societarie"}),(0,gt.jsx)(w_,{type:"number",value:S(e.id,"casse_societarie",e.casse_societarie||0),onChange:r=>y(e.id,"casse_societarie",parseInt(r.target.value))})]}),(0,gt.jsxs)(j_,{children:[(0,gt.jsx)(y_,{children:"Club Level"}),(0,gt.jsxs)(__,{value:S(e.id,"club_level",e.club_level||1),onChange:r=>y(e.id,"club_level",parseInt(r.target.value)),children:[(0,gt.jsx)("option",{value:1,children:"Level 1"}),(0,gt.jsx)("option",{value:2,children:"Level 2"}),(0,gt.jsx)("option",{value:3,children:"Level 3"}),(0,gt.jsx)("option",{value:4,children:"Level 4"}),(0,gt.jsx)("option",{value:5,children:"Level 5"})]})]}),(0,gt.jsxs)(j_,{children:[(0,gt.jsx)(y_,{children:"Proprietario"}),(0,gt.jsx)(w_,{type:"text",value:S(e.id,"proprietario",e.proprietario||""),onChange:r=>y(e.id,"proprietario",r.target.value)})]}),(0,gt.jsxs)(j_,{children:[(0,gt.jsx)(y_,{children:"Note"}),(0,gt.jsx)(k_,{value:S(e.id,"note",e.note||""),onChange:r=>y(e.id,"note",r.target.value),placeholder:"Note aggiuntive sulla squadra..."})]})]}),(0,gt.jsx)("div",{children:(0,gt.jsx)(S_,{className:"secondary",onClick:()=>{v(r=>{const t={...r};return delete t.squadreModifiche[e.id],t})},disabled:!w(e.id),children:"Annulla Modifiche Squadra"})}),u.gestione_giocatori&&(0,gt.jsxs)(E_,{children:[(0,gt.jsx)("h4",{children:"\ud83d\udc65 Gestione Giocatori"}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("h5",{children:"Giocatori Attuali:"}),(0,gt.jsx)(A_,{children:null===(t=e.giocatori)||void 0===t?void 0:t.map(r=>(0,gt.jsxs)(R_,{$isModified:k(e.id,r.id),$isRemoved:_(e.id,r.id),children:[(0,gt.jsxs)(N_,{children:[(null===r||void 0===r?void 0:r.nome)||"Nome"," ",(null===r||void 0===r?void 0:r.cognome)||""]}),(0,gt.jsxs)(T_,{children:["Ruolo: ",(null===r||void 0===r?void 0:r.ruolo)||"Ruolo"]}),(0,gt.jsxs)(T_,{children:["Valore: ",r.valore]}),!_(e.id,r.id)&&(0,gt.jsx)(S_,{className:"danger",onClick:()=>{return t=e.id,i=r.id,void v(e=>({...e,removedPlayers:{...e.removedPlayers,[t]:[...e.removedPlayers[t]||[],i]}}));var t,i},children:"Rimuovi"}),_(e.id,r.id)&&(0,gt.jsx)(S_,{className:"success",onClick:()=>{v(t=>({...t,removedPlayers:{...t.removedPlayers,[e.id]:t.removedPlayers[e.id].filter(e=>e!==r.id)}}))},children:"Ripristina"})]},r.id))})]}),(0,gt.jsxs)("div",{style:{marginTop:"2rem"},children:[(0,gt.jsx)("h5",{children:"Giocatori Disponibili:"}),(0,gt.jsx)(A_,{children:C(e.id).map(r=>(0,gt.jsxs)(R_,{children:[(0,gt.jsxs)(N_,{children:[(null===r||void 0===r?void 0:r.nome)||"Nome"," ",(null===r||void 0===r?void 0:r.cognome)||""]}),(0,gt.jsxs)(T_,{children:["Ruolo: ",(null===r||void 0===r?void 0:r.ruolo)||"Ruolo"]}),(0,gt.jsxs)(T_,{children:["Valore: ",r.valore]}),(0,gt.jsx)(S_,{className:"success",onClick:()=>{return t=e.id,i=r.id,void v(e=>({...e,addedPlayers:{...e.addedPlayers,[t]:[...e.addedPlayers[t]||[],i]}}));var t,i},children:"Aggiungi"})]},r.id))})]})]})]})})]},e.id)})]}),(0,gt.jsxs)(l_,{children:[(0,gt.jsx)(d_,{children:"\ud83d\udccb Riepilogo Modifiche"}),(0,gt.jsxs)("div",{children:[(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Squadre modificate:"})," ",Object.keys(x.squadreModifiche).length]}),u.gestione_giocatori&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Giocatori da aggiungere:"})," ",Object.values(x.addedPlayers).flat().length]}),(0,gt.jsxs)("p",{children:[(0,gt.jsx)("strong",{children:"Giocatori da rimuovere:"})," ",Object.values(x.removedPlayers).flat().length]})]})]})]}),(0,gt.jsx)("div",{style:{textAlign:"center"},children:(0,gt.jsx)(C_,{onClick:async()=>{try{const r={legaId:parseInt(e),tipo:"modifica_squadre",modifiche:x,descrizione:`Richiesta modifica squadre per la lega ${(null===o||void 0===o?void 0:o.nome)||"Nome"}`,dettagli:{squadreModificate:Object.keys(x.squadreModifiche).length,giocatoriAggiunti:Object.values(x.addedPlayers).flat().length,giocatoriRimossi:Object.values(x.removedPlayers).flat().length}};await Gi(r,i),alert("Richiesta inviata con successo! L'amministratore della lega esaminer\xe0 le tue modifiche."),t("/subadmin-area")}catch(r){alert("Errore nell'invio della richiesta: "+r.message)}},disabled:!z(),children:z()?"\ud83d\udce4 Invia Richiesta Modifiche":"Nessuna modifica da inviare"})})]})},P_=Ie.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`,$_=Ie.div`
  text-align: center;
  margin-bottom: 3rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 2rem;
  border-radius: 16px;
`,I_=Ie.h1`
  margin: 0 0 0.5rem 0;
  font-size: 2.5rem;
`,O_=Ie.p`
  font-size: 1.1rem;
  margin: 0;
  opacity: 0.9;
`,L_=Ie.div`
  background: #fff3cd;
  border: 1px solid #ffeaa7;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 2rem;
  color: #856404;
  text-align: center;
  font-weight: 600;
`,M_=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
`,D_=Ie.h2`
  color: #333;
  margin: 0 0 2rem 0;
  font-size: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,F_=Ie.div`
  overflow-x: auto;
`,U_=Ie.table`
  width: 100%;
  border-collapse: collapse;
  font-size: 0.85rem;
`,B_=Ie.th`
  background: #5856d6;
  color: white;
  padding: 0.75rem 0.5rem;
  text-align: center;
  font-weight: 600;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.2s;
  
  &:hover {
    background: #4a4ac7;
  }
  
  &:first-child {
    border-top-left-radius: 8px;
  }
  
  &:last-child {
    border-top-right-radius: 8px;
  }
`,G_=Ie.td`
  padding: 0.75rem 0.5rem;
  border-bottom: 1px solid #e5e5e7;
  color: #1d1d1f;
  text-align: center;
`,W_=Ie.div`
  font-weight: 600;
  color: #1d1d1f;
  margin-bottom: 0.25rem;
  cursor: pointer;
  transition: color 0.2s;
  
  &:hover {
    color: #007AFF;
  }
`,H_=Ie.div`
  font-size: 0.75rem;
  color: #86868b;
`,V_=Ie.span`
  font-weight: 600;
  color: #28a745;
`,Q_=Ie.span`
  font-weight: 600;
  color: #007AFF;
`,K_=Ie.button`
  background: none;
  border: none;
  color: #007AFF;
  cursor: pointer;
  font-size: 1.2rem;
  padding: 0.25rem;
  border-radius: 4px;
  transition: all 0.2s;
  
  &:hover {
    background: #f0f0f0;
  }
`,Y_=Ie.div`
  background: #f8f9fa;
  border-radius: 8px;
  margin: 0.5rem 0;
  overflow: hidden;
  transition: all 0.3s ease;
`,J_=Ie.div`
  background: #e9ecef;
  padding: 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  
  &:hover {
    background: #dee2e6;
  }
`,Z_=Ie.h3`
  margin: 0;
  color: #333;
  font-size: 1.1rem;
`,X_=Ie.span`
  background: #007AFF;
  color: white;
  padding: 0.25rem 0.5rem;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 600;
`,eS=Ie.div`
  padding: 1rem;
  max-height: ${e=>e.$expanded?"none":"0"};
  overflow: hidden;
  transition: all 0.3s ease;
`,rS=Ie.table`
  width: 100%;
  border-collapse: collapse;
  font-size: 0.8rem;
`,tS=Ie.tr`
  &:hover {
    background: #f0f0f0;
  }
`,iS=Ie.td`
  padding: 0.5rem;
  border-bottom: 1px solid #e5e5e7;
  color: #1d1d1f;
  text-align: center;
`,nS=Ie.div`
  font-weight: 600;
  color: #1d1d1f;
`,oS=Ie.span`
  .ruolo-badge {
    display: inline-block;
    padding: 2px 6px;
    margin: 1px;
    border-radius: 5px;
    font-size: 9.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: center;
    min-width: 18px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.08);
    border: 1px solid rgba(255,255,255,0.18);
    transition: all 0.2s ease;
  }
  
  .ruolo-badge:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.13);
  }
`,aS=Ie.button`
  background: #007AFF;
  color: white;
  border: none;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.75rem;
  transition: all 0.2s;
  
  &:hover {
    background: #0056b3;
  }
`,sS=Ie.div`
  position: fixed;
  left: 20px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  z-index: 1000;
`,lS=Ie.button`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  transition: all 0.2s;
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
  
  &.scroll-top {
    background: #28a745;
    color: white;
    
    &:hover {
      background: #218838;
    }
  }
  
  &.close-players {
    background: #dc3545;
    color: white;
    
    &:hover {
      background: #c82333;
    }
  }
`,dS=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 2000;
`,cS=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 900px;
  width: 95%;
  max-height: 90vh;
  overflow-y: auto;
`,uS=Ie.h3`
  margin: 0 0 1.5rem 0;
  color: #333;
  display: flex;
  justify-content: space-between;
  align-items: center;
`,gS=Ie.button`
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #666;
  
  &:hover {
    color: #333;
  }
`,pS=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
`,hS=Ie.div`
  display: flex;
  flex-direction: column;
`,mS=Ie.label`
  font-weight: 600;
  color: #333;
  margin-bottom: 0.5rem;
  font-size: 0.9rem;
`,fS=Ie.input`
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 0.9rem;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,xS=(Ie.select`
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 0.9rem;
  
  &:focus {
    outline: none;
    border-color: #007AFF;
  }
`,Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: flex-end;
  margin-top: 2rem;
`),vS=Ie.button`
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s;
  
  &.primary {
    background: #007AFF;
    color: white;
    
    &:hover {
      background: #0056b3;
    }
  }
  
  &.secondary {
    background: #6c757d;
    color: white;
  
  &:hover {
      background: #545b62;
    }
  }
  
  &.success {
    background: #28a745;
    color: white;
    
    &:hover {
      background: #218838;
    }
  }
`,bS=Ie.button`
  background: #28a745;
  color: white;
  border: none;
  padding: 1rem 2rem;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  font-size: 1.1rem;
  margin-top: 2rem;
  width: 100%;
  
  &:hover {
    background: #218838;
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,jS=Ie.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  font-size: 1.2rem;
  color: #666;
`,yS=()=>{const{legaId:e}=Pr(),t=qr(),{token:i}=Si(),[n,o]=(0,r.useState)(null),[a,s]=(0,r.useState)([]),[l,d]=(0,r.useState)({}),[c,u]=(0,r.useState)({}),[g,p]=(0,r.useState)(!0),[h,m]=(0,r.useState)(""),[f,x]=(0,r.useState)(!1),[v,b]=(0,r.useState)(null),[j,y]=(0,r.useState)({}),[w,k]=(0,r.useState)({});(0,r.useEffect)(()=>{i&&e&&async function(){p(!0),m("");try{const[t,n]=await Promise.all([Ao(e,i),Oo(e,i)]);o(t.lega),s(n.squadre||[]);const a={};for(const e of n.squadre||[])try{const r=await du(e.id,i);let t=[];r&&r.ok&&r.data?t=r.data.giocatori||r.data||[]:r&&r.giocatori?t=r.giocatori:Array.isArray(r)?t=r:console.error("Nessun dato valido trovato per giocatori:",r),a[e.id]=t}catch(r){console.error(`Errore caricamento giocatori squadra ${e.id}:`,r),a[e.id]=[]}d(a)}catch(r){m(r.message)}p(!1)}()},[i,e]);const _=e=>{u(r=>({...r,[e]:!r[e]}))},S=(e,r)=>{y(t=>({...t,[e]:r}))},C=()=>{x(!1),b(null),y({})},z=e=>new Intl.NumberFormat("it-IT",{style:"currency",currency:"EUR"}).format(e),E=()=>{let e=0;for(const r of Object.values(w))e+=Object.keys(r).length;return e},A=e=>{if(!e)return[];const r=((null===n||void 0===n?void 0:n.modalita)||"").includes("Mantra"),t=r?["Por","Ds","Dc","Dd","B","E","M","C","T","W","A","Pc"]:["P","D","C","A"];return[...e].sort((e,i)=>{const n=e.ruolo||"",o=i.ruolo||"";let a=n,s=o;if(r){a=n.split(";")[0],s=o.split(";")[0]}const l=t.indexOf(a),d=t.indexOf(s);return-1!==l&&-1!==d?l===d?n.localeCompare(o):l-d:-1!==l?-1:-1!==d?1:n.localeCompare(o)})};return g?(0,gt.jsx)(P_,{children:(0,gt.jsx)(jS,{children:"Caricamento dati lega..."})}):h?(0,gt.jsx)(P_,{children:(0,gt.jsxs)("div",{style:{color:"#dc3545",textAlign:"center",padding:"2rem"},children:["Errore: ",h]})}):(0,gt.jsxs)(P_,{children:[(0,gt.jsxs)($_,{children:[(0,gt.jsx)(I_,{children:"Richiesta Modifica Giocatori"}),(0,gt.jsxs)(O_,{children:["Lega: ",null===n||void 0===n?void 0:n.nome]})]}),(0,gt.jsx)(L_,{children:"\ud83d\udcdd Modalit\xe0 Richiesta: Le modifiche verranno inviate all'amministratore della lega per approvazione"}),(0,gt.jsxs)(M_,{children:[(0,gt.jsx)(D_,{children:"\ud83c\udfc6 Squadre della Lega"}),(0,gt.jsx)(F_,{children:(0,gt.jsxs)(U_,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(B_,{children:"Squadra"}),(0,gt.jsx)(B_,{children:"Proprietario"}),(0,gt.jsx)(B_,{children:"Giocatori"}),(0,gt.jsx)(B_,{children:"Valore Roster"}),(0,gt.jsx)(B_,{children:"Budget"}),(0,gt.jsx)(B_,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:a.map(e=>{var t,i,n;return(0,gt.jsxs)(r.Fragment,{children:[(0,gt.jsxs)("tr",{children:[(0,gt.jsxs)(G_,{children:[(0,gt.jsx)(W_,{onClick:()=>_(e.id),children:e.nome}),(0,gt.jsx)(H_,{children:e.proprietario||"N/A"})]}),(0,gt.jsx)(G_,{children:e.proprietario||"N/A"}),(0,gt.jsx)(G_,{children:(null===(t=l[e.id])||void 0===t?void 0:t.length)||0}),(0,gt.jsx)(G_,{children:(0,gt.jsx)(V_,{children:z((null===(i=l[e.id])||void 0===i?void 0:i.reduce((e,r)=>e+(r.valore||0),0))||0)})}),(0,gt.jsx)(G_,{children:(0,gt.jsx)(V_,{children:z(e.budget||0)})}),(0,gt.jsx)(G_,{children:(0,gt.jsx)(K_,{onClick:()=>_(e.id),children:c[e.id]?"\u25bc":"\u25b6"})})]}),c[e.id]&&(0,gt.jsx)("tr",{children:(0,gt.jsx)(G_,{colSpan:"6",style:{padding:0},children:(0,gt.jsxs)(Y_,{children:[(0,gt.jsxs)(J_,{children:[(0,gt.jsxs)(Z_,{children:["Giocatori di ",e.nome]}),(0,gt.jsx)(X_,{children:(null===(n=l[e.id])||void 0===n?void 0:n.length)||0})]}),(0,gt.jsx)(eS,{$expanded:c[e.id],children:(0,gt.jsxs)(rS,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(B_,{children:"Giocatore"}),(0,gt.jsx)(B_,{children:"Ruolo"}),(0,gt.jsx)(B_,{children:"M"}),(0,gt.jsx)(B_,{children:"FaM"}),(0,gt.jsx)(B_,{children:"Squadra Reale"}),(0,gt.jsx)(B_,{children:"Cantera"}),(0,gt.jsx)(B_,{children:"QI"}),(0,gt.jsx)(B_,{children:"Ingaggio"}),(0,gt.jsx)(B_,{children:"QA"}),(0,gt.jsx)(B_,{children:"FVMp"}),(0,gt.jsx)(B_,{children:"Anni Contratto"}),(0,gt.jsx)(B_,{children:"Prestito"}),(0,gt.jsx)(B_,{children:"Triggers"}),(0,gt.jsx)(B_,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:A(l[e.id]||[]).map(e=>(0,gt.jsxs)(tS,{children:[(0,gt.jsx)(iS,{children:(0,gt.jsxs)(nS,{children:[e.nome," ",e.cognome]})}),(0,gt.jsx)(iS,{children:(0,gt.jsx)(oS,{children:cu(e.ruolo).map((e,r)=>(0,gt.jsx)("span",{className:`ruolo-badge ${uu(e)}`,children:e},r))})}),(0,gt.jsx)(iS,{children:e.r||"N/A"}),(0,gt.jsx)(iS,{children:e.fr||"N/A"}),(0,gt.jsx)(iS,{children:e.squadra_reale||"N/A"}),(0,gt.jsx)(iS,{children:e.cantera?"\u2714":"-"}),(0,gt.jsx)(iS,{children:e.qi||"N/A"}),(0,gt.jsx)(iS,{children:(0,gt.jsxs)(Q_,{children:["FM ",e.costo_attuale||0]})}),(0,gt.jsx)(iS,{children:e.qa||"N/A"}),(0,gt.jsx)(iS,{children:e.fvmp||"N/A"}),(0,gt.jsx)(iS,{children:e.anni_contratto||"N/A"}),(0,gt.jsx)(iS,{children:e.prestito||"N/A"}),(0,gt.jsx)(iS,{children:e.triggers||"N/A"}),(0,gt.jsx)(iS,{children:(0,gt.jsx)(aS,{onClick:()=>(e=>{b(e),y({}),x(!0)})(e),children:"Modifica"})})]},e.id))})]})})]})})})]},e.id)})})]})})]}),Object.keys(c).length>0&&(0,gt.jsxs)(sS,{children:[(0,gt.jsx)(lS,{className:"scroll-top",onClick:()=>{window.scrollTo({top:0,behavior:"smooth"})},title:"Torna in cima",children:"\u2191"}),(0,gt.jsx)(lS,{className:"close-players",onClick:()=>{u({})},title:"Chiudi tutte le liste",children:"\u2715"})]}),f&&v&&(0,gt.jsx)(dS,{onClick:C,children:(0,gt.jsxs)(cS,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(uS,{children:["Modifica Giocatore: ",v.nome," ",v.cognome,(0,gt.jsx)(gS,{onClick:C,children:"\xd7"})]}),(0,gt.jsxs)(pS,{children:[(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Nome"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.nome,onChange:e=>S("nome",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Cognome"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.cognome,onChange:e=>S("cognome",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Ruolo"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.ruolo,onChange:e=>S("ruolo",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Media Voto"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.media_voto,onChange:e=>S("media_voto",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Fantamedia Voto"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.fantamedia_voto,onChange:e=>S("fantamedia_voto",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Squadra Reale"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.squadra_reale,onChange:e=>S("squadra_reale",e.target.value)})]}),(0,gt.jsx)(hS,{children:(0,gt.jsxs)(mS,{style:{display:"flex",alignItems:"center",gap:"0.5rem"},children:[(0,gt.jsx)("input",{type:"checkbox",defaultChecked:v.cantera,onChange:e=>S("cantera",e.target.checked)}),"Calciatore Cantera"]})}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Quotazione Iniziale"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.quotazione_iniziale,onChange:e=>S("quotazione_iniziale",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Ingaggio"}),(0,gt.jsx)(fS,{type:"number",defaultValue:v.costo_attuale,onChange:e=>S("costo_attuale",parseFloat(e.target.value))})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Quotazione Attuale"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.qa,onChange:e=>S("quotazione_attuale",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Fanta Valore di Mercato"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.fvm,onChange:e=>S("fanta_valore_mercato",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Anni Contratto"}),(0,gt.jsx)(fS,{type:"number",defaultValue:v.anni_contratto,onChange:e=>S("anni_contratto",parseInt(e.target.value))})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Prestito"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.prestito,onChange:e=>S("prestito",e.target.value)})]}),(0,gt.jsxs)(hS,{children:[(0,gt.jsx)(mS,{children:"Triggers"}),(0,gt.jsx)(fS,{type:"text",defaultValue:v.triggers,onChange:e=>S("triggers",e.target.value)})]})]}),(0,gt.jsxs)(xS,{children:[(0,gt.jsx)(vS,{className:"secondary",onClick:C,children:"Annulla"}),(0,gt.jsx)(vS,{className:"success",onClick:()=>{if(!v)return;const e=v.squadra_id,r=v.id;k(t=>{var i;return{...t,[e]:{...t[e],[r]:{...null===(i=t[e])||void 0===i?void 0:i[r],...j}}}}),x(!1),b(null),y({})},children:"Richiedi"})]})]})}),Object.keys(w).length>0&&(0,gt.jsxs)(M_,{children:[(0,gt.jsxs)(D_,{children:["\ud83d\udccb Modifiche in Attesa (",E(),")"]}),Object.entries(w).map(e=>{let[r,t]=e;const i=a.find(e=>e.id===r);return(0,gt.jsxs)("div",{style:{marginBottom:"1rem"},children:[(0,gt.jsx)("h4",{children:null===i||void 0===i?void 0:i.nome}),Object.entries(t).map(e=>{var t;let[i,n]=e;const o=null===(t=l[r])||void 0===t?void 0:t.find(e=>e.id===i);return(0,gt.jsxs)("div",{style:{background:"#f8f9fa",padding:"0.5rem",margin:"0.25rem 0",borderRadius:"4px",display:"flex",justifyContent:"space-between",alignItems:"center"},children:[(0,gt.jsxs)("span",{children:[null===o||void 0===o?void 0:o.nome," ",null===o||void 0===o?void 0:o.cognome," -",Object.entries(n).map(e=>{let[r,t]=e;return` ${{nome:"Nome",cognome:"Cognome",ruolo:"Ruolo",media_voto:"Media Voto",fantamedia_voto:"Fantamedia Voto",squadra_reale:"Squadra Reale",cantera:"Cantera",quotazione_iniziale:"Quotazione Iniziale",costo_attuale:"Ingaggio",quotazione_attuale:"Quotazione Attuale",fanta_valore_mercato:"Fanta Valore di Mercato",anni_contratto:"Anni Contratto",prestito:"Prestito",triggers:"Triggers"}[r]||r}: ${t}`}).join(", ")]}),(0,gt.jsx)(vS,{className:"secondary",onClick:()=>((e,r)=>{k(t=>{const i={...t};return i[e]&&(delete i[e][r],0===Object.keys(i[e]).length&&delete i[e]),i})})(r,i),style:{padding:"0.25rem 0.5rem",fontSize:"0.75rem"},children:"Rimuovi"})]},i)})]},r)}),(0,gt.jsxs)(bS,{onClick:async()=>{try{const n=[];for(const[t,i]of Object.entries(w))for(const[o,s]of Object.entries(i)){var r;const i=null===(r=l[t])||void 0===r?void 0:r.find(e=>e.id===o);if(i){const r=a.find(e=>e.id===parseInt(t)||e.id===t);console.log("Debug createPendingChange:",{squadraId:t,squadra:r,giocatore:i,modifiche:s}),n.push({legaId:parseInt(e),tipo:"gestione_giocatori",modifiche:{giocatoreId:parseInt(o),giocatore:i.nome+" "+i.cognome,squadra:(null===r||void 0===r?void 0:r.nome)||"N/A",modifiche:s,valoriOriginali:{nome:i.nome,cognome:i.cognome,ruolo:i.ruolo,media_voto:i.media_voto,fantamedia_voto:i.fantamedia_voto,squadra_reale:i.squadra_reale,eta:i.eta,quotazione_iniziale:i.quotazione_iniziale,costo_attuale:i.costo_attuale,quotazione_attuale:i.qa,fanta_valore_mercato:i.fvm,anni_contratto:i.anni_contratto,prestito:i.prestito,triggers:i.triggers}},descrizione:`Modifica giocatore ${i.nome} ${i.cognome}`,dettagli:{giocatore:i.nome+" "+i.cognome,modifiche:Object.keys(s)}})}}for(const e of n)await Gi(e,i);alert(`${n.length} richieste di modifica inviate con successo!`),t("/subadmin-area")}catch(n){alert("Errore nell'invio delle richieste: "+n.message)}},children:["Richiedi Modifiche (",E(),")"]})]})]})},wS=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`,kS=Ie.div`
  margin-bottom: 2rem;
`,_S=Ie.h1`
  color: #1d1d1f;
  margin-bottom: 0.5rem;
`,SS=Ie.p`
  color: #86868b;
  font-size: 1.1rem;
`,CS=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
`,zS=Ie.h2`
  color: #1d1d1f;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,ES=Ie.div`
  border: 1px solid #e5e5e7;
  border-radius: 8px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  background: #f8f9fa;
`,AS=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 1rem;
`,RS=Ie.div`
  flex: 1;
`,NS=Ie.h3`
  color: #1d1d1f;
  margin-bottom: 0.5rem;
`,TS=Ie.div`
  color: #86868b;
  font-size: 0.9rem;
  line-height: 1.4;
`,qS=Ie.div`
  display: flex;
  gap: 0.5rem;
`,PS=Ie.button`
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.2s;
  
  &.success {
    background: #28a745;
    color: white;
    
    &:hover {
      background: #218838;
    }
  }
  
  &.danger {
    background: #dc3545;
    color: white;
    
    &:hover {
      background: #c82333;
    }
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,$S=Ie.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`,IS=Ie.div`
  text-align: center;
  padding: 3rem;
  color: #666;
`,OS=()=>{const{token:e}=Si(),[t,i]=(0,r.useState)([]),[n,o]=(0,r.useState)(!0),[a,s]=(0,r.useState)("");(0,r.useEffect)(()=>{l()},[e]);const l=async()=>{try{o(!0);const r=await ni.get("/richieste/subadmin",{headers:{Authorization:`Bearer ${e}`}});if(200!==r.status){const e=r.data;throw new Error(e.error||"Errore nel caricamento delle richieste")}const t=r.data;i(t.richieste||[])}catch(r){s(r.message)}finally{o(!1)}},d=async function(r,t){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"";try{const n=await ni.post(`/richieste/${r}/rispondi`,{risposta:t,messaggio:i},{headers:{"Content-Type":"application/json",Authorization:`Bearer ${e}`}});if(200!==n.status){const e=n.data;throw new Error(e.error||"Errore nella risposta")}alert(`Richiesta ${"accetta"===t?"accettata":"rifiutata"} con successo!`),l()}catch(n){alert(`Errore: ${n.message}`)}};return n?(0,gt.jsx)(wS,{children:(0,gt.jsx)(IS,{children:"Caricamento richieste..."})}):a?(0,gt.jsx)(wS,{children:(0,gt.jsxs)(kS,{children:[(0,gt.jsx)(_S,{children:"Gestione Richieste"}),(0,gt.jsxs)(SS,{children:["Errore: ",a]})]})}):(0,gt.jsxs)(wS,{children:[(0,gt.jsxs)(kS,{children:[(0,gt.jsx)(_S,{children:"Gestione Richieste"}),(0,gt.jsx)(SS,{children:"Gestisci le richieste di ingresso nelle tue leghe"})]}),(0,gt.jsxs)(CS,{children:[(0,gt.jsxs)(zS,{children:["\ud83d\udccb Richieste in Attesa (",t.length,")"]}),t.length>0?t.map(e=>{return(0,gt.jsx)(ES,{children:(0,gt.jsxs)(AS,{children:[(0,gt.jsxs)(RS,{children:[(0,gt.jsxs)(NS,{children:["Richiesta di ingresso - ",e.lega_nome]}),(0,gt.jsxs)(TS,{children:[(0,gt.jsx)("strong",{children:"Utente:"})," ",e.utente_nome," (",e.utente_email,")",(0,gt.jsx)("br",{}),(0,gt.jsx)("strong",{children:"Squadra:"})," ",e.squadra_nome,(0,gt.jsx)("br",{}),(0,gt.jsx)("strong",{children:"Data richiesta:"})," ",(r=e.data_richiesta,new Date(r).toLocaleString("it-IT")),(0,gt.jsx)("br",{}),e.messaggio_richiesta&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)("strong",{children:"Messaggio:"})," ",e.messaggio_richiesta,(0,gt.jsx)("br",{})]})]})]}),(0,gt.jsxs)(qS,{children:[(0,gt.jsx)(PS,{className:"success",onClick:()=>d(e.id,"accetta"),children:"Accetta"}),(0,gt.jsx)(PS,{className:"danger",onClick:()=>{const r=prompt("Inserisci un messaggio per il rifiuto (opzionale):");d(e.id,"rifiuta",r)},children:"Rifiuta"})]})]})},e.id);var r}):(0,gt.jsx)($S,{children:"Nessuna richiesta in attesa"})]})]})},LS=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`,MS=Ie.div`
  margin-bottom: 2rem;
`,DS=Ie.p`
  color: #86868b;
  margin: 0;
`,FS=Ie.span`
  background: linear-gradient(135deg, #ff9f21 0%, #ff6b35 100%);
  color: white;
  padding: 0.4rem 0.8rem;
  border-radius: 20px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.9rem;
  text-decoration: none;
  display: inline-block;
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(255, 159, 33, 0.3);
  border: 2px solid transparent;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(255, 159, 33, 0.4);
    border-color: rgba(255, 255, 255, 0.3);
  }
  
  &:active {
    transform: translateY(0);
  }
`,US=Ie.img`
  width: 48px;
  height: 48px;
  border-radius: 50%;
  object-fit: cover;
  background: #eee;
  margin-right: 1rem;
  border: 2px solid #fff;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
`,BS=Ie.div`
  display: flex;
  align-items: center;
  margin-bottom: 0.5rem;
`,GS=Ie.h1`
  color: #1d1d1f;
  margin: 0;
  display: flex;
  align-items: center;
`,WS=Ie.button`
  background: none;
  border: none;
  color: #007aff;
  cursor: pointer;
  font-size: 1rem;
  margin-bottom: 1rem;
  padding: 0;
  
  &:hover {
    text-decoration: underline;
  }
`,HS=Ie.div`
  background: #f8f9fa;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 0.75rem;
`,VS=Ie.div`
  text-align: center;
`,QS=Ie.div`
  color: #86868b;
  font-size: 0.8rem;
  margin-bottom: 0.25rem;
`,KS=Ie.div`
  color: #1d1d1f;
  font-weight: 600;
  font-size: 1rem;
`,YS=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
`,JS=Ie.div`
  display: flex;
  gap: 1rem;
  align-items: center;
`,ZS=Ie.button`
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.2s;
  
  &.primary {
    background: #007aff;
    color: white;
    
    &:hover {
      background: #0056b3;
    }
    
    &:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
  }
  
  &.secondary {
    background: #6c757d;
    color: white;
    
    &:hover {
      background: #545b62;
    }
  }
  
  &.success {
    background: #28a745;
    color: white;
    
    &:hover {
      background: #1e7e34;
    }
  }
`,XS=Ie(ZS)`
  background: #28a745;
  color: white;
  font-weight: 600;
  padding: 0.75rem 1.5rem;
  
  &:hover {
    background: #1e7e34;
  }
  
  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,eC=Ie.div`
  background: white;
  border-radius: 8px;
  overflow-x: auto;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  margin-top: 1rem;
`,rC=Ie.table`
  width: 100%;
  border-collapse: collapse;
`,tC=Ie.th`
  background: #ff9f21;
  color: white;
  padding: 0.5rem 0.3rem;
  text-align: center;
  font-weight: 600;
  font-size: 0.7rem;
  text-transform: uppercase;
  letter-spacing: 0.3px;
  cursor: pointer;
  user-select: none;
  transition: background-color 0.2s;
  border-bottom: 1px solid #dee2e6;
  white-space: nowrap;
  
  &:hover {
    background: #e68a1e;
  }
  
  &:first-child {
    border-top-left-radius: 8px;
  }
  
  &:last-child {
    border-top-right-radius: 8px;
  }
`,iC=Ie.td`
  padding: 0.5rem 0.3rem;
  border-bottom: 1px solid #dee2e6;
  vertical-align: middle;
  font-size: 0.8rem;
  text-align: center;
  white-space: nowrap;
`,nC=Ie.input`
  width: 18px;
  height: 18px;
  cursor: pointer;
`,oC=Ie.span`
  color: #007aff;
  font-weight: 600;
  cursor: pointer;
  
  &:hover {
    text-decoration: underline;
  }
`,aC=Ie.span`
  .ruolo-badge {
    display: inline-block;
    padding: 4px 8px;
    margin: 2px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-align: center;
    min-width: 24px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    transition: all 0.2s ease;
  }
  
  .ruolo-badge:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
  }
  
  .ruolo-badge:last-child {
    margin-right: 0;
  }
  
  /* Ruoli Serie A Classic */
  .ruolo-p { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  .ruolo-d { 
    background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  .ruolo-c { 
    background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-a { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #c62828;
  }
  
  /* Ruoli Euroleghe Mantra */
  /* Portieri - Arancione (come P) */
  .ruolo-por { 
    background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); 
    color: white; 
    border-color: #e65100;
  }
  
  /* Difensori - Palette di verdi */
  .ruolo-dc { 
    background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); 
    color: white; 
    border-color: #0d4f14;
  }
  
  .ruolo-dd { 
    background: linear-gradient(135deg, #388e3c 0%, #2e7d32 100%); 
    color: white; 
    border-color: #1b5e20;
  }
  
  .ruolo-ds { 
    background: linear-gradient(135deg, #43a047 0%, #388e3c 100%); 
    color: white; 
    border-color: #2e7d32;
  }
  
  /* Centrocampisti - Palette di blu */
  .ruolo-b { 
    background: linear-gradient(135deg, #1565c0 0%, #0d47a1 100%); 
    color: white; 
    border-color: #002171;
  }
  
  .ruolo-e { 
    background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); 
    color: white; 
    border-color: #0d47a1;
  }
  
  .ruolo-m { 
    background: linear-gradient(135deg, #1e88e5 0%, #1976d2 100%); 
    color: white; 
    border-color: #1565c0;
  }
  
  .ruolo-t { 
    background: linear-gradient(135deg, #42a5f5 0%, #1e88e5 100%); 
    color: white; 
    border-color: #1976d2;
  }
  
  .ruolo-w { 
    background: linear-gradient(135deg, #64b5f6 0%, #42a5f5 100%); 
    color: white; 
    border-color: #1e88e5;
  }
  
  /* Attaccanti - Palette di rossi */
  .ruolo-a { 
    background: linear-gradient(135deg, #d32f2f 0%, #b71c1c 100%); 
    color: white; 
    border-color: #8e0000;
  }
  
  .ruolo-pc { 
    background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); 
    color: white; 
    border-color: #b71c1c;
  }
  
  /* Fallback */
  .ruolo-default { 
    background: linear-gradient(135deg, #757575 0%, #616161 100%); 
    color: white; 
    border-color: #424242;
  }
`,sC=Ie.button`
  padding: 0.3rem 0.6rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.75rem;
  transition: all 0.2s;
  white-space: nowrap;
  
  &.contract {
    background: #007aff;
    color: white;
    
    &:hover {
      background: #0056b3;
    }
  }
  
  &.transfer {
    background: #6c757d;
    color: white;
    
    &:hover {
      background: #545b62;
    }
  }
  
  &.renew {
    background: #28a745;
    color: white;
    
    &:hover {
      background: #1e7e34;
    }
  }
`,lC=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,dC=Ie.div`
  background: white;
  padding: 2rem;
  border-radius: 8px;
  max-width: 500px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
`,cC=Ie.h2`
  margin-bottom: 1.5rem;
  color: #1d1d1f;
`,uC=Ie.div`
  margin-bottom: 1rem;
`,gC=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #1d1d1f;
`,pC=Ie.input`
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #007aff;
  }
`,hC=Ie.div`
  display: flex;
  gap: 1rem;
  margin-top: 1.5rem;
`,mC=Ie.div`
  font-size: 0.9rem;
  color: #86868b;
  margin-bottom: 1rem;
  padding: 0.5rem;
  background: #f8f9fa;
  border-radius: 4px;
`,fC=Ie.div`
  background: #fff3cd;
  color: #856404;
  padding: 1rem;
  border-radius: 4px;
  margin: 1rem 0;
  border: 1px solid #ffeaa7;
`,xC=Ie.div`
  margin-top: 1.5rem;
  border-top: 1px solid #dee2e6;
  padding-top: 1rem;
`,vC=Ie.h4`
  color: #1d1d1f;
  margin-bottom: 1rem;
  font-size: 1rem;
`,bC=Ie.div`
  background: #f8f9fa;
  padding: 0.75rem;
  border-radius: 4px;
  margin-bottom: 0.5rem;
  border-left: 3px solid #28a745;
`,jC=Ie.div`
  font-size: 0.8rem;
  color: #86868b;
  margin-bottom: 0.25rem;
`,yC=Ie.div`
  font-size: 0.9rem;
  color: #1d1d1f;
  font-weight: 500;
`,wC=Ie.span`
  color: #28a745;
  font-weight: 600;
`,kC=Ie.div`
  text-align: center;
  color: #86868b;
  font-style: italic;
  padding: 1rem;
`,_C=()=>{var e,t,i;const{token:n}=Si(),o=qr(),{legaId:a}=Pr(),[s,l]=(0,r.useState)(null),[d,c]=(0,r.useState)(!0),[u,g]=(0,r.useState)(""),[p,h]=(0,r.useState)([]),[m,f]=(0,r.useState)(!1),[x,v]=(0,r.useState)(!1),[b,j]=(0,r.useState)(!1),[y,w]=(0,r.useState)(!1),[k,_]=(0,r.useState)(!1),[S,C]=(0,r.useState)(null),[z,E]=(0,r.useState)(1),[A,R]=(0,r.useState)([]),[N,T]=(0,r.useState)(!1),[q,P]=(0,r.useState)({prestito:!1,trasferimento:!1,valorePrestito:0,valoreTrasferimento:0}),[$,I]=(0,r.useState)(null),[O,L]=(0,r.useState)({roster_ab:!1,cantera:!1,contratti:!1,triggers:!1,is_classic:!1}),[M,D]=(0,r.useState)([]);(0,r.useEffect)(()=>{F()},[a,n]),(0,r.useEffect)(()=>{s&&n&&U()},[s,n]);const F=(0,r.useCallback)(async()=>{if(n&&a){c(!0),g("");try{var e,r;const t=await async function(e,r){return ni.get(`/squadre/my-team/${e}`,r)}(a,n);console.log("fetchSquadra: risposta API:",t);const i=(null===t||void 0===t||null===(e=t.data)||void 0===e?void 0:e.squadra)||(null===t||void 0===t?void 0:t.squadra);l(i),console.log("fetchSquadra: squadra impostata:",i);const o=(null===t||void 0===t||null===(r=t.data)||void 0===r?void 0:r.config)||(null===t||void 0===t?void 0:t.config);o&&L(o)}catch(t){console.error("fetchSquadra: errore:",t),g(t.message)}finally{c(!1)}}},[n,a]),U=(0,r.useCallback)(async()=>{if(s&&n&&s.id)try{console.log("fetchRosterData: chiamando API con squadra.id:",s.id);const e=await fetch(`${ri}/offerte/roster/${s.id}`,{headers:{Authorization:`Bearer ${n}`}});if(e.ok){const r=e.data;I(r)}else console.error("fetchRosterData: errore response:",e.status,e.statusText)}catch(e){console.error("Errore caricamento dati roster:",e)}else console.log("fetchRosterData: squadra o token mancanti, squadra:",s)},[s,n]),B=()=>{var e;null!==s&&void 0!==s&&s.giocatori&&h(null===(e=s.giocatori)||void 0===e?void 0:e.map(e=>null===e||void 0===e?void 0:e.id))},G=()=>{h([])},W=async(e,r)=>{if(C(r),"renew"===e){j(!0),T(!0);try{var t;const e=await(async(e,r)=>bc("GET",`/contratti/log-giocatore/${e}`,null,r))(r.id,n),i=(null===e||void 0===e||null===(t=e.data)||void 0===t?void 0:t.log)||(null===e||void 0===e?void 0:e.log)||[];R(i)}catch(i){console.log("Errore caricamento log rinnovi:",i),R([])}finally{T(!1)}}else v(!0)},H=e=>{if(!e&&0!==e)return"FM 0";return`FM ${(parseFloat(e)||0).toLocaleString()}`},V=e=>e?e.split(";").map(e=>e.trim()):[];if(d)return(0,gt.jsx)(LS,{children:(0,gt.jsx)("div",{children:"Caricamento squadra..."})});if(u)return(0,gt.jsx)(LS,{children:(0,gt.jsxs)("div",{children:["Errore: ",u]})});if(!s)return(0,gt.jsx)(LS,{children:(0,gt.jsx)("div",{children:"Squadra non trovata"})});const Q=null===p||void 0===p?void 0:p.reduce((e,r)=>{var t;const i=null===s||void 0===s||null===(t=s.giocatori)||void 0===t?void 0:t.find(e=>(null===e||void 0===e?void 0:e.id)===r);if($&&$.rosterA){return e+($.rosterA.some(e=>e.id===r)&&(null===i||void 0===i?void 0:i.costo_attuale)||0)}return e+((null===i||void 0===i?void 0:i.costo_attuale)||0)},0);return(0,gt.jsxs)(LS,{children:[(0,gt.jsx)(WS,{onClick:()=>o(-1),children:"\u2190 Torna indietro"}),(0,gt.jsxs)(MS,{children:[(0,gt.jsxs)(BS,{children:[s.logo_url?(0,gt.jsx)(US,{src:`${ri}/uploads/${s.logo_url}`,alt:(null===s||void 0===s?void 0:s.nome)||"Nome"}):(0,gt.jsx)(US,{src:"data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjQiIGN5PSIyNCIgcj0iMjQiIGZpbGw9IiM5OTk5OTkiLz4KPC9zdmc+",alt:(null===s||void 0===s?void 0:s.nome)||"Nome"}),(0,gt.jsxs)(GS,{children:["Gestione Squadra: ",(null===s||void 0===s?void 0:s.nome)||"Nome"]})]}),(0,gt.jsxs)(DS,{children:["Lega: ",(0,gt.jsx)(FS,{onClick:()=>o(`/lega/${a}`),children:s.lega_nome})]})]}),(0,gt.jsxs)(HS,{children:[(0,gt.jsxs)(VS,{children:[(0,gt.jsx)(QS,{children:"Nome Squadra"}),(0,gt.jsx)(KS,{children:(null===s||void 0===s?void 0:s.nome)||"Nome"})]}),(0,gt.jsxs)(VS,{children:[(0,gt.jsx)(QS,{children:"Proprietario"}),(0,gt.jsx)(KS,{children:s.proprietario_nome||"N/A"})]}),(0,gt.jsxs)(VS,{children:[(0,gt.jsx)(QS,{children:"Casse Societarie"}),(0,gt.jsx)(KS,{children:H(s.casse_societarie)})]}),(0,gt.jsxs)(VS,{children:[(0,gt.jsx)(QS,{children:"Giocatori"}),(0,gt.jsx)(KS,{children:(null===(e=s.giocatori)||void 0===e?void 0:e.length)||0})]}),(0,gt.jsxs)(VS,{children:[(0,gt.jsx)(QS,{children:"Selezionati"}),(0,gt.jsx)(KS,{children:(null===p||void 0===p?void 0:p.length)||0})]}),(0,gt.jsxs)(VS,{children:[(0,gt.jsx)(QS,{children:"Totale da Pagare"}),(0,gt.jsx)(KS,{children:H(Q)})]})]}),(0,gt.jsxs)(YS,{children:[(0,gt.jsxs)(JS,{children:[(0,gt.jsx)(ZS,{onClick:B,children:"Seleziona Tutti"}),(0,gt.jsx)(ZS,{onClick:G,children:"Deseleziona Tutti"})]}),O.contratti&&(0,gt.jsx)(XS,{onClick:async()=>{null!==p&&void 0!==p&&p.length},disabled:(null===p||void 0===p?void 0:p.length)||!0,children:m?"Pagamento...":"Paga Contratti"})]}),(0,gt.jsx)(eC,{children:(0,gt.jsxs)(rC,{children:[(0,gt.jsx)("thead",{children:(0,gt.jsxs)("tr",{children:[(0,gt.jsx)(tC,{children:(0,gt.jsx)(nC,{type:"checkbox",checked:(null===p||void 0===p?void 0:p.length)||0===(null===(t=s.giocatori)||void 0===t?void 0:t.length),onChange:null!==p&&void 0!==p&&p.length||0===(null===(i=s.giocatori)||void 0===i?void 0:i.length)?G:B})}),(0,gt.jsx)(tC,{children:"Giocatore"}),(0,gt.jsx)(tC,{children:"Ruolo"}),(0,gt.jsx)(tC,{children:"M"}),(0,gt.jsx)(tC,{children:"FaM"}),(0,gt.jsx)(tC,{children:(0,gt.jsxs)("div",{style:{whiteSpace:"pre-line",lineHeight:"1.2"},children:["Squadra","\n","Reale"]})}),(0,gt.jsx)(tC,{children:"Cantera"}),(0,gt.jsx)(tC,{children:"QI"}),(0,gt.jsx)(tC,{children:"QA"}),(0,gt.jsx)(tC,{children:"FVMP"}),O.contratti&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(tC,{children:"Ingaggio"}),(0,gt.jsx)(tC,{children:(0,gt.jsxs)("div",{style:{whiteSpace:"pre-line",lineHeight:"1.2"},children:["Anni","\n","Contratto"]})})]}),O.triggers&&(0,gt.jsx)(tC,{children:"Triggers"}),O.roster_ab&&(0,gt.jsx)(tC,{children:"Roster"}),(0,gt.jsx)(tC,{children:"St.Pres"}),(0,gt.jsx)(tC,{children:"St.Trasf"}),(0,gt.jsx)(tC,{children:"Azioni"})]})}),(0,gt.jsx)("tbody",{children:(e=>{if(!e)return[];const r=["P","Por","D","Dc","B","Dd","Ds","E","M","C","T","W","A","Pc"];return[...e].sort((e,t)=>{const i=V((null===e||void 0===e?void 0:e.ruolo)||"Ruolo")[0]||"",n=V((null===t||void 0===t?void 0:t.ruolo)||"Ruolo")[0]||"",o=r.indexOf(i),a=r.indexOf(n);return-1!==o&&-1!==a?o-a:-1!==o?-1:-1!==a?1:i.localeCompare(n)})})(s.giocatori||[]).map(e=>{let r="transparent";return e.squadra_prestito_id?r="#fffbf0":e.valore_prestito>0||e.valore_trasferimento>0?r="#faf5ff":($&&$.rosterA?$.rosterA.some(r=>r.id===e.id):"B"!==e.roster)||(r="#ffeaea"),(0,gt.jsxs)("tr",{style:{backgroundColor:r},children:[(0,gt.jsx)(iC,{children:(0,gt.jsx)(nC,{type:"checkbox",checked:p.includes(e.id),onChange:()=>{return r=e.id,void h(e=>e.includes(r)?null===e||void 0===e?void 0:e.filter(e=>e!==r):[...e,r]);var r}})}),(0,gt.jsx)(iC,{children:(0,gt.jsxs)(oC,{onClick:()=>o(`/giocatore/${e.id}`),children:[(null===e||void 0===e?void 0:e.nome)||"Nome"," ",(null===e||void 0===e?void 0:e.cognome)||""]})}),(0,gt.jsx)(iC,{children:(0,gt.jsx)(aC,{children:V((null===e||void 0===e?void 0:e.ruolo)||"Ruolo").map((e,r)=>(0,gt.jsx)("span",{className:`ruolo-badge ${uu(e)}`,children:e},r))})}),(0,gt.jsx)(iC,{children:e.r||"-"}),(0,gt.jsx)(iC,{children:e.fr||"-"}),(0,gt.jsx)(iC,{children:e.squadra_reale||"-"}),(0,gt.jsx)(iC,{children:e.cantera?"\u2714":"-"}),(0,gt.jsx)(iC,{children:e.qi||"-"}),(0,gt.jsx)(iC,{children:(null===e||void 0===e?void 0:e.qa)||e.quotazione_attuale||"-"}),(0,gt.jsx)(iC,{children:e.fv_mp||"-"}),O.contratti&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(iC,{children:H(e.costo_attuale)}),(0,gt.jsx)(iC,{children:e.anni_contratto||0})]}),O.triggers&&(0,gt.jsx)(iC,{children:e.triggers||"-"}),O.roster_ab&&(0,gt.jsx)(iC,{children:$&&$.rosterA?$.rosterA.some(r=>r.id===e.id)?(0,gt.jsx)("span",{style:{color:"#28a745",fontWeight:"bold"},children:"A"}):(0,gt.jsx)("span",{style:{color:"#ffc107",fontWeight:"bold"},children:"B"}):"B"===e.roster?(0,gt.jsx)("span",{style:{color:"#ffc107",fontWeight:"bold"},children:"B"}):(0,gt.jsx)("span",{style:{color:"#28a745",fontWeight:"bold"},children:"A"})}),(0,gt.jsx)(iC,{children:e.squadra_prestito_id?(0,gt.jsxs)("div",{style:{textAlign:"center",whiteSpace:"pre-line"},children:[(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#666",marginBottom:"2px"},children:"In Prestito da"}),(0,gt.jsx)("div",{style:{fontSize:"0.8rem",fontWeight:"600",color:"#28a745"},children:e.squadra_prestito_nome||"Sconosciuta"})]}):e.valore_prestito>0?(0,gt.jsxs)("div",{style:{textAlign:"center",whiteSpace:"pre-line"},children:[(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#666",marginBottom:"2px"},children:"Costo Prestito"}),(0,gt.jsxs)("div",{style:{fontSize:"0.8rem",fontWeight:"600",color:"#28a745"},children:["(",H(e.valore_prestito),")"]})]}):"-"}),(0,gt.jsx)(iC,{children:e.valore_trasferimento>0?(0,gt.jsxs)("div",{style:{textAlign:"center",whiteSpace:"pre-line"},children:[(0,gt.jsx)("div",{style:{fontSize:"0.8rem",color:"#666",marginBottom:"2px"},children:"Costo Trasferimento"}),(0,gt.jsxs)("div",{style:{fontSize:"0.8rem",fontWeight:"600",color:"#dc3545"},children:["(",H(e.valore_trasferimento),")"]})]}):"-"}),(0,gt.jsx)(iC,{style:{padding:"0.5rem",minWidth:"200px",textAlign:"center"},children:(()=>{const r=$&&$.rosterA?!$.rosterA.some(r=>r.id===e.id):"B"===e.roster;return(0,gt.jsxs)("div",{style:{display:"flex",flexWrap:"wrap",gap:"0.3rem",justifyContent:"center"},children:[O.contratti&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(sC,{className:"contract",onClick:()=>W("contract",e),disabled:r,title:r?"Giocatori in Roster B non possono essere modificati":"",children:"Contratto"}),(0,gt.jsx)(sC,{className:"renew",onClick:()=>W("renew",e),disabled:r,title:r?"Giocatori in Roster B non possono essere modificati":"",children:"Rinnovo"})]}),(0,gt.jsx)(sC,{className:"transfer",onClick:()=>{return C(r=e),P({prestito:r.prestito||!1,trasferimento:r.trasferimento||!1,valorePrestito:r.valore_prestito||0,valoreTrasferimento:r.valore_trasferimento||0}),void w(!0);var r},disabled:r||e.prestito,title:r?"Giocatori in Roster B non possono essere modificati":e.prestito?"Giocatori in prestito non possono essere trasferiti":"",children:(0,gt.jsxs)("div",{style:{whiteSpace:"pre-line",lineHeight:"1.2"},children:["Stato","\n","Trasferimento"]})}),e.squadra_prestito_id&&(0,gt.jsx)(sC,{className:"end-loan",onClick:()=>(C(e),void _(!0)),style:{backgroundColor:"#dc3545",color:"white"},title:"Concludi il prestito e riporta il giocatore alla squadra di appartenenza",children:(0,gt.jsxs)("div",{style:{whiteSpace:"pre-line",lineHeight:"1.2"},children:["Concludi","\n","Prestito"]})})]})})()})]},e.id)})})]})}),O.contratti&&x&&S&&(0,gt.jsx)(lC,{onClick:()=>v(!1),children:(0,gt.jsxs)(dC,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(cC,{children:["Gestione Contratto: ",(null===S||void 0===S?void 0:S.nome)||"Nome"]}),(0,gt.jsxs)(uC,{children:[(0,gt.jsx)(gC,{children:"Ingaggio Attuale"}),(0,gt.jsx)("div",{children:H(S.costo_attuale)})]}),(0,gt.jsxs)(uC,{children:[(0,gt.jsx)(gC,{children:"Anni Contratto Attuali"}),(0,gt.jsx)("div",{children:S.anni_contratto||0})]}),S.ultimo_pagamento_contratto&&(0,gt.jsxs)(mC,{children:["Ultimo pagamento: ",new Date(S.ultimo_pagamento_contratto).toLocaleString("it-IT")]}),S.ultimo_rinnovo_contratto&&(0,gt.jsxs)(mC,{children:["Ultimo rinnovo: ",new Date(S.ultimo_rinnovo_contratto).toLocaleString("it-IT")]}),(0,gt.jsxs)(hC,{children:[(0,gt.jsx)(ZS,{className:"success",onClick:async()=>{if(S)try{await(async(e,r)=>bc("POST",`/contratti/paga/${e}`,null,r))(S.id,n),await F(),v(!1),C(null)}catch(e){g(e.message)}},children:"Paga Contratto"}),(0,gt.jsx)(ZS,{className:"secondary",onClick:()=>v(!1),children:"Chiudi"})]})]})}),O.contratti&&b&&S&&(0,gt.jsx)(lC,{onClick:()=>j(!1),children:(0,gt.jsxs)(dC,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(cC,{children:["Rinnovo Contratto: ",(null===S||void 0===S?void 0:S.nome)||"Nome"]}),(0,gt.jsxs)(uC,{children:[(0,gt.jsx)(gC,{children:"Anni di Rinnovo"}),(0,gt.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"1rem"},children:[(0,gt.jsx)(ZS,{onClick:()=>E(Math.max(1,z-1)),disabled:z<=1,children:"-"}),(0,gt.jsx)("span",{style:{fontSize:"1.2rem",fontWeight:"600"},children:z}),(0,gt.jsx)(ZS,{onClick:()=>E(Math.min(4,z+1)),disabled:z>=4,children:"+"})]})]}),(0,gt.jsxs)(uC,{children:[(0,gt.jsx)(gC,{children:"Costo Rinnovo"}),(0,gt.jsx)("div",{children:H(S.quotazione_attuale)})]}),(0,gt.jsx)(fC,{children:"\u26a0\ufe0f Una volta chiuso questo popup non potrai pi\xf9 annullare il rinnovo"}),(0,gt.jsxs)(xC,{children:[(0,gt.jsx)(vC,{children:"Storico Rinnovi"}),N?(0,gt.jsx)("div",{style:{textAlign:"center",padding:"1rem"},children:"Caricamento log..."}):null!==A&&void 0!==A&&A.length?null===A||void 0===A?void 0:A.map((e,r)=>(0,gt.jsxs)(bC,{children:[(0,gt.jsx)(jC,{children:new Date(e.data_operazione).toLocaleString("it-IT")}),(0,gt.jsxs)(yC,{children:[e.note," - ",(0,gt.jsx)(wC,{children:H(e.importo)})]})]},r)):(0,gt.jsx)(kC,{children:"Nessun rinnovo precedente"})]}),(0,gt.jsxs)(hC,{children:[(0,gt.jsx)(ZS,{className:"success",onClick:async()=>{if(S)try{await(async(e,r,t)=>bc("POST",`/contratti/rinnova/${e}`,{anniRinnovo:r},t))(S.id,z,n),await F(),j(!1),C(null),E(1)}catch(e){g(e.message)}},children:"Rinnova Contratto"}),(0,gt.jsx)(ZS,{className:"secondary",onClick:()=>j(!1),children:"Chiudi"})]})]})}),y&&S&&(0,gt.jsx)(lC,{onClick:()=>w(!1),children:(0,gt.jsxs)(dC,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(cC,{children:["Impostazioni Trasferimento: ",(null===S||void 0===S?void 0:S.nome)||"Nome"]}),(0,gt.jsxs)(uC,{children:[(0,gt.jsxs)(gC,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:q.prestito,onChange:e=>P(r=>({...r,prestito:e.target.checked}))}),"Prestito"]}),q.prestito&&(0,gt.jsx)(pC,{type:"number",placeholder:"Valore prestito (FM)",value:q.valorePrestito||"",onChange:e=>{const r=e.target.value;P(e=>({...e,valorePrestito:""===r?0:parseFloat(r)||0}))}})]}),(0,gt.jsxs)(uC,{children:[(0,gt.jsxs)(gC,{children:[(0,gt.jsx)("input",{type:"checkbox",checked:q.trasferimento,onChange:e=>P(r=>({...r,trasferimento:e.target.checked}))}),"Trasferimento"]}),q.trasferimento&&(0,gt.jsx)(pC,{type:"number",placeholder:"Valore trasferimento (FM)",value:q.valoreTrasferimento||"",onChange:e=>{const r=e.target.value;P(e=>({...e,valoreTrasferimento:""===r?0:parseFloat(r)||0}))}})]}),(0,gt.jsxs)(hC,{children:[(0,gt.jsx)(ZS,{className:"success",onClick:async()=>{if(S)try{await(async(e,r,t)=>bc("POST",`/contratti/impostazioni/${e}`,r,t))(S.id,q,n),await F(),w(!1),C(null)}catch(e){g(e.message)}},children:"Salva"}),(0,gt.jsx)(ZS,{className:"secondary",onClick:()=>w(!1),children:"Chiudi"})]})]})}),k&&S&&(0,gt.jsx)(lC,{onClick:()=>_(!1),children:(0,gt.jsxs)(dC,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(cC,{children:["Concludi Prestito: ",(null===S||void 0===S?void 0:S.nome)||"Nome"]}),(0,gt.jsxs)(uC,{children:[(0,gt.jsx)(gC,{children:"Confermi di voler concludere il prestito di questo giocatore?"}),(0,gt.jsxs)("div",{style:{marginTop:"1rem",padding:"1rem",backgroundColor:"#f8f9fa",borderRadius:"4px"},children:[(0,gt.jsx)("strong",{children:"Giocatore:"})," ",(null===S||void 0===S?void 0:S.nome)||"Nome"," ",(null===S||void 0===S?void 0:S.cognome)||"",(0,gt.jsx)("br",{}),(0,gt.jsx)("strong",{children:"Squadra di appartenenza:"})," ",S.squadra_prestito_nome||"Sconosciuta",(0,gt.jsx)("br",{}),(0,gt.jsx)("strong",{children:"Squadra attuale:"})," ",(null===s||void 0===s?void 0:s.nome)||"Sconosciuta"]})]}),(0,gt.jsx)(fC,{children:"\u26a0\ufe0f Il giocatore torner\xe0 alla squadra di appartenenza. Se la squadra ha gi\xe0 il numero massimo di giocatori, il giocatore verr\xe0 automaticamente spostato nel Roster B."}),(0,gt.jsxs)(hC,{children:[(0,gt.jsx)(ZS,{className:"danger",onClick:async()=>{if(S)try{const e=await fetch(`${ri}/squadre/end-loan/${S.id}`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`}});if(!e.ok){const r=e.data;throw new Error(r.message||"Errore durante la conclusione del prestito")}await F(),_(!1),C(null)}catch(e){g(e.message)}},children:"Concludi Prestito"}),(0,gt.jsx)(ZS,{className:"secondary",onClick:()=>_(!1),children:"Annulla"})]})]})})]})},SC=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`,CC=Ie.h1`
  color: #333;
  margin-bottom: 30px;
  text-align: center;
`,zC=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
`,EC=Ie.div`
  background: white;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  cursor: pointer;
  transition: transform 0.2s;

  &:hover {
    transform: translateY(-2px);
  }
`,AC=Ie.h3`
  color: #2c3e50;
  margin-bottom: 10px;
`,RC=Ie.p`
  color: #666;
  font-size: 14px;
  line-height: 1.5;
`,NC=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,TC=Ie.div`
  background: white;
  border-radius: 10px;
  padding: 30px;
  max-width: 500px;
  width: 90%;
  max-height: 80vh;
  overflow-y: auto;
`,qC=Ie.h2`
  color: #2c3e50;
  margin-bottom: 20px;
  text-align: center;
`,PC=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 15px;
`,$C=Ie.input`
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
`,IC=Ie.textarea`
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
  min-height: 100px;
  resize: vertical;
`,OC=Ie.select`
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
`,LC=Ie.div`
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  margin-top: 20px;
`,MC=Ie.button`
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.2s;

  &.primary {
    background: #3498db;
    color: white;
    
    &:hover {
      background: #2980b9;
    }
  }

  &.secondary {
    background: #95a5a6;
    color: white;
    
    &:hover {
      background: #7f8c8d;
    }
  }

  &.danger {
    background: #e74c3c;
    color: white;
    
    &:hover {
      background: #c0392b;
    }
  }
`,DC=(Ie.div`
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 15px;
  margin-bottom: 10px;
`,Ie.div`
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
`),FC=Ie.button`
  background: #e74c3c;
  color: white;
  border: none;
  border-radius: 3px;
  padding: 5px 10px;
  font-size: 12px;
  cursor: pointer;
`,UC=(Ie.button`
  background: #27ae60;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 8px 15px;
  font-size: 12px;
  cursor: pointer;
  margin-top: 10px;
`,Ie.div`
  margin-top: 40px;
`),BC=Ie.h2`
  color: #2c3e50;
  margin-bottom: 20px;
`,GC=Ie.div`
  background: white;
  border-radius: 8px;
  padding: 15px;
  margin-bottom: 10px;
  box-shadow: 0 1px 5px rgba(0,0,0,0.1);
`,WC=Ie.span`
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: bold;
  
  &.pending {
    background: #f39c12;
    color: white;
  }
  
  &.accepted {
    background: #27ae60;
    color: white;
  }
  
  &.rejected {
    background: #e74c3c;
    color: white;
  }
  
  &.revision {
    background: #9b59b6;
    color: white;
  }
`,HC=()=>{const{token:e,user:t}=Si(),[i,n]=(0,r.useState)([]),[o,a]=(0,r.useState)(null),[s,l]=(0,r.useState)([]),[d,c]=(0,r.useState)([]),[u,g]=(0,r.useState)(!1),[p,h]=(0,r.useState)(""),[m,f]=(0,r.useState)({}),[x,v]=(0,r.useState)(!1);(0,r.useEffect)(()=>{e&&b()},[e]);const b=async()=>{try{var r;const t=await Lo(e),i=(null===t||void 0===t||null===(r=t.data)||void 0===r?void 0:r.squadre)||(null===t||void 0===t?void 0:t.squadre)||[];n(i),i&&null!==i&&void 0!==i&&i.length&&(a(i[0]),j(i[0].id),y(i[0].id))}catch(t){console.error("Errore caricamento squadre:",t)}},j=async r=>{try{const t=await du(r,e);let i=[];t&&t.ok&&t.data?i=t.data.giocatori||t.data||[]:t&&t.giocatori?i=t.giocatori:Array.isArray(t)?i=t:console.error("Nessun dato valido trovato per giocatori:",t),l(i)}catch(t){console.error("Errore caricamento giocatori:",t)}},y=async r=>{try{var t;const i=await(async(e,r)=>await ni.get(`/richieste-admin/squadra/${e}`,r))(r,e),n=(null===i||void 0===i||null===(t=i.data)||void 0===t?void 0:t.richieste)||(null===i||void 0===i?void 0:i.richieste)||[];c(n)}catch(i){console.error("Errore caricamento richieste:",i)}},w=e=>{h(e),f({}),g(!0)},k=()=>{g(!1),h(""),f({})},_=async r=>{var t;r.preventDefault(),v(!0);try{const r={};switch(p){case"club_level":r.nuovo_club_level=parseInt(m.nuovo_club_level);break;case"trigger":r.trigger=m.trigger;break;case"cantera":r.giocatori_selezionati=m.giocatori_selezionati||[],r.costi_dimezzati={},r.dettagli_giocatori={},null===m||void 0===m||null===(t=m.giocatori_selezionati)||void 0===t||t.forEach(e=>{const t=s.find(r=>r.id===e);t&&(r.costi_dimezzati[e]=Math.floor(t.costo_attuale/2),r.dettagli_giocatori[e]={nome:(null===t||void 0===t?void 0:t.nome)||"Nome",cognome:(null===t||void 0===t?void 0:t.cognome)||"",ruolo:(null===t||void 0===t?void 0:t.ruolo)||"Ruolo",squadra_reale:t.squadra_reale,qi:t.qi,qa:(null===t||void 0===t?void 0:t.qa)||t.quotazione_attuale,costo_attuale:t.costo_attuale,costo_dimezzato:Math.floor(t.costo_attuale/2)})});break;case"cambio_nome":r.nuovo_nome=m.nuovo_nome;break;case"cambio_logo":r.logo_url=m.logo_url;break;case"generale":r.messaggio=m.messaggio}await(async(e,r,t,i)=>await ni.post("/richieste-admin/create",{squadra_id:e,tipo_richiesta:r,dati_richiesta:t},i))(o.id,p,r,e),k(),y(o.id)}catch(i){console.error("Errore invio richiesta:",i),alert("Errore nell'invio della richiesta")}finally{v(!1)}},S=e=>{switch(e){case"club_level":return"Richiedi un aumento del Club Level della tua squadra";case"trigger":return"Richiedi l'attivazione di un trigger specifico";case"cantera":return"Richiedi l'attivazione della cantera per i tuoi giocatori";case"cambio_nome":return"Richiedi un cambio nome per la tua squadra";case"cambio_logo":return"Richiedi un cambio logo per la tua squadra";case"generale":return"Invia una richiesta generale all'admin";default:return""}},C=e=>{switch(e){case"pending":return"In attesa";case"accepted":return"Accettata";case"rejected":return"Rifiutata";case"revision":return"In revisione";default:return e}},z=e=>{var r,t;try{const a=e.dati_richiesta||{};switch(e.tipo_richiesta){case"cantera":if(a.giocatori_selezionati&&((null===(r=a.giocatori_selezionati)||void 0===r?void 0:r.length)||0)>0){var i;return`Richiesta Cantera per: ${null===(i=a.giocatori_selezionati)||void 0===i?void 0:i.map(e=>{const r=s.find(r=>r.id===e);return r?`${(null===r||void 0===r?void 0:r.nome)||"Nome"} ${(null===r||void 0===r?void 0:r.cognome)||""}`:`ID: ${e}`}).join(", ")}`}return"Richiesta Cantera";case"cambio_nome":return a.nuovo_nome?`Richiesta cambio nome: ${a.nuovo_nome}`:"Richiesta cambio nome";case"cambio_logo":return a.logo_url?`Richiesta cambio logo: ${a.logo_url}`:"Richiesta cambio logo";case"club_level":return a.nuovo_club_level?`Richiesta Club Level: ${a.nuovo_club_level}`:"Richiesta Club Level";case"trigger":var n;return a.trigger?`Richiesta Trigger: ${a.trigger.substring(0,50)}${((null===(n=a.trigger)||void 0===n?void 0:n.length)||0)>50?"...":""}`:"Richiesta Trigger";case"generale":var o;return a.messaggio?`Richiesta Generale: ${a.messaggio.substring(0,50)}${((null===(o=a.messaggio)||void 0===o?void 0:o.length)||0)>50?"...":""}`:"Richiesta Generale";default:return null===e||void 0===e||null===(t=e.tipo_richiesta)||void 0===t?void 0:t.replace("_"," ").toUpperCase()}}catch(l){var a;return null===e||void 0===e||null===(a=e.tipo_richiesta)||void 0===a?void 0:a.replace("_"," ").toUpperCase()}};return o?(0,gt.jsxs)(SC,{children:[(0,gt.jsx)(CC,{children:"Richiesta Admin"}),(0,gt.jsxs)("div",{style:{marginBottom:"20px"},children:[(0,gt.jsx)("label",{children:"Squadra: "}),(0,gt.jsx)(OC,{value:(null===o||void 0===o?void 0:o.id)||"",onChange:e=>{const r=i.find(r=>r.id===parseInt(e.target.value));r&&(e=>{a(e),j(e.id),y(e.id)})(r)},children:null===i||void 0===i?void 0:i.map(e=>(0,gt.jsx)("option",{value:e.id,children:(null===e||void 0===e?void 0:e.nome)||"Nome"},e.id))})]}),(0,gt.jsxs)(zC,{children:[(0,gt.jsxs)(EC,{onClick:()=>w("club_level"),children:[(0,gt.jsx)(AC,{children:"Richiesta Club Level"}),(0,gt.jsx)(RC,{children:S("club_level")})]}),(0,gt.jsxs)(EC,{onClick:()=>w("trigger"),children:[(0,gt.jsx)(AC,{children:"Richiesta Trigger"}),(0,gt.jsx)(RC,{children:S("trigger")})]}),(0,gt.jsxs)(EC,{onClick:()=>w("cantera"),children:[(0,gt.jsx)(AC,{children:"Richiesta Cantera"}),(0,gt.jsx)(RC,{children:S("cantera")})]}),(0,gt.jsxs)(EC,{onClick:()=>w("cambio_nome"),children:[(0,gt.jsx)(AC,{children:"Richiesta Cambio Nome"}),(0,gt.jsx)(RC,{children:S("cambio_nome")})]}),(0,gt.jsxs)(EC,{onClick:()=>w("cambio_logo"),children:[(0,gt.jsx)(AC,{children:"Richiesta Cambio Logo"}),(0,gt.jsx)(RC,{children:S("cambio_logo")})]}),(0,gt.jsxs)(EC,{onClick:()=>w("generale"),children:[(0,gt.jsx)(AC,{children:"Richiesta Generale"}),(0,gt.jsx)(RC,{children:S("generale")})]})]}),(0,gt.jsxs)(UC,{children:[(0,gt.jsx)(BC,{children:"Storico Richieste"}),0===((null===d||void 0===d?void 0:d.length)||0)?(0,gt.jsx)("p",{children:"Nessuna richiesta inviata"}):null===d||void 0===d?void 0:d.map(r=>(0,gt.jsxs)(GC,{children:[(0,gt.jsxs)("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:z(r)}),(0,gt.jsx)("br",{}),(0,gt.jsx)("small",{children:new Date(r.data_creazione).toLocaleString()})]}),(0,gt.jsx)(WC,{className:r.stato,children:C(r.stato)})]}),r.note_admin&&(0,gt.jsxs)("div",{style:{marginTop:"10px",fontSize:"14px",color:"#666"},children:[(0,gt.jsx)("strong",{children:"Note admin:"})," ",r.note_admin]}),"pending"===r.stato&&(0,gt.jsx)(MC,{type:"button",className:"danger",onClick:()=>(async r=>{try{(await fetch(`https://topleaguem.onrender.com/api/richieste-admin/${r}/annulla`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e}`}})).ok?y(o.id):alert("Errore nell'annullamento della richiesta")}catch(t){console.error("Errore annullamento richiesta:",t),alert("Errore nell'annullamento della richiesta")}})(r.id),children:"Annulla Richiesta"})]},r.id))]}),(()=>{var r,t;return u?(0,gt.jsx)(NC,{onClick:k,children:(0,gt.jsxs)(TC,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(qC,{children:["club_level"===p&&"Richiesta Club Level","trigger"===p&&"Richiesta Trigger","cantera"===p&&"Richiesta Cantera","cambio_nome"===p&&"Richiesta Cambio Nome","cambio_logo"===p&&"Richiesta Cambio Logo","generale"===p&&"Richiesta Generale"]}),(0,gt.jsxs)(PC,{onSubmit:_,children:["club_level"===p&&(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)("div",{children:(0,gt.jsxs)("label",{children:["Club Level Attuale: ",(null===o||void 0===o?void 0:o.club_level)||0]})}),(0,gt.jsx)($C,{type:"number",placeholder:"Nuovo Club Level",value:m.nuovo_club_level||"",onChange:e=>f({...m,nuovo_club_level:e.target.value}),min:(null===o||void 0===o?void 0:o.club_level)||0,required:!0}),(0,gt.jsxs)("div",{style:{fontSize:"12px",color:"#666"},children:[(0,gt.jsx)("strong",{children:"Descrizione Club Level:"}),(0,gt.jsx)("br",{}),"I prezzi del Club Level devono essere configurati dall'admin."]})]}),"trigger"===p&&(0,gt.jsx)(IC,{placeholder:"Descrivi il trigger che vuoi attivare...",value:m.trigger||"",onChange:e=>f({...m,trigger:e.target.value}),required:!0}),"cantera"===p&&(0,gt.jsxs)("div",{children:[(0,gt.jsx)("label",{children:"Seleziona i giocatori per la cantera:"}),(0,gt.jsxs)("div",{style:{display:"flex",gap:"10px",alignItems:"center",marginBottom:"10px"},children:[(0,gt.jsxs)(OC,{value:m.selectedPlayer||"",onChange:e=>f({...m,selectedPlayer:e.target.value}),style:{flex:1},children:[(0,gt.jsx)("option",{value:"",children:"Seleziona un giocatore"}),s.filter(e=>{var r;return!(null!==(r=m.giocatori_selezionati)&&void 0!==r&&r.includes(e.id))}).map(e=>(0,gt.jsxs)("option",{value:e.id,children:[(null===e||void 0===e?void 0:e.nome)||"Nome"," ",(null===e||void 0===e?void 0:e.cognome)||""," - QA: ",(null===e||void 0===e?void 0:e.qa)||0]},e.id))]}),(0,gt.jsx)(MC,{type:"button",className:"primary",onClick:()=>{if(m.selectedPlayer){const e=m.giocatori_selezionati||[];f({...m,giocatori_selezionati:[...e,parseInt(m.selectedPlayer)],selectedPlayer:""})}},style:{padding:"8px 15px",fontSize:"12px"},children:"Aggiungi"})]}),m.giocatori_selezionati&&((null===(r=m.giocatori_selezionati)||void 0===r?void 0:r.length)||0)>0&&(0,gt.jsxs)("div",{style:{marginTop:"15px"},children:[(0,gt.jsx)("label",{style:{fontWeight:"bold",marginBottom:"10px",display:"block"},children:"Giocatori selezionati:"}),null===(t=m.giocatori_selezionati)||void 0===t?void 0:t.map((e,r)=>{const t=s.find(r=>r.id===e);return(0,gt.jsxs)(DC,{children:[(0,gt.jsx)("span",{style:{flex:1},children:t?`${(null===t||void 0===t?void 0:t.nome)||"Nome"} ${(null===t||void 0===t?void 0:t.cognome)||""} - QA: ${(null===t||void 0===t?void 0:t.qa)||0}`:`ID: ${e}`}),(0,gt.jsx)(FC,{onClick:()=>{const r=m.giocatori_selezionati||[];f({...m,giocatori_selezionati:null===r||void 0===r?void 0:r.filter(r=>r!==e)})},children:"Rimuovi"})]},r)})]})]}),"cambio_nome"===p&&(0,gt.jsx)($C,{type:"text",placeholder:"Nuovo nome squadra",value:m.nuovo_nome||"",onChange:e=>f({...m,nuovo_nome:e.target.value}),required:!0}),"cambio_logo"===p&&(0,gt.jsxs)("div",{children:[(0,gt.jsx)($C,{type:"file",accept:"image/*",onChange:async r=>{const t=r.target.files[0];if(t)try{const r=new FormData;r.append("logo",t);const i=await fetch("https://topleaguem.onrender.com/api/upload/logo",{method:"POST",headers:{Authorization:`Bearer ${e}`},body:r});if(i.ok){const e=i.data;f({...r,logo_url:e.filename})}else console.error("Errore upload logo"),alert("Errore nel caricamento del logo")}catch(i){console.error("Errore upload logo:",i),alert("Errore nel caricamento del logo")}},required:!0}),(0,gt.jsxs)("div",{style:{fontSize:"12px",color:"#666",marginTop:"10px"},children:[(0,gt.jsx)("strong",{children:"Note:"})," Dimensioni massime 512x512px, formato PNG/JPG"]})]}),"generale"===p&&(0,gt.jsx)(IC,{placeholder:"Descrivi la tua richiesta generale...",value:m.messaggio||"",onChange:e=>f({...m,messaggio:e.target.value}),required:!0}),(0,gt.jsxs)(LC,{children:[(0,gt.jsx)(MC,{type:"button",className:"secondary",onClick:k,children:"Annulla"}),(0,gt.jsx)(MC,{type:"submit",className:"primary",disabled:x,children:x?"Invio...":"Invia Richiesta"})]})]})]})}):null})()]}):(0,gt.jsxs)(SC,{children:[(0,gt.jsx)(CC,{children:"Richiesta Admin"}),(0,gt.jsx)("p",{children:"Nessuna squadra disponibile"})]})},VC=Ie.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
`,QC=Ie.h1`
  color: #333;
  margin-bottom: 30px;
  text-align: center;
`,KC=(Ie.div`
  background: white;
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
`,Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
`,Ie.h3`
  color: #2c3e50;
  margin: 0;
`,Ie.div`
  font-size: 12px;
  color: #666;
  margin-bottom: 15px;
`,Ie.div`
  background: #f8f9fa;
  border-radius: 5px;
  padding: 15px;
  margin-bottom: 15px;
`),YC=(Ie.div`
  display: flex;
  gap: 10px;
  justify-content: flex-end;
`,Ie.button`
  padding: 8px 16px;
  border: none;
  border-radius: 5px;
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.2s;

  &.accept {
    background: #27ae60;
    color: white;
    
    &:hover {
      background: #229954;
    }
  }

  &.reject {
    background: #e74c3c;
    color: white;
    
    &:hover {
      background: #c0392b;
    }
  }

  &.revision {
    background: #f39c12;
    color: white;
    
    &:hover {
      background: #e67e22;
    }
  }
`),JC=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`,ZC=Ie.div`
  background: white;
  border-radius: 10px;
  padding: 30px;
  max-width: 500px;
  width: 90%;
`,XC=Ie.h2`
  color: #2c3e50;
  margin-bottom: 20px;
`,ez=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 15px;
`,rz=Ie.input`
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
`,tz=Ie.textarea`
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 14px;
  min-height: 100px;
  resize: vertical;
`,iz=Ie.div`
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  margin-top: 20px;
`,nz=Ie.div`
  text-align: center;
  padding: 40px;
  color: #666;
`,oz=()=>{const{legaId:e}=Pr(),{token:t}=Si(),[i,n]=(0,r.useState)([]),[o,a]=(0,r.useState)(!0),[s,l]=(0,r.useState)(!1),[d,c]=(0,r.useState)(null),[u,g]=(0,r.useState)(""),[p,h]=(0,r.useState)({});(0,r.useEffect)(()=>{t&&e&&m()},[t,e,m]);const m=(0,r.useCallback)(async()=>{try{var r;a(!0);const i=await(async(e,r)=>await ni.get(`/richieste-admin/pending/${e}`,r))(e,t),o=(null===i||void 0===i||null===(r=i.data)||void 0===r?void 0:r.richieste)||(null===i||void 0===i?void 0:i.richieste)||[];n(o)}catch(i){console.error("Errore caricamento richieste:",i)}finally{a(!1)}},[e,t]),f=()=>{l(!1),c(null),g(""),h({})},x=async e=>{e.preventDefault();try{await(async(e,r,t,i,n)=>await ni.post(`/richieste-admin/${e}/gestisci`,{azione:r,note_admin:t,valore_costo:i},n))(d.id,u,p.note_admin||"",p.valore_costo||0,t),f(),m()}catch(r){console.error("Errore gestione richiesta:",r),alert("Errore nella gestione della richiesta")}},v=e=>{switch(e){case"club_level":return"Club Level";case"trigger":return"Trigger";case"cantera":return"Cantera";case"cambio_nome":return"Cambio Nome";case"cambio_logo":return"Cambio Logo";case"generale":return"Generale";default:return e}},b=e=>{var r;const t=e.dati_richiesta||{};switch(e.tipo_richiesta){case"club_level":return(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Nuovo Club Level:"})," ",t.nuovo_club_level]});case"trigger":return(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Trigger richiesto:"})," ",t.trigger]});case"cantera":return(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Giocatori selezionati:"}),(0,gt.jsx)("ul",{children:null===(r=t.giocatori_selezionati)||void 0===r?void 0:r.map(r=>{var t;const i=null===(t=e.giocatori)||void 0===t?void 0:t.find(e=>e.id===r);return(0,gt.jsx)("li",{children:i?`${(null===i||void 0===i?void 0:i.nome)||"Nome"} ${(null===i||void 0===i?void 0:i.cognome)||""}`:`ID: ${r}`},r)})})]});case"cambio_nome":return(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Nuovo nome:"})," ",t.nuovo_nome]});case"cambio_logo":return(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Nuovo Logo:"}),(0,gt.jsxs)("div",{style:{marginTop:"10px"},children:[(0,gt.jsx)("img",{src:`https://topleaguem.onrender.com/uploads/${t.logo_url}`,alt:"Nuovo logo",style:{maxWidth:"100px",maxHeight:"100px",border:"1px solid #ddd",borderRadius:"5px"},onError:e=>{e.target.style.display="none",e.target.nextSibling.style.display="block"}}),(0,gt.jsxs)("div",{style:{display:"none",color:"#666",fontSize:"12px"},children:["Immagine non disponibile: ",t.logo_url]})]})]});case"generale":return(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Messaggio:"})," ",t.messaggio]});default:return(0,gt.jsx)("div",{children:"Dati non disponibili"})}};return o?(0,gt.jsxs)(VC,{children:[(0,gt.jsx)(QC,{children:"Gestione Richieste Admin"}),(0,gt.jsx)("div",{children:"Caricamento..."})]}):(0,gt.jsxs)(VC,{children:[(0,gt.jsx)(QC,{children:"Gestione Richieste Admin"}),(null!==i&&void 0!==i&&i.length,(0,gt.jsxs)(nz,{children:[(0,gt.jsx)("h3",{children:"Nessuna richiesta in attesa"}),(0,gt.jsx)("p",{children:"Non ci sono richieste pendenti per questa lega."})]})),s&&d?(0,gt.jsx)(JC,{onClick:f,children:(0,gt.jsxs)(ZC,{onClick:e=>e.stopPropagation(),children:[(0,gt.jsxs)(XC,{children:["accepted"===u&&"Accetta Richiesta","rejected"===u&&"Rifiuta Richiesta","revision"===u&&"Metti in Revisione"]}),(0,gt.jsxs)(ez,{onSubmit:x,children:[(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Tipo:"})," ",v(d.tipo_richiesta)]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Squadra:"})," ",d.squadra_nome]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Proprietario:"})," ",d.proprietario_username]}),(0,gt.jsxs)("div",{children:[(0,gt.jsx)("strong",{children:"Data richiesta:"})," ",new Date(d.data_creazione).toLocaleString()]}),(0,gt.jsx)(KC,{children:b(d)}),("club_level"===d.tipo_richiesta||"trigger"===d.tipo_richiesta)&&(0,gt.jsx)(rz,{type:"number",placeholder:"Valore costo (FM)",value:p.valore_costo||"",onChange:e=>h({...p,valore_costo:e.target.value}),required:!0}),(0,gt.jsx)(tz,{placeholder:"Note (opzionale)",value:p.note_admin||"",onChange:e=>h({...p,note_admin:e.target.value})}),(0,gt.jsxs)(iz,{children:[(0,gt.jsx)(YC,{type:"button",onClick:f,children:"Annulla"}),(0,gt.jsxs)(YC,{type:"submit",className:u,children:["accepted"===u&&"Accetta","rejected"===u&&"Rifiuta","revision"===u&&"Metti in Revisione"]})]})]})]})}):null]})},az=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
`,sz=Ie.div`
  background: white;
  padding: 2rem;
  border-radius: 12px;
  max-width: 400px;
  width: 90%;
  text-align: center;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
`,lz=Ie.h2`
  color: #dc2626;
  margin-bottom: 1rem;
  font-size: 1.5rem;
`,dz=Ie.p`
  color: #374151;
  margin-bottom: 1.5rem;
  line-height: 1.5;
`,cz=Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
`,uz=Ie.button`
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
  
  &.primary {
    background: #3b82f6;
    color: white;
    
    &:hover {
      background: #2563eb;
    }
  }
  
  &.secondary {
    background: #6b7280;
    color: white;
    
    &:hover {
      background: #4b5563;
    }
  }
  
  &.danger {
    background: #dc2626;
    color: white;
    
    &:hover {
      background: #b91c1c;
    }
  }
`,gz=e=>{let{isOpen:r,onClose:t,onRetry:i}=e;const{logout:n}=Si();return r?(0,gt.jsx)(az,{children:(0,gt.jsxs)(sz,{children:[(0,gt.jsx)(lz,{children:"\ud83d\udce1 Errore di Connessione"}),(0,gt.jsxs)(dz,{children:["Impossibile raggiungere il server. Questo pu\xf2 succedere quando:",(0,gt.jsx)("br",{}),"\u2022 Il backend non \xe8 attivo",(0,gt.jsx)("br",{}),"\u2022 La connessione internet \xe8 instabile",(0,gt.jsx)("br",{}),"\u2022 Il token di autenticazione \xe8 scaduto"]}),(0,gt.jsxs)(cz,{children:[(0,gt.jsx)(uz,{className:"primary",onClick:()=>{i(),t()},children:"\ud83d\udd04 Riprova"}),(0,gt.jsx)(uz,{className:"secondary",onClick:t,children:"\u274c Chiudi"}),(0,gt.jsx)(uz,{className:"danger",onClick:()=>{n(),t()},children:"\ud83d\udeaa Logout"})]})]})}):null},pz=Ie.div`
  min-height: 100vh;
  background: #f8fafc;
  padding: 1.5rem;
`,hz=Ie.div`
  max-width: 1400px;
  margin: 0 auto;
`,mz=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  border: 1px solid #e2e8f0;
`,fz=Ie.h1`
  color: #1e293b;
  margin: 0 0 0.5rem 0;
  font-size: 2rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`,xz=Ie.p`
  color: #64748b;
  font-size: 1rem;
  margin: 0;
`,vz=Ie.button`
  background: #3b82f6;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 0.875rem;
  margin-bottom: 1rem;
  
  &:hover {
    background: #2563eb;
  }
`,bz=Ie.div`
  background: #f0f9ff;
  border: 1px solid #0ea5e9;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1.5rem;
`,jz=Ie.h3`
  color: #0c4a6e;
  margin: 0 0 0.5rem 0;
  font-size: 1.1rem;
  font-weight: 600;
`,yz=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
`,wz=Ie.div`
  text-align: center;
  padding: 0.5rem;
  background: white;
  border-radius: 6px;
  border: 1px solid #e2e8f0;
`,kz=Ie.div`
  font-size: 1.25rem;
  font-weight: 700;
  color: #0ea5e9;
`,_z=Ie.div`
  font-size: 0.75rem;
  color: #64748b;
  font-weight: 500;
`,Sz=Ie.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  gap: 1.5rem;
  margin-top: 1.5rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
`,Cz=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border: 1px solid #e2e8f0;
  transition: all 0.2s ease;
  overflow: hidden;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  }
  
  @media (max-width: 768px) {
    padding: 1rem;
  }
`,zz=Ie.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 0.75rem;
  border-bottom: 1px solid #e2e8f0;
`,Ez=Ie.h3`
  color: #1e293b;
  margin: 0;
  font-size: 1.1rem;
  font-weight: 600;
`,Az=Ie.div`
  font-size: 0.8rem;
  color: #64748b;
  margin-top: 0.25rem;
`,Rz=Ie.div`
  text-align: center;
  font-size: 1rem;
  color: #64748b;
  margin: 3rem 0;
  padding: 2rem;
`,Nz=Ie.div`
  background: #fef2f2;
  border: 1px solid #fecaca;
  color: #dc2626;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-size: 0.875rem;
`,Tz=Ie.div`
  text-align: center;
  color: #64748b;
  padding: 3rem;
  font-size: 0.9rem;
`,qz=()=>{const{legaId:e}=Pr(),{token:t,user:i}=Si(),n=qr(),[o,a]=(0,r.useState)(null),[s,l]=(0,r.useState)([]),[d,c]=(0,r.useState)(!0),[u,g]=(0,r.useState)(null),[p,h]=(0,r.useState)(!1),m=async()=>{try{var r;c(!0),g(null);if(!["admin","superadmin","subadmin","Admin","SuperAdmin","SubAdmin"].includes(null===i||void 0===i?void 0:i.ruolo))return void g("Accesso negato. Solo admin, superadmin e subadmin possono gestire i roster.");const n=await ni.get(`/leghe/${e}`,t);a(n);const o=await ni.get(`/leghe/${e}/squadre`,t);console.log("\ud83d\udd0d Squadre response:",o),console.log("\ud83d\udd0d Squadre response type:",typeof o),console.log("\ud83d\udd0d Squadre response keys:",Object.keys(o||{}));let s=[];Array.isArray(o)?(s=o,console.log("\ud83d\udd0d Caso 1: Array diretto")):null!==o&&void 0!==o&&o.squadre&&Array.isArray(o.squadre)?(s=o.squadre,console.log("\ud83d\udd0d Caso 2: squadreResponse.squadre")):null!==o&&void 0!==o&&null!==(r=o.data)&&void 0!==r&&r.squadre&&Array.isArray(o.data.squadre)?(s=o.data.squadre,console.log("\ud83d\udd0d Caso 3: squadreResponse.data.squadre")):null!==o&&void 0!==o&&o.data&&Array.isArray(o.data)?(s=o.data,console.log("\ud83d\udd0d Caso 4: squadreResponse.data")):console.log("\ud83d\udd0d Caso 5: Nessun array trovato"),console.log("\ud83d\udd0d Squadre array finale:",s),console.log("\ud83d\udd0d Squadre array length:",s.length),l(s)}catch(n){console.error("Errore fetch data:",n),n.message.includes("Failed to fetch")||n.message.includes("ERR_CONNECTION_REFUSED")?h(!0):g("Errore nel caricamento dei dati")}finally{c(!1)}};return(0,r.useEffect)(()=>{t&&i&&m()},[e,t,i]),d?(0,gt.jsx)(pz,{children:(0,gt.jsx)(hz,{children:(0,gt.jsx)(Rz,{children:"Caricamento dati lega..."})})}):u?(0,gt.jsx)(pz,{children:(0,gt.jsxs)(hz,{children:[(0,gt.jsx)(Nz,{children:u}),(0,gt.jsx)(vz,{onClick:()=>n("/area-admin"),children:"\u2190 Torna alla Dashboard Admin"})]})}):o?(0,gt.jsx)(pz,{children:(0,gt.jsxs)(hz,{children:[(0,gt.jsx)(vz,{onClick:()=>n("/area-admin"),children:"\u2190 Torna alla Dashboard Admin"}),(0,gt.jsxs)(mz,{children:[(0,gt.jsxs)(fz,{children:["\ud83d\udcca Gestione Roster A/B - ",(null===o||void 0===o?void 0:o.nome)||"Nome"]}),(0,gt.jsx)(xz,{children:"Gestisci i roster A/B per tutte le squadre della lega. Solo admin, superadmin e subadmin possono modificare i roster."})]}),(0,gt.jsxs)(bz,{children:[(0,gt.jsx)(jz,{children:(null===o||void 0===o?void 0:o.nome)||"Nome"}),(0,gt.jsx)("div",{style:{fontSize:"0.9rem",color:"#64748b"},children:o.descrizione||"Nessuna descrizione disponibile"}),(0,gt.jsxs)(yz,{children:[(0,gt.jsxs)(wz,{children:[(0,gt.jsx)(kz,{children:Array.isArray(s)&&(null===s||void 0===s?void 0:s.length)||0}),(0,gt.jsx)(_z,{children:"Squadre"})]}),(0,gt.jsxs)(wz,{children:[(0,gt.jsx)(kz,{children:o.numero_tornei||0}),(0,gt.jsx)(_z,{children:"Tornei"})]}),(0,gt.jsxs)(wz,{children:[(0,gt.jsx)(kz,{children:(null===o||void 0===o?void 0:o.max_giocatori)||30}),(0,gt.jsx)(_z,{children:"Max Giocatori"})]}),(0,gt.jsxs)(wz,{children:[(0,gt.jsx)(kz,{children:null!==o&&void 0!==o&&o.is_pubblica?"Pubblica":"Privata"}),(0,gt.jsx)(_z,{children:"Tipo"})]})]})]}),Array.isArray(s)&&0!==s.length?(0,gt.jsx)(Sz,{children:s.map(r=>(0,gt.jsxs)(Cz,{children:[(0,gt.jsx)(zz,{children:(0,gt.jsxs)("div",{children:[(0,gt.jsx)(Ez,{children:(null===r||void 0===r?void 0:r.nome)||"Nome"}),(0,gt.jsxs)(Az,{children:["Proprietario: ",r.proprietario_nome," ",r.proprietario_cognome]})]})}),(0,gt.jsx)(om,{squadraId:r.id,legaId:e,userRole:null===i||void 0===i?void 0:i.ruolo},`roster-${r.id}-${e}`)]},r.id))}):(0,gt.jsx)(Tz,{children:"Nessuna squadra trovata in questa lega"}),(0,gt.jsx)(gz,{isOpen:p,onClose:()=>h(!1),onRetry:()=>{c(!0),g(null),h(!1),setTimeout(()=>{m()},1e3)}})]})}):(0,gt.jsx)(pz,{children:(0,gt.jsxs)(hz,{children:[(0,gt.jsx)(Tz,{children:"Lega non trovata"}),(0,gt.jsx)(vz,{onClick:()=>n("/area-admin"),children:"\u2190 Torna alla Dashboard Admin"})]})})},Pz=Ie.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 2rem;
`,$z=Ie.div`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 3rem;
  text-align: center;
  max-width: 500px;
  width: 100%;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
`,Iz=Ie.h1`
  font-size: 8rem;
  font-weight: 900;
  margin: 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  line-height: 1;
`,Oz=Ie.h2`
  font-size: 2rem;
  color: #2d3748;
  margin: 1rem 0;
  font-weight: 600;
`,Lz=Ie.p`
  font-size: 1.1rem;
  color: #718096;
  margin: 1rem 0 2rem 0;
  line-height: 1.6;
`,Mz=Ie.div`
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
  margin-top: 2rem;
`,Dz=Ie.button`
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 1rem;
  
  &:hover {
    transform: translateY(-2px);
  }
`,Fz=Ie(Dz)`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  
  &:hover {
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
  }
`,Uz=Ie(Dz)`
  background: transparent;
  color: #667eea;
  border: 2px solid #667eea;
  
  &:hover {
    background: #667eea;
    color: white;
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
  }
`,Bz=Ie.div`
  font-size: 4rem;
  margin-bottom: 1rem;
  opacity: 0.7;
`,Gz=()=>{const e=qr();return(0,gt.jsx)(Pz,{children:(0,gt.jsxs)($z,{children:[(0,gt.jsx)(Bz,{children:"\ud83c\udfc8"}),(0,gt.jsx)(Iz,{children:"404"}),(0,gt.jsx)(Oz,{children:"Pagina non trovata"}),(0,gt.jsx)(Lz,{children:"Ops! La pagina che stai cercando non esiste o \xe8 stata spostata. Potrebbe essere un errore di digitazione nell'URL o la pagina \xe8 stata rimossa."}),(0,gt.jsxs)(Mz,{children:[(0,gt.jsx)(Fz,{onClick:()=>{e("/")},children:"Torna alla Home"}),(0,gt.jsx)(Uz,{onClick:()=>{e(-1)},children:"Torna indietro"})]}),(0,gt.jsx)("div",{style:{marginTop:"2rem",fontSize:"0.9rem",color:"#a0aec0"},children:"Se pensi che questo sia un errore, contatta il supporto tecnico."})]})})},Wz=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
`,Hz=Ie.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  max-width: 500px;
  width: 90%;
  text-align: center;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
`,Vz=Ie.div`
  font-size: 3rem;
  margin-bottom: 1rem;
  opacity: 0.7;
`,Qz=Ie.h2`
  color: #e53e3e;
  margin: 1rem 0;
  font-size: 1.5rem;
`,Kz=Ie.p`
  color: #4a5568;
  margin: 1rem 0;
  line-height: 1.6;
`,Yz=Ie.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin: 0.5rem;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
  }
`,Jz=Ie.button`
  background: transparent;
  color: #718096;
  border: 2px solid #718096;
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin: 0.5rem;
  
  &:hover {
    background: #718096;
    color: white;
  }
`,Zz=Ie.form`
  margin-top: 1.5rem;
  text-align: left;
`,Xz=Ie.div`
  margin-bottom: 1rem;
`,eE=Ie.label`
  display: block;
  margin-bottom: 0.5rem;
  color: #4a5568;
  font-weight: 600;
  font-size: 0.9rem;
`,rE=Ie.input`
  width: 100%;
  padding: 0.75rem;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`,tE=Ie.button`
  background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin: 0.5rem;
  width: 100%;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(72, 187, 120, 0.4);
  }
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }
`,iE=Ie.p`
  color: #e53e3e;
  font-size: 0.9rem;
  margin-top: 0.5rem;
`,nE=e=>{let{children:t}=e;const[i,n]=(0,r.useState)(null),[o,a]=(0,r.useState)(navigator.onLine),[s,l]=(0,r.useState)({email:"",password:""}),[d,c]=(0,r.useState)(""),[u,g]=(0,r.useState)(!1);(0,r.useEffect)(()=>{const e=()=>{a(!0),n(null)},r=()=>{a(!1),n({type:"connection",message:"Connessione internet persa. Verifica la tua connessione e riprova.",title:"Errore di Connessione"})},t=e=>{if(e.detail&&e.detail.error){const r=e.detail.error;r.message&&r.message.includes("Failed to fetch")?n({type:"fetch",message:"Impossibile raggiungere il server. Verifica la tua connessione o riprova pi\xf9 tardi.",title:"Errore di Connessione"}):502===r.status?n({type:"server",message:"Il server \xe8 temporaneamente non disponibile. Riprova tra qualche minuto.",title:"Server Non Disponibile"}):404===r.status?n({type:"notfound",message:"La risorsa richiesta non \xe8 stata trovata.",title:"Risorsa Non Trovata"}):403===r.status?n({type:"forbidden",message:"Non hai i permessi per accedere a questa risorsa.",title:"Accesso Negato"}):401===r.status&&n({type:"unauthorized",message:"Sessione scaduta. Effettua di nuovo il login.",title:"Sessione Scaduta"})}};return window.addEventListener("online",e),window.addEventListener("offline",r),window.addEventListener("fetch-error",t),()=>{window.removeEventListener("online",e),window.removeEventListener("offline",r),window.removeEventListener("fetch-error",t)}},[]);const p=e=>{l({...s,[e.target.name]:e.target.value})};return i?(0,gt.jsxs)(gt.Fragment,{children:[t,(0,gt.jsx)(Wz,{children:(0,gt.jsxs)(Hz,{children:[(0,gt.jsxs)(Vz,{children:["connection"===i.type&&"\ud83c\udf10","server"===i.type&&"\ud83d\udd27","notfound"===i.type&&"\ud83d\udd0d","forbidden"===i.type&&"\ud83d\udeab","unauthorized"===i.type&&"\ud83d\udd10","fetch"===i.type&&"\ud83d\udce1"]}),(0,gt.jsx)(Qz,{children:i.title}),(0,gt.jsx)(Kz,{children:i.message}),"unauthorized"===i.type?(0,gt.jsxs)(Zz,{onSubmit:async e=>{e.preventDefault(),g(!0),c("");try{const e=await fetch("http://localhost:3001/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(s)}),r=e.data;e.ok?(localStorage.setItem("token",r.token),localStorage.setItem("user",JSON.stringify(r.user)),n(null),window.location.reload()):c(r.message||"Errore durante il login")}catch(r){c("Errore di connessione. Riprova.")}finally{g(!1)}},children:[(0,gt.jsxs)(Xz,{children:[(0,gt.jsx)(eE,{htmlFor:"email",children:"Email"}),(0,gt.jsx)(rE,{type:"email",id:"email",name:"email",value:s.email,onChange:p,placeholder:"Inserisci la tua email",required:!0})]}),(0,gt.jsxs)(Xz,{children:[(0,gt.jsx)(eE,{htmlFor:"password",children:"Password"}),(0,gt.jsx)(rE,{type:"password",id:"password",name:"password",value:(null===s||void 0===s?void 0:s.password)||"",onChange:p,placeholder:"Inserisci la tua password",required:!0})]}),d&&(0,gt.jsx)(iE,{children:d}),(0,gt.jsx)(tE,{type:"submit",disabled:u,children:u?"Accesso in corso...":"Accedi"})]}):(0,gt.jsxs)("div",{children:[(0,gt.jsx)(Yz,{onClick:()=>{n(null),window.location.reload()},children:"Riprova"}),(0,gt.jsx)(Jz,{onClick:()=>{n(null)},children:"Chiudi"})]})]})})]}):t},oE=Ie.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 99999;
  backdrop-filter: blur(5px);
`,aE=Ie.div`
  background: white;
  border-radius: 12px;
  padding: 2rem;
  max-width: 400px;
  width: 90%;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
  border: 2px solid #007bff;
  position: relative;
  z-index: 100000;
`,sE=Ie.h2`
  margin: 0 0 1rem 0;
  color: #dc3545;
  text-align: center;
  font-size: 1.5rem;
  font-weight: bold;
`,lE=Ie.p`
  color: #666;
  text-align: center;
  margin-bottom: 1.5rem;
  font-size: 1.1rem;
  line-height: 1.4;
`,dE=Ie.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`,cE=Ie.input`
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 0 2px rgba(0, 123, 255, 0.25);
  }
`,uE=Ie.button`
  background: #007bff;
  color: white;
  border: none;
  padding: 0.75rem;
  border-radius: 6px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
  
  &:hover {
    background: #0056b3;
  }
  
  &:disabled {
    background: #ccc;
    cursor: not-allowed;
  }
`,gE=Ie.div`
  color: #dc3545;
  background: #f8d7da;
  border: 1px solid #f5c6cb;
  border-radius: 6px;
  padding: 0.75rem;
  font-size: 0.9rem;
  text-align: center;
`,pE=e=>{let{children:t}=e;const[i,n]=(0,r.useState)(!1),[o,a]=(0,r.useState)({email:"",password:""}),[s,l]=(0,r.useState)(!1),[d,c]=(0,r.useState)(""),{loginUser:u}=Si();(0,r.useEffect)(()=>{const e=e=>{console.log("Token expired event received:",e.detail),console.log("Setting showLoginModal to true"),n(!0),c("")};return window.addEventListener("token-expired",e),()=>{window.removeEventListener("token-expired",e)}},[]),(0,r.useEffect)(()=>{console.log("TokenExpiredHandler - showLoginModal state:",i)},[i]);const g=e=>{a({...o,[e.target.name]:e.target.value})};return(0,gt.jsxs)(gt.Fragment,{children:[t,i&&(0,gt.jsxs)(gt.Fragment,{children:[console.log("Rendering login modal"),(0,gt.jsx)(oE,{children:(0,gt.jsxs)(aE,{children:[(0,gt.jsx)(sE,{children:"\u26a0\ufe0f Sessione Scaduta"}),(0,gt.jsx)(lE,{children:"La tua sessione \xe8 scaduta. Effettua di nuovo il login per continuare."}),(0,gt.jsxs)(dE,{onSubmit:async e=>{e.preventDefault(),l(!0),c("");try{const e=await oi({email:o.email,password:(null===o||void 0===o?void 0:o.password)||""});u(e.user,e.token),n(!1),a({email:"",password:""}),window.location.reload()}catch(r){c(r.message||"Errore durante il login")}finally{l(!1)}},children:[(0,gt.jsx)(cE,{type:"email",name:"email",placeholder:"Email",value:o.email,onChange:g,required:!0,style:{borderColor:"#007bff"}}),(0,gt.jsx)(cE,{type:"password",name:"password",placeholder:"Password",value:(null===o||void 0===o?void 0:o.password)||"",onChange:g,required:!0,style:{borderColor:"#007bff"}}),d&&(0,gt.jsx)(gE,{children:d}),(0,gt.jsx)(uE,{type:"submit",disabled:s,children:s?"Accesso in corso...":"Accedi"}),(0,gt.jsx)(uE,{type:"button",onClick:()=>{n(!1),a({email:"",password:""}),c(""),window.location.href="/login"},style:{background:"#6c757d",marginTop:"0.5rem"},children:"Vai alla pagina di login"})]})]})})]})]})},hE=()=>{const{user:e,loading:t}=Si(),i=qr(),n=Nr();return(0,r.useEffect)(()=>{if(!t&&!e&&"/login"!==n.pathname&&"/register"!==n.pathname){const e=n.pathname.replace("?/","/")+n.search;sessionStorage.setItem("redirectAfterLogin",e)}},[e,t,n.pathname,n.search]),(0,r.useEffect)(()=>{if(e&&!t){const e=sessionStorage.getItem("redirectAfterLogin");e&&e!==n.pathname+n.search&&(sessionStorage.removeItem("redirectAfterLogin"),i(e))}},[e,t,i,n.pathname,n.search]),null};function mE(){const e=Nr();return(0,r.useEffect)(()=>{if(console.log("\ud83d\udd0d App: Current location:",e.pathname),console.log("\ud83d\udd0d App: Preventing unwanted redirects"),e.pathname.includes("?/")){const r=e.pathname.replace("?/","/");window.history.replaceState(null,"",r)}},[e]),(0,gt.jsxs)(gt.Fragment,{children:[(0,gt.jsx)(dn,{}),(0,gt.jsxs)(Zr,{children:[(0,gt.jsx)(Yr,{path:"/",element:(0,gt.jsx)(zo,{})}),(0,gt.jsx)(Yr,{path:"/leghe",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(gs,{})})}),(0,gt.jsx)(Yr,{path:"/area-admin",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Qm,{})})}),(0,gt.jsx)(Yr,{path:"/area-admin/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Qm,{})})}),(0,gt.jsx)(Yr,{path:"/admin/richieste-unione-squadra/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)($w,{})})}),(0,gt.jsx)(Yr,{path:"/area-manager",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(bf,{})})}),(0,gt.jsx)(Yr,{path:"/proponi-offerta",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(pv,{})})}),(0,gt.jsx)(Yr,{path:"/unisciti-lega",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Ys,{})})}),(0,gt.jsx)(Yr,{path:"/lega/:id",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(au,{})})}),(0,gt.jsx)(Yr,{path:"/squadra/:id",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Lu,{})})}),(0,gt.jsx)(Yr,{path:"/modifica-squadra/:id",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Mu,{})})}),(0,gt.jsx)(Yr,{path:"/giocatore/:id",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Uh,{})})}),(0,gt.jsx)(Yr,{path:"/crea-lega",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(zs,{})})}),(0,gt.jsx)(Yr,{path:"/tornei/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Yv,{})})}),(0,gt.jsx)(Yr,{path:"/gestione-tornei/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Kb,{})})}),(0,gt.jsx)(Yr,{path:"/torneo/:torneoId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Ij,{})})}),(0,gt.jsx)(Yr,{path:"/paga-contratti",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(sy,{})})}),(0,gt.jsx)(Yr,{path:"/notifiche",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Qy,{})})}),(0,gt.jsx)(Yr,{path:"/scraping",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(yv,{})})}),(0,gt.jsx)(Yr,{path:"/scraping-manager/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(yv,{})})}),(0,gt.jsx)(Yr,{path:"/login",element:(0,gt.jsx)(_n,{})}),(0,gt.jsx)(Yr,{path:"/register",element:(0,gt.jsx)(Bn,{})}),(0,gt.jsx)(Yr,{path:"/super-admin-access",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Rf,{})})}),(0,gt.jsx)(Yr,{path:"/super-admin-dashboard",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(lx,{})})}),(0,gt.jsx)(Yr,{path:"/dashboard-avanzata",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Rx,{})})}),(0,gt.jsx)(Yr,{path:"/super-admin/lega/:id/edit",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(sg,{})})}),(0,gt.jsx)(Yr,{path:"/gestione-squadre-lega/:id",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Tg,{})})}),(0,gt.jsx)(Yr,{path:"/modifica-squadra-completa/:id",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(xp,{})})}),(0,gt.jsx)(Yr,{path:"/modifica-giocatore-completa/:id",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Up,{})})}),(0,gt.jsx)(Yr,{path:"/crea-giocatore",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(dh,{})})}),(0,gt.jsx)(Yr,{path:"/gestione-credenziali/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)($v,{})})}),(0,gt.jsx)(Yr,{path:"/league-admin/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(ck,{})})}),(0,gt.jsx)(Yr,{path:"/league-subadmin/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(t_,{})})}),(0,gt.jsx)(Yr,{path:"/subadmin-area",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(Ik,{})})}),(0,gt.jsx)(Yr,{path:"/subadmin-requests",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(OS,{})})}),(0,gt.jsx)(Yr,{path:"/request-squadre-modification/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(q_,{})})}),(0,gt.jsx)(Yr,{path:"/request-giocatori-modification/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(yS,{})})}),(0,gt.jsx)(Yr,{path:"/gestione-squadra/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(_C,{})})}),(0,gt.jsx)(Yr,{path:"/richiesta-admin",element:(0,gt.jsx)(HC,{})}),(0,gt.jsx)(Yr,{path:"/gestione-richieste-admin/:legaId",element:(0,gt.jsx)(oz,{})}),(0,gt.jsx)(Yr,{path:"/gestione-roster-admin/:legaId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(qz,{})})}),(0,gt.jsx)(Yr,{path:"/modifica-lega/:id",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(sg,{})})}),(0,gt.jsx)(Yr,{path:"/log-squadra/:squadraId",element:(0,gt.jsx)(cn,{children:(0,gt.jsx)(xw,{})})}),(0,gt.jsx)(Yr,{path:"*",element:(0,gt.jsx)(Gz,{})})]})]})}console.log("\ud83d\ude80 TopLeague Frontend v1.0.5 - Build:",(new Date).toISOString());const fE=function(){return(0,gt.jsx)(nE,{children:(0,gt.jsx)(_i,{children:(0,gt.jsx)($i,{children:(0,gt.jsxs)(pE,{children:[(0,gt.jsx)(hE,{}),(0,gt.jsx)(mE,{}),(0,gt.jsx)(pi,{})]})})})})};n.createRoot(document.getElementById("root")).render((0,gt.jsx)(r.StrictMode,{children:(0,gt.jsx)(Ne,{theme:{colors:{primary:"#FFA94D",background:"#ffffff",text:"#333333"},borderRadius:"16px",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif'},children:(0,gt.jsx)(pt,{children:(0,gt.jsx)(fE,{})})})}))})()})();
//# sourceMappingURL=main.7237bf16.js.map