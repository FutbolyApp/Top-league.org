// Mock Database per sviluppo locale
import bcrypt from 'bcryptjs';

// Dati mock
const mockUsers = [
  {
    id: 1,
    email: 'admin@top-league.org',
    password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // 'Borini'
    nome: 'Admin',
    cognome: 'Super',
    ruolo: 'super_admin',
    created_at: new Date(),
    updated_at: new Date()
  },
  {
    id: 2,
    email: 'user@topleague.com',
    password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // 'password'
    nome: 'User',
    cognome: 'Test',
    ruolo: 'user',
    created_at: new Date(),
    updated_at: new Date()
  }
];

const mockLeghe = [
  {
    id: 1,
    nome: 'Serie A Fantasy',
    descrizione: 'Lega Serie A',
    admin_id: 1,
    created_at: new Date(),
    updated_at: new Date()
  }
];

const mockSquadre = [
  {
    id: 1,
    nome: 'Milan Fantasy',
    lega_id: 1,
    utente_id: 2,
    created_at: new Date(),
    updated_at: new Date()
  }
];

// Simula database
let users = [...mockUsers];
let leghe = [...mockLeghe];
let squadre = [...mockSquadre];

export function getDb() {
  return {
    query: async (sql, params = []) => {
      console.log('🔍 Mock DB Query:', sql, params);
      
      // Simula query SQL
      if (sql.includes('SELECT * FROM users WHERE email = ?')) {
        const email = params[0];
        const user = users.find(u => u.email === email);
        return { rows: user ? [user] : [] };
      }
      
      if (sql.includes('SELECT * FROM users WHERE id = ?')) {
        const id = params[0];
        const user = users.find(u => u.id === id);
        return { rows: user ? [user] : [] };
      }
      
      if (sql.includes('INSERT INTO users')) {
        const newUser = {
          id: users.length + 1,
          email: params[0],
          password: params[1],
          nome: params[2],
          cognome: params[3],
          ruolo: params[4] || 'user',
          created_at: new Date(),
          updated_at: new Date()
        };
        users.push(newUser);
        return { insertId: newUser.id };
      }
      
      if (sql.includes('SELECT * FROM leghe')) {
        return { rows: leghe };
      }
      
      if (sql.includes('SELECT * FROM squadre')) {
        return { rows: squadre };
      }
      
      // Default response
      return { rows: [] };
    },
    
    execute: async (sql, params = []) => {
      return this.query(sql, params);
    }
  };
}

export async function initializeDatabase() {
  console.log('✅ Mock database initialized');
  return true;
}

// Funzioni helper
export async function getUtenteByEmail(email) {
  const user = users.find(u => u.email === email);
  return user;
}

export async function createUser(userData) {
  const hashedPassword = await bcrypt.hash(userData.password, 10);
  const newUser = {
    id: users.length + 1,
    email: userData.email,
    password: hashedPassword,
    nome: userData.nome,
    cognome: userData.cognome,
    ruolo: userData.ruolo || 'user',
    created_at: new Date(),
    updated_at: new Date()
  };
  users.push(newUser);
  return newUser;
}

export async function verifyPassword(password, hashedPassword) {
  return await bcrypt.compare(password, hashedPassword);
} 